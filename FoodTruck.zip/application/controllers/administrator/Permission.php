<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Permission extends MY_Controller
{
	
	public function __construct()
	{
		parent::__construct();

		/*if($this->is_logged_in_admin()):
	    	redirect('admin/role/add');
	    endif; */
	   $this -> load -> model('admin/Permission_m');
	   $this -> load -> model('admin/Role_m');
	}

	private function _loadView($data) {
		$this->load->view('admin/layouts/index', $data);
	}

	public function index() {
		$this -> data['title'] = 'Permission';
	    $this -> data['content'] = 'admin/permission/role';
	    $this -> data['all_menu'] = array();
	    $this -> data['role'] = $this -> Role_m -> get();
	    $this->_loadView($this -> data);

				
	}

	function listMenuAjax(){
		$role = $this -> input ->post('role');
		
		$this -> data['all_menu'] = $this -> Permission_m -> get();
	
		$menu_assigned = $this -> Permission_m -> get_assigned_menu($role);
	   
	   $h = $this -> load -> view('admin/permission/list',$this -> data, TRUE);
	   
	   echo json_encode(array('menu_vw' => $h, 'menu_assigned' => $menu_assigned));
	}

	function updateAssignedMenu(){
		$role_id = $this -> input -> post('role_id');
		$menu_id = $this -> input -> post('arr');

		$arr = array();

		foreach ($menu_id as $k => $v){
				$arr[] = array('role_id' => $role_id, 'menu_id' => $v);
		}

		    $this->db->trans_begin();

		 	$this -> db -> where('role_id', $role_id);
		 	$this -> db -> delete('role_menu');
		 	$this -> db -> insert_batch('role_menu',$arr);

		 	$this->db->trans_complete();


		 	if ($this->db->trans_status() === FALSE) {
           
           		 $this->db->trans_rollback();			  
           		 $status = "0";
        	} 
        	else {
           		$this->db->trans_commit();
           		$status = "1";
         	 }

			echo $status;
	}


}
		
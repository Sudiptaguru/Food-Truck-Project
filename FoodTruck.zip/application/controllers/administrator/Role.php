<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Role extends MY_Controller
{
	
	public function __construct()
	{
		parent::__construct();

		/*if($this->is_logged_in_admin()):
	    	redirect('admin/role/add');
	    endif; */
	    $this -> load -> model('admin/Role_m');
	}

	private function _loadView($data)
	{
		$this->load->view('admin/layouts/index', $data);
	}

	public function index(){
		$this -> data['content']='admin/role/list';
	    $this -> data['title']='List Role';
	    $this -> data['roles'] = $this -> Role_m -> get();
	    //echo '<pre>';print_r($this -> data['roles']);die;
	    $this->_loadView($this -> data);
				
	}

	public function add(){
		$this->form_validation->set_rules(
        'role', 'Role',
        'required|trim|min_length[5]|max_length[20]|is_unique[role.name]',
        array(
                'required'      => 'You have not provided %s.',
                'is_unique'     => 'This %s already exists.'
        )
		);


		if ($this -> form_validation -> run() === TRUE){
				$postData = $this -> input ->post();
				$d = array(
							'name' => $postData['role'],
							'date_of_creation' => date('Y-m-d H:i:s'),
							'date_of_update' => date('Y-m-d H:i:s')

					);

				$this -> db ->insert('role',$d);
				if ($this -> db -> insert_id()){
					$this -> session ->set_flashdata('success','Added successfully!');
				}
				else {
					$this -> session ->set_flashdata('error','Problem saving role! Try again.');
				}
				redirect('administrator/Role/add');

		}
      
	    $this -> data['content']='admin/role/add';
	    $this -> data['title']='Add Role';
	    $this->_loadView($this -> data);	 	
		
	}

	public function edit($id){

		if(!$id){
			show_404();
		}
		
	    $this -> data['content']='admin/role/edit';
	    $this -> data['title']='Edit Role';
	    $this -> data['role'] = $this -> Role_m -> get($id);
	  //  echo '<pre>';print_r($this -> data);die;
	    $this->_loadView($this -> data);	 	
		
	}

	function update($id){
			$this->form_validation->set_rules(
        'role', 'Role',
        'required|trim|min_length[5]|max_length[12]|is_unique[role.name]',
	        array(
	                'required'      => 'You have not provided %s.',
	                'is_unique'     => 'This %s already exists.'
	        )
		);


		if ($this -> form_validation -> run() === TRUE){
				$postData = $this -> input ->post();
				$d = array(
							'name' => $postData['role'],
							'date_of_update' => date('Y-m-d H:i:s')

					);

				$status = $this -> db ->update('role', $d, array('group_id' => $postData['role_id']));

				if ($status){
					$this -> session ->set_flashdata('success','Updated successfully!');
				}
				else {
					$this -> session ->set_flashdata('error','Problem updating role! Try again.');
				}

		}
		else {

				$this -> session ->set_flashdata('fail',validation_errors());			
					
				
		}

  	 redirect('administrator/role/edit/'.$id);	

	 
	}


	public function destroy($id){
		if (!$id){
		  show_404();
		}

		$this -> db -> delete('role', ['group_id' => $id]);
		$this -> session ->set_flashdata('success', 'Role deleted...');	
		redirect('administrator/Role');	

	}
	}
		
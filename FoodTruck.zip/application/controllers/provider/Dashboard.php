<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends Public_Controller
{
	
	public function __construct()
	{
		parent::__construct();

	}

	
	public function index(){
        
		$this -> data['main']='index';
	    $this -> data['title']='Dashboard';
	    $this -> load -> view('_layout', $this -> data);
				
	}

    function account(){
		
	}

}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends Public_Controller
{
	
	public function __construct()
	{
		parent::__construct();

	}
	
	public function index(){
		// echo "success login";die;
        
		$this -> data['main']='user/account';
	    // $this -> data['title']='Home';
	    $this -> load -> view('_layout', $this -> data);
				
	}

	// function updateUser(){
 //        $this->load->model('Account_m');
        
 //            $setArray = [
 //                'first_name' => $postData['first_name'],
	// 			'mobile' => $postData['mobile']
                 
 //            ];
 //            $userId = $this->input->post('userId');
 //            $status = $this->Account_m->update_User($setArray,$userId);
            
 //            if($status == true){
 //                $data['message'] = "<font color='green'>
 //                Successfully Updated </font>";
 //            }else{
 //                $data['message'] = "<font color='red'> Not upadted,Please Try Again </font>";
 //            }
 //            $data['userinfo'] = $this->Account_m->getAllUsers();
 //            $this->load->view('Home',$data);
        
 //    }

    function account(){
		$this -> load -> view('user/_layout', $this -> data);
	}

}
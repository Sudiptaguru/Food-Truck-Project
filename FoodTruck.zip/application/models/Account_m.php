<?php
class Account_m extends CI_Model{
	function update_User($setArray, $userId){
        $this->db->set($setArray);
        $this->db->where('user_id',$userId);
        if($this->db->update('user')){
            return true;
        }else{
            return false;
        }
    }
}
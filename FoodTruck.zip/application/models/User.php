<?php defined('BASEPATH') OR exit('No direct script access allowed'); 
 
class User extends CI_Model{ 
    function __construct() { 
        // Set table name 
        $this->table = 'user'; 
    }      
   
    /* 
     * Insert user data into the database 
     * @param $data data to be inserted 
     */ 
    public function insert($data = array()) { 
        if(!empty($data)){ 
            // Add created and modified date if not included 
            if(!array_key_exists("created_on", $data)){ 
                $data['created_on'] = date("Y-m-d H:i:s"); 
            } 

            if(!array_key_exists("updated_on", $data)){ 
                $data['updated_on'] = date("Y-m-d H:i:s"); 
            } 

            // if(!array_key_exists("modified", $data)){ 
            //     $data['modified'] = date("Y-m-d H:i:s"); 
            // } 
             
            // Insert member data 
            $insert = $this->db->insert($this->table, $data); 
             
            // Return the status 
            return $insert?$this->db->insert_id():false; 
        } 
        return false; 
    } 
    // public function get_data($id=0)
    // {
    //     if($id==0)
    //     {
    //         $query = $this->db->get('user')->result();
    //         return $query;
    //     }
    //     else
    //     {
    //         $this->db->where('id',$id);
    //         $query = $this->db->get('user')->result();
    //         return $query;
    //     }
        
    // }


    // public function upddata($data,$id)       
    // {
    //     extract($data); 
    //     $this->db->where('id', $id);
    //     $this->db->update('user', $data);
    //     return true;
    // }

    // public function delete_data($id)
    // {
    //     $this -> db -> where('id', $id);
    //     $this -> db -> delete('users');
    // }

    // public function update_status($status,$id)
    // {
    //     $this->db->query("UPDATE users SET status = '$status' WHERE id = '$id' ");
    //     return true;
    // }

    // function getAllUsers(){
    //     $query=$this->db->query("select * from user");
    //     return $query->result();
    // }
    // public function login( $data ) {

    //     $condition = "email= '".$data['email']."' AND password= '".$data['password']."' AND status='1'  ";
    //     $this->db->select( '*' );
    //     $this->db->from( 'user' );
    //     $this->db->where( $condition );
    //     $query = $this->db->get();
    //     if ( $query->num_rows() == 1 ) {
    //         return $query->result();
    //     } else {
    //         return false;
    //     }

    // }
    function login_check($data)
    {
        $condition = "email= '".$data['email']."' AND password= '".$data['password']."' ";
        $this->db->select( '*' );
        $this->db->from( 'user' );
        $this->db->where( $condition );
        $query = $this->db->get();
        if ( $query->num_rows() == 1 ) {
            return $query->result();
        } else {
            return false;
        }
    }
    // function get_user($user_id)
    // {
    //     $condition = "id= '".$user_id."' ";
    //     $this->db->select( '*' );
    //     $this->db->from( 'user' );
    //     $this->db->where( $condition );
    //     $query = $this->db->get()->result();
    //     return $query;
    // }
}
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="icon" href="<?=base_url()?>fassets/img/fav-icon.png">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://use.fontawesome.com/releases/v5.0.4/css/all.css" rel="stylesheet">
<!-- Bootstrap core CSS -->
<link rel="stylesheet" type="text/css" href="<?=base_url()?>fassets/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?=base_url()?>fassets/css/bootstrap-theme.min.css">
<link rel="stylesheet" type="text/css" href="<?=base_url()?>fassets/css/theme.css">
<link rel="stylesheet" type="text/css" href="<?=base_url()?>fassets/css/responsive.css">
<title><?= $title ?> | <?= $this -> sitename ?></title>
</head>
<body>

<div class="landing-page">
	<div class="container-fluid">
		<ul class="top-list">
		<?php
		if ($this -> session -> userdata('is_logged'))  {?>
			<li><a href="<?=base_url('Home/logout')?>">Sign Out</a></li>
			<?php } else { ?>
				<li><a href="<?=base_url('login')?>">Sign In</a></li>
			<?php } ?>
			<li><a href="<?=base_url('register')?>?utype=user">Register</a></li>
		</ul>

		<?php $this -> load -> view($main) ?>

		<ul class="landing-footer">
			<li><a href="#">Advertising Programs</a></li>
			<li><a href="#">Privacy & Terms</a></li>
			<li><a href="#">About WITFT</a></li>
		</ul>
	</div>
</div>

 


<!-- Bootstrap core JavaScript --> 
<!--<script src="https://code.jquery.com/jquery-3.4.1.js"></script>--> 
<script src="<?=base_url()?>fassets/js/jquery.1.11.3.min.js"></script> 
<script src="<?=base_url()?>fassets/js/bootstrap.min.js"></script> 	
<script src="<?=base_url()?>fassets/js/theme.js"></script> 
</body>
</html>


              <?php
              if (!empty($all_menu)) {
              foreach ($all_menu as $m) {?>
              <div class="main">
                 <div class="form-check main1">
                    <input id="<?=$m['menu_id']?>" class="form-check-input menu parent" value="<?=$m['menu_id']?>" type="checkbox" />
                    <label class="form-check-label">
                       <strong> <?=$m['menu_name']?></strong> 
                    </label>
                </div>
                   <?php 
                   //echo '<pre>'; print_r($m);
                   if (count($m['submenu'])) {
                      foreach ($m['submenu'] as $s) {
                   
                    ?>

                 <div class="form-check form-check-inline submain">
                  <input  id="<?=$m['menu_id']?>" class="form-check-input menu submenu child" type="checkbox" value="<?=$s['menu_id']?>">
                    <label class="form-check-label" for="defaultCheck1">
                      <?=$s['menu_name']?>
                    </label>
                 </div>
                 <?php
               }
             }
             ?>
              
             
              </div>
               <?php
               }
             
              
             }
           
              ?>
              <!-- /.card-body -->
              <br />
         <button type="button" class="btn btn-primary" id="btn-save"><i class="fas fa-save"></i> Save</button>

  <script>
  $(function(){

    $("#btn-save").on("click", function(e){
        e.preventDefault();
      
        var ar = [];
        var role_id = $("#role").val();

        $(".menu").each(function(){
            if ($(this).prop("checked")){
                ar.push(this.value);

            }
        });
        
        if (!ar.length){
            alert("Not selected anything...");
            return false;
        }
        
          $.ajax({
                  url:"<?=base_url('administrator/Permission/updateAssignedMenu')?>",
                  type:'post',
                  data:{role_id:role_id,arr:ar},
                  beforeSend:function(){
                    $("#btn-save").prop("disabled",true);
                  }
          }).done(function(response){
            
            $("#btn-save").prop("disabled",false);
                      alert("Updated successfully...");            

          }).catch(function(error){
              console.log(error);
          });
    });
  });
  </script>

  <script>
  $(function(){
        $(".parent").click(function(){
          var cur = $(this);
          var  childObj = cur.closest(".main").find(".child");
          if ($(this).is(':checked')){
                 
          if (childObj.length >0){
            childObj.each(function(){
              $(this).prop("checked",true);
            });
          }

          }
          else {
             childObj.each(function(){
              $(this).prop("checked",false);
            });
          }
        });

        $(".child").click(function(){

          var parentCheckboxObj = $(this).parent().parent().find(".parent");
          if ($(this).is(":checked")){
            parentCheckboxObj.prop("checked",true);
            var allChild = parentCheckboxObj.parent().parent().find(".child");
          }
          else {

          }
        });
  });
  </script>
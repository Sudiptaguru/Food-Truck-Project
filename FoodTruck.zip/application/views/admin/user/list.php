<div class="content-wrapper">
<div class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
         </div>
         <!-- /.col -->
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li><a href="<?=base_url('administrator/User/add')?>"><i class="fa fa-plus"></i> Add User</a></li>
            </ol>
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </div>
   <!-- /.container-fluid -->
</div>
    <!-- Main content -->
  <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
             <?php if($this -> session -> flashdata('success')) {?>
                <div class="alert alert-info" role="alert">
                  <?=$this -> session -> flashdata('success')?>
                </div>

            <?php } ?>

          </div>
        </div>
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
          <div class="card">
              <div class="card-header">
                <h3 class="card-title">User List</h3>

                <div class="card-tools">
                  <div class="input-group input-group-sm" style="width: 150px;">
                    <input type="text" name="table_search" class="form-control float-right" placeholder="Search">

                    <div class="input-group-append">
                      <button type="submit" class="btn btn-default">
                        <i class="fas fa-search"></i>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0">
                <table class="table table-hover text-nowrap">
                  <thead>
                    <tr>
                     
                       <th>Sno.</th>
                      <th>First name</th>
                      <th>Last name</th>
                      <th>Email</th>
                      <th>Role</th>
                      <th>Created</th>                
                      <th>Action</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php
                  if (count($user)){
                    foreach ($user as  $k => $u) {?>
                    <tr>
                       <td><?=$k+1?></td>
                      <td><?=$u['first_name']?></td>
                      <td><?=$u['last_name']?></td>
                      <td><?=$u['email']?></td>
                   
                      <td><?=$u['name']?></td>
                      <td><?=date('d-m-Y', strtotime($u['created_on']))?></td>
                      <td> 
                      <a  href="<?=base_url('administrator/User/edit/'.$u['user_id'])?>"><i class="fa fa-edit"></i></a> | 
                      <a onclick ="return confirm('Do you want to delete?');" href="<?=base_url('administrator/User/destroy/'.$u['user_id'])?>"><i class="fa fa-trash"></i></a> </td>
                     <td>
                  <select class="form-control" name="status" id="status_<?=$u['user_id']?>" onchange="changeStatus(this.id, this.value);">
                  <option value="">--select--</option>
                  <option value="0" <?php if ($u['status'] == USER_INACTIVE) echo ' selected';?>>Inactive</option>
                  <option value="1" <?php if ($u['status'] == USER_ACTIVE) echo ' selected';?>>Active</option>
                  
                  </select>
                     </td>
                    </tr>
                   <?php 
                 }
                 }
                   ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>

          </div>


       
 
          
              </div>
           
      </div>
    </section>
  </div>
  <script>
 
   function changeStatus(id, val) {


    if (!confirm("Do you want to change status?")){
      return false;
    }
         
      if (val ==  ""){
        alert("Please select...");
        return false;

      }

       var status = val;
       var uid = id.split('_')[1];

      $.ajax({
          url:"<?=base_url('administrator/User/changeUserStatusAjax')?>",
          type:"post",
          data:{uid:uid, status:status}
      }).done(function(response){
        if (response == "1"){
          let txtStatus = status == "1"  ? "Activated..." : "Deactivated...";
          alert("User "+txtStatus);
        }
        else {
          alert("Problem changing the status. Try again.")
        }

      }).catch(function(error){
          console.log(error);
      });
}
 
  </script
<div class="img-sec">
			<h1 class="landing-title">WHERE is that FOOD TRUCK?</h1>
			<img src="<?=base_url()?>fassets/img/car.png">
			<div class="form-l">
				
				<form>
						<div class="row">
							<div class="col-md-12">
								<input type="text" class="form-control" placeholder="Name of Food Truck...">
							</div>
							<div class="col-md-6">
								<input type="text" class="form-control" placeholder="City">
							</div>
							<div class="col-md-6">
								<input type="text" class="form-control" placeholder="State">
							</div>
							<div class="text-center col-md-12">
								<button type="submit">FIND THE TRUCK!</button>
							</div>
						</div>
				</form>
			</div>
</div>
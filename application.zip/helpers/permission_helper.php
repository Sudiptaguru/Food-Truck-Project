<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Permission {
	
   private $data = array();

   function __constructor($id){
   		$CI = & get_instance();
   		$this -> data

   }

}
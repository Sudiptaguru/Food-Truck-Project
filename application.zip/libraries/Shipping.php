<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Shipping extends CI_Controller {	
    var $arr;
    var $obj;
	var $logo='';
	var $account_no='113106199';
	var $api_key='575EFDD029F0A8EF71C0179D7A074119223E69B32545A65549DD478B38E29D3A';
    var $header=array();
	function __construct(){
		parent::__construct();
		$this->arr=array();
		$this->obj=new stdClass();
		$base_key="$this->account_no:$this->api_key";
		$this->header=array(
					'Host: api-test.couriersplease.com.au',
					'Accept: application/json',
					'Content-Type: application/json'
				);
		$this->logo=base_url().'/public/admin_assets/images/logo.jpg';
		$this->load->model('mproduct');
  	}
    private function displayOutput($response){
        header('Content-Type: application/json');
        echo json_encode($response);
        exit(0);
    }	
    private function cartList(){
		$cart_data=array();
		$ship=array();
		$final_ship_data=array();
		$cart_data=$this->cart->contents();
		$row=array();
		$total=0;
		if(count($cart_data)>0){
			foreach($cart_data as $cd){
				if($cd['id']!=0 && $cd['attribute_group_id']!=0){
					$row=$this->mproduct->productDetailsList($cd['id'],$cd['attribute_group_id']);
				}else{
					$row=$this->mproduct->productDetailsList($cd['id']);
				}
				$ship['quantity']=$cd['qty'];
				$ship['length']=$row['ship_length'];
				$ship['width']=$row['ship_height'];
				$ship['height']=$row['ship_width'];
				$ship['physicalWeight']=$row['ship_physical_weight'];
				$final_ship_data[]=$ship;
			}
		}
		return $final_ship_data;
	}
	public function get_quotes(){ 
		$response=array();
		$request=array();
		$url='https://api-test.couriersplease.com.au/v1/domestic/quote';
		if($this->input->post()){
			$cart_items=$this->cartList();
			$request['fromSuburb']=$this->input->post('fromSuburb');
			$request['fromPostcode']=$this->input->post('fromPostcode');
			$request['toSuburb']=$this->input->post('toSuburb');
			$request['toPostcode']=$this->input->post('toPostcode');
			$request['items']=$cart_items;
			$result=$this->final_curl($url,$request);
			if($result['error_code']=='0'){
				$response['error_code']='0';
				$response['data']=$result['result'];
				$response['message']=$result['message'];
			}else{
				$response['error_code']='1';
				$response['data']=$result['result'];
				$response['message']=$result['message'];
			}
		}else{
			$response['error_code']='1';
			$response['data']=$this->obj;
			$response['message']='Input fields are required';
		}
		$this->displayOutput($response);
	}
	public function final_curl($url,$request){ 
		$response=array();                  
		$data_string = json_encode($request);                                                                                                                                                                                                        
		$ch = curl_init('https://api-test.couriersplease.com.au/v1/domestic/quote');                                                                      
		curl_setopt($ch, CURLOPT_POST, true);                                                                   
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);  
		curl_setopt($ch, CURLOPT_USERPWD, $this->account_no . ":" . $this->api_key);                                                                
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
		curl_setopt($ch, CURLOPT_HTTPHEADER, array( 
			'Host: api-test.couriersplease.com.au',                                                                         
		    'Content-Type: application/json',                                                                                
		    'Content-Length: ' . strlen($data_string), 
		    'Accept: application/json'
		    )                                                                       
		);                                                                                                                   
        $result = curl_exec($ch);
        curl_close($ch);  
        $data=json_decode($result);
        if($data->responseCode=='SUCCESS'){
        	$response['error_code']='0';
        	$response['result']=$data->data;
        	$response['message']=$data->msg;
        }else{
        	$response['error_code']='1';
        	$response['result']=$data->data;
        	$response['message']=$data->msg;
        }
        return $response;
	}
}

INFO - 2021-03-22 21:10:10 --> Config Class Initialized
INFO - 2021-03-22 21:10:10 --> Hooks Class Initialized
DEBUG - 2021-03-22 21:10:10 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:10:10 --> Utf8 Class Initialized
INFO - 2021-03-22 21:10:10 --> URI Class Initialized
INFO - 2021-03-22 21:10:10 --> Router Class Initialized
INFO - 2021-03-22 21:10:10 --> Output Class Initialized
INFO - 2021-03-22 21:10:10 --> Security Class Initialized
DEBUG - 2021-03-22 21:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:10:10 --> Input Class Initialized
INFO - 2021-03-22 21:10:10 --> Language Class Initialized
INFO - 2021-03-22 21:10:10 --> Loader Class Initialized
INFO - 2021-03-22 21:10:10 --> Helper loaded: url_helper
INFO - 2021-03-22 21:10:10 --> Helper loaded: form_helper
INFO - 2021-03-22 21:10:10 --> Helper loaded: common_helper
INFO - 2021-03-22 21:10:10 --> Helper loaded: util_helper
INFO - 2021-03-22 21:10:10 --> Database Driver Class Initialized
DEBUG - 2021-03-22 21:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-22 21:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-22 21:10:10 --> Form Validation Class Initialized
INFO - 2021-03-22 21:10:10 --> Controller Class Initialized
INFO - 2021-03-22 21:10:10 --> Model Class Initialized
INFO - 2021-03-22 21:10:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-22 21:10:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-22 21:10:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/dashboard.php
INFO - 2021-03-22 21:10:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-22 21:10:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-22 21:10:10 --> Final output sent to browser
DEBUG - 2021-03-22 21:10:10 --> Total execution time: 0.0366
INFO - 2021-03-22 21:10:10 --> Config Class Initialized
INFO - 2021-03-22 21:10:10 --> Hooks Class Initialized
INFO - 2021-03-22 21:10:10 --> Config Class Initialized
INFO - 2021-03-22 21:10:10 --> Hooks Class Initialized
DEBUG - 2021-03-22 21:10:10 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:10:10 --> Utf8 Class Initialized
INFO - 2021-03-22 21:10:10 --> URI Class Initialized
DEBUG - 2021-03-22 21:10:10 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:10:10 --> Utf8 Class Initialized
INFO - 2021-03-22 21:10:10 --> Router Class Initialized
INFO - 2021-03-22 21:10:10 --> URI Class Initialized
INFO - 2021-03-22 21:10:10 --> Output Class Initialized
INFO - 2021-03-22 21:10:10 --> Router Class Initialized
INFO - 2021-03-22 21:10:10 --> Security Class Initialized
INFO - 2021-03-22 21:10:10 --> Output Class Initialized
INFO - 2021-03-22 21:10:10 --> Security Class Initialized
DEBUG - 2021-03-22 21:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:10:10 --> Input Class Initialized
DEBUG - 2021-03-22 21:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:10:10 --> Input Class Initialized
INFO - 2021-03-22 21:10:10 --> Language Class Initialized
INFO - 2021-03-22 21:10:10 --> Language Class Initialized
ERROR - 2021-03-22 21:10:10 --> 404 Page Not Found: Admin/dist
ERROR - 2021-03-22 21:10:10 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-22 21:10:10 --> Config Class Initialized
INFO - 2021-03-22 21:10:10 --> Hooks Class Initialized
DEBUG - 2021-03-22 21:10:10 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:10:10 --> Utf8 Class Initialized
INFO - 2021-03-22 21:10:10 --> URI Class Initialized
INFO - 2021-03-22 21:10:10 --> Config Class Initialized
INFO - 2021-03-22 21:10:10 --> Hooks Class Initialized
INFO - 2021-03-22 21:10:10 --> Router Class Initialized
DEBUG - 2021-03-22 21:10:10 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:10:10 --> Output Class Initialized
INFO - 2021-03-22 21:10:10 --> Utf8 Class Initialized
INFO - 2021-03-22 21:10:10 --> URI Class Initialized
INFO - 2021-03-22 21:10:10 --> Security Class Initialized
DEBUG - 2021-03-22 21:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:10:10 --> Router Class Initialized
INFO - 2021-03-22 21:10:10 --> Input Class Initialized
INFO - 2021-03-22 21:10:10 --> Language Class Initialized
INFO - 2021-03-22 21:10:10 --> Output Class Initialized
ERROR - 2021-03-22 21:10:10 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-22 21:10:10 --> Security Class Initialized
DEBUG - 2021-03-22 21:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:10:10 --> Input Class Initialized
INFO - 2021-03-22 21:10:10 --> Language Class Initialized
ERROR - 2021-03-22 21:10:10 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-22 21:11:03 --> Config Class Initialized
INFO - 2021-03-22 21:11:03 --> Hooks Class Initialized
DEBUG - 2021-03-22 21:11:03 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:11:03 --> Utf8 Class Initialized
INFO - 2021-03-22 21:11:03 --> URI Class Initialized
INFO - 2021-03-22 21:11:03 --> Router Class Initialized
INFO - 2021-03-22 21:11:03 --> Output Class Initialized
INFO - 2021-03-22 21:11:03 --> Security Class Initialized
DEBUG - 2021-03-22 21:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:11:03 --> Input Class Initialized
INFO - 2021-03-22 21:11:03 --> Language Class Initialized
INFO - 2021-03-22 21:11:03 --> Loader Class Initialized
INFO - 2021-03-22 21:11:03 --> Helper loaded: url_helper
INFO - 2021-03-22 21:11:03 --> Helper loaded: form_helper
INFO - 2021-03-22 21:11:03 --> Helper loaded: common_helper
INFO - 2021-03-22 21:11:03 --> Helper loaded: util_helper
INFO - 2021-03-22 21:11:03 --> Database Driver Class Initialized
DEBUG - 2021-03-22 21:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-22 21:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-22 21:11:03 --> Form Validation Class Initialized
INFO - 2021-03-22 21:11:03 --> Controller Class Initialized
INFO - 2021-03-22 21:11:03 --> Model Class Initialized
INFO - 2021-03-22 21:11:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-22 21:11:03 --> Config Class Initialized
INFO - 2021-03-22 21:11:03 --> Hooks Class Initialized
DEBUG - 2021-03-22 21:11:03 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:11:03 --> Utf8 Class Initialized
INFO - 2021-03-22 21:11:03 --> Config Class Initialized
INFO - 2021-03-22 21:11:03 --> Hooks Class Initialized
INFO - 2021-03-22 21:11:03 --> URI Class Initialized
DEBUG - 2021-03-22 21:11:03 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:11:03 --> Utf8 Class Initialized
INFO - 2021-03-22 21:11:03 --> Router Class Initialized
INFO - 2021-03-22 21:11:03 --> URI Class Initialized
INFO - 2021-03-22 21:11:03 --> Router Class Initialized
INFO - 2021-03-22 21:11:03 --> Output Class Initialized
INFO - 2021-03-22 21:11:03 --> Output Class Initialized
INFO - 2021-03-22 21:11:03 --> Security Class Initialized
INFO - 2021-03-22 21:11:03 --> Security Class Initialized
DEBUG - 2021-03-22 21:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:11:03 --> Input Class Initialized
DEBUG - 2021-03-22 21:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:11:03 --> Input Class Initialized
INFO - 2021-03-22 21:11:03 --> Language Class Initialized
INFO - 2021-03-22 21:11:03 --> Language Class Initialized
ERROR - 2021-03-22 21:11:03 --> 404 Page Not Found: Admin/dist
ERROR - 2021-03-22 21:11:03 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-22 21:11:03 --> Config Class Initialized
INFO - 2021-03-22 21:11:03 --> Hooks Class Initialized
DEBUG - 2021-03-22 21:11:03 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:11:03 --> Utf8 Class Initialized
INFO - 2021-03-22 21:11:03 --> URI Class Initialized
INFO - 2021-03-22 21:11:03 --> Router Class Initialized
INFO - 2021-03-22 21:11:03 --> Output Class Initialized
INFO - 2021-03-22 21:11:03 --> Config Class Initialized
INFO - 2021-03-22 21:11:03 --> Hooks Class Initialized
INFO - 2021-03-22 21:11:03 --> Security Class Initialized
DEBUG - 2021-03-22 21:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:11:03 --> Input Class Initialized
INFO - 2021-03-22 21:11:03 --> Language Class Initialized
DEBUG - 2021-03-22 21:11:03 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:11:03 --> Utf8 Class Initialized
INFO - 2021-03-22 21:11:03 --> URI Class Initialized
ERROR - 2021-03-22 21:11:03 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-22 21:11:03 --> Router Class Initialized
INFO - 2021-03-22 21:11:03 --> Output Class Initialized
INFO - 2021-03-22 21:11:03 --> Security Class Initialized
DEBUG - 2021-03-22 21:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:11:03 --> Input Class Initialized
INFO - 2021-03-22 21:11:03 --> Language Class Initialized
ERROR - 2021-03-22 21:11:03 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-22 21:11:07 --> Config Class Initialized
INFO - 2021-03-22 21:11:07 --> Hooks Class Initialized
DEBUG - 2021-03-22 21:11:07 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:11:07 --> Utf8 Class Initialized
INFO - 2021-03-22 21:11:07 --> URI Class Initialized
INFO - 2021-03-22 21:11:07 --> Router Class Initialized
INFO - 2021-03-22 21:11:07 --> Output Class Initialized
INFO - 2021-03-22 21:11:07 --> Security Class Initialized
DEBUG - 2021-03-22 21:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:11:07 --> Input Class Initialized
INFO - 2021-03-22 21:11:07 --> Language Class Initialized
INFO - 2021-03-22 21:11:07 --> Loader Class Initialized
INFO - 2021-03-22 21:11:07 --> Helper loaded: url_helper
INFO - 2021-03-22 21:11:07 --> Helper loaded: form_helper
INFO - 2021-03-22 21:11:07 --> Helper loaded: common_helper
INFO - 2021-03-22 21:11:07 --> Helper loaded: util_helper
INFO - 2021-03-22 21:11:07 --> Database Driver Class Initialized
DEBUG - 2021-03-22 21:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-22 21:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-22 21:11:07 --> Form Validation Class Initialized
INFO - 2021-03-22 21:11:07 --> Controller Class Initialized
INFO - 2021-03-22 21:11:07 --> Model Class Initialized
INFO - 2021-03-22 21:11:07 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-22 21:12:00 --> Config Class Initialized
INFO - 2021-03-22 21:12:00 --> Hooks Class Initialized
DEBUG - 2021-03-22 21:12:00 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:12:00 --> Utf8 Class Initialized
INFO - 2021-03-22 21:12:00 --> URI Class Initialized
INFO - 2021-03-22 21:12:00 --> Router Class Initialized
INFO - 2021-03-22 21:12:00 --> Output Class Initialized
INFO - 2021-03-22 21:12:00 --> Security Class Initialized
DEBUG - 2021-03-22 21:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:12:00 --> Input Class Initialized
INFO - 2021-03-22 21:12:00 --> Language Class Initialized
INFO - 2021-03-22 21:12:00 --> Loader Class Initialized
INFO - 2021-03-22 21:12:00 --> Helper loaded: url_helper
INFO - 2021-03-22 21:12:00 --> Helper loaded: form_helper
INFO - 2021-03-22 21:12:00 --> Helper loaded: common_helper
INFO - 2021-03-22 21:12:00 --> Helper loaded: util_helper
INFO - 2021-03-22 21:12:00 --> Database Driver Class Initialized
DEBUG - 2021-03-22 21:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-22 21:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-22 21:12:00 --> Form Validation Class Initialized
INFO - 2021-03-22 21:12:00 --> Controller Class Initialized
INFO - 2021-03-22 21:12:00 --> Model Class Initialized
INFO - 2021-03-22 21:12:00 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-22 21:12:00 --> Config Class Initialized
INFO - 2021-03-22 21:12:00 --> Hooks Class Initialized
INFO - 2021-03-22 21:12:00 --> Config Class Initialized
INFO - 2021-03-22 21:12:00 --> Hooks Class Initialized
DEBUG - 2021-03-22 21:12:00 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:12:00 --> Utf8 Class Initialized
INFO - 2021-03-22 21:12:00 --> URI Class Initialized
DEBUG - 2021-03-22 21:12:00 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:12:00 --> Utf8 Class Initialized
INFO - 2021-03-22 21:12:00 --> Router Class Initialized
INFO - 2021-03-22 21:12:00 --> URI Class Initialized
INFO - 2021-03-22 21:12:00 --> Output Class Initialized
INFO - 2021-03-22 21:12:00 --> Router Class Initialized
INFO - 2021-03-22 21:12:00 --> Security Class Initialized
INFO - 2021-03-22 21:12:00 --> Output Class Initialized
DEBUG - 2021-03-22 21:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:12:00 --> Input Class Initialized
INFO - 2021-03-22 21:12:00 --> Language Class Initialized
INFO - 2021-03-22 21:12:00 --> Security Class Initialized
DEBUG - 2021-03-22 21:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:12:00 --> Input Class Initialized
ERROR - 2021-03-22 21:12:00 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-22 21:12:00 --> Language Class Initialized
ERROR - 2021-03-22 21:12:00 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-22 21:12:00 --> Config Class Initialized
INFO - 2021-03-22 21:12:00 --> Hooks Class Initialized
DEBUG - 2021-03-22 21:12:00 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:12:00 --> Config Class Initialized
INFO - 2021-03-22 21:12:00 --> Utf8 Class Initialized
INFO - 2021-03-22 21:12:00 --> Hooks Class Initialized
INFO - 2021-03-22 21:12:00 --> URI Class Initialized
DEBUG - 2021-03-22 21:12:00 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:12:00 --> Router Class Initialized
INFO - 2021-03-22 21:12:00 --> Utf8 Class Initialized
INFO - 2021-03-22 21:12:00 --> URI Class Initialized
INFO - 2021-03-22 21:12:00 --> Output Class Initialized
INFO - 2021-03-22 21:12:01 --> Router Class Initialized
INFO - 2021-03-22 21:12:01 --> Security Class Initialized
INFO - 2021-03-22 21:12:01 --> Output Class Initialized
DEBUG - 2021-03-22 21:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:12:01 --> Input Class Initialized
INFO - 2021-03-22 21:12:01 --> Language Class Initialized
INFO - 2021-03-22 21:12:01 --> Security Class Initialized
DEBUG - 2021-03-22 21:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:12:01 --> Input Class Initialized
ERROR - 2021-03-22 21:12:01 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-22 21:12:01 --> Language Class Initialized
ERROR - 2021-03-22 21:12:01 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-22 21:12:03 --> Config Class Initialized
INFO - 2021-03-22 21:12:03 --> Hooks Class Initialized
DEBUG - 2021-03-22 21:12:03 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:12:03 --> Utf8 Class Initialized
INFO - 2021-03-22 21:12:03 --> URI Class Initialized
INFO - 2021-03-22 21:12:03 --> Router Class Initialized
INFO - 2021-03-22 21:12:03 --> Output Class Initialized
INFO - 2021-03-22 21:12:03 --> Security Class Initialized
DEBUG - 2021-03-22 21:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:12:03 --> Input Class Initialized
INFO - 2021-03-22 21:12:03 --> Language Class Initialized
INFO - 2021-03-22 21:12:03 --> Loader Class Initialized
INFO - 2021-03-22 21:12:03 --> Helper loaded: url_helper
INFO - 2021-03-22 21:12:03 --> Helper loaded: form_helper
INFO - 2021-03-22 21:12:03 --> Helper loaded: common_helper
INFO - 2021-03-22 21:12:03 --> Helper loaded: util_helper
INFO - 2021-03-22 21:12:03 --> Database Driver Class Initialized
DEBUG - 2021-03-22 21:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-22 21:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-22 21:12:03 --> Form Validation Class Initialized
INFO - 2021-03-22 21:12:03 --> Controller Class Initialized
INFO - 2021-03-22 21:12:03 --> Model Class Initialized
INFO - 2021-03-22 21:12:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-22 21:12:05 --> Config Class Initialized
INFO - 2021-03-22 21:12:05 --> Hooks Class Initialized
DEBUG - 2021-03-22 21:12:05 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:12:05 --> Utf8 Class Initialized
INFO - 2021-03-22 21:12:05 --> URI Class Initialized
INFO - 2021-03-22 21:12:05 --> Router Class Initialized
INFO - 2021-03-22 21:12:05 --> Output Class Initialized
INFO - 2021-03-22 21:12:05 --> Security Class Initialized
DEBUG - 2021-03-22 21:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:12:05 --> Input Class Initialized
INFO - 2021-03-22 21:12:05 --> Language Class Initialized
INFO - 2021-03-22 21:12:05 --> Loader Class Initialized
INFO - 2021-03-22 21:12:05 --> Helper loaded: url_helper
INFO - 2021-03-22 21:12:05 --> Helper loaded: form_helper
INFO - 2021-03-22 21:12:05 --> Helper loaded: common_helper
INFO - 2021-03-22 21:12:05 --> Helper loaded: util_helper
INFO - 2021-03-22 21:12:05 --> Database Driver Class Initialized
DEBUG - 2021-03-22 21:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-22 21:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-22 21:12:05 --> Form Validation Class Initialized
INFO - 2021-03-22 21:12:05 --> Controller Class Initialized
INFO - 2021-03-22 21:12:05 --> Model Class Initialized
INFO - 2021-03-22 21:12:05 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-22 21:12:34 --> Config Class Initialized
INFO - 2021-03-22 21:12:34 --> Hooks Class Initialized
DEBUG - 2021-03-22 21:12:34 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:12:34 --> Utf8 Class Initialized
INFO - 2021-03-22 21:12:34 --> URI Class Initialized
INFO - 2021-03-22 21:12:34 --> Router Class Initialized
INFO - 2021-03-22 21:12:34 --> Output Class Initialized
INFO - 2021-03-22 21:12:34 --> Security Class Initialized
DEBUG - 2021-03-22 21:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:12:34 --> Input Class Initialized
INFO - 2021-03-22 21:12:34 --> Language Class Initialized
INFO - 2021-03-22 21:12:34 --> Loader Class Initialized
INFO - 2021-03-22 21:12:34 --> Helper loaded: url_helper
INFO - 2021-03-22 21:12:34 --> Helper loaded: form_helper
INFO - 2021-03-22 21:12:34 --> Helper loaded: common_helper
INFO - 2021-03-22 21:12:34 --> Helper loaded: util_helper
INFO - 2021-03-22 21:12:34 --> Database Driver Class Initialized
DEBUG - 2021-03-22 21:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-22 21:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-22 21:12:34 --> Form Validation Class Initialized
INFO - 2021-03-22 21:12:34 --> Controller Class Initialized
INFO - 2021-03-22 21:12:34 --> Model Class Initialized
INFO - 2021-03-22 21:12:34 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-22 21:12:37 --> Config Class Initialized
INFO - 2021-03-22 21:12:37 --> Hooks Class Initialized
DEBUG - 2021-03-22 21:12:37 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:12:37 --> Utf8 Class Initialized
INFO - 2021-03-22 21:12:37 --> URI Class Initialized
INFO - 2021-03-22 21:12:37 --> Router Class Initialized
INFO - 2021-03-22 21:12:37 --> Output Class Initialized
INFO - 2021-03-22 21:12:37 --> Security Class Initialized
DEBUG - 2021-03-22 21:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:12:37 --> Input Class Initialized
INFO - 2021-03-22 21:12:37 --> Language Class Initialized
INFO - 2021-03-22 21:12:37 --> Loader Class Initialized
INFO - 2021-03-22 21:12:37 --> Helper loaded: url_helper
INFO - 2021-03-22 21:12:37 --> Helper loaded: form_helper
INFO - 2021-03-22 21:12:37 --> Helper loaded: common_helper
INFO - 2021-03-22 21:12:37 --> Helper loaded: util_helper
INFO - 2021-03-22 21:12:37 --> Database Driver Class Initialized
DEBUG - 2021-03-22 21:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-22 21:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-22 21:12:37 --> Form Validation Class Initialized
INFO - 2021-03-22 21:12:37 --> Controller Class Initialized
INFO - 2021-03-22 21:12:37 --> Model Class Initialized
INFO - 2021-03-22 21:12:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-22 21:12:37 --> Config Class Initialized
INFO - 2021-03-22 21:12:37 --> Hooks Class Initialized
DEBUG - 2021-03-22 21:12:37 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:12:37 --> Utf8 Class Initialized
INFO - 2021-03-22 21:12:37 --> Config Class Initialized
INFO - 2021-03-22 21:12:37 --> Hooks Class Initialized
INFO - 2021-03-22 21:12:37 --> URI Class Initialized
INFO - 2021-03-22 21:12:37 --> Router Class Initialized
DEBUG - 2021-03-22 21:12:37 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:12:37 --> Utf8 Class Initialized
INFO - 2021-03-22 21:12:37 --> Output Class Initialized
INFO - 2021-03-22 21:12:37 --> URI Class Initialized
INFO - 2021-03-22 21:12:37 --> Security Class Initialized
INFO - 2021-03-22 21:12:37 --> Router Class Initialized
DEBUG - 2021-03-22 21:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:12:37 --> Input Class Initialized
INFO - 2021-03-22 21:12:37 --> Language Class Initialized
INFO - 2021-03-22 21:12:37 --> Output Class Initialized
ERROR - 2021-03-22 21:12:37 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-22 21:12:37 --> Security Class Initialized
DEBUG - 2021-03-22 21:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:12:37 --> Input Class Initialized
INFO - 2021-03-22 21:12:37 --> Language Class Initialized
ERROR - 2021-03-22 21:12:37 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-22 21:12:37 --> Config Class Initialized
INFO - 2021-03-22 21:12:37 --> Hooks Class Initialized
INFO - 2021-03-22 21:12:37 --> Config Class Initialized
INFO - 2021-03-22 21:12:37 --> Hooks Class Initialized
DEBUG - 2021-03-22 21:12:37 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:12:37 --> Utf8 Class Initialized
DEBUG - 2021-03-22 21:12:37 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:12:37 --> URI Class Initialized
INFO - 2021-03-22 21:12:37 --> Utf8 Class Initialized
INFO - 2021-03-22 21:12:37 --> URI Class Initialized
INFO - 2021-03-22 21:12:37 --> Router Class Initialized
INFO - 2021-03-22 21:12:37 --> Router Class Initialized
INFO - 2021-03-22 21:12:37 --> Output Class Initialized
INFO - 2021-03-22 21:12:37 --> Security Class Initialized
INFO - 2021-03-22 21:12:37 --> Output Class Initialized
DEBUG - 2021-03-22 21:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:12:37 --> Security Class Initialized
INFO - 2021-03-22 21:12:37 --> Input Class Initialized
INFO - 2021-03-22 21:12:37 --> Language Class Initialized
DEBUG - 2021-03-22 21:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:12:37 --> Input Class Initialized
INFO - 2021-03-22 21:12:37 --> Language Class Initialized
ERROR - 2021-03-22 21:12:37 --> 404 Page Not Found: Admin/dist
ERROR - 2021-03-22 21:12:37 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-22 21:12:41 --> Config Class Initialized
INFO - 2021-03-22 21:12:41 --> Hooks Class Initialized
DEBUG - 2021-03-22 21:12:41 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:12:41 --> Utf8 Class Initialized
INFO - 2021-03-22 21:12:41 --> URI Class Initialized
INFO - 2021-03-22 21:12:41 --> Router Class Initialized
INFO - 2021-03-22 21:12:41 --> Output Class Initialized
INFO - 2021-03-22 21:12:41 --> Security Class Initialized
DEBUG - 2021-03-22 21:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:12:41 --> Input Class Initialized
INFO - 2021-03-22 21:12:41 --> Language Class Initialized
INFO - 2021-03-22 21:12:41 --> Loader Class Initialized
INFO - 2021-03-22 21:12:41 --> Helper loaded: url_helper
INFO - 2021-03-22 21:12:41 --> Helper loaded: form_helper
INFO - 2021-03-22 21:12:41 --> Helper loaded: common_helper
INFO - 2021-03-22 21:12:41 --> Helper loaded: util_helper
INFO - 2021-03-22 21:12:41 --> Database Driver Class Initialized
DEBUG - 2021-03-22 21:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-22 21:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-22 21:12:41 --> Form Validation Class Initialized
INFO - 2021-03-22 21:12:41 --> Controller Class Initialized
INFO - 2021-03-22 21:12:41 --> Model Class Initialized
INFO - 2021-03-22 21:12:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-22 21:12:56 --> Config Class Initialized
INFO - 2021-03-22 21:12:56 --> Hooks Class Initialized
DEBUG - 2021-03-22 21:12:56 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:12:56 --> Utf8 Class Initialized
INFO - 2021-03-22 21:12:56 --> URI Class Initialized
INFO - 2021-03-22 21:12:56 --> Router Class Initialized
INFO - 2021-03-22 21:12:56 --> Output Class Initialized
INFO - 2021-03-22 21:12:56 --> Security Class Initialized
DEBUG - 2021-03-22 21:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:12:56 --> Input Class Initialized
INFO - 2021-03-22 21:12:56 --> Language Class Initialized
INFO - 2021-03-22 21:12:56 --> Loader Class Initialized
INFO - 2021-03-22 21:12:56 --> Helper loaded: url_helper
INFO - 2021-03-22 21:12:56 --> Helper loaded: form_helper
INFO - 2021-03-22 21:12:56 --> Helper loaded: common_helper
INFO - 2021-03-22 21:12:56 --> Helper loaded: util_helper
INFO - 2021-03-22 21:12:56 --> Database Driver Class Initialized
DEBUG - 2021-03-22 21:12:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-22 21:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-22 21:12:56 --> Form Validation Class Initialized
INFO - 2021-03-22 21:12:56 --> Controller Class Initialized
INFO - 2021-03-22 21:12:56 --> Model Class Initialized
INFO - 2021-03-22 21:12:56 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-22 21:19:19 --> Config Class Initialized
INFO - 2021-03-22 21:19:19 --> Hooks Class Initialized
DEBUG - 2021-03-22 21:19:19 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:19:19 --> Utf8 Class Initialized
INFO - 2021-03-22 21:19:19 --> URI Class Initialized
INFO - 2021-03-22 21:19:19 --> Router Class Initialized
INFO - 2021-03-22 21:19:19 --> Output Class Initialized
INFO - 2021-03-22 21:19:19 --> Security Class Initialized
DEBUG - 2021-03-22 21:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:19:19 --> Input Class Initialized
INFO - 2021-03-22 21:19:19 --> Language Class Initialized
INFO - 2021-03-22 21:19:19 --> Loader Class Initialized
INFO - 2021-03-22 21:19:19 --> Helper loaded: url_helper
INFO - 2021-03-22 21:19:19 --> Helper loaded: form_helper
INFO - 2021-03-22 21:19:19 --> Helper loaded: common_helper
INFO - 2021-03-22 21:19:19 --> Helper loaded: util_helper
INFO - 2021-03-22 21:19:19 --> Database Driver Class Initialized
DEBUG - 2021-03-22 21:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-22 21:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-22 21:19:19 --> Form Validation Class Initialized
INFO - 2021-03-22 21:19:19 --> Controller Class Initialized
INFO - 2021-03-22 21:19:19 --> Model Class Initialized
INFO - 2021-03-22 21:19:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-22 21:19:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-22 21:19:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/dashboard.php
INFO - 2021-03-22 21:19:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-22 21:19:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-22 21:19:19 --> Final output sent to browser
DEBUG - 2021-03-22 21:19:19 --> Total execution time: 0.0392
INFO - 2021-03-22 21:19:19 --> Config Class Initialized
INFO - 2021-03-22 21:19:19 --> Hooks Class Initialized
INFO - 2021-03-22 21:19:19 --> Config Class Initialized
DEBUG - 2021-03-22 21:19:19 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:19:19 --> Hooks Class Initialized
INFO - 2021-03-22 21:19:19 --> Utf8 Class Initialized
INFO - 2021-03-22 21:19:19 --> URI Class Initialized
DEBUG - 2021-03-22 21:19:19 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:19:19 --> Utf8 Class Initialized
INFO - 2021-03-22 21:19:19 --> Router Class Initialized
INFO - 2021-03-22 21:19:19 --> URI Class Initialized
INFO - 2021-03-22 21:19:19 --> Output Class Initialized
INFO - 2021-03-22 21:19:19 --> Router Class Initialized
INFO - 2021-03-22 21:19:19 --> Security Class Initialized
DEBUG - 2021-03-22 21:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:19:19 --> Input Class Initialized
INFO - 2021-03-22 21:19:19 --> Output Class Initialized
INFO - 2021-03-22 21:19:19 --> Language Class Initialized
INFO - 2021-03-22 21:19:19 --> Security Class Initialized
ERROR - 2021-03-22 21:19:19 --> 404 Page Not Found: Admin/dist
DEBUG - 2021-03-22 21:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:19:19 --> Input Class Initialized
INFO - 2021-03-22 21:19:19 --> Language Class Initialized
ERROR - 2021-03-22 21:19:19 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-22 21:19:19 --> Config Class Initialized
INFO - 2021-03-22 21:19:19 --> Hooks Class Initialized
INFO - 2021-03-22 21:19:19 --> Config Class Initialized
INFO - 2021-03-22 21:19:19 --> Hooks Class Initialized
DEBUG - 2021-03-22 21:19:19 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:19:19 --> Utf8 Class Initialized
INFO - 2021-03-22 21:19:19 --> URI Class Initialized
DEBUG - 2021-03-22 21:19:19 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:19:19 --> Utf8 Class Initialized
INFO - 2021-03-22 21:19:19 --> Router Class Initialized
INFO - 2021-03-22 21:19:19 --> URI Class Initialized
INFO - 2021-03-22 21:19:19 --> Output Class Initialized
INFO - 2021-03-22 21:19:19 --> Router Class Initialized
INFO - 2021-03-22 21:19:19 --> Security Class Initialized
INFO - 2021-03-22 21:19:19 --> Output Class Initialized
DEBUG - 2021-03-22 21:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:19:19 --> Input Class Initialized
INFO - 2021-03-22 21:19:19 --> Language Class Initialized
INFO - 2021-03-22 21:19:19 --> Security Class Initialized
DEBUG - 2021-03-22 21:19:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-03-22 21:19:19 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-22 21:19:19 --> Input Class Initialized
INFO - 2021-03-22 21:19:19 --> Language Class Initialized
ERROR - 2021-03-22 21:19:19 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-22 21:19:47 --> Config Class Initialized
INFO - 2021-03-22 21:19:47 --> Hooks Class Initialized
DEBUG - 2021-03-22 21:19:47 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:19:47 --> Utf8 Class Initialized
INFO - 2021-03-22 21:19:47 --> URI Class Initialized
INFO - 2021-03-22 21:19:47 --> Router Class Initialized
INFO - 2021-03-22 21:19:47 --> Output Class Initialized
INFO - 2021-03-22 21:19:47 --> Security Class Initialized
DEBUG - 2021-03-22 21:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:19:47 --> Input Class Initialized
INFO - 2021-03-22 21:19:47 --> Language Class Initialized
INFO - 2021-03-22 21:19:47 --> Loader Class Initialized
INFO - 2021-03-22 21:19:47 --> Helper loaded: url_helper
INFO - 2021-03-22 21:19:47 --> Helper loaded: form_helper
INFO - 2021-03-22 21:19:47 --> Helper loaded: common_helper
INFO - 2021-03-22 21:19:47 --> Helper loaded: util_helper
INFO - 2021-03-22 21:19:47 --> Database Driver Class Initialized
DEBUG - 2021-03-22 21:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-22 21:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-22 21:19:47 --> Form Validation Class Initialized
INFO - 2021-03-22 21:19:47 --> Controller Class Initialized
INFO - 2021-03-22 21:19:47 --> Model Class Initialized
INFO - 2021-03-22 21:19:47 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-22 21:19:47 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-22 21:19:47 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/dashboard.php
INFO - 2021-03-22 21:19:47 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-22 21:19:47 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-22 21:19:47 --> Final output sent to browser
DEBUG - 2021-03-22 21:19:47 --> Total execution time: 0.0358
INFO - 2021-03-22 21:19:47 --> Config Class Initialized
INFO - 2021-03-22 21:19:47 --> Hooks Class Initialized
INFO - 2021-03-22 21:19:47 --> Config Class Initialized
INFO - 2021-03-22 21:19:47 --> Hooks Class Initialized
DEBUG - 2021-03-22 21:19:47 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:19:47 --> Utf8 Class Initialized
DEBUG - 2021-03-22 21:19:47 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:19:47 --> Utf8 Class Initialized
INFO - 2021-03-22 21:19:47 --> URI Class Initialized
INFO - 2021-03-22 21:19:47 --> URI Class Initialized
INFO - 2021-03-22 21:19:47 --> Router Class Initialized
INFO - 2021-03-22 21:19:47 --> Router Class Initialized
INFO - 2021-03-22 21:19:47 --> Output Class Initialized
INFO - 2021-03-22 21:19:47 --> Security Class Initialized
INFO - 2021-03-22 21:19:47 --> Output Class Initialized
DEBUG - 2021-03-22 21:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:19:47 --> Input Class Initialized
INFO - 2021-03-22 21:19:47 --> Security Class Initialized
INFO - 2021-03-22 21:19:47 --> Language Class Initialized
DEBUG - 2021-03-22 21:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:19:47 --> Input Class Initialized
ERROR - 2021-03-22 21:19:47 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-22 21:19:47 --> Language Class Initialized
ERROR - 2021-03-22 21:19:47 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-22 21:19:47 --> Config Class Initialized
INFO - 2021-03-22 21:19:47 --> Hooks Class Initialized
DEBUG - 2021-03-22 21:19:47 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:19:47 --> Utf8 Class Initialized
INFO - 2021-03-22 21:19:47 --> Config Class Initialized
INFO - 2021-03-22 21:19:47 --> URI Class Initialized
INFO - 2021-03-22 21:19:47 --> Hooks Class Initialized
INFO - 2021-03-22 21:19:47 --> Router Class Initialized
DEBUG - 2021-03-22 21:19:47 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:19:47 --> Utf8 Class Initialized
INFO - 2021-03-22 21:19:47 --> Output Class Initialized
INFO - 2021-03-22 21:19:47 --> URI Class Initialized
INFO - 2021-03-22 21:19:47 --> Security Class Initialized
INFO - 2021-03-22 21:19:47 --> Router Class Initialized
DEBUG - 2021-03-22 21:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:19:47 --> Input Class Initialized
INFO - 2021-03-22 21:19:47 --> Language Class Initialized
INFO - 2021-03-22 21:19:47 --> Output Class Initialized
ERROR - 2021-03-22 21:19:47 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-22 21:19:47 --> Security Class Initialized
DEBUG - 2021-03-22 21:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:19:47 --> Input Class Initialized
INFO - 2021-03-22 21:19:47 --> Language Class Initialized
ERROR - 2021-03-22 21:19:47 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-22 21:25:12 --> Config Class Initialized
INFO - 2021-03-22 21:25:12 --> Hooks Class Initialized
DEBUG - 2021-03-22 21:25:12 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:25:12 --> Utf8 Class Initialized
INFO - 2021-03-22 21:25:12 --> URI Class Initialized
INFO - 2021-03-22 21:25:12 --> Router Class Initialized
INFO - 2021-03-22 21:25:12 --> Output Class Initialized
INFO - 2021-03-22 21:25:12 --> Security Class Initialized
DEBUG - 2021-03-22 21:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:25:12 --> Input Class Initialized
INFO - 2021-03-22 21:25:12 --> Language Class Initialized
INFO - 2021-03-22 21:25:12 --> Loader Class Initialized
INFO - 2021-03-22 21:25:12 --> Helper loaded: url_helper
INFO - 2021-03-22 21:25:12 --> Helper loaded: form_helper
INFO - 2021-03-22 21:25:12 --> Helper loaded: common_helper
INFO - 2021-03-22 21:25:12 --> Helper loaded: util_helper
INFO - 2021-03-22 21:25:12 --> Database Driver Class Initialized
DEBUG - 2021-03-22 21:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-22 21:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-22 21:25:12 --> Form Validation Class Initialized
INFO - 2021-03-22 21:25:12 --> Controller Class Initialized
INFO - 2021-03-22 21:25:12 --> Model Class Initialized
INFO - 2021-03-22 21:25:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-22 21:25:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-22 21:25:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/dashboard.php
INFO - 2021-03-22 21:25:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-22 21:25:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-22 21:25:12 --> Final output sent to browser
DEBUG - 2021-03-22 21:25:12 --> Total execution time: 0.0362
INFO - 2021-03-22 21:25:12 --> Config Class Initialized
INFO - 2021-03-22 21:25:12 --> Hooks Class Initialized
INFO - 2021-03-22 21:25:12 --> Config Class Initialized
INFO - 2021-03-22 21:25:12 --> Hooks Class Initialized
DEBUG - 2021-03-22 21:25:12 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:25:12 --> Utf8 Class Initialized
INFO - 2021-03-22 21:25:12 --> URI Class Initialized
DEBUG - 2021-03-22 21:25:12 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:25:12 --> Utf8 Class Initialized
INFO - 2021-03-22 21:25:12 --> Router Class Initialized
INFO - 2021-03-22 21:25:12 --> URI Class Initialized
INFO - 2021-03-22 21:25:12 --> Output Class Initialized
INFO - 2021-03-22 21:25:12 --> Router Class Initialized
INFO - 2021-03-22 21:25:12 --> Security Class Initialized
INFO - 2021-03-22 21:25:12 --> Output Class Initialized
DEBUG - 2021-03-22 21:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:25:12 --> Input Class Initialized
INFO - 2021-03-22 21:25:12 --> Security Class Initialized
INFO - 2021-03-22 21:25:12 --> Language Class Initialized
DEBUG - 2021-03-22 21:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:25:12 --> Input Class Initialized
INFO - 2021-03-22 21:25:12 --> Language Class Initialized
ERROR - 2021-03-22 21:25:12 --> 404 Page Not Found: Admin/dist
ERROR - 2021-03-22 21:25:12 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-22 21:25:12 --> Config Class Initialized
INFO - 2021-03-22 21:25:12 --> Hooks Class Initialized
INFO - 2021-03-22 21:25:12 --> Config Class Initialized
INFO - 2021-03-22 21:25:12 --> Hooks Class Initialized
DEBUG - 2021-03-22 21:25:12 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:25:12 --> Utf8 Class Initialized
INFO - 2021-03-22 21:25:12 --> URI Class Initialized
DEBUG - 2021-03-22 21:25:12 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:25:12 --> Utf8 Class Initialized
INFO - 2021-03-22 21:25:12 --> URI Class Initialized
INFO - 2021-03-22 21:25:12 --> Router Class Initialized
INFO - 2021-03-22 21:25:12 --> Router Class Initialized
INFO - 2021-03-22 21:25:12 --> Output Class Initialized
INFO - 2021-03-22 21:25:12 --> Output Class Initialized
INFO - 2021-03-22 21:25:12 --> Security Class Initialized
INFO - 2021-03-22 21:25:12 --> Security Class Initialized
DEBUG - 2021-03-22 21:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-22 21:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:25:12 --> Input Class Initialized
INFO - 2021-03-22 21:25:12 --> Input Class Initialized
INFO - 2021-03-22 21:25:12 --> Language Class Initialized
INFO - 2021-03-22 21:25:12 --> Language Class Initialized
ERROR - 2021-03-22 21:25:12 --> 404 Page Not Found: Admin/dist
ERROR - 2021-03-22 21:25:12 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-22 21:25:14 --> Config Class Initialized
INFO - 2021-03-22 21:25:14 --> Hooks Class Initialized
DEBUG - 2021-03-22 21:25:14 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:25:14 --> Utf8 Class Initialized
INFO - 2021-03-22 21:25:14 --> URI Class Initialized
INFO - 2021-03-22 21:25:14 --> Router Class Initialized
INFO - 2021-03-22 21:25:14 --> Output Class Initialized
INFO - 2021-03-22 21:25:14 --> Security Class Initialized
DEBUG - 2021-03-22 21:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:25:14 --> Input Class Initialized
INFO - 2021-03-22 21:25:14 --> Language Class Initialized
INFO - 2021-03-22 21:25:14 --> Loader Class Initialized
INFO - 2021-03-22 21:25:14 --> Helper loaded: url_helper
INFO - 2021-03-22 21:25:14 --> Helper loaded: form_helper
INFO - 2021-03-22 21:25:14 --> Helper loaded: common_helper
INFO - 2021-03-22 21:25:14 --> Helper loaded: util_helper
INFO - 2021-03-22 21:25:14 --> Database Driver Class Initialized
DEBUG - 2021-03-22 21:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-22 21:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-22 21:25:14 --> Form Validation Class Initialized
INFO - 2021-03-22 21:25:14 --> Controller Class Initialized
INFO - 2021-03-22 21:25:14 --> Model Class Initialized
INFO - 2021-03-22 21:25:14 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-22 21:25:14 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-22 21:25:14 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/dashboard.php
INFO - 2021-03-22 21:25:14 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-22 21:25:14 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-22 21:25:14 --> Final output sent to browser
DEBUG - 2021-03-22 21:25:14 --> Total execution time: 0.0495
INFO - 2021-03-22 21:25:14 --> Config Class Initialized
INFO - 2021-03-22 21:25:14 --> Hooks Class Initialized
DEBUG - 2021-03-22 21:25:14 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:25:14 --> Utf8 Class Initialized
INFO - 2021-03-22 21:25:14 --> URI Class Initialized
INFO - 2021-03-22 21:25:14 --> Config Class Initialized
INFO - 2021-03-22 21:25:14 --> Hooks Class Initialized
INFO - 2021-03-22 21:25:14 --> Router Class Initialized
INFO - 2021-03-22 21:25:14 --> Output Class Initialized
DEBUG - 2021-03-22 21:25:14 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:25:14 --> Utf8 Class Initialized
INFO - 2021-03-22 21:25:14 --> Security Class Initialized
INFO - 2021-03-22 21:25:14 --> URI Class Initialized
DEBUG - 2021-03-22 21:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:25:14 --> Input Class Initialized
INFO - 2021-03-22 21:25:14 --> Language Class Initialized
INFO - 2021-03-22 21:25:14 --> Router Class Initialized
INFO - 2021-03-22 21:25:14 --> Output Class Initialized
ERROR - 2021-03-22 21:25:14 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-22 21:25:14 --> Security Class Initialized
DEBUG - 2021-03-22 21:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:25:14 --> Input Class Initialized
INFO - 2021-03-22 21:25:14 --> Language Class Initialized
ERROR - 2021-03-22 21:25:14 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-22 21:25:14 --> Config Class Initialized
INFO - 2021-03-22 21:25:14 --> Hooks Class Initialized
INFO - 2021-03-22 21:25:14 --> Config Class Initialized
INFO - 2021-03-22 21:25:14 --> Hooks Class Initialized
DEBUG - 2021-03-22 21:25:14 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:25:14 --> Utf8 Class Initialized
INFO - 2021-03-22 21:25:14 --> URI Class Initialized
DEBUG - 2021-03-22 21:25:14 --> UTF-8 Support Enabled
INFO - 2021-03-22 21:25:14 --> Router Class Initialized
INFO - 2021-03-22 21:25:14 --> Utf8 Class Initialized
INFO - 2021-03-22 21:25:14 --> URI Class Initialized
INFO - 2021-03-22 21:25:14 --> Output Class Initialized
INFO - 2021-03-22 21:25:14 --> Security Class Initialized
INFO - 2021-03-22 21:25:14 --> Router Class Initialized
DEBUG - 2021-03-22 21:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:25:14 --> Input Class Initialized
INFO - 2021-03-22 21:25:14 --> Output Class Initialized
INFO - 2021-03-22 21:25:14 --> Language Class Initialized
INFO - 2021-03-22 21:25:14 --> Security Class Initialized
ERROR - 2021-03-22 21:25:14 --> 404 Page Not Found: Admin/dist
DEBUG - 2021-03-22 21:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-22 21:25:14 --> Input Class Initialized
INFO - 2021-03-22 21:25:14 --> Language Class Initialized
ERROR - 2021-03-22 21:25:14 --> 404 Page Not Found: Admin/dist

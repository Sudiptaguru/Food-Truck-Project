<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-03-27 00:00:29 --> Config Class Initialized
INFO - 2021-03-27 00:00:29 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:00:29 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:00:29 --> Utf8 Class Initialized
INFO - 2021-03-27 00:00:29 --> URI Class Initialized
INFO - 2021-03-27 00:00:29 --> Router Class Initialized
INFO - 2021-03-27 00:00:29 --> Output Class Initialized
INFO - 2021-03-27 00:00:29 --> Security Class Initialized
DEBUG - 2021-03-27 00:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:00:29 --> Input Class Initialized
INFO - 2021-03-27 00:00:29 --> Language Class Initialized
INFO - 2021-03-27 00:00:29 --> Loader Class Initialized
INFO - 2021-03-27 00:00:29 --> Helper loaded: url_helper
INFO - 2021-03-27 00:00:29 --> Helper loaded: form_helper
INFO - 2021-03-27 00:00:29 --> Helper loaded: common_helper
INFO - 2021-03-27 00:00:29 --> Helper loaded: util_helper
INFO - 2021-03-27 00:00:29 --> Database Driver Class Initialized
DEBUG - 2021-03-27 00:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 00:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 00:00:29 --> Form Validation Class Initialized
INFO - 2021-03-27 00:00:29 --> Controller Class Initialized
INFO - 2021-03-27 00:00:29 --> Model Class Initialized
INFO - 2021-03-27 00:00:29 --> Model Class Initialized
INFO - 2021-03-27 00:00:29 --> Model Class Initialized
INFO - 2021-03-27 00:00:29 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-27 00:00:29 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-27 00:00:29 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-27 00:00:29 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-27 00:00:29 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-27 00:00:29 --> Final output sent to browser
DEBUG - 2021-03-27 00:00:29 --> Total execution time: 0.0467
INFO - 2021-03-27 00:00:29 --> Config Class Initialized
INFO - 2021-03-27 00:00:29 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:00:29 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:00:29 --> Utf8 Class Initialized
INFO - 2021-03-27 00:00:29 --> URI Class Initialized
INFO - 2021-03-27 00:00:29 --> Router Class Initialized
INFO - 2021-03-27 00:00:29 --> Output Class Initialized
INFO - 2021-03-27 00:00:29 --> Security Class Initialized
DEBUG - 2021-03-27 00:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:00:29 --> Input Class Initialized
INFO - 2021-03-27 00:00:29 --> Language Class Initialized
ERROR - 2021-03-27 00:00:29 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-27 00:00:29 --> Config Class Initialized
INFO - 2021-03-27 00:00:29 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:00:29 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:00:29 --> Utf8 Class Initialized
INFO - 2021-03-27 00:00:29 --> URI Class Initialized
INFO - 2021-03-27 00:00:29 --> Router Class Initialized
INFO - 2021-03-27 00:00:29 --> Output Class Initialized
INFO - 2021-03-27 00:00:29 --> Security Class Initialized
DEBUG - 2021-03-27 00:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:00:29 --> Input Class Initialized
INFO - 2021-03-27 00:00:29 --> Language Class Initialized
ERROR - 2021-03-27 00:00:29 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-27 00:00:29 --> Config Class Initialized
INFO - 2021-03-27 00:00:29 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:00:29 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:00:29 --> Utf8 Class Initialized
INFO - 2021-03-27 00:00:29 --> URI Class Initialized
INFO - 2021-03-27 00:00:29 --> Router Class Initialized
INFO - 2021-03-27 00:00:29 --> Output Class Initialized
INFO - 2021-03-27 00:00:29 --> Security Class Initialized
DEBUG - 2021-03-27 00:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:00:29 --> Input Class Initialized
INFO - 2021-03-27 00:00:29 --> Language Class Initialized
ERROR - 2021-03-27 00:00:29 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-27 00:00:29 --> Config Class Initialized
INFO - 2021-03-27 00:00:29 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:00:29 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:00:29 --> Utf8 Class Initialized
INFO - 2021-03-27 00:00:29 --> URI Class Initialized
INFO - 2021-03-27 00:00:29 --> Router Class Initialized
INFO - 2021-03-27 00:00:29 --> Output Class Initialized
INFO - 2021-03-27 00:00:29 --> Security Class Initialized
DEBUG - 2021-03-27 00:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:00:29 --> Input Class Initialized
INFO - 2021-03-27 00:00:29 --> Language Class Initialized
ERROR - 2021-03-27 00:00:29 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-27 00:00:31 --> Config Class Initialized
INFO - 2021-03-27 00:00:31 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:00:31 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:00:31 --> Utf8 Class Initialized
INFO - 2021-03-27 00:00:31 --> URI Class Initialized
INFO - 2021-03-27 00:00:31 --> Router Class Initialized
INFO - 2021-03-27 00:00:31 --> Output Class Initialized
INFO - 2021-03-27 00:00:31 --> Security Class Initialized
DEBUG - 2021-03-27 00:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:00:31 --> Input Class Initialized
INFO - 2021-03-27 00:00:31 --> Language Class Initialized
INFO - 2021-03-27 00:00:31 --> Loader Class Initialized
INFO - 2021-03-27 00:00:31 --> Helper loaded: url_helper
INFO - 2021-03-27 00:00:31 --> Helper loaded: form_helper
INFO - 2021-03-27 00:00:31 --> Helper loaded: common_helper
INFO - 2021-03-27 00:00:31 --> Helper loaded: util_helper
INFO - 2021-03-27 00:00:31 --> Database Driver Class Initialized
DEBUG - 2021-03-27 00:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 00:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 00:00:31 --> Form Validation Class Initialized
INFO - 2021-03-27 00:00:31 --> Controller Class Initialized
INFO - 2021-03-27 00:00:31 --> Model Class Initialized
INFO - 2021-03-27 00:00:31 --> Model Class Initialized
INFO - 2021-03-27 00:00:31 --> Model Class Initialized
INFO - 2021-03-27 00:00:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-27 00:00:31 --> Final output sent to browser
DEBUG - 2021-03-27 00:00:31 --> Total execution time: 0.0366
INFO - 2021-03-27 00:01:23 --> Config Class Initialized
INFO - 2021-03-27 00:01:23 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:01:23 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:01:23 --> Utf8 Class Initialized
INFO - 2021-03-27 00:01:23 --> URI Class Initialized
INFO - 2021-03-27 00:01:23 --> Router Class Initialized
INFO - 2021-03-27 00:01:23 --> Output Class Initialized
INFO - 2021-03-27 00:01:23 --> Security Class Initialized
DEBUG - 2021-03-27 00:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:01:23 --> Input Class Initialized
INFO - 2021-03-27 00:01:23 --> Language Class Initialized
INFO - 2021-03-27 00:01:23 --> Loader Class Initialized
INFO - 2021-03-27 00:01:23 --> Helper loaded: url_helper
INFO - 2021-03-27 00:01:23 --> Helper loaded: form_helper
INFO - 2021-03-27 00:01:23 --> Helper loaded: common_helper
INFO - 2021-03-27 00:01:23 --> Helper loaded: util_helper
INFO - 2021-03-27 00:01:23 --> Database Driver Class Initialized
DEBUG - 2021-03-27 00:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 00:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 00:01:23 --> Form Validation Class Initialized
INFO - 2021-03-27 00:01:23 --> Controller Class Initialized
INFO - 2021-03-27 00:01:23 --> Model Class Initialized
INFO - 2021-03-27 00:01:23 --> Model Class Initialized
INFO - 2021-03-27 00:01:23 --> Model Class Initialized
INFO - 2021-03-27 00:01:23 --> Final output sent to browser
DEBUG - 2021-03-27 00:01:23 --> Total execution time: 0.1071
INFO - 2021-03-27 00:01:43 --> Config Class Initialized
INFO - 2021-03-27 00:01:43 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:01:43 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:01:43 --> Utf8 Class Initialized
INFO - 2021-03-27 00:01:43 --> URI Class Initialized
INFO - 2021-03-27 00:01:43 --> Router Class Initialized
INFO - 2021-03-27 00:01:43 --> Output Class Initialized
INFO - 2021-03-27 00:01:43 --> Security Class Initialized
DEBUG - 2021-03-27 00:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:01:43 --> Input Class Initialized
INFO - 2021-03-27 00:01:43 --> Language Class Initialized
INFO - 2021-03-27 00:01:43 --> Loader Class Initialized
INFO - 2021-03-27 00:01:43 --> Helper loaded: url_helper
INFO - 2021-03-27 00:01:43 --> Helper loaded: form_helper
INFO - 2021-03-27 00:01:43 --> Helper loaded: common_helper
INFO - 2021-03-27 00:01:43 --> Helper loaded: util_helper
INFO - 2021-03-27 00:01:43 --> Database Driver Class Initialized
DEBUG - 2021-03-27 00:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 00:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 00:01:43 --> Form Validation Class Initialized
INFO - 2021-03-27 00:01:43 --> Controller Class Initialized
INFO - 2021-03-27 00:01:43 --> Model Class Initialized
INFO - 2021-03-27 00:01:43 --> Model Class Initialized
INFO - 2021-03-27 00:01:43 --> Model Class Initialized
INFO - 2021-03-27 00:01:43 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-27 00:01:43 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-27 00:01:43 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/role.php
INFO - 2021-03-27 00:01:43 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-27 00:01:43 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-27 00:01:43 --> Final output sent to browser
DEBUG - 2021-03-27 00:01:43 --> Total execution time: 0.0360
INFO - 2021-03-27 00:01:43 --> Config Class Initialized
INFO - 2021-03-27 00:01:43 --> Hooks Class Initialized
INFO - 2021-03-27 00:01:43 --> Config Class Initialized
INFO - 2021-03-27 00:01:43 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:01:43 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:01:43 --> Utf8 Class Initialized
INFO - 2021-03-27 00:01:43 --> URI Class Initialized
DEBUG - 2021-03-27 00:01:43 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:01:43 --> Utf8 Class Initialized
INFO - 2021-03-27 00:01:43 --> Router Class Initialized
INFO - 2021-03-27 00:01:43 --> URI Class Initialized
INFO - 2021-03-27 00:01:43 --> Output Class Initialized
INFO - 2021-03-27 00:01:43 --> Router Class Initialized
INFO - 2021-03-27 00:01:43 --> Security Class Initialized
INFO - 2021-03-27 00:01:43 --> Output Class Initialized
DEBUG - 2021-03-27 00:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:01:43 --> Input Class Initialized
INFO - 2021-03-27 00:01:43 --> Security Class Initialized
INFO - 2021-03-27 00:01:43 --> Language Class Initialized
DEBUG - 2021-03-27 00:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:01:43 --> Input Class Initialized
ERROR - 2021-03-27 00:01:43 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-27 00:01:43 --> Language Class Initialized
ERROR - 2021-03-27 00:01:43 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-27 00:01:43 --> Config Class Initialized
INFO - 2021-03-27 00:01:43 --> Hooks Class Initialized
INFO - 2021-03-27 00:01:43 --> Config Class Initialized
INFO - 2021-03-27 00:01:43 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:01:43 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:01:43 --> Utf8 Class Initialized
DEBUG - 2021-03-27 00:01:43 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:01:43 --> Utf8 Class Initialized
INFO - 2021-03-27 00:01:43 --> URI Class Initialized
INFO - 2021-03-27 00:01:43 --> URI Class Initialized
INFO - 2021-03-27 00:01:43 --> Router Class Initialized
INFO - 2021-03-27 00:01:43 --> Router Class Initialized
INFO - 2021-03-27 00:01:43 --> Output Class Initialized
INFO - 2021-03-27 00:01:43 --> Output Class Initialized
INFO - 2021-03-27 00:01:43 --> Security Class Initialized
INFO - 2021-03-27 00:01:43 --> Security Class Initialized
DEBUG - 2021-03-27 00:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-27 00:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:01:43 --> Input Class Initialized
INFO - 2021-03-27 00:01:43 --> Input Class Initialized
INFO - 2021-03-27 00:01:43 --> Language Class Initialized
INFO - 2021-03-27 00:01:43 --> Language Class Initialized
ERROR - 2021-03-27 00:01:43 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-27 00:01:43 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-27 00:01:46 --> Config Class Initialized
INFO - 2021-03-27 00:01:46 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:01:46 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:01:46 --> Utf8 Class Initialized
INFO - 2021-03-27 00:01:46 --> URI Class Initialized
INFO - 2021-03-27 00:01:46 --> Router Class Initialized
INFO - 2021-03-27 00:01:46 --> Output Class Initialized
INFO - 2021-03-27 00:01:46 --> Security Class Initialized
DEBUG - 2021-03-27 00:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:01:46 --> Input Class Initialized
INFO - 2021-03-27 00:01:46 --> Language Class Initialized
INFO - 2021-03-27 00:01:46 --> Loader Class Initialized
INFO - 2021-03-27 00:01:46 --> Helper loaded: url_helper
INFO - 2021-03-27 00:01:46 --> Helper loaded: form_helper
INFO - 2021-03-27 00:01:46 --> Helper loaded: common_helper
INFO - 2021-03-27 00:01:46 --> Helper loaded: util_helper
INFO - 2021-03-27 00:01:46 --> Database Driver Class Initialized
DEBUG - 2021-03-27 00:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 00:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 00:01:46 --> Form Validation Class Initialized
INFO - 2021-03-27 00:01:46 --> Controller Class Initialized
INFO - 2021-03-27 00:01:46 --> Model Class Initialized
INFO - 2021-03-27 00:01:46 --> Model Class Initialized
INFO - 2021-03-27 00:01:46 --> Model Class Initialized
INFO - 2021-03-27 00:01:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-27 00:01:46 --> Final output sent to browser
DEBUG - 2021-03-27 00:01:46 --> Total execution time: 0.0348
INFO - 2021-03-27 00:15:06 --> Config Class Initialized
INFO - 2021-03-27 00:15:06 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:15:06 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:15:06 --> Utf8 Class Initialized
INFO - 2021-03-27 00:15:06 --> URI Class Initialized
INFO - 2021-03-27 00:15:06 --> Router Class Initialized
INFO - 2021-03-27 00:15:06 --> Output Class Initialized
INFO - 2021-03-27 00:15:06 --> Security Class Initialized
DEBUG - 2021-03-27 00:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:15:06 --> Input Class Initialized
INFO - 2021-03-27 00:15:06 --> Language Class Initialized
INFO - 2021-03-27 00:15:06 --> Loader Class Initialized
INFO - 2021-03-27 00:15:06 --> Helper loaded: url_helper
INFO - 2021-03-27 00:15:06 --> Helper loaded: form_helper
INFO - 2021-03-27 00:15:06 --> Helper loaded: common_helper
INFO - 2021-03-27 00:15:06 --> Helper loaded: util_helper
INFO - 2021-03-27 00:15:06 --> Database Driver Class Initialized
DEBUG - 2021-03-27 00:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 00:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 00:15:06 --> Form Validation Class Initialized
INFO - 2021-03-27 00:15:06 --> Controller Class Initialized
INFO - 2021-03-27 00:15:06 --> Model Class Initialized
INFO - 2021-03-27 00:15:06 --> Config Class Initialized
INFO - 2021-03-27 00:15:06 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:15:06 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:15:06 --> Utf8 Class Initialized
INFO - 2021-03-27 00:15:06 --> URI Class Initialized
INFO - 2021-03-27 00:15:06 --> Router Class Initialized
INFO - 2021-03-27 00:15:06 --> Output Class Initialized
INFO - 2021-03-27 00:15:06 --> Security Class Initialized
DEBUG - 2021-03-27 00:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:15:06 --> Input Class Initialized
INFO - 2021-03-27 00:15:06 --> Language Class Initialized
INFO - 2021-03-27 00:15:06 --> Loader Class Initialized
INFO - 2021-03-27 00:15:06 --> Helper loaded: url_helper
INFO - 2021-03-27 00:15:06 --> Helper loaded: form_helper
INFO - 2021-03-27 00:15:06 --> Helper loaded: common_helper
INFO - 2021-03-27 00:15:06 --> Helper loaded: util_helper
INFO - 2021-03-27 00:15:06 --> Database Driver Class Initialized
DEBUG - 2021-03-27 00:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 00:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 00:15:06 --> Form Validation Class Initialized
INFO - 2021-03-27 00:15:06 --> Controller Class Initialized
INFO - 2021-03-27 00:15:06 --> Model Class Initialized
INFO - 2021-03-27 00:15:06 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/login.php
INFO - 2021-03-27 00:15:06 --> Final output sent to browser
DEBUG - 2021-03-27 00:15:06 --> Total execution time: 0.0365
INFO - 2021-03-27 00:44:45 --> Config Class Initialized
INFO - 2021-03-27 00:44:45 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:44:45 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:44:45 --> Utf8 Class Initialized
INFO - 2021-03-27 00:44:45 --> URI Class Initialized
INFO - 2021-03-27 00:44:45 --> Router Class Initialized
INFO - 2021-03-27 00:44:45 --> Output Class Initialized
INFO - 2021-03-27 00:44:45 --> Security Class Initialized
DEBUG - 2021-03-27 00:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:44:45 --> Input Class Initialized
INFO - 2021-03-27 00:44:45 --> Language Class Initialized
INFO - 2021-03-27 00:44:45 --> Loader Class Initialized
INFO - 2021-03-27 00:44:45 --> Helper loaded: url_helper
INFO - 2021-03-27 00:44:45 --> Helper loaded: form_helper
INFO - 2021-03-27 00:44:45 --> Helper loaded: common_helper
INFO - 2021-03-27 00:44:45 --> Helper loaded: util_helper
INFO - 2021-03-27 00:44:45 --> Database Driver Class Initialized
DEBUG - 2021-03-27 00:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 00:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 00:44:45 --> Form Validation Class Initialized
INFO - 2021-03-27 00:44:45 --> Controller Class Initialized
INFO - 2021-03-27 00:44:45 --> Model Class Initialized
INFO - 2021-03-27 00:44:45 --> Config Class Initialized
INFO - 2021-03-27 00:44:45 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:44:45 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:44:45 --> Utf8 Class Initialized
INFO - 2021-03-27 00:44:45 --> URI Class Initialized
INFO - 2021-03-27 00:44:45 --> Router Class Initialized
INFO - 2021-03-27 00:44:45 --> Output Class Initialized
INFO - 2021-03-27 00:44:45 --> Security Class Initialized
DEBUG - 2021-03-27 00:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:44:45 --> Input Class Initialized
INFO - 2021-03-27 00:44:45 --> Language Class Initialized
INFO - 2021-03-27 00:44:45 --> Loader Class Initialized
INFO - 2021-03-27 00:44:45 --> Helper loaded: url_helper
INFO - 2021-03-27 00:44:45 --> Helper loaded: form_helper
INFO - 2021-03-27 00:44:45 --> Helper loaded: common_helper
INFO - 2021-03-27 00:44:45 --> Helper loaded: util_helper
INFO - 2021-03-27 00:44:45 --> Database Driver Class Initialized
DEBUG - 2021-03-27 00:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 00:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 00:44:46 --> Form Validation Class Initialized
INFO - 2021-03-27 00:44:46 --> Controller Class Initialized
INFO - 2021-03-27 00:44:46 --> Model Class Initialized
INFO - 2021-03-27 00:44:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-27 00:44:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-27 00:44:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/dashboard.php
INFO - 2021-03-27 00:44:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-27 00:44:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-27 00:44:46 --> Final output sent to browser
DEBUG - 2021-03-27 00:44:46 --> Total execution time: 0.0552
INFO - 2021-03-27 00:44:46 --> Config Class Initialized
INFO - 2021-03-27 00:44:46 --> Hooks Class Initialized
INFO - 2021-03-27 00:44:46 --> Config Class Initialized
INFO - 2021-03-27 00:44:46 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:44:46 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:44:46 --> Utf8 Class Initialized
INFO - 2021-03-27 00:44:46 --> URI Class Initialized
DEBUG - 2021-03-27 00:44:46 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:44:46 --> Utf8 Class Initialized
INFO - 2021-03-27 00:44:46 --> Router Class Initialized
INFO - 2021-03-27 00:44:46 --> URI Class Initialized
INFO - 2021-03-27 00:44:46 --> Output Class Initialized
INFO - 2021-03-27 00:44:46 --> Router Class Initialized
INFO - 2021-03-27 00:44:46 --> Config Class Initialized
INFO - 2021-03-27 00:44:46 --> Hooks Class Initialized
INFO - 2021-03-27 00:44:46 --> Security Class Initialized
INFO - 2021-03-27 00:44:46 --> Output Class Initialized
INFO - 2021-03-27 00:44:46 --> Security Class Initialized
DEBUG - 2021-03-27 00:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:44:46 --> Input Class Initialized
INFO - 2021-03-27 00:44:46 --> Language Class Initialized
DEBUG - 2021-03-27 00:44:46 --> UTF-8 Support Enabled
DEBUG - 2021-03-27 00:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:44:46 --> Input Class Initialized
INFO - 2021-03-27 00:44:46 --> Utf8 Class Initialized
INFO - 2021-03-27 00:44:46 --> Language Class Initialized
ERROR - 2021-03-27 00:44:46 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-27 00:44:46 --> URI Class Initialized
ERROR - 2021-03-27 00:44:46 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-27 00:44:46 --> Router Class Initialized
INFO - 2021-03-27 00:44:46 --> Output Class Initialized
INFO - 2021-03-27 00:44:46 --> Security Class Initialized
DEBUG - 2021-03-27 00:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:44:46 --> Input Class Initialized
INFO - 2021-03-27 00:44:46 --> Language Class Initialized
ERROR - 2021-03-27 00:44:46 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-27 00:44:46 --> Config Class Initialized
INFO - 2021-03-27 00:44:46 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:44:46 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:44:46 --> Utf8 Class Initialized
INFO - 2021-03-27 00:44:46 --> URI Class Initialized
INFO - 2021-03-27 00:44:46 --> Router Class Initialized
INFO - 2021-03-27 00:44:46 --> Output Class Initialized
INFO - 2021-03-27 00:44:46 --> Security Class Initialized
DEBUG - 2021-03-27 00:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:44:46 --> Input Class Initialized
INFO - 2021-03-27 00:44:46 --> Language Class Initialized
ERROR - 2021-03-27 00:44:46 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-27 00:44:50 --> Config Class Initialized
INFO - 2021-03-27 00:44:50 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:44:50 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:44:50 --> Utf8 Class Initialized
INFO - 2021-03-27 00:44:50 --> URI Class Initialized
INFO - 2021-03-27 00:44:50 --> Router Class Initialized
INFO - 2021-03-27 00:44:50 --> Output Class Initialized
INFO - 2021-03-27 00:44:50 --> Security Class Initialized
DEBUG - 2021-03-27 00:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:44:50 --> Input Class Initialized
INFO - 2021-03-27 00:44:50 --> Language Class Initialized
INFO - 2021-03-27 00:44:50 --> Loader Class Initialized
INFO - 2021-03-27 00:44:50 --> Helper loaded: url_helper
INFO - 2021-03-27 00:44:50 --> Helper loaded: form_helper
INFO - 2021-03-27 00:44:50 --> Helper loaded: common_helper
INFO - 2021-03-27 00:44:50 --> Helper loaded: util_helper
INFO - 2021-03-27 00:44:50 --> Database Driver Class Initialized
DEBUG - 2021-03-27 00:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 00:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 00:44:50 --> Form Validation Class Initialized
INFO - 2021-03-27 00:44:50 --> Controller Class Initialized
INFO - 2021-03-27 00:44:50 --> Model Class Initialized
INFO - 2021-03-27 00:44:50 --> Model Class Initialized
INFO - 2021-03-27 00:44:50 --> Model Class Initialized
INFO - 2021-03-27 00:44:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-27 00:44:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-27 00:44:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/list.php
INFO - 2021-03-27 00:44:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-27 00:44:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-27 00:44:50 --> Final output sent to browser
DEBUG - 2021-03-27 00:44:50 --> Total execution time: 0.0501
INFO - 2021-03-27 00:44:50 --> Config Class Initialized
INFO - 2021-03-27 00:44:50 --> Hooks Class Initialized
INFO - 2021-03-27 00:44:50 --> Config Class Initialized
INFO - 2021-03-27 00:44:50 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:44:50 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:44:50 --> Utf8 Class Initialized
INFO - 2021-03-27 00:44:50 --> URI Class Initialized
DEBUG - 2021-03-27 00:44:50 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:44:50 --> Utf8 Class Initialized
INFO - 2021-03-27 00:44:50 --> Router Class Initialized
INFO - 2021-03-27 00:44:50 --> URI Class Initialized
INFO - 2021-03-27 00:44:50 --> Output Class Initialized
INFO - 2021-03-27 00:44:50 --> Router Class Initialized
INFO - 2021-03-27 00:44:50 --> Security Class Initialized
INFO - 2021-03-27 00:44:50 --> Output Class Initialized
DEBUG - 2021-03-27 00:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:44:50 --> Input Class Initialized
INFO - 2021-03-27 00:44:50 --> Security Class Initialized
INFO - 2021-03-27 00:44:50 --> Language Class Initialized
DEBUG - 2021-03-27 00:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:44:50 --> Input Class Initialized
ERROR - 2021-03-27 00:44:50 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-27 00:44:50 --> Language Class Initialized
ERROR - 2021-03-27 00:44:50 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-27 00:44:50 --> Config Class Initialized
INFO - 2021-03-27 00:44:50 --> Hooks Class Initialized
INFO - 2021-03-27 00:44:50 --> Config Class Initialized
INFO - 2021-03-27 00:44:50 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:44:50 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:44:50 --> Utf8 Class Initialized
DEBUG - 2021-03-27 00:44:50 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:44:50 --> Utf8 Class Initialized
INFO - 2021-03-27 00:44:50 --> URI Class Initialized
INFO - 2021-03-27 00:44:50 --> URI Class Initialized
INFO - 2021-03-27 00:44:50 --> Router Class Initialized
INFO - 2021-03-27 00:44:50 --> Router Class Initialized
INFO - 2021-03-27 00:44:50 --> Output Class Initialized
INFO - 2021-03-27 00:44:50 --> Output Class Initialized
INFO - 2021-03-27 00:44:50 --> Security Class Initialized
INFO - 2021-03-27 00:44:50 --> Security Class Initialized
DEBUG - 2021-03-27 00:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-27 00:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:44:50 --> Input Class Initialized
INFO - 2021-03-27 00:44:50 --> Input Class Initialized
INFO - 2021-03-27 00:44:50 --> Language Class Initialized
INFO - 2021-03-27 00:44:50 --> Language Class Initialized
ERROR - 2021-03-27 00:44:50 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-27 00:44:50 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-27 00:44:54 --> Config Class Initialized
INFO - 2021-03-27 00:44:54 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:44:54 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:44:54 --> Utf8 Class Initialized
INFO - 2021-03-27 00:44:54 --> URI Class Initialized
INFO - 2021-03-27 00:44:54 --> Router Class Initialized
INFO - 2021-03-27 00:44:54 --> Output Class Initialized
INFO - 2021-03-27 00:44:54 --> Security Class Initialized
DEBUG - 2021-03-27 00:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:44:54 --> Input Class Initialized
INFO - 2021-03-27 00:44:54 --> Language Class Initialized
INFO - 2021-03-27 00:44:54 --> Loader Class Initialized
INFO - 2021-03-27 00:44:54 --> Helper loaded: url_helper
INFO - 2021-03-27 00:44:54 --> Helper loaded: form_helper
INFO - 2021-03-27 00:44:54 --> Helper loaded: common_helper
INFO - 2021-03-27 00:44:54 --> Helper loaded: util_helper
INFO - 2021-03-27 00:44:54 --> Database Driver Class Initialized
DEBUG - 2021-03-27 00:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 00:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 00:44:54 --> Form Validation Class Initialized
INFO - 2021-03-27 00:44:54 --> Controller Class Initialized
INFO - 2021-03-27 00:44:54 --> Model Class Initialized
INFO - 2021-03-27 00:44:54 --> Model Class Initialized
INFO - 2021-03-27 00:44:54 --> Model Class Initialized
INFO - 2021-03-27 00:44:54 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-27 00:44:54 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-27 00:44:54 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-27 00:44:54 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-27 00:44:54 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-27 00:44:54 --> Final output sent to browser
DEBUG - 2021-03-27 00:44:54 --> Total execution time: 0.0478
INFO - 2021-03-27 00:44:55 --> Config Class Initialized
INFO - 2021-03-27 00:44:55 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:44:55 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:44:55 --> Utf8 Class Initialized
INFO - 2021-03-27 00:44:55 --> URI Class Initialized
INFO - 2021-03-27 00:44:55 --> Router Class Initialized
INFO - 2021-03-27 00:44:55 --> Output Class Initialized
INFO - 2021-03-27 00:44:55 --> Security Class Initialized
DEBUG - 2021-03-27 00:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:44:55 --> Input Class Initialized
INFO - 2021-03-27 00:44:55 --> Language Class Initialized
INFO - 2021-03-27 00:44:55 --> Loader Class Initialized
INFO - 2021-03-27 00:44:55 --> Helper loaded: url_helper
INFO - 2021-03-27 00:44:55 --> Helper loaded: form_helper
INFO - 2021-03-27 00:44:55 --> Helper loaded: common_helper
INFO - 2021-03-27 00:44:55 --> Config Class Initialized
INFO - 2021-03-27 00:44:55 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:44:55 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:44:55 --> Utf8 Class Initialized
INFO - 2021-03-27 00:44:55 --> URI Class Initialized
INFO - 2021-03-27 00:44:55 --> Router Class Initialized
INFO - 2021-03-27 00:44:55 --> Output Class Initialized
INFO - 2021-03-27 00:44:55 --> Security Class Initialized
DEBUG - 2021-03-27 00:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:44:55 --> Input Class Initialized
INFO - 2021-03-27 00:44:55 --> Helper loaded: util_helper
INFO - 2021-03-27 00:44:55 --> Language Class Initialized
INFO - 2021-03-27 00:44:55 --> Loader Class Initialized
INFO - 2021-03-27 00:44:55 --> Helper loaded: url_helper
INFO - 2021-03-27 00:44:55 --> Database Driver Class Initialized
INFO - 2021-03-27 00:44:55 --> Helper loaded: form_helper
INFO - 2021-03-27 00:44:55 --> Helper loaded: common_helper
INFO - 2021-03-27 00:44:55 --> Helper loaded: util_helper
DEBUG - 2021-03-27 00:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 00:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 00:44:55 --> Form Validation Class Initialized
INFO - 2021-03-27 00:44:55 --> Controller Class Initialized
INFO - 2021-03-27 00:44:55 --> Model Class Initialized
INFO - 2021-03-27 00:44:55 --> Model Class Initialized
INFO - 2021-03-27 00:44:55 --> Model Class Initialized
INFO - 2021-03-27 00:44:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-27 00:44:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-27 00:44:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-27 00:44:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-27 00:44:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-27 00:44:55 --> Final output sent to browser
DEBUG - 2021-03-27 00:44:55 --> Total execution time: 0.0681
INFO - 2021-03-27 00:44:55 --> Config Class Initialized
INFO - 2021-03-27 00:44:55 --> Hooks Class Initialized
INFO - 2021-03-27 00:44:55 --> Database Driver Class Initialized
DEBUG - 2021-03-27 00:44:55 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:44:55 --> Utf8 Class Initialized
INFO - 2021-03-27 00:44:55 --> URI Class Initialized
DEBUG - 2021-03-27 00:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 00:44:55 --> Router Class Initialized
INFO - 2021-03-27 00:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 00:44:55 --> Config Class Initialized
INFO - 2021-03-27 00:44:55 --> Hooks Class Initialized
INFO - 2021-03-27 00:44:55 --> Output Class Initialized
INFO - 2021-03-27 00:44:55 --> Form Validation Class Initialized
INFO - 2021-03-27 00:44:55 --> Controller Class Initialized
INFO - 2021-03-27 00:44:55 --> Security Class Initialized
DEBUG - 2021-03-27 00:44:55 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:44:55 --> Utf8 Class Initialized
INFO - 2021-03-27 00:44:55 --> Model Class Initialized
DEBUG - 2021-03-27 00:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:44:55 --> Model Class Initialized
INFO - 2021-03-27 00:44:55 --> Input Class Initialized
INFO - 2021-03-27 00:44:55 --> URI Class Initialized
INFO - 2021-03-27 00:44:55 --> Model Class Initialized
INFO - 2021-03-27 00:44:55 --> Language Class Initialized
INFO - 2021-03-27 00:44:55 --> Router Class Initialized
INFO - 2021-03-27 00:44:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-27 00:44:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-27 00:44:55 --> Output Class Initialized
INFO - 2021-03-27 00:44:55 --> Loader Class Initialized
INFO - 2021-03-27 00:44:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-27 00:44:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-27 00:44:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-27 00:44:55 --> Security Class Initialized
INFO - 2021-03-27 00:44:55 --> Final output sent to browser
DEBUG - 2021-03-27 00:44:55 --> Total execution time: 0.0881
INFO - 2021-03-27 00:44:55 --> Helper loaded: url_helper
DEBUG - 2021-03-27 00:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:44:55 --> Input Class Initialized
INFO - 2021-03-27 00:44:55 --> Helper loaded: form_helper
INFO - 2021-03-27 00:44:55 --> Language Class Initialized
INFO - 2021-03-27 00:44:55 --> Helper loaded: common_helper
INFO - 2021-03-27 00:44:55 --> Helper loaded: util_helper
INFO - 2021-03-27 00:44:55 --> Loader Class Initialized
INFO - 2021-03-27 00:44:55 --> Helper loaded: url_helper
INFO - 2021-03-27 00:44:55 --> Helper loaded: form_helper
INFO - 2021-03-27 00:44:55 --> Database Driver Class Initialized
INFO - 2021-03-27 00:44:55 --> Helper loaded: common_helper
INFO - 2021-03-27 00:44:55 --> Helper loaded: util_helper
DEBUG - 2021-03-27 00:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 00:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 00:44:55 --> Form Validation Class Initialized
INFO - 2021-03-27 00:44:55 --> Controller Class Initialized
INFO - 2021-03-27 00:44:55 --> Database Driver Class Initialized
INFO - 2021-03-27 00:44:55 --> Model Class Initialized
INFO - 2021-03-27 00:44:55 --> Model Class Initialized
INFO - 2021-03-27 00:44:55 --> Model Class Initialized
DEBUG - 2021-03-27 00:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 00:44:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-27 00:44:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-27 00:44:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-27 00:44:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-27 00:44:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-27 00:44:55 --> Final output sent to browser
DEBUG - 2021-03-27 00:44:55 --> Total execution time: 0.0566
INFO - 2021-03-27 00:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 00:44:55 --> Form Validation Class Initialized
INFO - 2021-03-27 00:44:55 --> Controller Class Initialized
INFO - 2021-03-27 00:44:55 --> Model Class Initialized
INFO - 2021-03-27 00:44:55 --> Model Class Initialized
INFO - 2021-03-27 00:44:55 --> Model Class Initialized
INFO - 2021-03-27 00:44:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-27 00:44:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-27 00:44:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-27 00:44:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-27 00:44:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-27 00:44:55 --> Final output sent to browser
DEBUG - 2021-03-27 00:44:55 --> Total execution time: 0.0574
INFO - 2021-03-27 00:45:39 --> Config Class Initialized
INFO - 2021-03-27 00:45:39 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:45:39 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:45:39 --> Utf8 Class Initialized
INFO - 2021-03-27 00:45:39 --> URI Class Initialized
INFO - 2021-03-27 00:45:39 --> Router Class Initialized
INFO - 2021-03-27 00:45:39 --> Output Class Initialized
INFO - 2021-03-27 00:45:39 --> Security Class Initialized
DEBUG - 2021-03-27 00:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:45:39 --> Input Class Initialized
INFO - 2021-03-27 00:45:39 --> Language Class Initialized
INFO - 2021-03-27 00:45:39 --> Loader Class Initialized
INFO - 2021-03-27 00:45:39 --> Helper loaded: url_helper
INFO - 2021-03-27 00:45:39 --> Helper loaded: form_helper
INFO - 2021-03-27 00:45:39 --> Helper loaded: common_helper
INFO - 2021-03-27 00:45:39 --> Helper loaded: util_helper
INFO - 2021-03-27 00:45:39 --> Database Driver Class Initialized
DEBUG - 2021-03-27 00:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 00:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 00:45:39 --> Form Validation Class Initialized
INFO - 2021-03-27 00:45:39 --> Controller Class Initialized
INFO - 2021-03-27 00:45:39 --> Model Class Initialized
INFO - 2021-03-27 00:45:39 --> Config Class Initialized
INFO - 2021-03-27 00:45:39 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:45:39 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:45:39 --> Utf8 Class Initialized
INFO - 2021-03-27 00:45:39 --> URI Class Initialized
INFO - 2021-03-27 00:45:39 --> Router Class Initialized
INFO - 2021-03-27 00:45:39 --> Output Class Initialized
INFO - 2021-03-27 00:45:39 --> Security Class Initialized
DEBUG - 2021-03-27 00:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:45:39 --> Input Class Initialized
INFO - 2021-03-27 00:45:39 --> Language Class Initialized
INFO - 2021-03-27 00:45:39 --> Loader Class Initialized
INFO - 2021-03-27 00:45:39 --> Helper loaded: url_helper
INFO - 2021-03-27 00:45:39 --> Helper loaded: form_helper
INFO - 2021-03-27 00:45:39 --> Helper loaded: common_helper
INFO - 2021-03-27 00:45:39 --> Helper loaded: util_helper
INFO - 2021-03-27 00:45:39 --> Database Driver Class Initialized
DEBUG - 2021-03-27 00:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 00:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 00:45:39 --> Form Validation Class Initialized
INFO - 2021-03-27 00:45:39 --> Controller Class Initialized
INFO - 2021-03-27 00:45:39 --> Model Class Initialized
INFO - 2021-03-27 00:45:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/login.php
INFO - 2021-03-27 00:45:39 --> Final output sent to browser
DEBUG - 2021-03-27 00:45:39 --> Total execution time: 0.0433
INFO - 2021-03-27 00:45:44 --> Config Class Initialized
INFO - 2021-03-27 00:45:44 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:45:44 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:45:44 --> Utf8 Class Initialized
INFO - 2021-03-27 00:45:44 --> URI Class Initialized
INFO - 2021-03-27 00:45:44 --> Router Class Initialized
INFO - 2021-03-27 00:45:44 --> Output Class Initialized
INFO - 2021-03-27 00:45:44 --> Security Class Initialized
DEBUG - 2021-03-27 00:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:45:44 --> Input Class Initialized
INFO - 2021-03-27 00:45:44 --> Language Class Initialized
INFO - 2021-03-27 00:45:44 --> Loader Class Initialized
INFO - 2021-03-27 00:45:44 --> Helper loaded: url_helper
INFO - 2021-03-27 00:45:44 --> Helper loaded: form_helper
INFO - 2021-03-27 00:45:44 --> Helper loaded: common_helper
INFO - 2021-03-27 00:45:44 --> Helper loaded: util_helper
INFO - 2021-03-27 00:45:44 --> Database Driver Class Initialized
DEBUG - 2021-03-27 00:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 00:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 00:45:44 --> Form Validation Class Initialized
INFO - 2021-03-27 00:45:44 --> Controller Class Initialized
INFO - 2021-03-27 00:45:44 --> Model Class Initialized
INFO - 2021-03-27 00:45:44 --> Config Class Initialized
INFO - 2021-03-27 00:45:44 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:45:44 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:45:44 --> Utf8 Class Initialized
INFO - 2021-03-27 00:45:44 --> URI Class Initialized
INFO - 2021-03-27 00:45:44 --> Router Class Initialized
INFO - 2021-03-27 00:45:44 --> Output Class Initialized
INFO - 2021-03-27 00:45:44 --> Security Class Initialized
DEBUG - 2021-03-27 00:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:45:44 --> Input Class Initialized
INFO - 2021-03-27 00:45:44 --> Language Class Initialized
INFO - 2021-03-27 00:45:44 --> Loader Class Initialized
INFO - 2021-03-27 00:45:44 --> Helper loaded: url_helper
INFO - 2021-03-27 00:45:44 --> Helper loaded: form_helper
INFO - 2021-03-27 00:45:44 --> Helper loaded: common_helper
INFO - 2021-03-27 00:45:44 --> Helper loaded: util_helper
INFO - 2021-03-27 00:45:44 --> Database Driver Class Initialized
DEBUG - 2021-03-27 00:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 00:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 00:45:44 --> Form Validation Class Initialized
INFO - 2021-03-27 00:45:44 --> Controller Class Initialized
INFO - 2021-03-27 00:45:44 --> Model Class Initialized
INFO - 2021-03-27 00:45:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-27 00:45:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-27 00:45:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/dashboard.php
INFO - 2021-03-27 00:45:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-27 00:45:44 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-27 00:45:44 --> Final output sent to browser
DEBUG - 2021-03-27 00:45:44 --> Total execution time: 0.0477
INFO - 2021-03-27 00:45:44 --> Config Class Initialized
INFO - 2021-03-27 00:45:44 --> Hooks Class Initialized
INFO - 2021-03-27 00:45:44 --> Config Class Initialized
INFO - 2021-03-27 00:45:44 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:45:44 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:45:44 --> Utf8 Class Initialized
DEBUG - 2021-03-27 00:45:44 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:45:44 --> Utf8 Class Initialized
INFO - 2021-03-27 00:45:44 --> URI Class Initialized
INFO - 2021-03-27 00:45:44 --> URI Class Initialized
INFO - 2021-03-27 00:45:44 --> Router Class Initialized
INFO - 2021-03-27 00:45:44 --> Router Class Initialized
INFO - 2021-03-27 00:45:44 --> Output Class Initialized
INFO - 2021-03-27 00:45:44 --> Output Class Initialized
INFO - 2021-03-27 00:45:44 --> Security Class Initialized
INFO - 2021-03-27 00:45:44 --> Security Class Initialized
DEBUG - 2021-03-27 00:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-27 00:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:45:44 --> Input Class Initialized
INFO - 2021-03-27 00:45:44 --> Input Class Initialized
INFO - 2021-03-27 00:45:44 --> Language Class Initialized
INFO - 2021-03-27 00:45:44 --> Language Class Initialized
ERROR - 2021-03-27 00:45:44 --> 404 Page Not Found: Admin/dist
ERROR - 2021-03-27 00:45:44 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-27 00:45:44 --> Config Class Initialized
INFO - 2021-03-27 00:45:44 --> Hooks Class Initialized
INFO - 2021-03-27 00:45:44 --> Config Class Initialized
INFO - 2021-03-27 00:45:44 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:45:44 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:45:44 --> Utf8 Class Initialized
DEBUG - 2021-03-27 00:45:44 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:45:44 --> Utf8 Class Initialized
INFO - 2021-03-27 00:45:44 --> URI Class Initialized
INFO - 2021-03-27 00:45:44 --> URI Class Initialized
INFO - 2021-03-27 00:45:44 --> Router Class Initialized
INFO - 2021-03-27 00:45:44 --> Router Class Initialized
INFO - 2021-03-27 00:45:44 --> Output Class Initialized
INFO - 2021-03-27 00:45:44 --> Output Class Initialized
INFO - 2021-03-27 00:45:44 --> Security Class Initialized
INFO - 2021-03-27 00:45:44 --> Security Class Initialized
DEBUG - 2021-03-27 00:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-27 00:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:45:44 --> Input Class Initialized
INFO - 2021-03-27 00:45:44 --> Input Class Initialized
INFO - 2021-03-27 00:45:44 --> Language Class Initialized
INFO - 2021-03-27 00:45:44 --> Language Class Initialized
ERROR - 2021-03-27 00:45:44 --> 404 Page Not Found: Admin/dist
ERROR - 2021-03-27 00:45:44 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-27 00:45:51 --> Config Class Initialized
INFO - 2021-03-27 00:45:51 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:45:51 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:45:51 --> Utf8 Class Initialized
INFO - 2021-03-27 00:45:51 --> URI Class Initialized
INFO - 2021-03-27 00:45:51 --> Router Class Initialized
INFO - 2021-03-27 00:45:51 --> Output Class Initialized
INFO - 2021-03-27 00:45:51 --> Security Class Initialized
DEBUG - 2021-03-27 00:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:45:51 --> Input Class Initialized
INFO - 2021-03-27 00:45:51 --> Language Class Initialized
INFO - 2021-03-27 00:45:51 --> Loader Class Initialized
INFO - 2021-03-27 00:45:51 --> Helper loaded: url_helper
INFO - 2021-03-27 00:45:51 --> Helper loaded: form_helper
INFO - 2021-03-27 00:45:51 --> Helper loaded: common_helper
INFO - 2021-03-27 00:45:51 --> Helper loaded: util_helper
INFO - 2021-03-27 00:45:51 --> Database Driver Class Initialized
DEBUG - 2021-03-27 00:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 00:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 00:45:51 --> Form Validation Class Initialized
INFO - 2021-03-27 00:45:51 --> Controller Class Initialized
INFO - 2021-03-27 00:45:51 --> Model Class Initialized
INFO - 2021-03-27 00:45:51 --> Model Class Initialized
INFO - 2021-03-27 00:45:51 --> Model Class Initialized
INFO - 2021-03-27 00:45:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-27 00:45:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-27 00:45:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/list.php
INFO - 2021-03-27 00:45:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-27 00:45:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-27 00:45:51 --> Final output sent to browser
DEBUG - 2021-03-27 00:45:51 --> Total execution time: 0.0349
INFO - 2021-03-27 00:45:51 --> Config Class Initialized
INFO - 2021-03-27 00:45:51 --> Hooks Class Initialized
INFO - 2021-03-27 00:45:51 --> Config Class Initialized
INFO - 2021-03-27 00:45:51 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:45:51 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:45:51 --> Utf8 Class Initialized
INFO - 2021-03-27 00:45:51 --> URI Class Initialized
INFO - 2021-03-27 00:45:51 --> Router Class Initialized
DEBUG - 2021-03-27 00:45:51 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:45:51 --> Utf8 Class Initialized
INFO - 2021-03-27 00:45:51 --> Output Class Initialized
INFO - 2021-03-27 00:45:51 --> URI Class Initialized
INFO - 2021-03-27 00:45:51 --> Security Class Initialized
INFO - 2021-03-27 00:45:51 --> Router Class Initialized
DEBUG - 2021-03-27 00:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:45:51 --> Input Class Initialized
INFO - 2021-03-27 00:45:51 --> Language Class Initialized
INFO - 2021-03-27 00:45:51 --> Output Class Initialized
ERROR - 2021-03-27 00:45:51 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-27 00:45:51 --> Security Class Initialized
DEBUG - 2021-03-27 00:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:45:51 --> Input Class Initialized
INFO - 2021-03-27 00:45:51 --> Language Class Initialized
ERROR - 2021-03-27 00:45:51 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-27 00:45:51 --> Config Class Initialized
INFO - 2021-03-27 00:45:51 --> Hooks Class Initialized
INFO - 2021-03-27 00:45:51 --> Config Class Initialized
INFO - 2021-03-27 00:45:51 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:45:51 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:45:51 --> Utf8 Class Initialized
INFO - 2021-03-27 00:45:51 --> URI Class Initialized
DEBUG - 2021-03-27 00:45:51 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:45:51 --> Utf8 Class Initialized
INFO - 2021-03-27 00:45:51 --> Router Class Initialized
INFO - 2021-03-27 00:45:51 --> URI Class Initialized
INFO - 2021-03-27 00:45:51 --> Output Class Initialized
INFO - 2021-03-27 00:45:51 --> Router Class Initialized
INFO - 2021-03-27 00:45:51 --> Security Class Initialized
INFO - 2021-03-27 00:45:51 --> Output Class Initialized
DEBUG - 2021-03-27 00:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:45:51 --> Input Class Initialized
INFO - 2021-03-27 00:45:51 --> Security Class Initialized
INFO - 2021-03-27 00:45:51 --> Language Class Initialized
DEBUG - 2021-03-27 00:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:45:51 --> Input Class Initialized
ERROR - 2021-03-27 00:45:51 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-27 00:45:51 --> Language Class Initialized
ERROR - 2021-03-27 00:45:51 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-27 00:52:25 --> Config Class Initialized
INFO - 2021-03-27 00:52:25 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:52:25 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:52:25 --> Utf8 Class Initialized
INFO - 2021-03-27 00:52:25 --> URI Class Initialized
INFO - 2021-03-27 00:52:25 --> Router Class Initialized
INFO - 2021-03-27 00:52:25 --> Output Class Initialized
INFO - 2021-03-27 00:52:25 --> Security Class Initialized
DEBUG - 2021-03-27 00:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:52:25 --> Input Class Initialized
INFO - 2021-03-27 00:52:25 --> Language Class Initialized
INFO - 2021-03-27 00:52:25 --> Loader Class Initialized
INFO - 2021-03-27 00:52:25 --> Helper loaded: url_helper
INFO - 2021-03-27 00:52:25 --> Helper loaded: form_helper
INFO - 2021-03-27 00:52:25 --> Helper loaded: common_helper
INFO - 2021-03-27 00:52:25 --> Helper loaded: util_helper
INFO - 2021-03-27 00:52:25 --> Database Driver Class Initialized
DEBUG - 2021-03-27 00:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 00:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 00:52:25 --> Form Validation Class Initialized
INFO - 2021-03-27 00:52:25 --> Controller Class Initialized
INFO - 2021-03-27 00:52:25 --> Model Class Initialized
INFO - 2021-03-27 00:52:25 --> Model Class Initialized
INFO - 2021-03-27 00:52:25 --> Model Class Initialized
INFO - 2021-03-27 00:52:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-27 00:52:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-27 00:52:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/list.php
INFO - 2021-03-27 00:52:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-27 00:52:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-27 00:52:25 --> Final output sent to browser
DEBUG - 2021-03-27 00:52:25 --> Total execution time: 0.0366
INFO - 2021-03-27 00:52:25 --> Config Class Initialized
INFO - 2021-03-27 00:52:25 --> Hooks Class Initialized
INFO - 2021-03-27 00:52:25 --> Config Class Initialized
INFO - 2021-03-27 00:52:25 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:52:25 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:52:25 --> Utf8 Class Initialized
INFO - 2021-03-27 00:52:25 --> URI Class Initialized
DEBUG - 2021-03-27 00:52:25 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:52:25 --> Utf8 Class Initialized
INFO - 2021-03-27 00:52:25 --> Router Class Initialized
INFO - 2021-03-27 00:52:25 --> URI Class Initialized
INFO - 2021-03-27 00:52:25 --> Output Class Initialized
INFO - 2021-03-27 00:52:25 --> Router Class Initialized
INFO - 2021-03-27 00:52:25 --> Security Class Initialized
DEBUG - 2021-03-27 00:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:52:25 --> Input Class Initialized
INFO - 2021-03-27 00:52:25 --> Output Class Initialized
INFO - 2021-03-27 00:52:25 --> Language Class Initialized
INFO - 2021-03-27 00:52:25 --> Security Class Initialized
DEBUG - 2021-03-27 00:52:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-03-27 00:52:25 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-27 00:52:25 --> Input Class Initialized
INFO - 2021-03-27 00:52:25 --> Language Class Initialized
ERROR - 2021-03-27 00:52:25 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-27 00:52:25 --> Config Class Initialized
INFO - 2021-03-27 00:52:25 --> Hooks Class Initialized
INFO - 2021-03-27 00:52:25 --> Config Class Initialized
INFO - 2021-03-27 00:52:25 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:52:25 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:52:25 --> Utf8 Class Initialized
DEBUG - 2021-03-27 00:52:25 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:52:25 --> Utf8 Class Initialized
INFO - 2021-03-27 00:52:25 --> URI Class Initialized
INFO - 2021-03-27 00:52:25 --> URI Class Initialized
INFO - 2021-03-27 00:52:25 --> Router Class Initialized
INFO - 2021-03-27 00:52:25 --> Router Class Initialized
INFO - 2021-03-27 00:52:25 --> Output Class Initialized
INFO - 2021-03-27 00:52:25 --> Output Class Initialized
INFO - 2021-03-27 00:52:25 --> Security Class Initialized
DEBUG - 2021-03-27 00:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:52:25 --> Security Class Initialized
INFO - 2021-03-27 00:52:25 --> Input Class Initialized
INFO - 2021-03-27 00:52:25 --> Language Class Initialized
DEBUG - 2021-03-27 00:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:52:25 --> Input Class Initialized
INFO - 2021-03-27 00:52:25 --> Language Class Initialized
ERROR - 2021-03-27 00:52:25 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-27 00:52:25 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-27 00:53:45 --> Config Class Initialized
INFO - 2021-03-27 00:53:45 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:53:45 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:53:45 --> Utf8 Class Initialized
INFO - 2021-03-27 00:53:45 --> URI Class Initialized
INFO - 2021-03-27 00:53:45 --> Router Class Initialized
INFO - 2021-03-27 00:53:45 --> Output Class Initialized
INFO - 2021-03-27 00:53:45 --> Security Class Initialized
DEBUG - 2021-03-27 00:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:53:45 --> Input Class Initialized
INFO - 2021-03-27 00:53:45 --> Language Class Initialized
INFO - 2021-03-27 00:53:45 --> Loader Class Initialized
INFO - 2021-03-27 00:53:45 --> Helper loaded: url_helper
INFO - 2021-03-27 00:53:45 --> Helper loaded: form_helper
INFO - 2021-03-27 00:53:45 --> Helper loaded: common_helper
INFO - 2021-03-27 00:53:45 --> Helper loaded: util_helper
INFO - 2021-03-27 00:53:45 --> Database Driver Class Initialized
DEBUG - 2021-03-27 00:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 00:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 00:53:45 --> Form Validation Class Initialized
INFO - 2021-03-27 00:53:45 --> Controller Class Initialized
INFO - 2021-03-27 00:53:45 --> Model Class Initialized
INFO - 2021-03-27 00:53:45 --> Config Class Initialized
INFO - 2021-03-27 00:53:45 --> Hooks Class Initialized
DEBUG - 2021-03-27 00:53:45 --> UTF-8 Support Enabled
INFO - 2021-03-27 00:53:45 --> Utf8 Class Initialized
INFO - 2021-03-27 00:53:45 --> URI Class Initialized
INFO - 2021-03-27 00:53:45 --> Router Class Initialized
INFO - 2021-03-27 00:53:45 --> Output Class Initialized
INFO - 2021-03-27 00:53:45 --> Security Class Initialized
DEBUG - 2021-03-27 00:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 00:53:45 --> Input Class Initialized
INFO - 2021-03-27 00:53:45 --> Language Class Initialized
INFO - 2021-03-27 00:53:45 --> Loader Class Initialized
INFO - 2021-03-27 00:53:45 --> Helper loaded: url_helper
INFO - 2021-03-27 00:53:45 --> Helper loaded: form_helper
INFO - 2021-03-27 00:53:45 --> Helper loaded: common_helper
INFO - 2021-03-27 00:53:45 --> Helper loaded: util_helper
INFO - 2021-03-27 00:53:45 --> Database Driver Class Initialized
DEBUG - 2021-03-27 00:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 00:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 00:53:45 --> Form Validation Class Initialized
INFO - 2021-03-27 00:53:45 --> Controller Class Initialized
INFO - 2021-03-27 00:53:45 --> Model Class Initialized
INFO - 2021-03-27 00:53:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/login.php
INFO - 2021-03-27 00:53:45 --> Final output sent to browser
DEBUG - 2021-03-27 00:53:45 --> Total execution time: 0.0310
INFO - 2021-03-27 01:40:48 --> Config Class Initialized
INFO - 2021-03-27 01:40:48 --> Hooks Class Initialized
DEBUG - 2021-03-27 01:40:48 --> UTF-8 Support Enabled
INFO - 2021-03-27 01:40:48 --> Utf8 Class Initialized
INFO - 2021-03-27 01:40:48 --> URI Class Initialized
INFO - 2021-03-27 01:40:48 --> Router Class Initialized
INFO - 2021-03-27 01:40:48 --> Output Class Initialized
INFO - 2021-03-27 01:40:48 --> Security Class Initialized
DEBUG - 2021-03-27 01:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 01:40:48 --> Input Class Initialized
INFO - 2021-03-27 01:40:48 --> Language Class Initialized
INFO - 2021-03-27 01:40:48 --> Loader Class Initialized
INFO - 2021-03-27 01:40:48 --> Helper loaded: url_helper
INFO - 2021-03-27 01:40:48 --> Helper loaded: form_helper
INFO - 2021-03-27 01:40:48 --> Helper loaded: common_helper
INFO - 2021-03-27 01:40:48 --> Helper loaded: util_helper
INFO - 2021-03-27 01:40:48 --> Database Driver Class Initialized
DEBUG - 2021-03-27 01:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 01:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 01:40:48 --> Form Validation Class Initialized
INFO - 2021-03-27 01:40:48 --> Controller Class Initialized
INFO - 2021-03-27 01:40:48 --> Model Class Initialized
INFO - 2021-03-27 01:40:48 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/login.php
INFO - 2021-03-27 01:40:48 --> Final output sent to browser
DEBUG - 2021-03-27 01:40:48 --> Total execution time: 0.0413
INFO - 2021-03-27 01:40:59 --> Config Class Initialized
INFO - 2021-03-27 01:40:59 --> Hooks Class Initialized
DEBUG - 2021-03-27 01:40:59 --> UTF-8 Support Enabled
INFO - 2021-03-27 01:40:59 --> Utf8 Class Initialized
INFO - 2021-03-27 01:40:59 --> URI Class Initialized
INFO - 2021-03-27 01:40:59 --> Router Class Initialized
INFO - 2021-03-27 01:40:59 --> Output Class Initialized
INFO - 2021-03-27 01:40:59 --> Security Class Initialized
DEBUG - 2021-03-27 01:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 01:40:59 --> Input Class Initialized
INFO - 2021-03-27 01:40:59 --> Language Class Initialized
INFO - 2021-03-27 01:40:59 --> Loader Class Initialized
INFO - 2021-03-27 01:40:59 --> Helper loaded: url_helper
INFO - 2021-03-27 01:40:59 --> Helper loaded: form_helper
INFO - 2021-03-27 01:40:59 --> Helper loaded: common_helper
INFO - 2021-03-27 01:40:59 --> Helper loaded: util_helper
INFO - 2021-03-27 01:40:59 --> Database Driver Class Initialized
DEBUG - 2021-03-27 01:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 01:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 01:40:59 --> Form Validation Class Initialized
INFO - 2021-03-27 01:40:59 --> Controller Class Initialized
INFO - 2021-03-27 01:40:59 --> Model Class Initialized
INFO - 2021-03-27 01:41:26 --> Config Class Initialized
INFO - 2021-03-27 01:41:26 --> Hooks Class Initialized
DEBUG - 2021-03-27 01:41:26 --> UTF-8 Support Enabled
INFO - 2021-03-27 01:41:26 --> Utf8 Class Initialized
INFO - 2021-03-27 01:41:26 --> URI Class Initialized
INFO - 2021-03-27 01:41:26 --> Router Class Initialized
INFO - 2021-03-27 01:41:26 --> Output Class Initialized
INFO - 2021-03-27 01:41:26 --> Security Class Initialized
DEBUG - 2021-03-27 01:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 01:41:26 --> Input Class Initialized
INFO - 2021-03-27 01:41:26 --> Language Class Initialized
INFO - 2021-03-27 01:41:26 --> Loader Class Initialized
INFO - 2021-03-27 01:41:26 --> Helper loaded: url_helper
INFO - 2021-03-27 01:41:26 --> Helper loaded: form_helper
INFO - 2021-03-27 01:41:26 --> Helper loaded: common_helper
INFO - 2021-03-27 01:41:26 --> Helper loaded: util_helper
INFO - 2021-03-27 01:41:26 --> Database Driver Class Initialized
DEBUG - 2021-03-27 01:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 01:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 01:41:26 --> Form Validation Class Initialized
INFO - 2021-03-27 01:41:26 --> Controller Class Initialized
INFO - 2021-03-27 01:41:26 --> Model Class Initialized
INFO - 2021-03-27 01:41:26 --> Config Class Initialized
INFO - 2021-03-27 01:41:26 --> Hooks Class Initialized
DEBUG - 2021-03-27 01:41:26 --> UTF-8 Support Enabled
INFO - 2021-03-27 01:41:26 --> Utf8 Class Initialized
INFO - 2021-03-27 01:41:26 --> URI Class Initialized
INFO - 2021-03-27 01:41:27 --> Router Class Initialized
INFO - 2021-03-27 01:41:27 --> Output Class Initialized
INFO - 2021-03-27 01:41:27 --> Security Class Initialized
DEBUG - 2021-03-27 01:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 01:41:27 --> Input Class Initialized
INFO - 2021-03-27 01:41:27 --> Language Class Initialized
INFO - 2021-03-27 01:41:27 --> Loader Class Initialized
INFO - 2021-03-27 01:41:27 --> Helper loaded: url_helper
INFO - 2021-03-27 01:41:27 --> Helper loaded: form_helper
INFO - 2021-03-27 01:41:27 --> Helper loaded: common_helper
INFO - 2021-03-27 01:41:27 --> Helper loaded: util_helper
INFO - 2021-03-27 01:41:27 --> Database Driver Class Initialized
DEBUG - 2021-03-27 01:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 01:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 01:41:27 --> Form Validation Class Initialized
INFO - 2021-03-27 01:41:27 --> Controller Class Initialized
INFO - 2021-03-27 01:41:27 --> Model Class Initialized
INFO - 2021-03-27 01:41:27 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/login.php
INFO - 2021-03-27 01:41:27 --> Final output sent to browser
DEBUG - 2021-03-27 01:41:27 --> Total execution time: 0.0303
INFO - 2021-03-27 01:41:41 --> Config Class Initialized
INFO - 2021-03-27 01:41:41 --> Hooks Class Initialized
DEBUG - 2021-03-27 01:41:41 --> UTF-8 Support Enabled
INFO - 2021-03-27 01:41:41 --> Utf8 Class Initialized
INFO - 2021-03-27 01:41:41 --> URI Class Initialized
INFO - 2021-03-27 01:41:41 --> Router Class Initialized
INFO - 2021-03-27 01:41:41 --> Output Class Initialized
INFO - 2021-03-27 01:41:41 --> Security Class Initialized
DEBUG - 2021-03-27 01:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 01:41:41 --> Input Class Initialized
INFO - 2021-03-27 01:41:41 --> Language Class Initialized
INFO - 2021-03-27 01:41:41 --> Loader Class Initialized
INFO - 2021-03-27 01:41:41 --> Helper loaded: url_helper
INFO - 2021-03-27 01:41:41 --> Helper loaded: form_helper
INFO - 2021-03-27 01:41:41 --> Helper loaded: common_helper
INFO - 2021-03-27 01:41:41 --> Helper loaded: util_helper
INFO - 2021-03-27 01:41:41 --> Database Driver Class Initialized
DEBUG - 2021-03-27 01:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 01:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 01:41:41 --> Form Validation Class Initialized
INFO - 2021-03-27 01:41:41 --> Controller Class Initialized
INFO - 2021-03-27 01:41:41 --> Model Class Initialized
INFO - 2021-03-27 01:41:41 --> Config Class Initialized
INFO - 2021-03-27 01:41:41 --> Hooks Class Initialized
DEBUG - 2021-03-27 01:41:41 --> UTF-8 Support Enabled
INFO - 2021-03-27 01:41:41 --> Utf8 Class Initialized
INFO - 2021-03-27 01:41:41 --> URI Class Initialized
INFO - 2021-03-27 01:41:41 --> Router Class Initialized
INFO - 2021-03-27 01:41:41 --> Output Class Initialized
INFO - 2021-03-27 01:41:41 --> Security Class Initialized
DEBUG - 2021-03-27 01:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 01:41:41 --> Input Class Initialized
INFO - 2021-03-27 01:41:41 --> Language Class Initialized
INFO - 2021-03-27 01:41:41 --> Loader Class Initialized
INFO - 2021-03-27 01:41:41 --> Helper loaded: url_helper
INFO - 2021-03-27 01:41:41 --> Helper loaded: form_helper
INFO - 2021-03-27 01:41:41 --> Helper loaded: common_helper
INFO - 2021-03-27 01:41:41 --> Helper loaded: util_helper
INFO - 2021-03-27 01:41:41 --> Database Driver Class Initialized
DEBUG - 2021-03-27 01:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 01:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 01:41:41 --> Form Validation Class Initialized
INFO - 2021-03-27 01:41:41 --> Controller Class Initialized
INFO - 2021-03-27 01:41:41 --> Model Class Initialized
INFO - 2021-03-27 01:41:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/login.php
INFO - 2021-03-27 01:41:41 --> Final output sent to browser
DEBUG - 2021-03-27 01:41:41 --> Total execution time: 0.0443
INFO - 2021-03-27 01:42:02 --> Config Class Initialized
INFO - 2021-03-27 01:42:02 --> Hooks Class Initialized
DEBUG - 2021-03-27 01:42:02 --> UTF-8 Support Enabled
INFO - 2021-03-27 01:42:02 --> Utf8 Class Initialized
INFO - 2021-03-27 01:42:02 --> URI Class Initialized
INFO - 2021-03-27 01:42:02 --> Router Class Initialized
INFO - 2021-03-27 01:42:02 --> Output Class Initialized
INFO - 2021-03-27 01:42:02 --> Security Class Initialized
DEBUG - 2021-03-27 01:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 01:42:02 --> Input Class Initialized
INFO - 2021-03-27 01:42:02 --> Language Class Initialized
INFO - 2021-03-27 01:42:02 --> Loader Class Initialized
INFO - 2021-03-27 01:42:02 --> Helper loaded: url_helper
INFO - 2021-03-27 01:42:02 --> Helper loaded: form_helper
INFO - 2021-03-27 01:42:02 --> Helper loaded: common_helper
INFO - 2021-03-27 01:42:02 --> Helper loaded: util_helper
INFO - 2021-03-27 01:42:02 --> Database Driver Class Initialized
DEBUG - 2021-03-27 01:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 01:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 01:42:02 --> Form Validation Class Initialized
INFO - 2021-03-27 01:42:02 --> Controller Class Initialized
INFO - 2021-03-27 01:42:02 --> Model Class Initialized
INFO - 2021-03-27 01:43:09 --> Config Class Initialized
INFO - 2021-03-27 01:43:09 --> Hooks Class Initialized
DEBUG - 2021-03-27 01:43:09 --> UTF-8 Support Enabled
INFO - 2021-03-27 01:43:09 --> Utf8 Class Initialized
INFO - 2021-03-27 01:43:09 --> URI Class Initialized
INFO - 2021-03-27 01:43:09 --> Router Class Initialized
INFO - 2021-03-27 01:43:09 --> Output Class Initialized
INFO - 2021-03-27 01:43:09 --> Security Class Initialized
DEBUG - 2021-03-27 01:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 01:43:09 --> Input Class Initialized
INFO - 2021-03-27 01:43:09 --> Language Class Initialized
INFO - 2021-03-27 01:43:09 --> Loader Class Initialized
INFO - 2021-03-27 01:43:09 --> Helper loaded: url_helper
INFO - 2021-03-27 01:43:09 --> Helper loaded: form_helper
INFO - 2021-03-27 01:43:09 --> Helper loaded: common_helper
INFO - 2021-03-27 01:43:09 --> Helper loaded: util_helper
INFO - 2021-03-27 01:43:09 --> Database Driver Class Initialized
DEBUG - 2021-03-27 01:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 01:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 01:43:09 --> Form Validation Class Initialized
INFO - 2021-03-27 01:43:09 --> Controller Class Initialized
INFO - 2021-03-27 01:43:09 --> Model Class Initialized
INFO - 2021-03-27 01:43:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/login.php
INFO - 2021-03-27 01:43:09 --> Final output sent to browser
DEBUG - 2021-03-27 01:43:09 --> Total execution time: 0.0415
INFO - 2021-03-27 01:43:20 --> Config Class Initialized
INFO - 2021-03-27 01:43:20 --> Hooks Class Initialized
DEBUG - 2021-03-27 01:43:20 --> UTF-8 Support Enabled
INFO - 2021-03-27 01:43:20 --> Utf8 Class Initialized
INFO - 2021-03-27 01:43:20 --> URI Class Initialized
INFO - 2021-03-27 01:43:20 --> Router Class Initialized
INFO - 2021-03-27 01:43:20 --> Output Class Initialized
INFO - 2021-03-27 01:43:20 --> Security Class Initialized
DEBUG - 2021-03-27 01:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 01:43:20 --> Input Class Initialized
INFO - 2021-03-27 01:43:20 --> Language Class Initialized
INFO - 2021-03-27 01:43:20 --> Loader Class Initialized
INFO - 2021-03-27 01:43:20 --> Helper loaded: url_helper
INFO - 2021-03-27 01:43:20 --> Helper loaded: form_helper
INFO - 2021-03-27 01:43:20 --> Helper loaded: common_helper
INFO - 2021-03-27 01:43:20 --> Helper loaded: util_helper
INFO - 2021-03-27 01:43:20 --> Database Driver Class Initialized
DEBUG - 2021-03-27 01:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 01:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 01:43:20 --> Form Validation Class Initialized
INFO - 2021-03-27 01:43:20 --> Controller Class Initialized
INFO - 2021-03-27 01:43:20 --> Model Class Initialized
INFO - 2021-03-27 01:44:16 --> Config Class Initialized
INFO - 2021-03-27 01:44:16 --> Hooks Class Initialized
DEBUG - 2021-03-27 01:44:16 --> UTF-8 Support Enabled
INFO - 2021-03-27 01:44:16 --> Utf8 Class Initialized
INFO - 2021-03-27 01:44:16 --> URI Class Initialized
INFO - 2021-03-27 01:44:16 --> Router Class Initialized
INFO - 2021-03-27 01:44:16 --> Output Class Initialized
INFO - 2021-03-27 01:44:16 --> Security Class Initialized
DEBUG - 2021-03-27 01:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 01:44:16 --> Input Class Initialized
INFO - 2021-03-27 01:44:16 --> Language Class Initialized
INFO - 2021-03-27 01:44:16 --> Loader Class Initialized
INFO - 2021-03-27 01:44:16 --> Helper loaded: url_helper
INFO - 2021-03-27 01:44:16 --> Helper loaded: form_helper
INFO - 2021-03-27 01:44:16 --> Helper loaded: common_helper
INFO - 2021-03-27 01:44:16 --> Helper loaded: util_helper
INFO - 2021-03-27 01:44:16 --> Database Driver Class Initialized
DEBUG - 2021-03-27 01:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 01:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 01:44:16 --> Form Validation Class Initialized
INFO - 2021-03-27 01:44:16 --> Controller Class Initialized
INFO - 2021-03-27 01:44:16 --> Model Class Initialized
INFO - 2021-03-27 01:44:30 --> Config Class Initialized
INFO - 2021-03-27 01:44:30 --> Hooks Class Initialized
DEBUG - 2021-03-27 01:44:30 --> UTF-8 Support Enabled
INFO - 2021-03-27 01:44:30 --> Utf8 Class Initialized
INFO - 2021-03-27 01:44:30 --> URI Class Initialized
INFO - 2021-03-27 01:44:30 --> Router Class Initialized
INFO - 2021-03-27 01:44:30 --> Output Class Initialized
INFO - 2021-03-27 01:44:30 --> Security Class Initialized
DEBUG - 2021-03-27 01:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 01:44:30 --> Input Class Initialized
INFO - 2021-03-27 01:44:30 --> Language Class Initialized
INFO - 2021-03-27 01:44:30 --> Loader Class Initialized
INFO - 2021-03-27 01:44:30 --> Helper loaded: url_helper
INFO - 2021-03-27 01:44:30 --> Helper loaded: form_helper
INFO - 2021-03-27 01:44:30 --> Helper loaded: common_helper
INFO - 2021-03-27 01:44:30 --> Helper loaded: util_helper
INFO - 2021-03-27 01:44:30 --> Database Driver Class Initialized
DEBUG - 2021-03-27 01:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 01:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 01:44:30 --> Form Validation Class Initialized
INFO - 2021-03-27 01:44:30 --> Controller Class Initialized
INFO - 2021-03-27 01:44:30 --> Model Class Initialized
INFO - 2021-03-27 01:44:30 --> Config Class Initialized
INFO - 2021-03-27 01:44:30 --> Hooks Class Initialized
DEBUG - 2021-03-27 01:44:30 --> UTF-8 Support Enabled
INFO - 2021-03-27 01:44:30 --> Utf8 Class Initialized
INFO - 2021-03-27 01:44:30 --> URI Class Initialized
INFO - 2021-03-27 01:44:30 --> Router Class Initialized
INFO - 2021-03-27 01:44:30 --> Output Class Initialized
INFO - 2021-03-27 01:44:30 --> Security Class Initialized
DEBUG - 2021-03-27 01:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 01:44:30 --> Input Class Initialized
INFO - 2021-03-27 01:44:30 --> Language Class Initialized
INFO - 2021-03-27 01:44:30 --> Loader Class Initialized
INFO - 2021-03-27 01:44:30 --> Helper loaded: url_helper
INFO - 2021-03-27 01:44:30 --> Helper loaded: form_helper
INFO - 2021-03-27 01:44:30 --> Helper loaded: common_helper
INFO - 2021-03-27 01:44:30 --> Helper loaded: util_helper
INFO - 2021-03-27 01:44:30 --> Database Driver Class Initialized
DEBUG - 2021-03-27 01:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 01:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 01:44:30 --> Form Validation Class Initialized
INFO - 2021-03-27 01:44:30 --> Controller Class Initialized
INFO - 2021-03-27 01:44:30 --> Model Class Initialized
INFO - 2021-03-27 01:44:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-27 01:44:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-27 01:44:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/dashboard.php
INFO - 2021-03-27 01:44:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-27 01:44:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-27 01:44:30 --> Final output sent to browser
DEBUG - 2021-03-27 01:44:30 --> Total execution time: 0.0358
INFO - 2021-03-27 01:44:31 --> Config Class Initialized
INFO - 2021-03-27 01:44:31 --> Hooks Class Initialized
INFO - 2021-03-27 01:44:31 --> Config Class Initialized
INFO - 2021-03-27 01:44:31 --> Hooks Class Initialized
DEBUG - 2021-03-27 01:44:31 --> UTF-8 Support Enabled
INFO - 2021-03-27 01:44:31 --> Utf8 Class Initialized
DEBUG - 2021-03-27 01:44:31 --> UTF-8 Support Enabled
INFO - 2021-03-27 01:44:31 --> URI Class Initialized
INFO - 2021-03-27 01:44:31 --> Utf8 Class Initialized
INFO - 2021-03-27 01:44:31 --> URI Class Initialized
INFO - 2021-03-27 01:44:31 --> Router Class Initialized
INFO - 2021-03-27 01:44:31 --> Router Class Initialized
INFO - 2021-03-27 01:44:31 --> Output Class Initialized
INFO - 2021-03-27 01:44:31 --> Security Class Initialized
INFO - 2021-03-27 01:44:31 --> Output Class Initialized
DEBUG - 2021-03-27 01:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 01:44:31 --> Input Class Initialized
INFO - 2021-03-27 01:44:31 --> Security Class Initialized
INFO - 2021-03-27 01:44:31 --> Language Class Initialized
DEBUG - 2021-03-27 01:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 01:44:31 --> Input Class Initialized
INFO - 2021-03-27 01:44:31 --> Language Class Initialized
ERROR - 2021-03-27 01:44:31 --> 404 Page Not Found: Admin/dist
ERROR - 2021-03-27 01:44:31 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-27 01:44:31 --> Config Class Initialized
INFO - 2021-03-27 01:44:31 --> Hooks Class Initialized
DEBUG - 2021-03-27 01:44:31 --> UTF-8 Support Enabled
INFO - 2021-03-27 01:44:31 --> Utf8 Class Initialized
INFO - 2021-03-27 01:44:31 --> URI Class Initialized
INFO - 2021-03-27 01:44:31 --> Router Class Initialized
INFO - 2021-03-27 01:44:31 --> Output Class Initialized
INFO - 2021-03-27 01:44:31 --> Security Class Initialized
DEBUG - 2021-03-27 01:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 01:44:31 --> Input Class Initialized
INFO - 2021-03-27 01:44:31 --> Language Class Initialized
INFO - 2021-03-27 01:44:31 --> Config Class Initialized
INFO - 2021-03-27 01:44:31 --> Hooks Class Initialized
ERROR - 2021-03-27 01:44:31 --> 404 Page Not Found: Admin/dist
DEBUG - 2021-03-27 01:44:31 --> UTF-8 Support Enabled
INFO - 2021-03-27 01:44:31 --> Utf8 Class Initialized
INFO - 2021-03-27 01:44:31 --> URI Class Initialized
INFO - 2021-03-27 01:44:31 --> Router Class Initialized
INFO - 2021-03-27 01:44:31 --> Output Class Initialized
INFO - 2021-03-27 01:44:31 --> Security Class Initialized
DEBUG - 2021-03-27 01:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 01:44:31 --> Input Class Initialized
INFO - 2021-03-27 01:44:31 --> Language Class Initialized
ERROR - 2021-03-27 01:44:31 --> 404 Page Not Found: Admin/dist
INFO - 2021-03-27 01:47:11 --> Config Class Initialized
INFO - 2021-03-27 01:47:11 --> Hooks Class Initialized
DEBUG - 2021-03-27 01:47:11 --> UTF-8 Support Enabled
INFO - 2021-03-27 01:47:11 --> Utf8 Class Initialized
INFO - 2021-03-27 01:47:11 --> URI Class Initialized
INFO - 2021-03-27 01:47:11 --> Router Class Initialized
INFO - 2021-03-27 01:47:11 --> Output Class Initialized
INFO - 2021-03-27 01:47:11 --> Security Class Initialized
DEBUG - 2021-03-27 01:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 01:47:11 --> Input Class Initialized
INFO - 2021-03-27 01:47:11 --> Language Class Initialized
INFO - 2021-03-27 01:47:11 --> Loader Class Initialized
INFO - 2021-03-27 01:47:11 --> Helper loaded: url_helper
INFO - 2021-03-27 01:47:11 --> Helper loaded: form_helper
INFO - 2021-03-27 01:47:11 --> Helper loaded: common_helper
INFO - 2021-03-27 01:47:11 --> Helper loaded: util_helper
INFO - 2021-03-27 01:47:11 --> Database Driver Class Initialized
DEBUG - 2021-03-27 01:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 01:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 01:47:11 --> Form Validation Class Initialized
INFO - 2021-03-27 01:47:11 --> Controller Class Initialized
INFO - 2021-03-27 01:47:11 --> Model Class Initialized
INFO - 2021-03-27 01:47:11 --> Config Class Initialized
INFO - 2021-03-27 01:47:11 --> Hooks Class Initialized
DEBUG - 2021-03-27 01:47:11 --> UTF-8 Support Enabled
INFO - 2021-03-27 01:47:11 --> Utf8 Class Initialized
INFO - 2021-03-27 01:47:11 --> URI Class Initialized
INFO - 2021-03-27 01:47:11 --> Router Class Initialized
INFO - 2021-03-27 01:47:11 --> Output Class Initialized
INFO - 2021-03-27 01:47:11 --> Security Class Initialized
DEBUG - 2021-03-27 01:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-27 01:47:11 --> Input Class Initialized
INFO - 2021-03-27 01:47:11 --> Language Class Initialized
INFO - 2021-03-27 01:47:11 --> Loader Class Initialized
INFO - 2021-03-27 01:47:11 --> Helper loaded: url_helper
INFO - 2021-03-27 01:47:11 --> Helper loaded: form_helper
INFO - 2021-03-27 01:47:11 --> Helper loaded: common_helper
INFO - 2021-03-27 01:47:11 --> Helper loaded: util_helper
INFO - 2021-03-27 01:47:11 --> Database Driver Class Initialized
DEBUG - 2021-03-27 01:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-27 01:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-27 01:47:11 --> Form Validation Class Initialized
INFO - 2021-03-27 01:47:11 --> Controller Class Initialized
INFO - 2021-03-27 01:47:11 --> Model Class Initialized
INFO - 2021-03-27 01:47:11 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/login.php
INFO - 2021-03-27 01:47:11 --> Final output sent to browser
DEBUG - 2021-03-27 01:47:11 --> Total execution time: 0.0463

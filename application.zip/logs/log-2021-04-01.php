<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-04-01 00:13:37 --> Config Class Initialized
INFO - 2021-04-01 00:13:37 --> Hooks Class Initialized
DEBUG - 2021-04-01 00:13:37 --> UTF-8 Support Enabled
INFO - 2021-04-01 00:13:37 --> Utf8 Class Initialized
INFO - 2021-04-01 00:13:37 --> URI Class Initialized
INFO - 2021-04-01 00:13:37 --> Router Class Initialized
INFO - 2021-04-01 00:13:37 --> Output Class Initialized
INFO - 2021-04-01 00:13:37 --> Security Class Initialized
DEBUG - 2021-04-01 00:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-01 00:13:37 --> Input Class Initialized
INFO - 2021-04-01 00:13:38 --> Language Class Initialized
INFO - 2021-04-01 00:13:38 --> Loader Class Initialized
INFO - 2021-04-01 00:13:38 --> Helper loaded: url_helper
INFO - 2021-04-01 00:13:38 --> Helper loaded: form_helper
INFO - 2021-04-01 00:13:38 --> Helper loaded: common_helper
INFO - 2021-04-01 00:13:38 --> Helper loaded: util_helper
INFO - 2021-04-01 00:13:38 --> Database Driver Class Initialized
DEBUG - 2021-04-01 00:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-01 00:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-01 00:13:38 --> Form Validation Class Initialized
INFO - 2021-04-01 00:13:38 --> Controller Class Initialized
INFO - 2021-04-01 00:13:38 --> Model Class Initialized
INFO - 2021-04-01 00:13:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/login.php
INFO - 2021-04-01 00:13:38 --> Final output sent to browser
DEBUG - 2021-04-01 00:13:38 --> Total execution time: 0.0519
INFO - 2021-04-01 00:13:40 --> Config Class Initialized
INFO - 2021-04-01 00:13:40 --> Hooks Class Initialized
DEBUG - 2021-04-01 00:13:40 --> UTF-8 Support Enabled
INFO - 2021-04-01 00:13:40 --> Utf8 Class Initialized
INFO - 2021-04-01 00:13:40 --> URI Class Initialized
INFO - 2021-04-01 00:13:40 --> Router Class Initialized
INFO - 2021-04-01 00:13:40 --> Output Class Initialized
INFO - 2021-04-01 00:13:40 --> Security Class Initialized
DEBUG - 2021-04-01 00:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-01 00:13:40 --> Input Class Initialized
INFO - 2021-04-01 00:13:40 --> Language Class Initialized
INFO - 2021-04-01 00:13:40 --> Loader Class Initialized
INFO - 2021-04-01 00:13:40 --> Helper loaded: url_helper
INFO - 2021-04-01 00:13:40 --> Helper loaded: form_helper
INFO - 2021-04-01 00:13:40 --> Helper loaded: common_helper
INFO - 2021-04-01 00:13:40 --> Helper loaded: util_helper
INFO - 2021-04-01 00:13:40 --> Database Driver Class Initialized
DEBUG - 2021-04-01 00:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-01 00:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-01 00:13:40 --> Form Validation Class Initialized
INFO - 2021-04-01 00:13:40 --> Controller Class Initialized
INFO - 2021-04-01 00:13:40 --> Model Class Initialized
INFO - 2021-04-01 00:13:40 --> Config Class Initialized
INFO - 2021-04-01 00:13:40 --> Hooks Class Initialized
DEBUG - 2021-04-01 00:13:40 --> UTF-8 Support Enabled
INFO - 2021-04-01 00:13:40 --> Utf8 Class Initialized
INFO - 2021-04-01 00:13:40 --> URI Class Initialized
INFO - 2021-04-01 00:13:40 --> Router Class Initialized
INFO - 2021-04-01 00:13:40 --> Output Class Initialized
INFO - 2021-04-01 00:13:40 --> Security Class Initialized
DEBUG - 2021-04-01 00:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-01 00:13:40 --> Input Class Initialized
INFO - 2021-04-01 00:13:40 --> Language Class Initialized
INFO - 2021-04-01 00:13:40 --> Loader Class Initialized
INFO - 2021-04-01 00:13:40 --> Helper loaded: url_helper
INFO - 2021-04-01 00:13:40 --> Helper loaded: form_helper
INFO - 2021-04-01 00:13:40 --> Helper loaded: common_helper
INFO - 2021-04-01 00:13:40 --> Helper loaded: util_helper
INFO - 2021-04-01 00:13:40 --> Database Driver Class Initialized
DEBUG - 2021-04-01 00:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-01 00:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-01 00:13:40 --> Form Validation Class Initialized
INFO - 2021-04-01 00:13:40 --> Controller Class Initialized
INFO - 2021-04-01 00:13:40 --> Model Class Initialized
INFO - 2021-04-01 00:13:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-04-01 00:13:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-01 00:13:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/dashboard.php
INFO - 2021-04-01 00:13:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-04-01 00:13:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-04-01 00:13:40 --> Final output sent to browser
DEBUG - 2021-04-01 00:13:40 --> Total execution time: 0.0355
INFO - 2021-04-01 00:13:40 --> Config Class Initialized
INFO - 2021-04-01 00:13:40 --> Hooks Class Initialized
DEBUG - 2021-04-01 00:13:40 --> UTF-8 Support Enabled
INFO - 2021-04-01 00:13:40 --> Utf8 Class Initialized
INFO - 2021-04-01 00:13:40 --> URI Class Initialized
INFO - 2021-04-01 00:13:40 --> Router Class Initialized
INFO - 2021-04-01 00:13:40 --> Output Class Initialized
INFO - 2021-04-01 00:13:40 --> Security Class Initialized
DEBUG - 2021-04-01 00:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-01 00:13:40 --> Input Class Initialized
INFO - 2021-04-01 00:13:40 --> Language Class Initialized
ERROR - 2021-04-01 00:13:40 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-01 00:13:40 --> Config Class Initialized
INFO - 2021-04-01 00:13:40 --> Hooks Class Initialized
INFO - 2021-04-01 00:13:40 --> Config Class Initialized
INFO - 2021-04-01 00:13:40 --> Hooks Class Initialized
DEBUG - 2021-04-01 00:13:40 --> UTF-8 Support Enabled
INFO - 2021-04-01 00:13:40 --> Utf8 Class Initialized
INFO - 2021-04-01 00:13:40 --> URI Class Initialized
DEBUG - 2021-04-01 00:13:40 --> UTF-8 Support Enabled
INFO - 2021-04-01 00:13:40 --> Utf8 Class Initialized
INFO - 2021-04-01 00:13:40 --> Router Class Initialized
INFO - 2021-04-01 00:13:40 --> URI Class Initialized
INFO - 2021-04-01 00:13:40 --> Config Class Initialized
INFO - 2021-04-01 00:13:40 --> Hooks Class Initialized
INFO - 2021-04-01 00:13:40 --> Output Class Initialized
INFO - 2021-04-01 00:13:40 --> Router Class Initialized
INFO - 2021-04-01 00:13:40 --> Security Class Initialized
INFO - 2021-04-01 00:13:40 --> Output Class Initialized
DEBUG - 2021-04-01 00:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-01 00:13:40 --> Input Class Initialized
DEBUG - 2021-04-01 00:13:40 --> UTF-8 Support Enabled
INFO - 2021-04-01 00:13:40 --> Utf8 Class Initialized
INFO - 2021-04-01 00:13:40 --> Security Class Initialized
INFO - 2021-04-01 00:13:40 --> Language Class Initialized
INFO - 2021-04-01 00:13:40 --> URI Class Initialized
DEBUG - 2021-04-01 00:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-01 00:13:40 --> Input Class Initialized
ERROR - 2021-04-01 00:13:40 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-01 00:13:40 --> Language Class Initialized
INFO - 2021-04-01 00:13:40 --> Router Class Initialized
ERROR - 2021-04-01 00:13:40 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-01 00:13:40 --> Output Class Initialized
INFO - 2021-04-01 00:13:40 --> Security Class Initialized
DEBUG - 2021-04-01 00:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-01 00:13:40 --> Input Class Initialized
INFO - 2021-04-01 00:13:40 --> Language Class Initialized
ERROR - 2021-04-01 00:13:40 --> 404 Page Not Found: Admin/dist
INFO - 2021-04-01 00:13:43 --> Config Class Initialized
INFO - 2021-04-01 00:13:43 --> Hooks Class Initialized
DEBUG - 2021-04-01 00:13:43 --> UTF-8 Support Enabled
INFO - 2021-04-01 00:13:43 --> Utf8 Class Initialized
INFO - 2021-04-01 00:13:43 --> URI Class Initialized
INFO - 2021-04-01 00:13:43 --> Router Class Initialized
INFO - 2021-04-01 00:13:43 --> Output Class Initialized
INFO - 2021-04-01 00:13:43 --> Security Class Initialized
DEBUG - 2021-04-01 00:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-01 00:13:43 --> Input Class Initialized
INFO - 2021-04-01 00:13:43 --> Language Class Initialized
INFO - 2021-04-01 00:13:43 --> Loader Class Initialized
INFO - 2021-04-01 00:13:43 --> Helper loaded: url_helper
INFO - 2021-04-01 00:13:43 --> Helper loaded: form_helper
INFO - 2021-04-01 00:13:43 --> Helper loaded: common_helper
INFO - 2021-04-01 00:13:43 --> Helper loaded: util_helper
INFO - 2021-04-01 00:13:43 --> Database Driver Class Initialized
DEBUG - 2021-04-01 00:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-01 00:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-01 00:13:43 --> Form Validation Class Initialized
INFO - 2021-04-01 00:13:43 --> Controller Class Initialized
INFO - 2021-04-01 00:13:43 --> Model Class Initialized
INFO - 2021-04-01 00:13:43 --> Model Class Initialized
INFO - 2021-04-01 00:13:43 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-04-01 00:13:43 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-01 00:13:43 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/add.php
INFO - 2021-04-01 00:13:43 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-04-01 00:13:43 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-04-01 00:13:43 --> Final output sent to browser
DEBUG - 2021-04-01 00:13:43 --> Total execution time: 0.0362
INFO - 2021-04-01 00:13:43 --> Config Class Initialized
INFO - 2021-04-01 00:13:43 --> Config Class Initialized
INFO - 2021-04-01 00:13:43 --> Hooks Class Initialized
INFO - 2021-04-01 00:13:43 --> Hooks Class Initialized
DEBUG - 2021-04-01 00:13:43 --> UTF-8 Support Enabled
INFO - 2021-04-01 00:13:43 --> Utf8 Class Initialized
DEBUG - 2021-04-01 00:13:43 --> UTF-8 Support Enabled
INFO - 2021-04-01 00:13:43 --> URI Class Initialized
INFO - 2021-04-01 00:13:43 --> Utf8 Class Initialized
INFO - 2021-04-01 00:13:43 --> URI Class Initialized
INFO - 2021-04-01 00:13:43 --> Router Class Initialized
INFO - 2021-04-01 00:13:43 --> Output Class Initialized
INFO - 2021-04-01 00:13:43 --> Router Class Initialized
INFO - 2021-04-01 00:13:43 --> Security Class Initialized
DEBUG - 2021-04-01 00:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-01 00:13:43 --> Input Class Initialized
INFO - 2021-04-01 00:13:43 --> Output Class Initialized
INFO - 2021-04-01 00:13:43 --> Language Class Initialized
INFO - 2021-04-01 00:13:43 --> Security Class Initialized
ERROR - 2021-04-01 00:13:43 --> 404 Page Not Found: administrator/Company/dist
DEBUG - 2021-04-01 00:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-01 00:13:43 --> Input Class Initialized
INFO - 2021-04-01 00:13:43 --> Language Class Initialized
ERROR - 2021-04-01 00:13:43 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-04-01 00:13:43 --> Config Class Initialized
INFO - 2021-04-01 00:13:43 --> Hooks Class Initialized
DEBUG - 2021-04-01 00:13:43 --> UTF-8 Support Enabled
INFO - 2021-04-01 00:13:43 --> Utf8 Class Initialized
INFO - 2021-04-01 00:13:43 --> Config Class Initialized
INFO - 2021-04-01 00:13:43 --> URI Class Initialized
INFO - 2021-04-01 00:13:43 --> Hooks Class Initialized
INFO - 2021-04-01 00:13:44 --> Router Class Initialized
DEBUG - 2021-04-01 00:13:44 --> UTF-8 Support Enabled
INFO - 2021-04-01 00:13:44 --> Utf8 Class Initialized
INFO - 2021-04-01 00:13:44 --> Output Class Initialized
INFO - 2021-04-01 00:13:44 --> URI Class Initialized
INFO - 2021-04-01 00:13:44 --> Security Class Initialized
INFO - 2021-04-01 00:13:44 --> Router Class Initialized
DEBUG - 2021-04-01 00:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-01 00:13:44 --> Input Class Initialized
INFO - 2021-04-01 00:13:44 --> Output Class Initialized
INFO - 2021-04-01 00:13:44 --> Language Class Initialized
INFO - 2021-04-01 00:13:44 --> Security Class Initialized
ERROR - 2021-04-01 00:13:44 --> 404 Page Not Found: administrator/Company/dist
DEBUG - 2021-04-01 00:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-01 00:13:44 --> Input Class Initialized
INFO - 2021-04-01 00:13:44 --> Language Class Initialized
ERROR - 2021-04-01 00:13:44 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-04-01 00:13:49 --> Config Class Initialized
INFO - 2021-04-01 00:13:49 --> Hooks Class Initialized
DEBUG - 2021-04-01 00:13:49 --> UTF-8 Support Enabled
INFO - 2021-04-01 00:13:49 --> Utf8 Class Initialized
INFO - 2021-04-01 00:13:49 --> URI Class Initialized
INFO - 2021-04-01 00:13:49 --> Router Class Initialized
INFO - 2021-04-01 00:13:49 --> Output Class Initialized
INFO - 2021-04-01 00:13:49 --> Security Class Initialized
DEBUG - 2021-04-01 00:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-01 00:13:50 --> Input Class Initialized
INFO - 2021-04-01 00:13:50 --> Language Class Initialized
INFO - 2021-04-01 00:13:50 --> Loader Class Initialized
INFO - 2021-04-01 00:13:50 --> Helper loaded: url_helper
INFO - 2021-04-01 00:13:50 --> Helper loaded: form_helper
INFO - 2021-04-01 00:13:50 --> Helper loaded: common_helper
INFO - 2021-04-01 00:13:50 --> Helper loaded: util_helper
INFO - 2021-04-01 00:13:50 --> Database Driver Class Initialized
DEBUG - 2021-04-01 00:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-01 00:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-01 00:13:50 --> Form Validation Class Initialized
INFO - 2021-04-01 00:13:50 --> Controller Class Initialized
INFO - 2021-04-01 00:13:50 --> Model Class Initialized
INFO - 2021-04-01 00:13:50 --> Model Class Initialized
INFO - 2021-04-01 00:13:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-04-01 00:13:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-01 00:13:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/list.php
INFO - 2021-04-01 00:13:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-04-01 00:13:50 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-04-01 00:13:50 --> Final output sent to browser
DEBUG - 2021-04-01 00:13:50 --> Total execution time: 0.0409
INFO - 2021-04-01 00:13:50 --> Config Class Initialized
INFO - 2021-04-01 00:13:50 --> Hooks Class Initialized
DEBUG - 2021-04-01 00:13:50 --> UTF-8 Support Enabled
INFO - 2021-04-01 00:13:50 --> Utf8 Class Initialized
INFO - 2021-04-01 00:13:50 --> URI Class Initialized
INFO - 2021-04-01 00:13:50 --> Router Class Initialized
INFO - 2021-04-01 00:13:50 --> Output Class Initialized
INFO - 2021-04-01 00:13:50 --> Security Class Initialized
DEBUG - 2021-04-01 00:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-01 00:13:50 --> Input Class Initialized
INFO - 2021-04-01 00:13:50 --> Language Class Initialized
ERROR - 2021-04-01 00:13:50 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-04-01 00:13:50 --> Config Class Initialized
INFO - 2021-04-01 00:13:50 --> Config Class Initialized
INFO - 2021-04-01 00:13:50 --> Hooks Class Initialized
INFO - 2021-04-01 00:13:50 --> Hooks Class Initialized
INFO - 2021-04-01 00:13:50 --> Config Class Initialized
INFO - 2021-04-01 00:13:50 --> Hooks Class Initialized
DEBUG - 2021-04-01 00:13:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-01 00:13:50 --> UTF-8 Support Enabled
INFO - 2021-04-01 00:13:50 --> Utf8 Class Initialized
INFO - 2021-04-01 00:13:50 --> Utf8 Class Initialized
DEBUG - 2021-04-01 00:13:50 --> UTF-8 Support Enabled
INFO - 2021-04-01 00:13:50 --> URI Class Initialized
INFO - 2021-04-01 00:13:50 --> URI Class Initialized
INFO - 2021-04-01 00:13:50 --> Utf8 Class Initialized
INFO - 2021-04-01 00:13:50 --> URI Class Initialized
INFO - 2021-04-01 00:13:50 --> Router Class Initialized
INFO - 2021-04-01 00:13:50 --> Router Class Initialized
INFO - 2021-04-01 00:13:50 --> Router Class Initialized
INFO - 2021-04-01 00:13:50 --> Output Class Initialized
INFO - 2021-04-01 00:13:50 --> Output Class Initialized
INFO - 2021-04-01 00:13:50 --> Security Class Initialized
INFO - 2021-04-01 00:13:50 --> Output Class Initialized
INFO - 2021-04-01 00:13:50 --> Security Class Initialized
DEBUG - 2021-04-01 00:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-01 00:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-01 00:13:50 --> Security Class Initialized
INFO - 2021-04-01 00:13:50 --> Input Class Initialized
INFO - 2021-04-01 00:13:50 --> Input Class Initialized
INFO - 2021-04-01 00:13:50 --> Language Class Initialized
INFO - 2021-04-01 00:13:50 --> Language Class Initialized
DEBUG - 2021-04-01 00:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-01 00:13:50 --> Input Class Initialized
INFO - 2021-04-01 00:13:50 --> Language Class Initialized
ERROR - 2021-04-01 00:13:50 --> 404 Page Not Found: administrator/Company/dist
ERROR - 2021-04-01 00:13:50 --> 404 Page Not Found: administrator/Company/dist
ERROR - 2021-04-01 00:13:50 --> 404 Page Not Found: administrator/Company/dist
INFO - 2021-04-01 00:13:52 --> Config Class Initialized
INFO - 2021-04-01 00:13:52 --> Hooks Class Initialized
DEBUG - 2021-04-01 00:13:52 --> UTF-8 Support Enabled
INFO - 2021-04-01 00:13:52 --> Utf8 Class Initialized
INFO - 2021-04-01 00:13:52 --> URI Class Initialized
INFO - 2021-04-01 00:13:52 --> Router Class Initialized
INFO - 2021-04-01 00:13:52 --> Output Class Initialized
INFO - 2021-04-01 00:13:52 --> Security Class Initialized
DEBUG - 2021-04-01 00:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-01 00:13:52 --> Input Class Initialized
INFO - 2021-04-01 00:13:52 --> Language Class Initialized
INFO - 2021-04-01 00:13:52 --> Loader Class Initialized
INFO - 2021-04-01 00:13:52 --> Helper loaded: url_helper
INFO - 2021-04-01 00:13:52 --> Helper loaded: form_helper
INFO - 2021-04-01 00:13:52 --> Helper loaded: common_helper
INFO - 2021-04-01 00:13:52 --> Helper loaded: util_helper
INFO - 2021-04-01 00:13:52 --> Database Driver Class Initialized
DEBUG - 2021-04-01 00:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-01 00:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-01 00:13:52 --> Form Validation Class Initialized
INFO - 2021-04-01 00:13:52 --> Controller Class Initialized
INFO - 2021-04-01 00:13:52 --> Model Class Initialized
INFO - 2021-04-01 00:13:52 --> Model Class Initialized
INFO - 2021-04-01 00:13:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-04-01 00:13:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-01 00:13:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
INFO - 2021-04-01 00:13:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-04-01 00:13:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-04-01 00:13:52 --> Final output sent to browser
DEBUG - 2021-04-01 00:13:52 --> Total execution time: 0.0343
INFO - 2021-04-01 00:13:52 --> Config Class Initialized
INFO - 2021-04-01 00:13:52 --> Config Class Initialized
INFO - 2021-04-01 00:13:52 --> Hooks Class Initialized
INFO - 2021-04-01 00:13:52 --> Hooks Class Initialized
DEBUG - 2021-04-01 00:13:52 --> UTF-8 Support Enabled
INFO - 2021-04-01 00:13:52 --> Utf8 Class Initialized
DEBUG - 2021-04-01 00:13:52 --> UTF-8 Support Enabled
INFO - 2021-04-01 00:13:52 --> Utf8 Class Initialized
INFO - 2021-04-01 00:13:52 --> URI Class Initialized
INFO - 2021-04-01 00:13:52 --> URI Class Initialized
INFO - 2021-04-01 00:13:52 --> Router Class Initialized
INFO - 2021-04-01 00:13:52 --> Output Class Initialized
INFO - 2021-04-01 00:13:52 --> Security Class Initialized
DEBUG - 2021-04-01 00:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-01 00:13:52 --> Input Class Initialized
INFO - 2021-04-01 00:13:52 --> Language Class Initialized
INFO - 2021-04-01 00:13:52 --> Config Class Initialized
INFO - 2021-04-01 00:13:52 --> Hooks Class Initialized
DEBUG - 2021-04-01 00:13:52 --> UTF-8 Support Enabled
INFO - 2021-04-01 00:13:52 --> Utf8 Class Initialized
INFO - 2021-04-01 00:13:52 --> Loader Class Initialized
INFO - 2021-04-01 00:13:52 --> URI Class Initialized
INFO - 2021-04-01 00:13:52 --> Helper loaded: url_helper
INFO - 2021-04-01 00:13:52 --> Router Class Initialized
INFO - 2021-04-01 00:13:52 --> Helper loaded: form_helper
INFO - 2021-04-01 00:13:52 --> Output Class Initialized
INFO - 2021-04-01 00:13:52 --> Config Class Initialized
INFO - 2021-04-01 00:13:52 --> Hooks Class Initialized
INFO - 2021-04-01 00:13:52 --> Helper loaded: common_helper
INFO - 2021-04-01 00:13:52 --> Helper loaded: util_helper
INFO - 2021-04-01 00:13:52 --> Security Class Initialized
DEBUG - 2021-04-01 00:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-01 00:13:52 --> UTF-8 Support Enabled
INFO - 2021-04-01 00:13:52 --> Input Class Initialized
INFO - 2021-04-01 00:13:52 --> Utf8 Class Initialized
INFO - 2021-04-01 00:13:52 --> Language Class Initialized
INFO - 2021-04-01 00:13:52 --> URI Class Initialized
INFO - 2021-04-01 00:13:52 --> Loader Class Initialized
INFO - 2021-04-01 00:13:52 --> Router Class Initialized
INFO - 2021-04-01 00:13:52 --> Helper loaded: url_helper
INFO - 2021-04-01 00:13:52 --> Database Driver Class Initialized
INFO - 2021-04-01 00:13:52 --> Helper loaded: form_helper
INFO - 2021-04-01 00:13:52 --> Helper loaded: common_helper
INFO - 2021-04-01 00:13:52 --> Router Class Initialized
INFO - 2021-04-01 00:13:52 --> Helper loaded: util_helper
DEBUG - 2021-04-01 00:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-01 00:13:52 --> Output Class Initialized
INFO - 2021-04-01 00:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-01 00:13:52 --> Security Class Initialized
INFO - 2021-04-01 00:13:52 --> Form Validation Class Initialized
INFO - 2021-04-01 00:13:52 --> Controller Class Initialized
DEBUG - 2021-04-01 00:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-01 00:13:52 --> Input Class Initialized
INFO - 2021-04-01 00:13:52 --> Language Class Initialized
INFO - 2021-04-01 00:13:52 --> Model Class Initialized
INFO - 2021-04-01 00:13:52 --> Database Driver Class Initialized
INFO - 2021-04-01 00:13:52 --> Model Class Initialized
INFO - 2021-04-01 00:13:52 --> Output Class Initialized
INFO - 2021-04-01 00:13:52 --> Loader Class Initialized
INFO - 2021-04-01 00:13:52 --> Security Class Initialized
DEBUG - 2021-04-01 00:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-01 00:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-01 00:13:52 --> Helper loaded: url_helper
INFO - 2021-04-01 00:13:52 --> Input Class Initialized
INFO - 2021-04-01 00:13:52 --> Language Class Initialized
INFO - 2021-04-01 00:13:52 --> Helper loaded: form_helper
INFO - 2021-04-01 00:13:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-04-01 00:13:52 --> Helper loaded: common_helper
INFO - 2021-04-01 00:13:52 --> Helper loaded: util_helper
INFO - 2021-04-01 00:13:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-01 00:13:52 --> Loader Class Initialized
INFO - 2021-04-01 00:13:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
INFO - 2021-04-01 00:13:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-04-01 00:13:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-04-01 00:13:52 --> Final output sent to browser
INFO - 2021-04-01 00:13:52 --> Helper loaded: url_helper
DEBUG - 2021-04-01 00:13:52 --> Total execution time: 0.0550
INFO - 2021-04-01 00:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-01 00:13:52 --> Helper loaded: form_helper
INFO - 2021-04-01 00:13:52 --> Form Validation Class Initialized
INFO - 2021-04-01 00:13:52 --> Controller Class Initialized
INFO - 2021-04-01 00:13:52 --> Helper loaded: common_helper
INFO - 2021-04-01 00:13:52 --> Helper loaded: util_helper
INFO - 2021-04-01 00:13:52 --> Model Class Initialized
INFO - 2021-04-01 00:13:52 --> Model Class Initialized
INFO - 2021-04-01 00:13:52 --> Database Driver Class Initialized
INFO - 2021-04-01 00:13:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-04-01 00:13:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-01 00:13:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
DEBUG - 2021-04-01 00:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-01 00:13:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-04-01 00:13:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-04-01 00:13:52 --> Final output sent to browser
DEBUG - 2021-04-01 00:13:52 --> Total execution time: 0.0511
INFO - 2021-04-01 00:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-01 00:13:52 --> Database Driver Class Initialized
INFO - 2021-04-01 00:13:52 --> Form Validation Class Initialized
INFO - 2021-04-01 00:13:52 --> Controller Class Initialized
INFO - 2021-04-01 00:13:52 --> Model Class Initialized
INFO - 2021-04-01 00:13:52 --> Model Class Initialized
DEBUG - 2021-04-01 00:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-01 00:13:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-04-01 00:13:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-01 00:13:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
INFO - 2021-04-01 00:13:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-04-01 00:13:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-04-01 00:13:52 --> Final output sent to browser
DEBUG - 2021-04-01 00:13:52 --> Total execution time: 0.0606
INFO - 2021-04-01 00:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-01 00:13:52 --> Form Validation Class Initialized
INFO - 2021-04-01 00:13:52 --> Controller Class Initialized
INFO - 2021-04-01 00:13:52 --> Model Class Initialized
INFO - 2021-04-01 00:13:52 --> Model Class Initialized
INFO - 2021-04-01 00:13:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-04-01 00:13:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-01 00:13:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/company/edit.php
INFO - 2021-04-01 00:13:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-04-01 00:13:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-04-01 00:13:52 --> Final output sent to browser
DEBUG - 2021-04-01 00:13:52 --> Total execution time: 0.0897
INFO - 2021-04-01 00:15:01 --> Config Class Initialized
INFO - 2021-04-01 00:15:01 --> Hooks Class Initialized
DEBUG - 2021-04-01 00:15:01 --> UTF-8 Support Enabled
INFO - 2021-04-01 00:15:01 --> Utf8 Class Initialized
INFO - 2021-04-01 00:15:01 --> URI Class Initialized
INFO - 2021-04-01 00:15:01 --> Router Class Initialized
INFO - 2021-04-01 00:15:01 --> Output Class Initialized
INFO - 2021-04-01 00:15:01 --> Security Class Initialized
DEBUG - 2021-04-01 00:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-01 00:15:01 --> Input Class Initialized
INFO - 2021-04-01 00:15:01 --> Language Class Initialized
INFO - 2021-04-01 00:15:01 --> Loader Class Initialized
INFO - 2021-04-01 00:15:01 --> Helper loaded: url_helper
INFO - 2021-04-01 00:15:01 --> Helper loaded: form_helper
INFO - 2021-04-01 00:15:01 --> Helper loaded: common_helper
INFO - 2021-04-01 00:15:01 --> Helper loaded: util_helper
INFO - 2021-04-01 00:15:01 --> Database Driver Class Initialized
DEBUG - 2021-04-01 00:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-01 00:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-01 00:15:01 --> Form Validation Class Initialized
INFO - 2021-04-01 00:15:01 --> Controller Class Initialized
INFO - 2021-04-01 00:15:01 --> Model Class Initialized
INFO - 2021-04-01 00:15:01 --> Config Class Initialized
INFO - 2021-04-01 00:15:01 --> Hooks Class Initialized
DEBUG - 2021-04-01 00:15:01 --> UTF-8 Support Enabled
INFO - 2021-04-01 00:15:01 --> Utf8 Class Initialized
INFO - 2021-04-01 00:15:01 --> URI Class Initialized
INFO - 2021-04-01 00:15:01 --> Router Class Initialized
INFO - 2021-04-01 00:15:01 --> Output Class Initialized
INFO - 2021-04-01 00:15:01 --> Security Class Initialized
DEBUG - 2021-04-01 00:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-01 00:15:01 --> Input Class Initialized
INFO - 2021-04-01 00:15:01 --> Language Class Initialized
INFO - 2021-04-01 00:15:01 --> Loader Class Initialized
INFO - 2021-04-01 00:15:01 --> Helper loaded: url_helper
INFO - 2021-04-01 00:15:01 --> Helper loaded: form_helper
INFO - 2021-04-01 00:15:01 --> Helper loaded: common_helper
INFO - 2021-04-01 00:15:01 --> Helper loaded: util_helper
INFO - 2021-04-01 00:15:01 --> Database Driver Class Initialized
DEBUG - 2021-04-01 00:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-01 00:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-01 00:15:01 --> Form Validation Class Initialized
INFO - 2021-04-01 00:15:01 --> Controller Class Initialized
INFO - 2021-04-01 00:15:01 --> Model Class Initialized
INFO - 2021-04-01 00:15:01 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/login.php
INFO - 2021-04-01 00:15:01 --> Final output sent to browser
DEBUG - 2021-04-01 00:15:01 --> Total execution time: 0.0338

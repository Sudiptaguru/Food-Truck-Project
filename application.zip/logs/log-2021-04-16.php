<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-04-16 14:45:47 --> Config Class Initialized
INFO - 2021-04-16 14:45:47 --> Hooks Class Initialized
DEBUG - 2021-04-16 14:45:47 --> UTF-8 Support Enabled
INFO - 2021-04-16 14:45:47 --> Utf8 Class Initialized
INFO - 2021-04-16 14:45:47 --> URI Class Initialized
DEBUG - 2021-04-16 14:45:47 --> No URI present. Default controller set.
INFO - 2021-04-16 14:45:47 --> Router Class Initialized
INFO - 2021-04-16 14:45:47 --> Output Class Initialized
INFO - 2021-04-16 14:45:47 --> Security Class Initialized
DEBUG - 2021-04-16 14:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 14:45:47 --> Input Class Initialized
INFO - 2021-04-16 14:45:47 --> Language Class Initialized
INFO - 2021-04-16 14:45:47 --> Loader Class Initialized
INFO - 2021-04-16 14:45:47 --> Helper loaded: url_helper
INFO - 2021-04-16 14:45:47 --> Helper loaded: form_helper
INFO - 2021-04-16 14:45:47 --> Helper loaded: common_helper
INFO - 2021-04-16 14:45:47 --> Helper loaded: util_helper
INFO - 2021-04-16 14:45:47 --> Database Driver Class Initialized
DEBUG - 2021-04-16 14:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 14:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 14:45:47 --> Form Validation Class Initialized
INFO - 2021-04-16 14:45:47 --> Controller Class Initialized
INFO - 2021-04-16 14:45:47 --> Model Class Initialized
INFO - 2021-04-16 14:45:47 --> Model Class Initialized
INFO - 2021-04-16 14:45:47 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 14:45:47 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 14:45:47 --> Final output sent to browser
DEBUG - 2021-04-16 14:45:47 --> Total execution time: 0.0423
INFO - 2021-04-16 14:45:48 --> Config Class Initialized
INFO - 2021-04-16 14:45:48 --> Hooks Class Initialized
DEBUG - 2021-04-16 14:45:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 14:45:48 --> Utf8 Class Initialized
INFO - 2021-04-16 14:45:48 --> URI Class Initialized
INFO - 2021-04-16 14:45:48 --> Router Class Initialized
INFO - 2021-04-16 14:45:48 --> Output Class Initialized
INFO - 2021-04-16 14:45:48 --> Security Class Initialized
DEBUG - 2021-04-16 14:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 14:45:48 --> Input Class Initialized
INFO - 2021-04-16 14:45:48 --> Language Class Initialized
ERROR - 2021-04-16 14:45:48 --> 404 Page Not Found: Fassets/img
INFO - 2021-04-16 14:45:50 --> Config Class Initialized
INFO - 2021-04-16 14:45:50 --> Hooks Class Initialized
DEBUG - 2021-04-16 14:45:50 --> UTF-8 Support Enabled
INFO - 2021-04-16 14:45:50 --> Utf8 Class Initialized
INFO - 2021-04-16 14:45:50 --> URI Class Initialized
INFO - 2021-04-16 14:45:50 --> Router Class Initialized
INFO - 2021-04-16 14:45:50 --> Output Class Initialized
INFO - 2021-04-16 14:45:50 --> Security Class Initialized
DEBUG - 2021-04-16 14:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 14:45:50 --> Input Class Initialized
INFO - 2021-04-16 14:45:50 --> Language Class Initialized
INFO - 2021-04-16 14:45:50 --> Loader Class Initialized
INFO - 2021-04-16 14:45:50 --> Helper loaded: url_helper
INFO - 2021-04-16 14:45:50 --> Helper loaded: form_helper
INFO - 2021-04-16 14:45:50 --> Helper loaded: common_helper
INFO - 2021-04-16 14:45:50 --> Helper loaded: util_helper
INFO - 2021-04-16 14:45:50 --> Database Driver Class Initialized
DEBUG - 2021-04-16 14:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 14:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 14:45:50 --> Form Validation Class Initialized
INFO - 2021-04-16 14:45:50 --> Controller Class Initialized
INFO - 2021-04-16 14:45:50 --> Model Class Initialized
INFO - 2021-04-16 14:45:50 --> Model Class Initialized
INFO - 2021-04-16 14:45:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 14:45:50 --> Final output sent to browser
DEBUG - 2021-04-16 14:45:50 --> Total execution time: 0.0266
INFO - 2021-04-16 14:45:50 --> Config Class Initialized
INFO - 2021-04-16 14:45:50 --> Hooks Class Initialized
INFO - 2021-04-16 14:45:50 --> Config Class Initialized
INFO - 2021-04-16 14:45:50 --> Hooks Class Initialized
DEBUG - 2021-04-16 14:45:50 --> UTF-8 Support Enabled
INFO - 2021-04-16 14:45:50 --> Utf8 Class Initialized
DEBUG - 2021-04-16 14:45:50 --> UTF-8 Support Enabled
INFO - 2021-04-16 14:45:50 --> URI Class Initialized
INFO - 2021-04-16 14:45:50 --> Utf8 Class Initialized
INFO - 2021-04-16 14:45:50 --> URI Class Initialized
INFO - 2021-04-16 14:45:50 --> Router Class Initialized
INFO - 2021-04-16 14:45:50 --> Router Class Initialized
INFO - 2021-04-16 14:45:50 --> Output Class Initialized
INFO - 2021-04-16 14:45:50 --> Output Class Initialized
INFO - 2021-04-16 14:45:50 --> Security Class Initialized
INFO - 2021-04-16 14:45:50 --> Security Class Initialized
DEBUG - 2021-04-16 14:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 14:45:50 --> Input Class Initialized
DEBUG - 2021-04-16 14:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 14:45:50 --> Language Class Initialized
INFO - 2021-04-16 14:45:50 --> Input Class Initialized
INFO - 2021-04-16 14:45:50 --> Language Class Initialized
ERROR - 2021-04-16 14:45:50 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-16 14:45:50 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-16 14:46:16 --> Config Class Initialized
INFO - 2021-04-16 14:46:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 14:46:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 14:46:16 --> Utf8 Class Initialized
INFO - 2021-04-16 14:46:16 --> URI Class Initialized
INFO - 2021-04-16 14:46:16 --> Router Class Initialized
INFO - 2021-04-16 14:46:16 --> Output Class Initialized
INFO - 2021-04-16 14:46:16 --> Security Class Initialized
DEBUG - 2021-04-16 14:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 14:46:16 --> Input Class Initialized
INFO - 2021-04-16 14:46:16 --> Language Class Initialized
INFO - 2021-04-16 14:46:16 --> Loader Class Initialized
INFO - 2021-04-16 14:46:16 --> Helper loaded: url_helper
INFO - 2021-04-16 14:46:16 --> Helper loaded: form_helper
INFO - 2021-04-16 14:46:16 --> Helper loaded: common_helper
INFO - 2021-04-16 14:46:16 --> Helper loaded: util_helper
INFO - 2021-04-16 14:46:16 --> Database Driver Class Initialized
DEBUG - 2021-04-16 14:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 14:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 14:46:16 --> Form Validation Class Initialized
INFO - 2021-04-16 14:46:16 --> Controller Class Initialized
INFO - 2021-04-16 14:46:16 --> Model Class Initialized
INFO - 2021-04-16 14:46:16 --> Model Class Initialized
INFO - 2021-04-16 14:46:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-16 14:46:16 --> Config Class Initialized
INFO - 2021-04-16 14:46:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 14:46:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 14:46:16 --> Utf8 Class Initialized
INFO - 2021-04-16 14:46:16 --> URI Class Initialized
INFO - 2021-04-16 14:46:16 --> Router Class Initialized
INFO - 2021-04-16 14:46:16 --> Output Class Initialized
INFO - 2021-04-16 14:46:16 --> Security Class Initialized
DEBUG - 2021-04-16 14:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 14:46:16 --> Input Class Initialized
INFO - 2021-04-16 14:46:16 --> Language Class Initialized
INFO - 2021-04-16 14:46:16 --> Loader Class Initialized
INFO - 2021-04-16 14:46:16 --> Helper loaded: url_helper
INFO - 2021-04-16 14:46:16 --> Helper loaded: form_helper
INFO - 2021-04-16 14:46:16 --> Helper loaded: common_helper
INFO - 2021-04-16 14:46:16 --> Helper loaded: util_helper
INFO - 2021-04-16 14:46:16 --> Database Driver Class Initialized
DEBUG - 2021-04-16 14:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 14:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 14:46:16 --> Form Validation Class Initialized
INFO - 2021-04-16 14:46:16 --> Controller Class Initialized
INFO - 2021-04-16 14:46:16 --> Model Class Initialized
INFO - 2021-04-16 14:46:16 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 14:46:16 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 14:46:16 --> Final output sent to browser
DEBUG - 2021-04-16 14:46:16 --> Total execution time: 0.0313
INFO - 2021-04-16 14:46:16 --> Config Class Initialized
INFO - 2021-04-16 14:46:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 14:46:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 14:46:16 --> Utf8 Class Initialized
INFO - 2021-04-16 14:46:16 --> URI Class Initialized
INFO - 2021-04-16 14:46:16 --> Router Class Initialized
INFO - 2021-04-16 14:46:16 --> Output Class Initialized
INFO - 2021-04-16 14:46:16 --> Security Class Initialized
DEBUG - 2021-04-16 14:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 14:46:16 --> Input Class Initialized
INFO - 2021-04-16 14:46:16 --> Language Class Initialized
INFO - 2021-04-16 14:46:16 --> Config Class Initialized
INFO - 2021-04-16 14:46:16 --> Hooks Class Initialized
INFO - 2021-04-16 14:46:16 --> Config Class Initialized
ERROR - 2021-04-16 14:46:16 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 14:46:16 --> Config Class Initialized
INFO - 2021-04-16 14:46:16 --> Hooks Class Initialized
INFO - 2021-04-16 14:46:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 14:46:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 14:46:16 --> Utf8 Class Initialized
DEBUG - 2021-04-16 14:46:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 14:46:16 --> Utf8 Class Initialized
INFO - 2021-04-16 14:46:16 --> URI Class Initialized
INFO - 2021-04-16 14:46:16 --> URI Class Initialized
INFO - 2021-04-16 14:46:16 --> Router Class Initialized
INFO - 2021-04-16 14:46:16 --> Router Class Initialized
DEBUG - 2021-04-16 14:46:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 14:46:16 --> Utf8 Class Initialized
INFO - 2021-04-16 14:46:16 --> Output Class Initialized
INFO - 2021-04-16 14:46:16 --> URI Class Initialized
INFO - 2021-04-16 14:46:16 --> Output Class Initialized
INFO - 2021-04-16 14:46:16 --> Security Class Initialized
INFO - 2021-04-16 14:46:16 --> Config Class Initialized
INFO - 2021-04-16 14:46:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 14:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 14:46:16 --> Input Class Initialized
INFO - 2021-04-16 14:46:16 --> Language Class Initialized
INFO - 2021-04-16 14:46:16 --> Config Class Initialized
INFO - 2021-04-16 14:46:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 14:46:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 14:46:16 --> Utf8 Class Initialized
ERROR - 2021-04-16 14:46:16 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-16 14:46:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 14:46:16 --> URI Class Initialized
INFO - 2021-04-16 14:46:16 --> Utf8 Class Initialized
INFO - 2021-04-16 14:46:16 --> URI Class Initialized
INFO - 2021-04-16 14:46:16 --> Router Class Initialized
INFO - 2021-04-16 14:46:16 --> Router Class Initialized
INFO - 2021-04-16 14:46:16 --> Output Class Initialized
INFO - 2021-04-16 14:46:16 --> Output Class Initialized
INFO - 2021-04-16 14:46:16 --> Security Class Initialized
INFO - 2021-04-16 14:46:16 --> Security Class Initialized
INFO - 2021-04-16 14:46:16 --> Security Class Initialized
DEBUG - 2021-04-16 14:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 14:46:16 --> Input Class Initialized
DEBUG - 2021-04-16 14:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 14:46:16 --> Input Class Initialized
INFO - 2021-04-16 14:46:16 --> Input Class Initialized
INFO - 2021-04-16 14:46:16 --> Language Class Initialized
INFO - 2021-04-16 14:46:16 --> Language Class Initialized
INFO - 2021-04-16 14:46:16 --> Language Class Initialized
ERROR - 2021-04-16 14:46:16 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-16 14:46:16 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-16 14:46:16 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 14:46:16 --> Router Class Initialized
INFO - 2021-04-16 14:46:16 --> Output Class Initialized
INFO - 2021-04-16 14:46:16 --> Security Class Initialized
INFO - 2021-04-16 14:46:16 --> Config Class Initialized
INFO - 2021-04-16 14:46:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 14:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 14:46:16 --> Input Class Initialized
INFO - 2021-04-16 14:46:16 --> Config Class Initialized
INFO - 2021-04-16 14:46:16 --> Config Class Initialized
INFO - 2021-04-16 14:46:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 14:46:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 14:46:16 --> Hooks Class Initialized
INFO - 2021-04-16 14:46:16 --> Utf8 Class Initialized
INFO - 2021-04-16 14:46:16 --> Language Class Initialized
INFO - 2021-04-16 14:46:16 --> URI Class Initialized
DEBUG - 2021-04-16 14:46:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 14:46:16 --> Utf8 Class Initialized
DEBUG - 2021-04-16 14:46:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 14:46:16 --> Router Class Initialized
INFO - 2021-04-16 14:46:16 --> Utf8 Class Initialized
INFO - 2021-04-16 14:46:16 --> URI Class Initialized
ERROR - 2021-04-16 14:46:16 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 14:46:16 --> URI Class Initialized
INFO - 2021-04-16 14:46:16 --> Output Class Initialized
INFO - 2021-04-16 14:46:16 --> Router Class Initialized
INFO - 2021-04-16 14:46:16 --> Router Class Initialized
INFO - 2021-04-16 14:46:16 --> Security Class Initialized
INFO - 2021-04-16 14:46:16 --> Output Class Initialized
DEBUG - 2021-04-16 14:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 14:46:16 --> Input Class Initialized
INFO - 2021-04-16 14:46:16 --> Security Class Initialized
INFO - 2021-04-16 14:46:16 --> Output Class Initialized
INFO - 2021-04-16 14:46:16 --> Language Class Initialized
DEBUG - 2021-04-16 14:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 14:46:16 --> Input Class Initialized
INFO - 2021-04-16 14:46:16 --> Security Class Initialized
INFO - 2021-04-16 14:46:16 --> Language Class Initialized
ERROR - 2021-04-16 14:46:16 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-16 14:46:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 14:46:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 14:46:16 --> Input Class Initialized
INFO - 2021-04-16 14:46:16 --> Language Class Initialized
ERROR - 2021-04-16 14:46:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 14:46:16 --> Config Class Initialized
INFO - 2021-04-16 14:46:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 14:46:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 14:46:16 --> Utf8 Class Initialized
INFO - 2021-04-16 14:46:16 --> URI Class Initialized
INFO - 2021-04-16 14:46:16 --> Router Class Initialized
INFO - 2021-04-16 14:46:16 --> Output Class Initialized
INFO - 2021-04-16 14:46:16 --> Security Class Initialized
DEBUG - 2021-04-16 14:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 14:46:16 --> Input Class Initialized
INFO - 2021-04-16 14:46:16 --> Language Class Initialized
ERROR - 2021-04-16 14:46:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 14:46:16 --> Config Class Initialized
INFO - 2021-04-16 14:46:16 --> Hooks Class Initialized
INFO - 2021-04-16 14:46:16 --> Config Class Initialized
INFO - 2021-04-16 14:46:16 --> Config Class Initialized
INFO - 2021-04-16 14:46:16 --> Hooks Class Initialized
INFO - 2021-04-16 14:46:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 14:46:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 14:46:16 --> Utf8 Class Initialized
DEBUG - 2021-04-16 14:46:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 14:46:16 --> Utf8 Class Initialized
DEBUG - 2021-04-16 14:46:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 14:46:16 --> Utf8 Class Initialized
INFO - 2021-04-16 14:46:16 --> URI Class Initialized
INFO - 2021-04-16 14:46:16 --> URI Class Initialized
INFO - 2021-04-16 14:46:16 --> URI Class Initialized
INFO - 2021-04-16 14:46:16 --> Router Class Initialized
INFO - 2021-04-16 14:46:16 --> Router Class Initialized
INFO - 2021-04-16 14:46:16 --> Router Class Initialized
INFO - 2021-04-16 14:46:16 --> Output Class Initialized
INFO - 2021-04-16 14:46:16 --> Output Class Initialized
INFO - 2021-04-16 14:46:16 --> Output Class Initialized
INFO - 2021-04-16 14:46:16 --> Security Class Initialized
INFO - 2021-04-16 14:46:16 --> Security Class Initialized
INFO - 2021-04-16 14:46:16 --> Security Class Initialized
DEBUG - 2021-04-16 14:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 14:46:16 --> Input Class Initialized
DEBUG - 2021-04-16 14:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 14:46:16 --> Input Class Initialized
DEBUG - 2021-04-16 14:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 14:46:16 --> Language Class Initialized
INFO - 2021-04-16 14:46:16 --> Input Class Initialized
INFO - 2021-04-16 14:46:16 --> Language Class Initialized
INFO - 2021-04-16 14:46:16 --> Language Class Initialized
ERROR - 2021-04-16 14:46:16 --> 404 Page Not Found: user/Assets/img
ERROR - 2021-04-16 14:46:16 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-16 14:46:16 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-16 14:46:16 --> Config Class Initialized
INFO - 2021-04-16 14:46:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 14:46:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 14:46:16 --> Utf8 Class Initialized
INFO - 2021-04-16 14:46:16 --> URI Class Initialized
INFO - 2021-04-16 14:46:16 --> Router Class Initialized
INFO - 2021-04-16 14:46:16 --> Output Class Initialized
INFO - 2021-04-16 14:46:16 --> Security Class Initialized
DEBUG - 2021-04-16 14:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 14:46:16 --> Input Class Initialized
INFO - 2021-04-16 14:46:16 --> Language Class Initialized
ERROR - 2021-04-16 14:46:16 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 14:46:16 --> Config Class Initialized
INFO - 2021-04-16 14:46:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 14:46:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 14:46:16 --> Utf8 Class Initialized
INFO - 2021-04-16 14:46:16 --> URI Class Initialized
INFO - 2021-04-16 14:46:16 --> Router Class Initialized
INFO - 2021-04-16 14:46:16 --> Output Class Initialized
INFO - 2021-04-16 14:46:16 --> Security Class Initialized
DEBUG - 2021-04-16 14:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 14:46:16 --> Input Class Initialized
INFO - 2021-04-16 14:46:16 --> Language Class Initialized
ERROR - 2021-04-16 14:46:16 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 14:46:16 --> Config Class Initialized
INFO - 2021-04-16 14:46:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 14:46:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 14:46:16 --> Utf8 Class Initialized
INFO - 2021-04-16 14:46:16 --> URI Class Initialized
INFO - 2021-04-16 14:46:16 --> Router Class Initialized
INFO - 2021-04-16 14:46:16 --> Output Class Initialized
INFO - 2021-04-16 14:46:16 --> Security Class Initialized
DEBUG - 2021-04-16 14:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 14:46:16 --> Input Class Initialized
INFO - 2021-04-16 14:46:16 --> Language Class Initialized
ERROR - 2021-04-16 14:46:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 14:46:16 --> Config Class Initialized
INFO - 2021-04-16 14:46:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 14:46:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 14:46:16 --> Utf8 Class Initialized
INFO - 2021-04-16 14:46:16 --> URI Class Initialized
INFO - 2021-04-16 14:46:16 --> Router Class Initialized
INFO - 2021-04-16 14:46:16 --> Output Class Initialized
INFO - 2021-04-16 14:46:16 --> Security Class Initialized
DEBUG - 2021-04-16 14:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 14:46:16 --> Input Class Initialized
INFO - 2021-04-16 14:46:16 --> Language Class Initialized
ERROR - 2021-04-16 14:46:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 14:46:16 --> Config Class Initialized
INFO - 2021-04-16 14:46:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 14:46:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 14:46:16 --> Utf8 Class Initialized
INFO - 2021-04-16 14:46:16 --> URI Class Initialized
INFO - 2021-04-16 14:46:16 --> Router Class Initialized
INFO - 2021-04-16 14:46:16 --> Output Class Initialized
INFO - 2021-04-16 14:46:16 --> Security Class Initialized
DEBUG - 2021-04-16 14:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 14:46:16 --> Input Class Initialized
INFO - 2021-04-16 14:46:16 --> Language Class Initialized
ERROR - 2021-04-16 14:46:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 14:46:16 --> Config Class Initialized
INFO - 2021-04-16 14:46:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 14:46:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 14:46:16 --> Utf8 Class Initialized
INFO - 2021-04-16 14:46:16 --> URI Class Initialized
INFO - 2021-04-16 14:46:16 --> Router Class Initialized
INFO - 2021-04-16 14:46:16 --> Output Class Initialized
INFO - 2021-04-16 14:46:16 --> Security Class Initialized
DEBUG - 2021-04-16 14:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 14:46:16 --> Input Class Initialized
INFO - 2021-04-16 14:46:16 --> Language Class Initialized
ERROR - 2021-04-16 14:46:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:29:18 --> Config Class Initialized
INFO - 2021-04-16 15:29:18 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:29:18 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:29:18 --> Utf8 Class Initialized
INFO - 2021-04-16 15:29:18 --> URI Class Initialized
INFO - 2021-04-16 15:29:18 --> Router Class Initialized
INFO - 2021-04-16 15:29:18 --> Output Class Initialized
INFO - 2021-04-16 15:29:18 --> Security Class Initialized
DEBUG - 2021-04-16 15:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:29:18 --> Input Class Initialized
INFO - 2021-04-16 15:29:18 --> Language Class Initialized
INFO - 2021-04-16 15:29:18 --> Loader Class Initialized
INFO - 2021-04-16 15:29:18 --> Helper loaded: url_helper
INFO - 2021-04-16 15:29:18 --> Helper loaded: form_helper
INFO - 2021-04-16 15:29:18 --> Helper loaded: common_helper
INFO - 2021-04-16 15:29:18 --> Helper loaded: util_helper
INFO - 2021-04-16 15:29:18 --> Database Driver Class Initialized
DEBUG - 2021-04-16 15:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 15:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 15:29:18 --> Form Validation Class Initialized
INFO - 2021-04-16 15:29:18 --> Controller Class Initialized
INFO - 2021-04-16 15:29:18 --> Model Class Initialized
INFO - 2021-04-16 15:29:18 --> Model Class Initialized
INFO - 2021-04-16 15:29:18 --> Config Class Initialized
INFO - 2021-04-16 15:29:18 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:29:18 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:29:18 --> Utf8 Class Initialized
INFO - 2021-04-16 15:29:18 --> URI Class Initialized
INFO - 2021-04-16 15:29:18 --> Router Class Initialized
INFO - 2021-04-16 15:29:18 --> Output Class Initialized
INFO - 2021-04-16 15:29:18 --> Security Class Initialized
DEBUG - 2021-04-16 15:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:29:18 --> Input Class Initialized
INFO - 2021-04-16 15:29:18 --> Language Class Initialized
INFO - 2021-04-16 15:29:18 --> Loader Class Initialized
INFO - 2021-04-16 15:29:18 --> Helper loaded: url_helper
INFO - 2021-04-16 15:29:18 --> Helper loaded: form_helper
INFO - 2021-04-16 15:29:18 --> Helper loaded: common_helper
INFO - 2021-04-16 15:29:18 --> Helper loaded: util_helper
INFO - 2021-04-16 15:29:18 --> Database Driver Class Initialized
DEBUG - 2021-04-16 15:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 15:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 15:29:18 --> Form Validation Class Initialized
INFO - 2021-04-16 15:29:18 --> Controller Class Initialized
INFO - 2021-04-16 15:29:18 --> Model Class Initialized
INFO - 2021-04-16 15:29:18 --> Model Class Initialized
INFO - 2021-04-16 15:29:18 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 15:29:18 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 15:29:18 --> Final output sent to browser
DEBUG - 2021-04-16 15:29:18 --> Total execution time: 0.0283
INFO - 2021-04-16 15:29:20 --> Config Class Initialized
INFO - 2021-04-16 15:29:20 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:29:20 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:29:20 --> Utf8 Class Initialized
INFO - 2021-04-16 15:29:20 --> URI Class Initialized
INFO - 2021-04-16 15:29:20 --> Router Class Initialized
INFO - 2021-04-16 15:29:20 --> Output Class Initialized
INFO - 2021-04-16 15:29:20 --> Security Class Initialized
DEBUG - 2021-04-16 15:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:29:20 --> Input Class Initialized
INFO - 2021-04-16 15:29:20 --> Language Class Initialized
INFO - 2021-04-16 15:29:20 --> Loader Class Initialized
INFO - 2021-04-16 15:29:20 --> Helper loaded: url_helper
INFO - 2021-04-16 15:29:20 --> Helper loaded: form_helper
INFO - 2021-04-16 15:29:20 --> Helper loaded: common_helper
INFO - 2021-04-16 15:29:20 --> Helper loaded: util_helper
INFO - 2021-04-16 15:29:20 --> Database Driver Class Initialized
DEBUG - 2021-04-16 15:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 15:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 15:29:20 --> Form Validation Class Initialized
INFO - 2021-04-16 15:29:20 --> Controller Class Initialized
INFO - 2021-04-16 15:29:20 --> Model Class Initialized
INFO - 2021-04-16 15:29:20 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 15:29:20 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 15:29:20 --> Final output sent to browser
DEBUG - 2021-04-16 15:29:20 --> Total execution time: 0.0283
INFO - 2021-04-16 15:29:20 --> Config Class Initialized
INFO - 2021-04-16 15:29:20 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:29:20 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:29:20 --> Utf8 Class Initialized
INFO - 2021-04-16 15:29:20 --> URI Class Initialized
INFO - 2021-04-16 15:29:20 --> Router Class Initialized
INFO - 2021-04-16 15:29:20 --> Config Class Initialized
INFO - 2021-04-16 15:29:20 --> Hooks Class Initialized
INFO - 2021-04-16 15:29:20 --> Output Class Initialized
INFO - 2021-04-16 15:29:20 --> Security Class Initialized
DEBUG - 2021-04-16 15:29:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:29:20 --> Utf8 Class Initialized
INFO - 2021-04-16 15:29:20 --> Input Class Initialized
INFO - 2021-04-16 15:29:20 --> Language Class Initialized
INFO - 2021-04-16 15:29:20 --> URI Class Initialized
INFO - 2021-04-16 15:29:20 --> Router Class Initialized
ERROR - 2021-04-16 15:29:20 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:29:20 --> Output Class Initialized
INFO - 2021-04-16 15:29:20 --> Security Class Initialized
DEBUG - 2021-04-16 15:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:29:20 --> Input Class Initialized
INFO - 2021-04-16 15:29:20 --> Language Class Initialized
ERROR - 2021-04-16 15:29:20 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:30:01 --> Config Class Initialized
INFO - 2021-04-16 15:30:01 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:30:01 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:30:01 --> Utf8 Class Initialized
INFO - 2021-04-16 15:30:01 --> URI Class Initialized
INFO - 2021-04-16 15:30:01 --> Router Class Initialized
INFO - 2021-04-16 15:30:01 --> Output Class Initialized
INFO - 2021-04-16 15:30:01 --> Security Class Initialized
DEBUG - 2021-04-16 15:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:30:01 --> Input Class Initialized
INFO - 2021-04-16 15:30:01 --> Language Class Initialized
INFO - 2021-04-16 15:30:01 --> Loader Class Initialized
INFO - 2021-04-16 15:30:01 --> Helper loaded: url_helper
INFO - 2021-04-16 15:30:01 --> Helper loaded: form_helper
INFO - 2021-04-16 15:30:01 --> Helper loaded: common_helper
INFO - 2021-04-16 15:30:01 --> Helper loaded: util_helper
INFO - 2021-04-16 15:30:01 --> Database Driver Class Initialized
DEBUG - 2021-04-16 15:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 15:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 15:30:01 --> Form Validation Class Initialized
INFO - 2021-04-16 15:30:01 --> Controller Class Initialized
INFO - 2021-04-16 15:30:01 --> Model Class Initialized
INFO - 2021-04-16 15:30:01 --> Model Class Initialized
INFO - 2021-04-16 15:30:01 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 15:30:01 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 15:30:01 --> Final output sent to browser
DEBUG - 2021-04-16 15:30:01 --> Total execution time: 0.0278
INFO - 2021-04-16 15:30:07 --> Config Class Initialized
INFO - 2021-04-16 15:30:07 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:30:07 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:30:07 --> Utf8 Class Initialized
INFO - 2021-04-16 15:30:07 --> URI Class Initialized
INFO - 2021-04-16 15:30:07 --> Router Class Initialized
INFO - 2021-04-16 15:30:07 --> Output Class Initialized
INFO - 2021-04-16 15:30:07 --> Security Class Initialized
DEBUG - 2021-04-16 15:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:30:07 --> Input Class Initialized
INFO - 2021-04-16 15:30:07 --> Language Class Initialized
INFO - 2021-04-16 15:30:07 --> Loader Class Initialized
INFO - 2021-04-16 15:30:07 --> Helper loaded: url_helper
INFO - 2021-04-16 15:30:07 --> Helper loaded: form_helper
INFO - 2021-04-16 15:30:07 --> Helper loaded: common_helper
INFO - 2021-04-16 15:30:07 --> Helper loaded: util_helper
INFO - 2021-04-16 15:30:07 --> Database Driver Class Initialized
DEBUG - 2021-04-16 15:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 15:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 15:30:07 --> Form Validation Class Initialized
INFO - 2021-04-16 15:30:07 --> Controller Class Initialized
INFO - 2021-04-16 15:30:07 --> Model Class Initialized
INFO - 2021-04-16 15:30:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 15:30:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 15:30:07 --> Final output sent to browser
DEBUG - 2021-04-16 15:30:07 --> Total execution time: 0.0284
INFO - 2021-04-16 15:30:09 --> Config Class Initialized
INFO - 2021-04-16 15:30:09 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:30:09 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:30:09 --> Utf8 Class Initialized
INFO - 2021-04-16 15:30:09 --> URI Class Initialized
INFO - 2021-04-16 15:30:09 --> Router Class Initialized
INFO - 2021-04-16 15:30:09 --> Output Class Initialized
INFO - 2021-04-16 15:30:09 --> Security Class Initialized
DEBUG - 2021-04-16 15:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:30:09 --> Input Class Initialized
INFO - 2021-04-16 15:30:09 --> Language Class Initialized
INFO - 2021-04-16 15:30:09 --> Loader Class Initialized
INFO - 2021-04-16 15:30:09 --> Helper loaded: url_helper
INFO - 2021-04-16 15:30:09 --> Helper loaded: form_helper
INFO - 2021-04-16 15:30:09 --> Helper loaded: common_helper
INFO - 2021-04-16 15:30:09 --> Helper loaded: util_helper
INFO - 2021-04-16 15:30:09 --> Database Driver Class Initialized
DEBUG - 2021-04-16 15:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 15:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 15:30:09 --> Form Validation Class Initialized
INFO - 2021-04-16 15:30:09 --> Controller Class Initialized
INFO - 2021-04-16 15:30:09 --> Model Class Initialized
INFO - 2021-04-16 15:30:09 --> Model Class Initialized
INFO - 2021-04-16 15:30:09 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 15:30:09 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 15:30:09 --> Final output sent to browser
DEBUG - 2021-04-16 15:30:09 --> Total execution time: 0.0269
INFO - 2021-04-16 15:30:10 --> Config Class Initialized
INFO - 2021-04-16 15:30:10 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:30:10 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:30:10 --> Utf8 Class Initialized
INFO - 2021-04-16 15:30:10 --> URI Class Initialized
INFO - 2021-04-16 15:30:10 --> Router Class Initialized
INFO - 2021-04-16 15:30:10 --> Output Class Initialized
INFO - 2021-04-16 15:30:10 --> Security Class Initialized
DEBUG - 2021-04-16 15:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:30:10 --> Input Class Initialized
INFO - 2021-04-16 15:30:10 --> Language Class Initialized
INFO - 2021-04-16 15:30:10 --> Loader Class Initialized
INFO - 2021-04-16 15:30:10 --> Helper loaded: url_helper
INFO - 2021-04-16 15:30:10 --> Helper loaded: form_helper
INFO - 2021-04-16 15:30:10 --> Helper loaded: common_helper
INFO - 2021-04-16 15:30:10 --> Helper loaded: util_helper
INFO - 2021-04-16 15:30:10 --> Database Driver Class Initialized
DEBUG - 2021-04-16 15:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 15:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 15:30:10 --> Form Validation Class Initialized
INFO - 2021-04-16 15:30:10 --> Controller Class Initialized
INFO - 2021-04-16 15:30:10 --> Model Class Initialized
INFO - 2021-04-16 15:30:10 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 15:30:10 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 15:30:10 --> Final output sent to browser
DEBUG - 2021-04-16 15:30:10 --> Total execution time: 0.0339
INFO - 2021-04-16 15:30:11 --> Config Class Initialized
INFO - 2021-04-16 15:30:11 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:30:11 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:30:11 --> Utf8 Class Initialized
INFO - 2021-04-16 15:30:11 --> URI Class Initialized
INFO - 2021-04-16 15:30:11 --> Router Class Initialized
INFO - 2021-04-16 15:30:11 --> Output Class Initialized
INFO - 2021-04-16 15:30:11 --> Security Class Initialized
DEBUG - 2021-04-16 15:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:30:11 --> Input Class Initialized
INFO - 2021-04-16 15:30:11 --> Language Class Initialized
INFO - 2021-04-16 15:30:11 --> Loader Class Initialized
INFO - 2021-04-16 15:30:11 --> Helper loaded: url_helper
INFO - 2021-04-16 15:30:11 --> Helper loaded: form_helper
INFO - 2021-04-16 15:30:11 --> Helper loaded: common_helper
INFO - 2021-04-16 15:30:11 --> Helper loaded: util_helper
INFO - 2021-04-16 15:30:11 --> Database Driver Class Initialized
DEBUG - 2021-04-16 15:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 15:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 15:30:11 --> Form Validation Class Initialized
INFO - 2021-04-16 15:30:11 --> Controller Class Initialized
INFO - 2021-04-16 15:30:11 --> Model Class Initialized
INFO - 2021-04-16 15:30:11 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 15:30:11 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 15:30:11 --> Final output sent to browser
DEBUG - 2021-04-16 15:30:11 --> Total execution time: 0.0380
INFO - 2021-04-16 15:30:11 --> Config Class Initialized
INFO - 2021-04-16 15:30:11 --> Hooks Class Initialized
INFO - 2021-04-16 15:30:11 --> Config Class Initialized
INFO - 2021-04-16 15:30:11 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:30:11 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:30:11 --> Utf8 Class Initialized
INFO - 2021-04-16 15:30:11 --> URI Class Initialized
DEBUG - 2021-04-16 15:30:11 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:30:11 --> Utf8 Class Initialized
INFO - 2021-04-16 15:30:11 --> URI Class Initialized
INFO - 2021-04-16 15:30:11 --> Router Class Initialized
INFO - 2021-04-16 15:30:11 --> Router Class Initialized
INFO - 2021-04-16 15:30:11 --> Output Class Initialized
INFO - 2021-04-16 15:30:11 --> Output Class Initialized
INFO - 2021-04-16 15:30:11 --> Security Class Initialized
INFO - 2021-04-16 15:30:11 --> Security Class Initialized
DEBUG - 2021-04-16 15:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:30:11 --> Input Class Initialized
INFO - 2021-04-16 15:30:11 --> Language Class Initialized
DEBUG - 2021-04-16 15:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:30:11 --> Input Class Initialized
INFO - 2021-04-16 15:30:11 --> Language Class Initialized
ERROR - 2021-04-16 15:30:11 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-16 15:30:11 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:30:11 --> Config Class Initialized
INFO - 2021-04-16 15:30:11 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:30:11 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:30:11 --> Utf8 Class Initialized
INFO - 2021-04-16 15:30:11 --> URI Class Initialized
INFO - 2021-04-16 15:30:11 --> Config Class Initialized
INFO - 2021-04-16 15:30:11 --> Hooks Class Initialized
INFO - 2021-04-16 15:30:11 --> Router Class Initialized
INFO - 2021-04-16 15:30:11 --> Config Class Initialized
INFO - 2021-04-16 15:30:11 --> Hooks Class Initialized
INFO - 2021-04-16 15:30:11 --> Config Class Initialized
INFO - 2021-04-16 15:30:11 --> Hooks Class Initialized
INFO - 2021-04-16 15:30:11 --> Output Class Initialized
DEBUG - 2021-04-16 15:30:11 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:30:11 --> Utf8 Class Initialized
INFO - 2021-04-16 15:30:11 --> Security Class Initialized
DEBUG - 2021-04-16 15:30:11 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:30:11 --> URI Class Initialized
INFO - 2021-04-16 15:30:11 --> Utf8 Class Initialized
DEBUG - 2021-04-16 15:30:11 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:30:11 --> Utf8 Class Initialized
DEBUG - 2021-04-16 15:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:30:11 --> Input Class Initialized
INFO - 2021-04-16 15:30:11 --> Router Class Initialized
INFO - 2021-04-16 15:30:11 --> URI Class Initialized
INFO - 2021-04-16 15:30:11 --> URI Class Initialized
INFO - 2021-04-16 15:30:11 --> Language Class Initialized
INFO - 2021-04-16 15:30:11 --> Output Class Initialized
INFO - 2021-04-16 15:30:11 --> Router Class Initialized
INFO - 2021-04-16 15:30:11 --> Router Class Initialized
ERROR - 2021-04-16 15:30:11 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:30:11 --> Security Class Initialized
INFO - 2021-04-16 15:30:11 --> Output Class Initialized
INFO - 2021-04-16 15:30:11 --> Output Class Initialized
DEBUG - 2021-04-16 15:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:30:11 --> Input Class Initialized
INFO - 2021-04-16 15:30:11 --> Language Class Initialized
INFO - 2021-04-16 15:30:11 --> Security Class Initialized
INFO - 2021-04-16 15:30:11 --> Security Class Initialized
ERROR - 2021-04-16 15:30:11 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-16 15:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:30:11 --> Input Class Initialized
INFO - 2021-04-16 15:30:11 --> Input Class Initialized
INFO - 2021-04-16 15:30:11 --> Language Class Initialized
INFO - 2021-04-16 15:30:11 --> Language Class Initialized
ERROR - 2021-04-16 15:30:11 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-16 15:30:11 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:30:11 --> Config Class Initialized
INFO - 2021-04-16 15:30:11 --> Config Class Initialized
INFO - 2021-04-16 15:30:11 --> Hooks Class Initialized
INFO - 2021-04-16 15:30:11 --> Hooks Class Initialized
INFO - 2021-04-16 15:30:11 --> Config Class Initialized
INFO - 2021-04-16 15:30:11 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:30:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:30:11 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:30:11 --> Utf8 Class Initialized
INFO - 2021-04-16 15:30:11 --> Utf8 Class Initialized
INFO - 2021-04-16 15:30:11 --> URI Class Initialized
INFO - 2021-04-16 15:30:11 --> URI Class Initialized
INFO - 2021-04-16 15:30:11 --> Router Class Initialized
INFO - 2021-04-16 15:30:11 --> Router Class Initialized
DEBUG - 2021-04-16 15:30:11 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:30:11 --> Utf8 Class Initialized
INFO - 2021-04-16 15:30:11 --> Output Class Initialized
INFO - 2021-04-16 15:30:11 --> Output Class Initialized
INFO - 2021-04-16 15:30:11 --> Config Class Initialized
INFO - 2021-04-16 15:30:11 --> Hooks Class Initialized
INFO - 2021-04-16 15:30:11 --> Security Class Initialized
INFO - 2021-04-16 15:30:11 --> URI Class Initialized
INFO - 2021-04-16 15:30:11 --> Security Class Initialized
INFO - 2021-04-16 15:30:11 --> Router Class Initialized
DEBUG - 2021-04-16 15:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:30:11 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:30:11 --> Input Class Initialized
INFO - 2021-04-16 15:30:11 --> Utf8 Class Initialized
INFO - 2021-04-16 15:30:11 --> Language Class Initialized
INFO - 2021-04-16 15:30:11 --> Config Class Initialized
INFO - 2021-04-16 15:30:11 --> Hooks Class Initialized
INFO - 2021-04-16 15:30:11 --> Output Class Initialized
INFO - 2021-04-16 15:30:11 --> URI Class Initialized
ERROR - 2021-04-16 15:30:11 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-16 15:30:11 --> Security Class Initialized
DEBUG - 2021-04-16 15:30:11 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:30:11 --> Utf8 Class Initialized
INFO - 2021-04-16 15:30:11 --> Router Class Initialized
INFO - 2021-04-16 15:30:11 --> URI Class Initialized
DEBUG - 2021-04-16 15:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:30:11 --> Input Class Initialized
INFO - 2021-04-16 15:30:11 --> Language Class Initialized
INFO - 2021-04-16 15:30:11 --> Router Class Initialized
INFO - 2021-04-16 15:30:11 --> Output Class Initialized
ERROR - 2021-04-16 15:30:11 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:30:11 --> Security Class Initialized
INFO - 2021-04-16 15:30:11 --> Output Class Initialized
DEBUG - 2021-04-16 15:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:30:11 --> Security Class Initialized
DEBUG - 2021-04-16 15:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:30:11 --> Input Class Initialized
INFO - 2021-04-16 15:30:11 --> Input Class Initialized
DEBUG - 2021-04-16 15:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:30:11 --> Language Class Initialized
INFO - 2021-04-16 15:30:11 --> Input Class Initialized
INFO - 2021-04-16 15:30:11 --> Language Class Initialized
INFO - 2021-04-16 15:30:11 --> Language Class Initialized
ERROR - 2021-04-16 15:30:11 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-16 15:30:11 --> 404 Page Not Found: user/Assets/img
ERROR - 2021-04-16 15:30:11 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:30:11 --> Config Class Initialized
INFO - 2021-04-16 15:30:11 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:30:11 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:30:11 --> Utf8 Class Initialized
INFO - 2021-04-16 15:30:11 --> URI Class Initialized
INFO - 2021-04-16 15:30:11 --> Router Class Initialized
INFO - 2021-04-16 15:30:11 --> Output Class Initialized
INFO - 2021-04-16 15:30:11 --> Security Class Initialized
DEBUG - 2021-04-16 15:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:30:11 --> Input Class Initialized
INFO - 2021-04-16 15:30:11 --> Language Class Initialized
ERROR - 2021-04-16 15:30:11 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:30:11 --> Config Class Initialized
INFO - 2021-04-16 15:30:11 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:30:11 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:30:11 --> Utf8 Class Initialized
INFO - 2021-04-16 15:30:11 --> URI Class Initialized
INFO - 2021-04-16 15:30:11 --> Router Class Initialized
INFO - 2021-04-16 15:30:11 --> Output Class Initialized
INFO - 2021-04-16 15:30:11 --> Security Class Initialized
DEBUG - 2021-04-16 15:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:30:11 --> Input Class Initialized
INFO - 2021-04-16 15:30:11 --> Language Class Initialized
ERROR - 2021-04-16 15:30:11 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:30:11 --> Config Class Initialized
INFO - 2021-04-16 15:30:11 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:30:11 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:30:11 --> Utf8 Class Initialized
INFO - 2021-04-16 15:30:11 --> URI Class Initialized
INFO - 2021-04-16 15:30:11 --> Router Class Initialized
INFO - 2021-04-16 15:30:11 --> Output Class Initialized
INFO - 2021-04-16 15:30:11 --> Security Class Initialized
DEBUG - 2021-04-16 15:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:30:11 --> Input Class Initialized
INFO - 2021-04-16 15:30:11 --> Language Class Initialized
ERROR - 2021-04-16 15:30:11 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:30:11 --> Config Class Initialized
INFO - 2021-04-16 15:30:11 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:30:11 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:30:11 --> Utf8 Class Initialized
INFO - 2021-04-16 15:30:11 --> URI Class Initialized
INFO - 2021-04-16 15:30:11 --> Router Class Initialized
INFO - 2021-04-16 15:30:11 --> Output Class Initialized
INFO - 2021-04-16 15:30:11 --> Security Class Initialized
DEBUG - 2021-04-16 15:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:30:11 --> Input Class Initialized
INFO - 2021-04-16 15:30:11 --> Language Class Initialized
ERROR - 2021-04-16 15:30:11 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:30:11 --> Config Class Initialized
INFO - 2021-04-16 15:30:11 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:30:11 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:30:11 --> Utf8 Class Initialized
INFO - 2021-04-16 15:30:11 --> URI Class Initialized
INFO - 2021-04-16 15:30:11 --> Router Class Initialized
INFO - 2021-04-16 15:30:11 --> Output Class Initialized
INFO - 2021-04-16 15:30:11 --> Security Class Initialized
DEBUG - 2021-04-16 15:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:30:11 --> Input Class Initialized
INFO - 2021-04-16 15:30:11 --> Language Class Initialized
ERROR - 2021-04-16 15:30:11 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:30:11 --> Config Class Initialized
INFO - 2021-04-16 15:30:11 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:30:11 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:30:11 --> Utf8 Class Initialized
INFO - 2021-04-16 15:30:11 --> URI Class Initialized
INFO - 2021-04-16 15:30:11 --> Router Class Initialized
INFO - 2021-04-16 15:30:11 --> Output Class Initialized
INFO - 2021-04-16 15:30:11 --> Security Class Initialized
DEBUG - 2021-04-16 15:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:30:11 --> Input Class Initialized
INFO - 2021-04-16 15:30:11 --> Language Class Initialized
ERROR - 2021-04-16 15:30:11 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:30:13 --> Config Class Initialized
INFO - 2021-04-16 15:30:13 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:30:13 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:30:13 --> Utf8 Class Initialized
INFO - 2021-04-16 15:30:13 --> URI Class Initialized
INFO - 2021-04-16 15:30:13 --> Router Class Initialized
INFO - 2021-04-16 15:30:13 --> Output Class Initialized
INFO - 2021-04-16 15:30:13 --> Security Class Initialized
DEBUG - 2021-04-16 15:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:30:13 --> Input Class Initialized
INFO - 2021-04-16 15:30:13 --> Language Class Initialized
INFO - 2021-04-16 15:30:13 --> Loader Class Initialized
INFO - 2021-04-16 15:30:13 --> Helper loaded: url_helper
INFO - 2021-04-16 15:30:13 --> Helper loaded: form_helper
INFO - 2021-04-16 15:30:13 --> Helper loaded: common_helper
INFO - 2021-04-16 15:30:13 --> Helper loaded: util_helper
INFO - 2021-04-16 15:30:13 --> Database Driver Class Initialized
DEBUG - 2021-04-16 15:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 15:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 15:30:13 --> Form Validation Class Initialized
INFO - 2021-04-16 15:30:13 --> Controller Class Initialized
INFO - 2021-04-16 15:30:13 --> Model Class Initialized
INFO - 2021-04-16 15:30:13 --> Model Class Initialized
INFO - 2021-04-16 15:30:13 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 15:30:13 --> Final output sent to browser
DEBUG - 2021-04-16 15:30:13 --> Total execution time: 0.0275
INFO - 2021-04-16 15:30:16 --> Config Class Initialized
INFO - 2021-04-16 15:30:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:30:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:30:16 --> Utf8 Class Initialized
INFO - 2021-04-16 15:30:16 --> URI Class Initialized
INFO - 2021-04-16 15:30:16 --> Router Class Initialized
INFO - 2021-04-16 15:30:16 --> Output Class Initialized
INFO - 2021-04-16 15:30:16 --> Security Class Initialized
DEBUG - 2021-04-16 15:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:30:16 --> Input Class Initialized
INFO - 2021-04-16 15:30:16 --> Language Class Initialized
INFO - 2021-04-16 15:30:16 --> Loader Class Initialized
INFO - 2021-04-16 15:30:16 --> Helper loaded: url_helper
INFO - 2021-04-16 15:30:16 --> Helper loaded: form_helper
INFO - 2021-04-16 15:30:16 --> Helper loaded: common_helper
INFO - 2021-04-16 15:30:16 --> Helper loaded: util_helper
INFO - 2021-04-16 15:30:16 --> Database Driver Class Initialized
DEBUG - 2021-04-16 15:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 15:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 15:30:16 --> Form Validation Class Initialized
INFO - 2021-04-16 15:30:16 --> Controller Class Initialized
INFO - 2021-04-16 15:30:16 --> Model Class Initialized
INFO - 2021-04-16 15:30:16 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 15:30:16 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 15:30:16 --> Final output sent to browser
DEBUG - 2021-04-16 15:30:16 --> Total execution time: 0.0287
INFO - 2021-04-16 15:30:16 --> Config Class Initialized
INFO - 2021-04-16 15:30:16 --> Hooks Class Initialized
INFO - 2021-04-16 15:30:16 --> Config Class Initialized
INFO - 2021-04-16 15:30:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:30:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:30:16 --> Utf8 Class Initialized
DEBUG - 2021-04-16 15:30:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:30:16 --> Utf8 Class Initialized
INFO - 2021-04-16 15:30:16 --> URI Class Initialized
INFO - 2021-04-16 15:30:16 --> URI Class Initialized
INFO - 2021-04-16 15:30:16 --> Router Class Initialized
INFO - 2021-04-16 15:30:16 --> Router Class Initialized
INFO - 2021-04-16 15:30:16 --> Output Class Initialized
INFO - 2021-04-16 15:30:16 --> Security Class Initialized
INFO - 2021-04-16 15:30:16 --> Output Class Initialized
DEBUG - 2021-04-16 15:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:30:16 --> Security Class Initialized
INFO - 2021-04-16 15:30:16 --> Input Class Initialized
INFO - 2021-04-16 15:30:16 --> Language Class Initialized
DEBUG - 2021-04-16 15:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:30:16 --> Input Class Initialized
INFO - 2021-04-16 15:30:16 --> Language Class Initialized
ERROR - 2021-04-16 15:30:16 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-16 15:30:16 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:30:16 --> Config Class Initialized
INFO - 2021-04-16 15:30:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:30:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:30:16 --> Utf8 Class Initialized
INFO - 2021-04-16 15:30:16 --> URI Class Initialized
INFO - 2021-04-16 15:30:16 --> Router Class Initialized
INFO - 2021-04-16 15:30:16 --> Output Class Initialized
INFO - 2021-04-16 15:30:16 --> Security Class Initialized
DEBUG - 2021-04-16 15:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:30:16 --> Input Class Initialized
INFO - 2021-04-16 15:30:16 --> Language Class Initialized
ERROR - 2021-04-16 15:30:16 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-16 15:30:16 --> Config Class Initialized
INFO - 2021-04-16 15:30:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:30:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:30:16 --> Utf8 Class Initialized
INFO - 2021-04-16 15:30:16 --> URI Class Initialized
INFO - 2021-04-16 15:30:16 --> Router Class Initialized
INFO - 2021-04-16 15:30:16 --> Output Class Initialized
INFO - 2021-04-16 15:30:16 --> Security Class Initialized
DEBUG - 2021-04-16 15:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:30:16 --> Input Class Initialized
INFO - 2021-04-16 15:30:16 --> Language Class Initialized
INFO - 2021-04-16 15:30:16 --> Loader Class Initialized
INFO - 2021-04-16 15:30:16 --> Helper loaded: url_helper
INFO - 2021-04-16 15:30:16 --> Helper loaded: form_helper
INFO - 2021-04-16 15:30:16 --> Helper loaded: common_helper
INFO - 2021-04-16 15:30:16 --> Helper loaded: util_helper
INFO - 2021-04-16 15:30:16 --> Database Driver Class Initialized
DEBUG - 2021-04-16 15:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 15:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 15:30:16 --> Form Validation Class Initialized
INFO - 2021-04-16 15:30:16 --> Controller Class Initialized
INFO - 2021-04-16 15:30:16 --> Model Class Initialized
INFO - 2021-04-16 15:30:16 --> Model Class Initialized
INFO - 2021-04-16 15:30:16 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 15:30:16 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 15:30:16 --> Final output sent to browser
DEBUG - 2021-04-16 15:30:16 --> Total execution time: 0.0273
INFO - 2021-04-16 15:31:29 --> Config Class Initialized
INFO - 2021-04-16 15:31:29 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:31:29 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:31:29 --> Utf8 Class Initialized
INFO - 2021-04-16 15:31:29 --> URI Class Initialized
INFO - 2021-04-16 15:31:29 --> Router Class Initialized
INFO - 2021-04-16 15:31:29 --> Output Class Initialized
INFO - 2021-04-16 15:31:29 --> Security Class Initialized
DEBUG - 2021-04-16 15:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:31:29 --> Input Class Initialized
INFO - 2021-04-16 15:31:29 --> Language Class Initialized
INFO - 2021-04-16 15:31:29 --> Loader Class Initialized
INFO - 2021-04-16 15:31:29 --> Helper loaded: url_helper
INFO - 2021-04-16 15:31:29 --> Helper loaded: form_helper
INFO - 2021-04-16 15:31:29 --> Helper loaded: common_helper
INFO - 2021-04-16 15:31:29 --> Helper loaded: util_helper
INFO - 2021-04-16 15:31:29 --> Database Driver Class Initialized
DEBUG - 2021-04-16 15:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 15:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 15:31:29 --> Form Validation Class Initialized
INFO - 2021-04-16 15:31:29 --> Controller Class Initialized
INFO - 2021-04-16 15:31:29 --> Model Class Initialized
INFO - 2021-04-16 15:31:29 --> Model Class Initialized
INFO - 2021-04-16 15:31:29 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 15:31:29 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 15:31:29 --> Final output sent to browser
DEBUG - 2021-04-16 15:31:29 --> Total execution time: 0.0263
INFO - 2021-04-16 15:31:32 --> Config Class Initialized
INFO - 2021-04-16 15:31:32 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:31:32 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:31:32 --> Utf8 Class Initialized
INFO - 2021-04-16 15:31:32 --> URI Class Initialized
INFO - 2021-04-16 15:31:32 --> Router Class Initialized
INFO - 2021-04-16 15:31:32 --> Output Class Initialized
INFO - 2021-04-16 15:31:32 --> Security Class Initialized
DEBUG - 2021-04-16 15:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:31:32 --> Input Class Initialized
INFO - 2021-04-16 15:31:32 --> Language Class Initialized
INFO - 2021-04-16 15:31:32 --> Loader Class Initialized
INFO - 2021-04-16 15:31:32 --> Helper loaded: url_helper
INFO - 2021-04-16 15:31:32 --> Helper loaded: form_helper
INFO - 2021-04-16 15:31:32 --> Helper loaded: common_helper
INFO - 2021-04-16 15:31:32 --> Helper loaded: util_helper
INFO - 2021-04-16 15:31:32 --> Database Driver Class Initialized
DEBUG - 2021-04-16 15:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 15:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 15:31:32 --> Form Validation Class Initialized
INFO - 2021-04-16 15:31:32 --> Controller Class Initialized
INFO - 2021-04-16 15:31:32 --> Model Class Initialized
INFO - 2021-04-16 15:31:32 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 15:31:32 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 15:31:32 --> Final output sent to browser
DEBUG - 2021-04-16 15:31:32 --> Total execution time: 0.0284
INFO - 2021-04-16 15:31:32 --> Config Class Initialized
INFO - 2021-04-16 15:31:32 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:31:32 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:31:32 --> Utf8 Class Initialized
INFO - 2021-04-16 15:31:32 --> URI Class Initialized
INFO - 2021-04-16 15:31:32 --> Router Class Initialized
INFO - 2021-04-16 15:31:32 --> Output Class Initialized
INFO - 2021-04-16 15:31:32 --> Security Class Initialized
DEBUG - 2021-04-16 15:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:31:32 --> Input Class Initialized
INFO - 2021-04-16 15:31:32 --> Language Class Initialized
ERROR - 2021-04-16 15:31:32 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:31:33 --> Config Class Initialized
INFO - 2021-04-16 15:31:33 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:31:33 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:31:33 --> Utf8 Class Initialized
INFO - 2021-04-16 15:31:33 --> URI Class Initialized
INFO - 2021-04-16 15:31:33 --> Router Class Initialized
INFO - 2021-04-16 15:31:33 --> Output Class Initialized
INFO - 2021-04-16 15:31:33 --> Security Class Initialized
DEBUG - 2021-04-16 15:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:31:33 --> Input Class Initialized
INFO - 2021-04-16 15:31:33 --> Language Class Initialized
INFO - 2021-04-16 15:31:33 --> Loader Class Initialized
INFO - 2021-04-16 15:31:33 --> Helper loaded: url_helper
INFO - 2021-04-16 15:31:33 --> Helper loaded: form_helper
INFO - 2021-04-16 15:31:33 --> Helper loaded: common_helper
INFO - 2021-04-16 15:31:33 --> Helper loaded: util_helper
INFO - 2021-04-16 15:31:33 --> Database Driver Class Initialized
DEBUG - 2021-04-16 15:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 15:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 15:31:33 --> Form Validation Class Initialized
INFO - 2021-04-16 15:31:33 --> Controller Class Initialized
INFO - 2021-04-16 15:31:33 --> Model Class Initialized
INFO - 2021-04-16 15:31:33 --> Model Class Initialized
INFO - 2021-04-16 15:31:33 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 15:31:33 --> Final output sent to browser
DEBUG - 2021-04-16 15:31:33 --> Total execution time: 0.0257
INFO - 2021-04-16 15:32:08 --> Config Class Initialized
INFO - 2021-04-16 15:32:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:32:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:32:08 --> Utf8 Class Initialized
INFO - 2021-04-16 15:32:08 --> URI Class Initialized
INFO - 2021-04-16 15:32:08 --> Router Class Initialized
INFO - 2021-04-16 15:32:08 --> Output Class Initialized
INFO - 2021-04-16 15:32:08 --> Security Class Initialized
DEBUG - 2021-04-16 15:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:32:08 --> Input Class Initialized
INFO - 2021-04-16 15:32:08 --> Language Class Initialized
INFO - 2021-04-16 15:32:08 --> Loader Class Initialized
INFO - 2021-04-16 15:32:08 --> Helper loaded: url_helper
INFO - 2021-04-16 15:32:08 --> Helper loaded: form_helper
INFO - 2021-04-16 15:32:08 --> Helper loaded: common_helper
INFO - 2021-04-16 15:32:08 --> Helper loaded: util_helper
INFO - 2021-04-16 15:32:08 --> Database Driver Class Initialized
DEBUG - 2021-04-16 15:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 15:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 15:32:08 --> Form Validation Class Initialized
INFO - 2021-04-16 15:32:08 --> Controller Class Initialized
INFO - 2021-04-16 15:32:08 --> Model Class Initialized
INFO - 2021-04-16 15:32:08 --> Model Class Initialized
INFO - 2021-04-16 15:32:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-16 15:32:08 --> Config Class Initialized
INFO - 2021-04-16 15:32:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:32:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:32:08 --> Utf8 Class Initialized
INFO - 2021-04-16 15:32:08 --> URI Class Initialized
INFO - 2021-04-16 15:32:08 --> Router Class Initialized
INFO - 2021-04-16 15:32:08 --> Output Class Initialized
INFO - 2021-04-16 15:32:08 --> Security Class Initialized
DEBUG - 2021-04-16 15:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:32:08 --> Input Class Initialized
INFO - 2021-04-16 15:32:08 --> Language Class Initialized
INFO - 2021-04-16 15:32:08 --> Loader Class Initialized
INFO - 2021-04-16 15:32:08 --> Helper loaded: url_helper
INFO - 2021-04-16 15:32:08 --> Helper loaded: form_helper
INFO - 2021-04-16 15:32:08 --> Helper loaded: common_helper
INFO - 2021-04-16 15:32:08 --> Helper loaded: util_helper
INFO - 2021-04-16 15:32:08 --> Database Driver Class Initialized
DEBUG - 2021-04-16 15:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 15:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 15:32:08 --> Form Validation Class Initialized
INFO - 2021-04-16 15:32:08 --> Controller Class Initialized
INFO - 2021-04-16 15:32:08 --> Model Class Initialized
INFO - 2021-04-16 15:32:08 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 15:32:08 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 15:32:08 --> Final output sent to browser
DEBUG - 2021-04-16 15:32:08 --> Total execution time: 0.0308
INFO - 2021-04-16 15:32:08 --> Config Class Initialized
INFO - 2021-04-16 15:32:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:32:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:32:08 --> Utf8 Class Initialized
INFO - 2021-04-16 15:32:08 --> URI Class Initialized
INFO - 2021-04-16 15:32:08 --> Router Class Initialized
INFO - 2021-04-16 15:32:08 --> Output Class Initialized
INFO - 2021-04-16 15:32:08 --> Config Class Initialized
INFO - 2021-04-16 15:32:08 --> Config Class Initialized
INFO - 2021-04-16 15:32:08 --> Hooks Class Initialized
INFO - 2021-04-16 15:32:08 --> Config Class Initialized
INFO - 2021-04-16 15:32:08 --> Hooks Class Initialized
INFO - 2021-04-16 15:32:08 --> Security Class Initialized
INFO - 2021-04-16 15:32:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:32:08 --> Input Class Initialized
DEBUG - 2021-04-16 15:32:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:32:08 --> Language Class Initialized
INFO - 2021-04-16 15:32:08 --> Utf8 Class Initialized
DEBUG - 2021-04-16 15:32:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:32:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:32:08 --> Utf8 Class Initialized
INFO - 2021-04-16 15:32:08 --> Utf8 Class Initialized
INFO - 2021-04-16 15:32:08 --> URI Class Initialized
ERROR - 2021-04-16 15:32:08 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:32:08 --> URI Class Initialized
INFO - 2021-04-16 15:32:08 --> URI Class Initialized
INFO - 2021-04-16 15:32:08 --> Router Class Initialized
INFO - 2021-04-16 15:32:08 --> Router Class Initialized
INFO - 2021-04-16 15:32:08 --> Router Class Initialized
INFO - 2021-04-16 15:32:08 --> Output Class Initialized
INFO - 2021-04-16 15:32:08 --> Output Class Initialized
INFO - 2021-04-16 15:32:08 --> Output Class Initialized
INFO - 2021-04-16 15:32:08 --> Security Class Initialized
INFO - 2021-04-16 15:32:08 --> Security Class Initialized
INFO - 2021-04-16 15:32:08 --> Security Class Initialized
DEBUG - 2021-04-16 15:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:32:08 --> Input Class Initialized
DEBUG - 2021-04-16 15:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:32:08 --> Input Class Initialized
INFO - 2021-04-16 15:32:08 --> Input Class Initialized
INFO - 2021-04-16 15:32:08 --> Language Class Initialized
INFO - 2021-04-16 15:32:08 --> Language Class Initialized
INFO - 2021-04-16 15:32:08 --> Language Class Initialized
ERROR - 2021-04-16 15:32:08 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-16 15:32:08 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-16 15:32:08 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:32:08 --> Config Class Initialized
INFO - 2021-04-16 15:32:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:32:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:32:08 --> Utf8 Class Initialized
INFO - 2021-04-16 15:32:08 --> URI Class Initialized
INFO - 2021-04-16 15:32:08 --> Router Class Initialized
INFO - 2021-04-16 15:32:08 --> Config Class Initialized
INFO - 2021-04-16 15:32:08 --> Hooks Class Initialized
INFO - 2021-04-16 15:32:08 --> Output Class Initialized
INFO - 2021-04-16 15:32:08 --> Config Class Initialized
INFO - 2021-04-16 15:32:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:32:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:32:08 --> Security Class Initialized
INFO - 2021-04-16 15:32:08 --> Utf8 Class Initialized
INFO - 2021-04-16 15:32:08 --> URI Class Initialized
DEBUG - 2021-04-16 15:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:32:08 --> Input Class Initialized
INFO - 2021-04-16 15:32:08 --> Language Class Initialized
DEBUG - 2021-04-16 15:32:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:32:08 --> Utf8 Class Initialized
INFO - 2021-04-16 15:32:08 --> URI Class Initialized
ERROR - 2021-04-16 15:32:08 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:32:08 --> Router Class Initialized
INFO - 2021-04-16 15:32:08 --> Router Class Initialized
INFO - 2021-04-16 15:32:08 --> Config Class Initialized
INFO - 2021-04-16 15:32:08 --> Output Class Initialized
INFO - 2021-04-16 15:32:08 --> Config Class Initialized
INFO - 2021-04-16 15:32:08 --> Hooks Class Initialized
INFO - 2021-04-16 15:32:08 --> Output Class Initialized
INFO - 2021-04-16 15:32:08 --> Security Class Initialized
INFO - 2021-04-16 15:32:08 --> Security Class Initialized
DEBUG - 2021-04-16 15:32:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:32:08 --> Utf8 Class Initialized
INFO - 2021-04-16 15:32:08 --> Input Class Initialized
DEBUG - 2021-04-16 15:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:32:08 --> Input Class Initialized
INFO - 2021-04-16 15:32:08 --> URI Class Initialized
INFO - 2021-04-16 15:32:08 --> Language Class Initialized
INFO - 2021-04-16 15:32:08 --> Language Class Initialized
INFO - 2021-04-16 15:32:08 --> Config Class Initialized
INFO - 2021-04-16 15:32:08 --> Hooks Class Initialized
INFO - 2021-04-16 15:32:08 --> Router Class Initialized
ERROR - 2021-04-16 15:32:08 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-16 15:32:08 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-16 15:32:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:32:08 --> Utf8 Class Initialized
INFO - 2021-04-16 15:32:08 --> Output Class Initialized
INFO - 2021-04-16 15:32:08 --> URI Class Initialized
INFO - 2021-04-16 15:32:08 --> Hooks Class Initialized
INFO - 2021-04-16 15:32:08 --> Security Class Initialized
INFO - 2021-04-16 15:32:08 --> Router Class Initialized
DEBUG - 2021-04-16 15:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:32:08 --> Output Class Initialized
DEBUG - 2021-04-16 15:32:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:32:08 --> Input Class Initialized
INFO - 2021-04-16 15:32:08 --> Utf8 Class Initialized
INFO - 2021-04-16 15:32:08 --> Language Class Initialized
INFO - 2021-04-16 15:32:08 --> Security Class Initialized
INFO - 2021-04-16 15:32:08 --> URI Class Initialized
DEBUG - 2021-04-16 15:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:32:08 --> Input Class Initialized
ERROR - 2021-04-16 15:32:08 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:32:08 --> Language Class Initialized
INFO - 2021-04-16 15:32:08 --> Router Class Initialized
ERROR - 2021-04-16 15:32:08 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-16 15:32:08 --> Output Class Initialized
INFO - 2021-04-16 15:32:08 --> Config Class Initialized
INFO - 2021-04-16 15:32:08 --> Hooks Class Initialized
INFO - 2021-04-16 15:32:08 --> Security Class Initialized
DEBUG - 2021-04-16 15:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:32:08 --> Input Class Initialized
INFO - 2021-04-16 15:32:08 --> Language Class Initialized
DEBUG - 2021-04-16 15:32:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:32:08 --> Utf8 Class Initialized
ERROR - 2021-04-16 15:32:08 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:32:08 --> URI Class Initialized
INFO - 2021-04-16 15:32:08 --> Router Class Initialized
INFO - 2021-04-16 15:32:08 --> Output Class Initialized
INFO - 2021-04-16 15:32:08 --> Security Class Initialized
DEBUG - 2021-04-16 15:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:32:08 --> Input Class Initialized
INFO - 2021-04-16 15:32:08 --> Language Class Initialized
ERROR - 2021-04-16 15:32:08 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-16 15:32:08 --> Config Class Initialized
INFO - 2021-04-16 15:32:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:32:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:32:08 --> Utf8 Class Initialized
INFO - 2021-04-16 15:32:08 --> URI Class Initialized
INFO - 2021-04-16 15:32:08 --> Router Class Initialized
INFO - 2021-04-16 15:32:08 --> Output Class Initialized
INFO - 2021-04-16 15:32:08 --> Security Class Initialized
DEBUG - 2021-04-16 15:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:32:08 --> Input Class Initialized
INFO - 2021-04-16 15:32:08 --> Language Class Initialized
ERROR - 2021-04-16 15:32:08 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:32:08 --> Config Class Initialized
INFO - 2021-04-16 15:32:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:32:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:32:08 --> Utf8 Class Initialized
INFO - 2021-04-16 15:32:08 --> URI Class Initialized
INFO - 2021-04-16 15:32:08 --> Router Class Initialized
INFO - 2021-04-16 15:32:08 --> Output Class Initialized
INFO - 2021-04-16 15:32:08 --> Security Class Initialized
DEBUG - 2021-04-16 15:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:32:08 --> Input Class Initialized
INFO - 2021-04-16 15:32:08 --> Language Class Initialized
ERROR - 2021-04-16 15:32:08 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:32:08 --> Config Class Initialized
INFO - 2021-04-16 15:32:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:32:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:32:08 --> Utf8 Class Initialized
INFO - 2021-04-16 15:32:08 --> URI Class Initialized
INFO - 2021-04-16 15:32:08 --> Router Class Initialized
INFO - 2021-04-16 15:32:08 --> Output Class Initialized
INFO - 2021-04-16 15:32:08 --> Security Class Initialized
DEBUG - 2021-04-16 15:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:32:08 --> Input Class Initialized
INFO - 2021-04-16 15:32:08 --> Language Class Initialized
ERROR - 2021-04-16 15:32:08 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:32:08 --> Config Class Initialized
INFO - 2021-04-16 15:32:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:32:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:32:08 --> Utf8 Class Initialized
INFO - 2021-04-16 15:32:08 --> URI Class Initialized
INFO - 2021-04-16 15:32:08 --> Router Class Initialized
INFO - 2021-04-16 15:32:08 --> Output Class Initialized
INFO - 2021-04-16 15:32:08 --> Security Class Initialized
DEBUG - 2021-04-16 15:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:32:08 --> Input Class Initialized
INFO - 2021-04-16 15:32:08 --> Language Class Initialized
ERROR - 2021-04-16 15:32:08 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:32:08 --> Config Class Initialized
INFO - 2021-04-16 15:32:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:32:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:32:08 --> Utf8 Class Initialized
INFO - 2021-04-16 15:32:08 --> URI Class Initialized
INFO - 2021-04-16 15:32:08 --> Router Class Initialized
INFO - 2021-04-16 15:32:08 --> Output Class Initialized
INFO - 2021-04-16 15:32:08 --> Security Class Initialized
DEBUG - 2021-04-16 15:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:32:08 --> Input Class Initialized
INFO - 2021-04-16 15:32:08 --> Language Class Initialized
ERROR - 2021-04-16 15:32:08 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:32:08 --> Config Class Initialized
INFO - 2021-04-16 15:32:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:32:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:32:08 --> Utf8 Class Initialized
INFO - 2021-04-16 15:32:08 --> URI Class Initialized
INFO - 2021-04-16 15:32:08 --> Router Class Initialized
INFO - 2021-04-16 15:32:08 --> Output Class Initialized
INFO - 2021-04-16 15:32:08 --> Security Class Initialized
DEBUG - 2021-04-16 15:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:32:08 --> Input Class Initialized
INFO - 2021-04-16 15:32:08 --> Language Class Initialized
ERROR - 2021-04-16 15:32:08 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:32:08 --> Config Class Initialized
INFO - 2021-04-16 15:32:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:32:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:32:08 --> Utf8 Class Initialized
INFO - 2021-04-16 15:32:08 --> URI Class Initialized
INFO - 2021-04-16 15:32:08 --> Router Class Initialized
INFO - 2021-04-16 15:32:08 --> Output Class Initialized
INFO - 2021-04-16 15:32:08 --> Security Class Initialized
DEBUG - 2021-04-16 15:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:32:08 --> Input Class Initialized
INFO - 2021-04-16 15:32:08 --> Language Class Initialized
ERROR - 2021-04-16 15:32:08 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:32:08 --> Config Class Initialized
INFO - 2021-04-16 15:32:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:32:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:32:08 --> Utf8 Class Initialized
INFO - 2021-04-16 15:32:08 --> URI Class Initialized
INFO - 2021-04-16 15:32:08 --> Router Class Initialized
INFO - 2021-04-16 15:32:08 --> Output Class Initialized
INFO - 2021-04-16 15:32:08 --> Security Class Initialized
DEBUG - 2021-04-16 15:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:32:08 --> Input Class Initialized
INFO - 2021-04-16 15:32:08 --> Language Class Initialized
ERROR - 2021-04-16 15:32:08 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:36:01 --> Config Class Initialized
INFO - 2021-04-16 15:36:01 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:36:01 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:36:01 --> Utf8 Class Initialized
INFO - 2021-04-16 15:36:01 --> URI Class Initialized
INFO - 2021-04-16 15:36:01 --> Router Class Initialized
INFO - 2021-04-16 15:36:01 --> Output Class Initialized
INFO - 2021-04-16 15:36:01 --> Security Class Initialized
DEBUG - 2021-04-16 15:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:36:01 --> Input Class Initialized
INFO - 2021-04-16 15:36:01 --> Language Class Initialized
INFO - 2021-04-16 15:36:01 --> Loader Class Initialized
INFO - 2021-04-16 15:36:01 --> Helper loaded: url_helper
INFO - 2021-04-16 15:36:01 --> Helper loaded: form_helper
INFO - 2021-04-16 15:36:01 --> Helper loaded: common_helper
INFO - 2021-04-16 15:36:01 --> Helper loaded: util_helper
INFO - 2021-04-16 15:36:01 --> Database Driver Class Initialized
DEBUG - 2021-04-16 15:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 15:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 15:36:01 --> Form Validation Class Initialized
INFO - 2021-04-16 15:36:01 --> Controller Class Initialized
INFO - 2021-04-16 15:36:01 --> Model Class Initialized
INFO - 2021-04-16 15:36:01 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 15:36:01 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 15:36:01 --> Final output sent to browser
DEBUG - 2021-04-16 15:36:01 --> Total execution time: 0.0412
INFO - 2021-04-16 15:36:01 --> Config Class Initialized
INFO - 2021-04-16 15:36:01 --> Hooks Class Initialized
INFO - 2021-04-16 15:36:01 --> Config Class Initialized
INFO - 2021-04-16 15:36:01 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:36:01 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:36:01 --> Utf8 Class Initialized
DEBUG - 2021-04-16 15:36:01 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:36:01 --> Utf8 Class Initialized
INFO - 2021-04-16 15:36:01 --> URI Class Initialized
INFO - 2021-04-16 15:36:01 --> URI Class Initialized
INFO - 2021-04-16 15:36:01 --> Router Class Initialized
INFO - 2021-04-16 15:36:01 --> Router Class Initialized
INFO - 2021-04-16 15:36:01 --> Output Class Initialized
INFO - 2021-04-16 15:36:01 --> Output Class Initialized
INFO - 2021-04-16 15:36:01 --> Security Class Initialized
INFO - 2021-04-16 15:36:01 --> Security Class Initialized
DEBUG - 2021-04-16 15:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:36:01 --> Input Class Initialized
DEBUG - 2021-04-16 15:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:36:01 --> Language Class Initialized
INFO - 2021-04-16 15:36:01 --> Input Class Initialized
INFO - 2021-04-16 15:36:01 --> Language Class Initialized
ERROR - 2021-04-16 15:36:01 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-16 15:36:01 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:36:01 --> Config Class Initialized
INFO - 2021-04-16 15:36:01 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:36:01 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:36:01 --> Utf8 Class Initialized
INFO - 2021-04-16 15:36:01 --> URI Class Initialized
INFO - 2021-04-16 15:36:01 --> Config Class Initialized
INFO - 2021-04-16 15:36:01 --> Hooks Class Initialized
INFO - 2021-04-16 15:36:01 --> Router Class Initialized
INFO - 2021-04-16 15:36:01 --> Output Class Initialized
DEBUG - 2021-04-16 15:36:01 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:36:01 --> Utf8 Class Initialized
INFO - 2021-04-16 15:36:01 --> URI Class Initialized
INFO - 2021-04-16 15:36:01 --> Security Class Initialized
DEBUG - 2021-04-16 15:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:36:01 --> Router Class Initialized
INFO - 2021-04-16 15:36:01 --> Input Class Initialized
INFO - 2021-04-16 15:36:01 --> Language Class Initialized
INFO - 2021-04-16 15:36:01 --> Output Class Initialized
INFO - 2021-04-16 15:36:01 --> Config Class Initialized
INFO - 2021-04-16 15:36:01 --> Hooks Class Initialized
INFO - 2021-04-16 15:36:01 --> Security Class Initialized
DEBUG - 2021-04-16 15:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:36:01 --> Input Class Initialized
ERROR - 2021-04-16 15:36:01 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:36:01 --> Language Class Initialized
DEBUG - 2021-04-16 15:36:01 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:36:01 --> Utf8 Class Initialized
ERROR - 2021-04-16 15:36:01 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:36:01 --> URI Class Initialized
INFO - 2021-04-16 15:36:01 --> Router Class Initialized
INFO - 2021-04-16 15:36:01 --> Config Class Initialized
INFO - 2021-04-16 15:36:01 --> Config Class Initialized
INFO - 2021-04-16 15:36:01 --> Hooks Class Initialized
INFO - 2021-04-16 15:36:01 --> Hooks Class Initialized
INFO - 2021-04-16 15:36:01 --> Config Class Initialized
DEBUG - 2021-04-16 15:36:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:36:01 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:36:01 --> Utf8 Class Initialized
INFO - 2021-04-16 15:36:01 --> Utf8 Class Initialized
INFO - 2021-04-16 15:36:01 --> URI Class Initialized
INFO - 2021-04-16 15:36:01 --> URI Class Initialized
INFO - 2021-04-16 15:36:01 --> Router Class Initialized
INFO - 2021-04-16 15:36:01 --> Router Class Initialized
INFO - 2021-04-16 15:36:01 --> Output Class Initialized
INFO - 2021-04-16 15:36:01 --> Output Class Initialized
INFO - 2021-04-16 15:36:01 --> Hooks Class Initialized
INFO - 2021-04-16 15:36:01 --> Security Class Initialized
INFO - 2021-04-16 15:36:01 --> Security Class Initialized
DEBUG - 2021-04-16 15:36:01 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:36:01 --> Utf8 Class Initialized
DEBUG - 2021-04-16 15:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:36:01 --> Input Class Initialized
INFO - 2021-04-16 15:36:01 --> Input Class Initialized
INFO - 2021-04-16 15:36:01 --> URI Class Initialized
INFO - 2021-04-16 15:36:01 --> Language Class Initialized
INFO - 2021-04-16 15:36:01 --> Language Class Initialized
INFO - 2021-04-16 15:36:01 --> Router Class Initialized
ERROR - 2021-04-16 15:36:01 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-16 15:36:01 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:36:01 --> Output Class Initialized
INFO - 2021-04-16 15:36:01 --> Output Class Initialized
INFO - 2021-04-16 15:36:01 --> Config Class Initialized
INFO - 2021-04-16 15:36:01 --> Hooks Class Initialized
INFO - 2021-04-16 15:36:01 --> Security Class Initialized
DEBUG - 2021-04-16 15:36:01 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:36:01 --> Config Class Initialized
DEBUG - 2021-04-16 15:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:36:01 --> Utf8 Class Initialized
INFO - 2021-04-16 15:36:01 --> Hooks Class Initialized
INFO - 2021-04-16 15:36:01 --> Input Class Initialized
INFO - 2021-04-16 15:36:01 --> Language Class Initialized
INFO - 2021-04-16 15:36:01 --> URI Class Initialized
DEBUG - 2021-04-16 15:36:01 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:36:01 --> Utf8 Class Initialized
ERROR - 2021-04-16 15:36:01 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:36:01 --> URI Class Initialized
INFO - 2021-04-16 15:36:01 --> Router Class Initialized
INFO - 2021-04-16 15:36:01 --> Config Class Initialized
INFO - 2021-04-16 15:36:01 --> Hooks Class Initialized
INFO - 2021-04-16 15:36:01 --> Router Class Initialized
INFO - 2021-04-16 15:36:01 --> Output Class Initialized
INFO - 2021-04-16 15:36:01 --> Output Class Initialized
INFO - 2021-04-16 15:36:01 --> Security Class Initialized
DEBUG - 2021-04-16 15:36:01 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:36:01 --> Utf8 Class Initialized
INFO - 2021-04-16 15:36:01 --> Security Class Initialized
INFO - 2021-04-16 15:36:01 --> URI Class Initialized
DEBUG - 2021-04-16 15:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:36:01 --> Input Class Initialized
DEBUG - 2021-04-16 15:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:36:01 --> Language Class Initialized
INFO - 2021-04-16 15:36:01 --> Input Class Initialized
INFO - 2021-04-16 15:36:01 --> Router Class Initialized
INFO - 2021-04-16 15:36:01 --> Language Class Initialized
INFO - 2021-04-16 15:36:01 --> Output Class Initialized
ERROR - 2021-04-16 15:36:01 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-16 15:36:01 --> Security Class Initialized
DEBUG - 2021-04-16 15:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:36:01 --> Input Class Initialized
INFO - 2021-04-16 15:36:01 --> Language Class Initialized
ERROR - 2021-04-16 15:36:01 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-16 15:36:01 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:36:01 --> Security Class Initialized
INFO - 2021-04-16 15:36:01 --> Config Class Initialized
INFO - 2021-04-16 15:36:01 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:36:01 --> Input Class Initialized
DEBUG - 2021-04-16 15:36:01 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:36:01 --> Utf8 Class Initialized
INFO - 2021-04-16 15:36:01 --> Language Class Initialized
INFO - 2021-04-16 15:36:01 --> URI Class Initialized
ERROR - 2021-04-16 15:36:01 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:36:01 --> Router Class Initialized
INFO - 2021-04-16 15:36:01 --> Output Class Initialized
INFO - 2021-04-16 15:36:01 --> Security Class Initialized
DEBUG - 2021-04-16 15:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:36:01 --> Input Class Initialized
INFO - 2021-04-16 15:36:01 --> Config Class Initialized
INFO - 2021-04-16 15:36:01 --> Hooks Class Initialized
INFO - 2021-04-16 15:36:01 --> Language Class Initialized
ERROR - 2021-04-16 15:36:01 --> 404 Page Not Found: user/Assets/img
DEBUG - 2021-04-16 15:36:01 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:36:01 --> Utf8 Class Initialized
INFO - 2021-04-16 15:36:01 --> URI Class Initialized
INFO - 2021-04-16 15:36:01 --> Router Class Initialized
INFO - 2021-04-16 15:36:01 --> Output Class Initialized
INFO - 2021-04-16 15:36:01 --> Security Class Initialized
DEBUG - 2021-04-16 15:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:36:01 --> Input Class Initialized
INFO - 2021-04-16 15:36:01 --> Language Class Initialized
ERROR - 2021-04-16 15:36:01 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:36:01 --> Config Class Initialized
INFO - 2021-04-16 15:36:01 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:36:01 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:36:01 --> Utf8 Class Initialized
INFO - 2021-04-16 15:36:01 --> URI Class Initialized
INFO - 2021-04-16 15:36:01 --> Router Class Initialized
INFO - 2021-04-16 15:36:01 --> Output Class Initialized
INFO - 2021-04-16 15:36:01 --> Security Class Initialized
DEBUG - 2021-04-16 15:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:36:01 --> Input Class Initialized
INFO - 2021-04-16 15:36:01 --> Language Class Initialized
ERROR - 2021-04-16 15:36:01 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:36:01 --> Config Class Initialized
INFO - 2021-04-16 15:36:01 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:36:01 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:36:01 --> Utf8 Class Initialized
INFO - 2021-04-16 15:36:01 --> URI Class Initialized
INFO - 2021-04-16 15:36:01 --> Router Class Initialized
INFO - 2021-04-16 15:36:01 --> Output Class Initialized
INFO - 2021-04-16 15:36:01 --> Security Class Initialized
DEBUG - 2021-04-16 15:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:36:01 --> Input Class Initialized
INFO - 2021-04-16 15:36:01 --> Language Class Initialized
ERROR - 2021-04-16 15:36:01 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:36:01 --> Config Class Initialized
INFO - 2021-04-16 15:36:01 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:36:01 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:36:01 --> Utf8 Class Initialized
INFO - 2021-04-16 15:36:01 --> URI Class Initialized
INFO - 2021-04-16 15:36:01 --> Router Class Initialized
INFO - 2021-04-16 15:36:01 --> Output Class Initialized
INFO - 2021-04-16 15:36:01 --> Security Class Initialized
DEBUG - 2021-04-16 15:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:36:01 --> Input Class Initialized
INFO - 2021-04-16 15:36:01 --> Language Class Initialized
ERROR - 2021-04-16 15:36:01 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:36:01 --> Config Class Initialized
INFO - 2021-04-16 15:36:01 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:36:01 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:36:01 --> Utf8 Class Initialized
INFO - 2021-04-16 15:36:01 --> URI Class Initialized
INFO - 2021-04-16 15:36:01 --> Router Class Initialized
INFO - 2021-04-16 15:36:01 --> Output Class Initialized
INFO - 2021-04-16 15:36:01 --> Security Class Initialized
DEBUG - 2021-04-16 15:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:36:01 --> Input Class Initialized
INFO - 2021-04-16 15:36:01 --> Language Class Initialized
ERROR - 2021-04-16 15:36:01 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:36:01 --> Config Class Initialized
INFO - 2021-04-16 15:36:01 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:36:01 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:36:01 --> Utf8 Class Initialized
INFO - 2021-04-16 15:36:01 --> URI Class Initialized
INFO - 2021-04-16 15:36:01 --> Router Class Initialized
INFO - 2021-04-16 15:36:01 --> Output Class Initialized
INFO - 2021-04-16 15:36:01 --> Security Class Initialized
DEBUG - 2021-04-16 15:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:36:01 --> Input Class Initialized
INFO - 2021-04-16 15:36:01 --> Language Class Initialized
ERROR - 2021-04-16 15:36:01 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:36:01 --> Config Class Initialized
INFO - 2021-04-16 15:36:01 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:36:01 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:36:01 --> Utf8 Class Initialized
INFO - 2021-04-16 15:36:01 --> URI Class Initialized
INFO - 2021-04-16 15:36:01 --> Router Class Initialized
INFO - 2021-04-16 15:36:01 --> Output Class Initialized
INFO - 2021-04-16 15:36:01 --> Security Class Initialized
DEBUG - 2021-04-16 15:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:36:01 --> Input Class Initialized
INFO - 2021-04-16 15:36:01 --> Language Class Initialized
ERROR - 2021-04-16 15:36:01 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:38:01 --> Config Class Initialized
INFO - 2021-04-16 15:38:01 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:38:01 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:38:01 --> Utf8 Class Initialized
INFO - 2021-04-16 15:38:01 --> URI Class Initialized
INFO - 2021-04-16 15:38:01 --> Router Class Initialized
INFO - 2021-04-16 15:38:01 --> Output Class Initialized
INFO - 2021-04-16 15:38:01 --> Security Class Initialized
DEBUG - 2021-04-16 15:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:38:01 --> Input Class Initialized
INFO - 2021-04-16 15:38:01 --> Language Class Initialized
INFO - 2021-04-16 15:38:01 --> Loader Class Initialized
INFO - 2021-04-16 15:38:01 --> Helper loaded: url_helper
INFO - 2021-04-16 15:38:01 --> Helper loaded: form_helper
INFO - 2021-04-16 15:38:01 --> Helper loaded: common_helper
INFO - 2021-04-16 15:38:01 --> Helper loaded: util_helper
INFO - 2021-04-16 15:38:01 --> Database Driver Class Initialized
DEBUG - 2021-04-16 15:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 15:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 15:38:01 --> Form Validation Class Initialized
INFO - 2021-04-16 15:38:01 --> Controller Class Initialized
INFO - 2021-04-16 15:38:01 --> Model Class Initialized
INFO - 2021-04-16 15:38:12 --> Config Class Initialized
INFO - 2021-04-16 15:38:12 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:38:12 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:38:12 --> Utf8 Class Initialized
INFO - 2021-04-16 15:38:12 --> URI Class Initialized
INFO - 2021-04-16 15:38:12 --> Router Class Initialized
INFO - 2021-04-16 15:38:12 --> Output Class Initialized
INFO - 2021-04-16 15:38:12 --> Security Class Initialized
DEBUG - 2021-04-16 15:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:38:12 --> Input Class Initialized
INFO - 2021-04-16 15:38:12 --> Language Class Initialized
INFO - 2021-04-16 15:38:12 --> Loader Class Initialized
INFO - 2021-04-16 15:38:12 --> Helper loaded: url_helper
INFO - 2021-04-16 15:38:12 --> Helper loaded: form_helper
INFO - 2021-04-16 15:38:12 --> Helper loaded: common_helper
INFO - 2021-04-16 15:38:12 --> Helper loaded: util_helper
INFO - 2021-04-16 15:38:12 --> Database Driver Class Initialized
DEBUG - 2021-04-16 15:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 15:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 15:38:12 --> Form Validation Class Initialized
INFO - 2021-04-16 15:38:12 --> Controller Class Initialized
INFO - 2021-04-16 15:38:12 --> Model Class Initialized
INFO - 2021-04-16 15:38:12 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 15:38:12 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 15:38:12 --> Final output sent to browser
DEBUG - 2021-04-16 15:38:12 --> Total execution time: 0.0274
INFO - 2021-04-16 15:38:13 --> Config Class Initialized
INFO - 2021-04-16 15:38:13 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:38:13 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:38:13 --> Utf8 Class Initialized
INFO - 2021-04-16 15:38:13 --> URI Class Initialized
INFO - 2021-04-16 15:38:13 --> Router Class Initialized
INFO - 2021-04-16 15:38:13 --> Output Class Initialized
INFO - 2021-04-16 15:38:13 --> Security Class Initialized
DEBUG - 2021-04-16 15:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:38:13 --> Input Class Initialized
INFO - 2021-04-16 15:38:13 --> Language Class Initialized
ERROR - 2021-04-16 15:38:13 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:38:13 --> Config Class Initialized
INFO - 2021-04-16 15:38:13 --> Hooks Class Initialized
INFO - 2021-04-16 15:38:13 --> Config Class Initialized
INFO - 2021-04-16 15:38:13 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:38:13 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:38:13 --> Utf8 Class Initialized
INFO - 2021-04-16 15:38:13 --> Config Class Initialized
INFO - 2021-04-16 15:38:13 --> Config Class Initialized
INFO - 2021-04-16 15:38:13 --> URI Class Initialized
INFO - 2021-04-16 15:38:13 --> Hooks Class Initialized
INFO - 2021-04-16 15:38:13 --> Hooks Class Initialized
INFO - 2021-04-16 15:38:13 --> Router Class Initialized
DEBUG - 2021-04-16 15:38:13 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:38:13 --> Utf8 Class Initialized
INFO - 2021-04-16 15:38:13 --> URI Class Initialized
INFO - 2021-04-16 15:38:13 --> Output Class Initialized
DEBUG - 2021-04-16 15:38:13 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:38:13 --> Utf8 Class Initialized
INFO - 2021-04-16 15:38:13 --> Router Class Initialized
INFO - 2021-04-16 15:38:13 --> Security Class Initialized
INFO - 2021-04-16 15:38:13 --> URI Class Initialized
INFO - 2021-04-16 15:38:13 --> Output Class Initialized
DEBUG - 2021-04-16 15:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:38:13 --> Config Class Initialized
INFO - 2021-04-16 15:38:13 --> Input Class Initialized
INFO - 2021-04-16 15:38:13 --> Hooks Class Initialized
INFO - 2021-04-16 15:38:13 --> Router Class Initialized
INFO - 2021-04-16 15:38:13 --> Security Class Initialized
INFO - 2021-04-16 15:38:13 --> Language Class Initialized
DEBUG - 2021-04-16 15:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:38:13 --> Output Class Initialized
INFO - 2021-04-16 15:38:13 --> Input Class Initialized
ERROR - 2021-04-16 15:38:13 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-16 15:38:13 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:38:13 --> Language Class Initialized
INFO - 2021-04-16 15:38:13 --> Utf8 Class Initialized
INFO - 2021-04-16 15:38:13 --> Security Class Initialized
INFO - 2021-04-16 15:38:13 --> URI Class Initialized
ERROR - 2021-04-16 15:38:13 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-16 15:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:38:13 --> Input Class Initialized
INFO - 2021-04-16 15:38:13 --> Language Class Initialized
INFO - 2021-04-16 15:38:13 --> Router Class Initialized
DEBUG - 2021-04-16 15:38:13 --> UTF-8 Support Enabled
ERROR - 2021-04-16 15:38:13 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:38:13 --> Utf8 Class Initialized
INFO - 2021-04-16 15:38:13 --> Output Class Initialized
INFO - 2021-04-16 15:38:13 --> URI Class Initialized
INFO - 2021-04-16 15:38:13 --> Config Class Initialized
INFO - 2021-04-16 15:38:13 --> Security Class Initialized
INFO - 2021-04-16 15:38:13 --> Router Class Initialized
DEBUG - 2021-04-16 15:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:38:13 --> Input Class Initialized
INFO - 2021-04-16 15:38:13 --> Output Class Initialized
INFO - 2021-04-16 15:38:13 --> Language Class Initialized
INFO - 2021-04-16 15:38:13 --> Security Class Initialized
ERROR - 2021-04-16 15:38:13 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-16 15:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:38:13 --> Input Class Initialized
INFO - 2021-04-16 15:38:13 --> Language Class Initialized
INFO - 2021-04-16 15:38:13 --> Config Class Initialized
INFO - 2021-04-16 15:38:13 --> Hooks Class Initialized
ERROR - 2021-04-16 15:38:13 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:38:13 --> Config Class Initialized
INFO - 2021-04-16 15:38:13 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:38:13 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:38:13 --> Utf8 Class Initialized
INFO - 2021-04-16 15:38:13 --> URI Class Initialized
DEBUG - 2021-04-16 15:38:13 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:38:13 --> Utf8 Class Initialized
INFO - 2021-04-16 15:38:13 --> Router Class Initialized
INFO - 2021-04-16 15:38:13 --> URI Class Initialized
INFO - 2021-04-16 15:38:13 --> Config Class Initialized
INFO - 2021-04-16 15:38:13 --> Hooks Class Initialized
INFO - 2021-04-16 15:38:13 --> Output Class Initialized
INFO - 2021-04-16 15:38:13 --> Router Class Initialized
INFO - 2021-04-16 15:38:13 --> Hooks Class Initialized
INFO - 2021-04-16 15:38:13 --> Security Class Initialized
INFO - 2021-04-16 15:38:13 --> Output Class Initialized
DEBUG - 2021-04-16 15:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:38:13 --> Input Class Initialized
INFO - 2021-04-16 15:38:13 --> Security Class Initialized
INFO - 2021-04-16 15:38:13 --> Language Class Initialized
DEBUG - 2021-04-16 15:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:38:13 --> Input Class Initialized
ERROR - 2021-04-16 15:38:13 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:38:13 --> Language Class Initialized
DEBUG - 2021-04-16 15:38:13 --> UTF-8 Support Enabled
ERROR - 2021-04-16 15:38:13 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:38:13 --> Utf8 Class Initialized
INFO - 2021-04-16 15:38:13 --> URI Class Initialized
INFO - 2021-04-16 15:38:13 --> Router Class Initialized
DEBUG - 2021-04-16 15:38:13 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:38:13 --> Utf8 Class Initialized
INFO - 2021-04-16 15:38:13 --> Config Class Initialized
INFO - 2021-04-16 15:38:13 --> Hooks Class Initialized
INFO - 2021-04-16 15:38:13 --> URI Class Initialized
INFO - 2021-04-16 15:38:13 --> Output Class Initialized
INFO - 2021-04-16 15:38:13 --> Config Class Initialized
INFO - 2021-04-16 15:38:13 --> Hooks Class Initialized
INFO - 2021-04-16 15:38:13 --> Security Class Initialized
INFO - 2021-04-16 15:38:13 --> Router Class Initialized
DEBUG - 2021-04-16 15:38:13 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:38:13 --> Utf8 Class Initialized
INFO - 2021-04-16 15:38:13 --> URI Class Initialized
DEBUG - 2021-04-16 15:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:38:13 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:38:13 --> Utf8 Class Initialized
INFO - 2021-04-16 15:38:13 --> Input Class Initialized
INFO - 2021-04-16 15:38:13 --> Output Class Initialized
INFO - 2021-04-16 15:38:13 --> Router Class Initialized
INFO - 2021-04-16 15:38:13 --> URI Class Initialized
INFO - 2021-04-16 15:38:13 --> Language Class Initialized
INFO - 2021-04-16 15:38:13 --> Security Class Initialized
INFO - 2021-04-16 15:38:13 --> Router Class Initialized
INFO - 2021-04-16 15:38:13 --> Output Class Initialized
ERROR - 2021-04-16 15:38:13 --> 404 Page Not Found: user/Assets/img
DEBUG - 2021-04-16 15:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:38:13 --> Security Class Initialized
INFO - 2021-04-16 15:38:13 --> Output Class Initialized
INFO - 2021-04-16 15:38:13 --> Input Class Initialized
DEBUG - 2021-04-16 15:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:38:13 --> Input Class Initialized
INFO - 2021-04-16 15:38:13 --> Security Class Initialized
INFO - 2021-04-16 15:38:13 --> Language Class Initialized
INFO - 2021-04-16 15:38:13 --> Language Class Initialized
DEBUG - 2021-04-16 15:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:38:13 --> Input Class Initialized
INFO - 2021-04-16 15:38:13 --> Language Class Initialized
ERROR - 2021-04-16 15:38:13 --> 404 Page Not Found: user/Assets/img
ERROR - 2021-04-16 15:38:13 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-16 15:38:13 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:38:13 --> Config Class Initialized
INFO - 2021-04-16 15:38:13 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:38:13 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:38:13 --> Utf8 Class Initialized
INFO - 2021-04-16 15:38:13 --> URI Class Initialized
INFO - 2021-04-16 15:38:13 --> Router Class Initialized
INFO - 2021-04-16 15:38:13 --> Output Class Initialized
INFO - 2021-04-16 15:38:13 --> Security Class Initialized
DEBUG - 2021-04-16 15:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:38:13 --> Input Class Initialized
INFO - 2021-04-16 15:38:13 --> Language Class Initialized
ERROR - 2021-04-16 15:38:13 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:38:13 --> Config Class Initialized
INFO - 2021-04-16 15:38:13 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:38:13 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:38:13 --> Utf8 Class Initialized
INFO - 2021-04-16 15:38:13 --> URI Class Initialized
INFO - 2021-04-16 15:38:13 --> Router Class Initialized
INFO - 2021-04-16 15:38:13 --> Output Class Initialized
INFO - 2021-04-16 15:38:13 --> Security Class Initialized
DEBUG - 2021-04-16 15:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:38:13 --> Input Class Initialized
INFO - 2021-04-16 15:38:13 --> Language Class Initialized
ERROR - 2021-04-16 15:38:13 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:38:13 --> Config Class Initialized
INFO - 2021-04-16 15:38:13 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:38:13 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:38:13 --> Utf8 Class Initialized
INFO - 2021-04-16 15:38:13 --> URI Class Initialized
INFO - 2021-04-16 15:38:13 --> Router Class Initialized
INFO - 2021-04-16 15:38:13 --> Output Class Initialized
INFO - 2021-04-16 15:38:13 --> Security Class Initialized
DEBUG - 2021-04-16 15:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:38:13 --> Input Class Initialized
INFO - 2021-04-16 15:38:13 --> Language Class Initialized
ERROR - 2021-04-16 15:38:13 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:38:13 --> Config Class Initialized
INFO - 2021-04-16 15:38:13 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:38:13 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:38:13 --> Utf8 Class Initialized
INFO - 2021-04-16 15:38:13 --> URI Class Initialized
INFO - 2021-04-16 15:38:13 --> Router Class Initialized
INFO - 2021-04-16 15:38:13 --> Output Class Initialized
INFO - 2021-04-16 15:38:13 --> Security Class Initialized
DEBUG - 2021-04-16 15:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:38:13 --> Input Class Initialized
INFO - 2021-04-16 15:38:13 --> Language Class Initialized
ERROR - 2021-04-16 15:38:13 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:38:13 --> Config Class Initialized
INFO - 2021-04-16 15:38:13 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:38:13 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:38:13 --> Utf8 Class Initialized
INFO - 2021-04-16 15:38:13 --> URI Class Initialized
INFO - 2021-04-16 15:38:13 --> Router Class Initialized
INFO - 2021-04-16 15:38:13 --> Output Class Initialized
INFO - 2021-04-16 15:38:13 --> Security Class Initialized
DEBUG - 2021-04-16 15:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:38:13 --> Input Class Initialized
INFO - 2021-04-16 15:38:13 --> Language Class Initialized
ERROR - 2021-04-16 15:38:13 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:38:13 --> Config Class Initialized
INFO - 2021-04-16 15:38:13 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:38:13 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:38:13 --> Utf8 Class Initialized
INFO - 2021-04-16 15:38:13 --> URI Class Initialized
INFO - 2021-04-16 15:38:13 --> Router Class Initialized
INFO - 2021-04-16 15:38:13 --> Output Class Initialized
INFO - 2021-04-16 15:38:13 --> Security Class Initialized
DEBUG - 2021-04-16 15:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:38:13 --> Input Class Initialized
INFO - 2021-04-16 15:38:13 --> Language Class Initialized
ERROR - 2021-04-16 15:38:13 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:38:13 --> Config Class Initialized
INFO - 2021-04-16 15:38:13 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:38:13 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:38:13 --> Utf8 Class Initialized
INFO - 2021-04-16 15:38:13 --> URI Class Initialized
INFO - 2021-04-16 15:38:13 --> Router Class Initialized
INFO - 2021-04-16 15:38:13 --> Output Class Initialized
INFO - 2021-04-16 15:38:13 --> Security Class Initialized
DEBUG - 2021-04-16 15:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:38:13 --> Input Class Initialized
INFO - 2021-04-16 15:38:13 --> Language Class Initialized
ERROR - 2021-04-16 15:38:13 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:38:25 --> Config Class Initialized
INFO - 2021-04-16 15:38:25 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:38:25 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:38:25 --> Utf8 Class Initialized
INFO - 2021-04-16 15:38:25 --> URI Class Initialized
INFO - 2021-04-16 15:38:25 --> Router Class Initialized
INFO - 2021-04-16 15:38:25 --> Output Class Initialized
INFO - 2021-04-16 15:38:25 --> Security Class Initialized
DEBUG - 2021-04-16 15:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:38:25 --> Input Class Initialized
INFO - 2021-04-16 15:38:25 --> Language Class Initialized
INFO - 2021-04-16 15:38:25 --> Loader Class Initialized
INFO - 2021-04-16 15:38:25 --> Helper loaded: url_helper
INFO - 2021-04-16 15:38:25 --> Helper loaded: form_helper
INFO - 2021-04-16 15:38:25 --> Helper loaded: common_helper
INFO - 2021-04-16 15:38:25 --> Helper loaded: util_helper
INFO - 2021-04-16 15:38:25 --> Database Driver Class Initialized
DEBUG - 2021-04-16 15:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 15:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 15:38:25 --> Form Validation Class Initialized
INFO - 2021-04-16 15:38:25 --> Controller Class Initialized
INFO - 2021-04-16 15:38:25 --> Model Class Initialized
INFO - 2021-04-16 15:41:44 --> Config Class Initialized
INFO - 2021-04-16 15:41:44 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:41:44 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:41:44 --> Utf8 Class Initialized
INFO - 2021-04-16 15:41:44 --> URI Class Initialized
INFO - 2021-04-16 15:41:44 --> Router Class Initialized
INFO - 2021-04-16 15:41:44 --> Output Class Initialized
INFO - 2021-04-16 15:41:44 --> Security Class Initialized
DEBUG - 2021-04-16 15:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:41:44 --> Input Class Initialized
INFO - 2021-04-16 15:41:44 --> Language Class Initialized
INFO - 2021-04-16 15:41:44 --> Loader Class Initialized
INFO - 2021-04-16 15:41:44 --> Helper loaded: url_helper
INFO - 2021-04-16 15:41:44 --> Helper loaded: form_helper
INFO - 2021-04-16 15:41:44 --> Helper loaded: common_helper
INFO - 2021-04-16 15:41:44 --> Helper loaded: util_helper
INFO - 2021-04-16 15:41:44 --> Database Driver Class Initialized
DEBUG - 2021-04-16 15:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 15:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 15:41:44 --> Form Validation Class Initialized
INFO - 2021-04-16 15:41:44 --> Controller Class Initialized
INFO - 2021-04-16 15:41:44 --> Model Class Initialized
INFO - 2021-04-16 15:41:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 15:41:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 15:41:44 --> Final output sent to browser
DEBUG - 2021-04-16 15:41:44 --> Total execution time: 0.0379
INFO - 2021-04-16 15:41:44 --> Config Class Initialized
INFO - 2021-04-16 15:41:44 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:41:44 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:41:44 --> Utf8 Class Initialized
INFO - 2021-04-16 15:41:44 --> URI Class Initialized
INFO - 2021-04-16 15:41:44 --> Config Class Initialized
INFO - 2021-04-16 15:41:44 --> Hooks Class Initialized
INFO - 2021-04-16 15:41:44 --> Router Class Initialized
INFO - 2021-04-16 15:41:44 --> Output Class Initialized
DEBUG - 2021-04-16 15:41:44 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:41:44 --> Utf8 Class Initialized
INFO - 2021-04-16 15:41:44 --> Security Class Initialized
INFO - 2021-04-16 15:41:44 --> URI Class Initialized
DEBUG - 2021-04-16 15:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:41:44 --> Input Class Initialized
INFO - 2021-04-16 15:41:44 --> Router Class Initialized
INFO - 2021-04-16 15:41:44 --> Language Class Initialized
INFO - 2021-04-16 15:41:44 --> Output Class Initialized
ERROR - 2021-04-16 15:41:44 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:41:44 --> Security Class Initialized
DEBUG - 2021-04-16 15:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:41:44 --> Input Class Initialized
INFO - 2021-04-16 15:41:44 --> Language Class Initialized
ERROR - 2021-04-16 15:41:44 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:41:44 --> Config Class Initialized
INFO - 2021-04-16 15:41:44 --> Hooks Class Initialized
INFO - 2021-04-16 15:41:44 --> Config Class Initialized
INFO - 2021-04-16 15:41:44 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:41:44 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:41:44 --> Utf8 Class Initialized
DEBUG - 2021-04-16 15:41:44 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:41:44 --> Utf8 Class Initialized
INFO - 2021-04-16 15:41:44 --> URI Class Initialized
INFO - 2021-04-16 15:41:44 --> URI Class Initialized
INFO - 2021-04-16 15:41:44 --> Router Class Initialized
INFO - 2021-04-16 15:41:44 --> Router Class Initialized
INFO - 2021-04-16 15:41:44 --> Output Class Initialized
INFO - 2021-04-16 15:41:44 --> Output Class Initialized
INFO - 2021-04-16 15:41:44 --> Security Class Initialized
INFO - 2021-04-16 15:41:44 --> Security Class Initialized
DEBUG - 2021-04-16 15:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:41:44 --> Input Class Initialized
INFO - 2021-04-16 15:41:44 --> Language Class Initialized
DEBUG - 2021-04-16 15:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:41:44 --> Input Class Initialized
INFO - 2021-04-16 15:41:44 --> Language Class Initialized
ERROR - 2021-04-16 15:41:44 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-16 15:41:44 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:41:44 --> Config Class Initialized
INFO - 2021-04-16 15:41:44 --> Config Class Initialized
INFO - 2021-04-16 15:41:44 --> Hooks Class Initialized
INFO - 2021-04-16 15:41:44 --> Config Class Initialized
INFO - 2021-04-16 15:41:44 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:41:44 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:41:44 --> Utf8 Class Initialized
INFO - 2021-04-16 15:41:44 --> Config Class Initialized
INFO - 2021-04-16 15:41:44 --> Hooks Class Initialized
INFO - 2021-04-16 15:41:44 --> URI Class Initialized
INFO - 2021-04-16 15:41:44 --> Config Class Initialized
INFO - 2021-04-16 15:41:44 --> Hooks Class Initialized
INFO - 2021-04-16 15:41:44 --> Router Class Initialized
DEBUG - 2021-04-16 15:41:44 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:41:44 --> Utf8 Class Initialized
DEBUG - 2021-04-16 15:41:44 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:41:44 --> Utf8 Class Initialized
DEBUG - 2021-04-16 15:41:44 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:41:44 --> URI Class Initialized
INFO - 2021-04-16 15:41:44 --> Utf8 Class Initialized
INFO - 2021-04-16 15:41:44 --> Output Class Initialized
INFO - 2021-04-16 15:41:44 --> URI Class Initialized
INFO - 2021-04-16 15:41:44 --> Router Class Initialized
INFO - 2021-04-16 15:41:44 --> Security Class Initialized
INFO - 2021-04-16 15:41:44 --> URI Class Initialized
INFO - 2021-04-16 15:41:44 --> Router Class Initialized
DEBUG - 2021-04-16 15:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:41:44 --> Input Class Initialized
INFO - 2021-04-16 15:41:44 --> Output Class Initialized
INFO - 2021-04-16 15:41:44 --> Language Class Initialized
INFO - 2021-04-16 15:41:44 --> Output Class Initialized
INFO - 2021-04-16 15:41:44 --> Router Class Initialized
INFO - 2021-04-16 15:41:44 --> Security Class Initialized
ERROR - 2021-04-16 15:41:44 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:41:44 --> Security Class Initialized
DEBUG - 2021-04-16 15:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:41:44 --> Input Class Initialized
INFO - 2021-04-16 15:41:44 --> Language Class Initialized
INFO - 2021-04-16 15:41:44 --> Output Class Initialized
INFO - 2021-04-16 15:41:44 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:41:44 --> Input Class Initialized
INFO - 2021-04-16 15:41:44 --> Security Class Initialized
ERROR - 2021-04-16 15:41:44 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:41:44 --> Language Class Initialized
DEBUG - 2021-04-16 15:41:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:41:44 --> Utf8 Class Initialized
INFO - 2021-04-16 15:41:44 --> Input Class Initialized
ERROR - 2021-04-16 15:41:44 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-16 15:41:44 --> URI Class Initialized
INFO - 2021-04-16 15:41:44 --> Language Class Initialized
INFO - 2021-04-16 15:41:44 --> Config Class Initialized
INFO - 2021-04-16 15:41:44 --> Router Class Initialized
ERROR - 2021-04-16 15:41:44 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:41:44 --> Hooks Class Initialized
INFO - 2021-04-16 15:41:44 --> Output Class Initialized
INFO - 2021-04-16 15:41:44 --> Security Class Initialized
DEBUG - 2021-04-16 15:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:41:44 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:41:44 --> Input Class Initialized
INFO - 2021-04-16 15:41:44 --> Utf8 Class Initialized
INFO - 2021-04-16 15:41:44 --> Language Class Initialized
INFO - 2021-04-16 15:41:44 --> URI Class Initialized
ERROR - 2021-04-16 15:41:44 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:41:44 --> Config Class Initialized
INFO - 2021-04-16 15:41:44 --> Hooks Class Initialized
INFO - 2021-04-16 15:41:44 --> Router Class Initialized
INFO - 2021-04-16 15:41:44 --> Output Class Initialized
DEBUG - 2021-04-16 15:41:44 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:41:44 --> Utf8 Class Initialized
INFO - 2021-04-16 15:41:44 --> Security Class Initialized
INFO - 2021-04-16 15:41:44 --> URI Class Initialized
DEBUG - 2021-04-16 15:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:41:44 --> Input Class Initialized
INFO - 2021-04-16 15:41:44 --> Router Class Initialized
INFO - 2021-04-16 15:41:44 --> Language Class Initialized
INFO - 2021-04-16 15:41:44 --> Output Class Initialized
ERROR - 2021-04-16 15:41:44 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:41:44 --> Security Class Initialized
DEBUG - 2021-04-16 15:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:41:44 --> Input Class Initialized
INFO - 2021-04-16 15:41:44 --> Language Class Initialized
ERROR - 2021-04-16 15:41:44 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-16 15:41:44 --> Config Class Initialized
INFO - 2021-04-16 15:41:44 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:41:44 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:41:44 --> Utf8 Class Initialized
INFO - 2021-04-16 15:41:44 --> URI Class Initialized
INFO - 2021-04-16 15:41:44 --> Router Class Initialized
INFO - 2021-04-16 15:41:44 --> Output Class Initialized
INFO - 2021-04-16 15:41:44 --> Security Class Initialized
DEBUG - 2021-04-16 15:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:41:44 --> Input Class Initialized
INFO - 2021-04-16 15:41:44 --> Language Class Initialized
ERROR - 2021-04-16 15:41:44 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:41:44 --> Config Class Initialized
INFO - 2021-04-16 15:41:44 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:41:44 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:41:44 --> Utf8 Class Initialized
INFO - 2021-04-16 15:41:44 --> URI Class Initialized
INFO - 2021-04-16 15:41:44 --> Router Class Initialized
INFO - 2021-04-16 15:41:44 --> Output Class Initialized
INFO - 2021-04-16 15:41:44 --> Security Class Initialized
DEBUG - 2021-04-16 15:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:41:44 --> Input Class Initialized
INFO - 2021-04-16 15:41:44 --> Language Class Initialized
ERROR - 2021-04-16 15:41:44 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:41:44 --> Config Class Initialized
INFO - 2021-04-16 15:41:44 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:41:44 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:41:44 --> Utf8 Class Initialized
INFO - 2021-04-16 15:41:44 --> URI Class Initialized
INFO - 2021-04-16 15:41:44 --> Router Class Initialized
INFO - 2021-04-16 15:41:44 --> Output Class Initialized
INFO - 2021-04-16 15:41:44 --> Security Class Initialized
DEBUG - 2021-04-16 15:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:41:44 --> Input Class Initialized
INFO - 2021-04-16 15:41:44 --> Language Class Initialized
ERROR - 2021-04-16 15:41:44 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:41:44 --> Config Class Initialized
INFO - 2021-04-16 15:41:44 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:41:44 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:41:44 --> Utf8 Class Initialized
INFO - 2021-04-16 15:41:44 --> URI Class Initialized
INFO - 2021-04-16 15:41:44 --> Router Class Initialized
INFO - 2021-04-16 15:41:44 --> Output Class Initialized
INFO - 2021-04-16 15:41:44 --> Security Class Initialized
DEBUG - 2021-04-16 15:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:41:44 --> Input Class Initialized
INFO - 2021-04-16 15:41:44 --> Language Class Initialized
ERROR - 2021-04-16 15:41:44 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:41:44 --> Config Class Initialized
INFO - 2021-04-16 15:41:44 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:41:44 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:41:44 --> Utf8 Class Initialized
INFO - 2021-04-16 15:41:44 --> URI Class Initialized
INFO - 2021-04-16 15:41:44 --> Router Class Initialized
INFO - 2021-04-16 15:41:44 --> Output Class Initialized
INFO - 2021-04-16 15:41:44 --> Security Class Initialized
DEBUG - 2021-04-16 15:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:41:44 --> Input Class Initialized
INFO - 2021-04-16 15:41:44 --> Language Class Initialized
ERROR - 2021-04-16 15:41:44 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:41:44 --> Config Class Initialized
INFO - 2021-04-16 15:41:44 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:41:44 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:41:44 --> Utf8 Class Initialized
INFO - 2021-04-16 15:41:44 --> URI Class Initialized
INFO - 2021-04-16 15:41:44 --> Router Class Initialized
INFO - 2021-04-16 15:41:44 --> Output Class Initialized
INFO - 2021-04-16 15:41:44 --> Security Class Initialized
DEBUG - 2021-04-16 15:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:41:44 --> Input Class Initialized
INFO - 2021-04-16 15:41:44 --> Language Class Initialized
ERROR - 2021-04-16 15:41:44 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:49:28 --> Config Class Initialized
INFO - 2021-04-16 15:49:28 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:49:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:49:28 --> Utf8 Class Initialized
INFO - 2021-04-16 15:49:28 --> URI Class Initialized
INFO - 2021-04-16 15:49:28 --> Router Class Initialized
INFO - 2021-04-16 15:49:28 --> Output Class Initialized
INFO - 2021-04-16 15:49:28 --> Security Class Initialized
DEBUG - 2021-04-16 15:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:49:28 --> Input Class Initialized
INFO - 2021-04-16 15:49:28 --> Language Class Initialized
INFO - 2021-04-16 15:49:28 --> Loader Class Initialized
INFO - 2021-04-16 15:49:28 --> Helper loaded: url_helper
INFO - 2021-04-16 15:49:28 --> Helper loaded: form_helper
INFO - 2021-04-16 15:49:28 --> Helper loaded: common_helper
INFO - 2021-04-16 15:49:28 --> Helper loaded: util_helper
INFO - 2021-04-16 15:49:28 --> Database Driver Class Initialized
DEBUG - 2021-04-16 15:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 15:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 15:49:28 --> Form Validation Class Initialized
INFO - 2021-04-16 15:49:28 --> Controller Class Initialized
INFO - 2021-04-16 15:49:28 --> Model Class Initialized
INFO - 2021-04-16 15:49:28 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 15:49:28 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 15:49:28 --> Final output sent to browser
DEBUG - 2021-04-16 15:49:28 --> Total execution time: 0.0377
INFO - 2021-04-16 15:49:28 --> Config Class Initialized
INFO - 2021-04-16 15:49:28 --> Hooks Class Initialized
INFO - 2021-04-16 15:49:28 --> Config Class Initialized
INFO - 2021-04-16 15:49:28 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:49:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:49:28 --> Utf8 Class Initialized
INFO - 2021-04-16 15:49:28 --> URI Class Initialized
DEBUG - 2021-04-16 15:49:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:49:28 --> Utf8 Class Initialized
INFO - 2021-04-16 15:49:28 --> URI Class Initialized
INFO - 2021-04-16 15:49:28 --> Router Class Initialized
INFO - 2021-04-16 15:49:28 --> Router Class Initialized
INFO - 2021-04-16 15:49:28 --> Output Class Initialized
INFO - 2021-04-16 15:49:28 --> Security Class Initialized
INFO - 2021-04-16 15:49:28 --> Output Class Initialized
DEBUG - 2021-04-16 15:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:49:28 --> Security Class Initialized
INFO - 2021-04-16 15:49:28 --> Input Class Initialized
INFO - 2021-04-16 15:49:28 --> Language Class Initialized
DEBUG - 2021-04-16 15:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:49:28 --> Input Class Initialized
INFO - 2021-04-16 15:49:28 --> Language Class Initialized
ERROR - 2021-04-16 15:49:28 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-16 15:49:28 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:49:28 --> Config Class Initialized
INFO - 2021-04-16 15:49:28 --> Config Class Initialized
INFO - 2021-04-16 15:49:28 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:49:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:49:28 --> Utf8 Class Initialized
INFO - 2021-04-16 15:49:28 --> URI Class Initialized
INFO - 2021-04-16 15:49:28 --> Router Class Initialized
INFO - 2021-04-16 15:49:28 --> Config Class Initialized
INFO - 2021-04-16 15:49:28 --> Output Class Initialized
INFO - 2021-04-16 15:49:28 --> Hooks Class Initialized
INFO - 2021-04-16 15:49:28 --> Security Class Initialized
INFO - 2021-04-16 15:49:28 --> Config Class Initialized
DEBUG - 2021-04-16 15:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:49:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:49:28 --> Hooks Class Initialized
INFO - 2021-04-16 15:49:28 --> Hooks Class Initialized
INFO - 2021-04-16 15:49:28 --> Utf8 Class Initialized
INFO - 2021-04-16 15:49:28 --> Config Class Initialized
INFO - 2021-04-16 15:49:28 --> Hooks Class Initialized
INFO - 2021-04-16 15:49:28 --> URI Class Initialized
DEBUG - 2021-04-16 15:49:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:49:28 --> Utf8 Class Initialized
DEBUG - 2021-04-16 15:49:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:49:28 --> Utf8 Class Initialized
INFO - 2021-04-16 15:49:28 --> URI Class Initialized
DEBUG - 2021-04-16 15:49:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:49:28 --> Utf8 Class Initialized
INFO - 2021-04-16 15:49:28 --> Router Class Initialized
INFO - 2021-04-16 15:49:28 --> Router Class Initialized
INFO - 2021-04-16 15:49:28 --> URI Class Initialized
INFO - 2021-04-16 15:49:28 --> URI Class Initialized
INFO - 2021-04-16 15:49:28 --> Output Class Initialized
INFO - 2021-04-16 15:49:28 --> Router Class Initialized
INFO - 2021-04-16 15:49:28 --> Output Class Initialized
INFO - 2021-04-16 15:49:28 --> Router Class Initialized
INFO - 2021-04-16 15:49:28 --> Security Class Initialized
INFO - 2021-04-16 15:49:28 --> Security Class Initialized
INFO - 2021-04-16 15:49:28 --> Output Class Initialized
DEBUG - 2021-04-16 15:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:49:28 --> Input Class Initialized
INFO - 2021-04-16 15:49:28 --> Security Class Initialized
INFO - 2021-04-16 15:49:28 --> Output Class Initialized
INFO - 2021-04-16 15:49:28 --> Language Class Initialized
INFO - 2021-04-16 15:49:28 --> Config Class Initialized
INFO - 2021-04-16 15:49:28 --> Input Class Initialized
DEBUG - 2021-04-16 15:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:49:28 --> Input Class Initialized
INFO - 2021-04-16 15:49:28 --> Language Class Initialized
ERROR - 2021-04-16 15:49:28 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:49:28 --> Security Class Initialized
INFO - 2021-04-16 15:49:28 --> Language Class Initialized
INFO - 2021-04-16 15:49:28 --> Hooks Class Initialized
ERROR - 2021-04-16 15:49:28 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:49:28 --> Input Class Initialized
DEBUG - 2021-04-16 15:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:49:28 --> Language Class Initialized
INFO - 2021-04-16 15:49:28 --> Input Class Initialized
ERROR - 2021-04-16 15:49:28 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:49:28 --> Language Class Initialized
DEBUG - 2021-04-16 15:49:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:49:28 --> Utf8 Class Initialized
ERROR - 2021-04-16 15:49:28 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:49:28 --> URI Class Initialized
ERROR - 2021-04-16 15:49:28 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:49:28 --> Router Class Initialized
INFO - 2021-04-16 15:49:28 --> Output Class Initialized
INFO - 2021-04-16 15:49:28 --> Security Class Initialized
DEBUG - 2021-04-16 15:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:49:28 --> Input Class Initialized
INFO - 2021-04-16 15:49:28 --> Language Class Initialized
ERROR - 2021-04-16 15:49:28 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:49:28 --> Config Class Initialized
INFO - 2021-04-16 15:49:28 --> Config Class Initialized
INFO - 2021-04-16 15:49:28 --> Hooks Class Initialized
INFO - 2021-04-16 15:49:28 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:49:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:49:28 --> Utf8 Class Initialized
DEBUG - 2021-04-16 15:49:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:49:28 --> Utf8 Class Initialized
INFO - 2021-04-16 15:49:28 --> Config Class Initialized
INFO - 2021-04-16 15:49:28 --> Hooks Class Initialized
INFO - 2021-04-16 15:49:28 --> URI Class Initialized
INFO - 2021-04-16 15:49:28 --> URI Class Initialized
INFO - 2021-04-16 15:49:28 --> Router Class Initialized
INFO - 2021-04-16 15:49:28 --> Router Class Initialized
DEBUG - 2021-04-16 15:49:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:49:28 --> Utf8 Class Initialized
INFO - 2021-04-16 15:49:28 --> Output Class Initialized
INFO - 2021-04-16 15:49:28 --> URI Class Initialized
INFO - 2021-04-16 15:49:28 --> Output Class Initialized
INFO - 2021-04-16 15:49:28 --> Security Class Initialized
INFO - 2021-04-16 15:49:28 --> Router Class Initialized
INFO - 2021-04-16 15:49:28 --> Security Class Initialized
DEBUG - 2021-04-16 15:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:49:28 --> Input Class Initialized
INFO - 2021-04-16 15:49:28 --> Language Class Initialized
DEBUG - 2021-04-16 15:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:49:28 --> Output Class Initialized
INFO - 2021-04-16 15:49:28 --> Input Class Initialized
INFO - 2021-04-16 15:49:28 --> Language Class Initialized
ERROR - 2021-04-16 15:49:28 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:49:28 --> Security Class Initialized
DEBUG - 2021-04-16 15:49:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:49:28 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-16 15:49:28 --> Input Class Initialized
INFO - 2021-04-16 15:49:28 --> Language Class Initialized
ERROR - 2021-04-16 15:49:28 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-16 15:49:28 --> Config Class Initialized
INFO - 2021-04-16 15:49:28 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:49:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:49:28 --> Utf8 Class Initialized
INFO - 2021-04-16 15:49:28 --> URI Class Initialized
INFO - 2021-04-16 15:49:28 --> Router Class Initialized
INFO - 2021-04-16 15:49:28 --> Output Class Initialized
INFO - 2021-04-16 15:49:28 --> Security Class Initialized
DEBUG - 2021-04-16 15:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:49:28 --> Input Class Initialized
INFO - 2021-04-16 15:49:28 --> Language Class Initialized
ERROR - 2021-04-16 15:49:28 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:49:28 --> Config Class Initialized
INFO - 2021-04-16 15:49:28 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:49:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:49:28 --> Utf8 Class Initialized
INFO - 2021-04-16 15:49:28 --> URI Class Initialized
INFO - 2021-04-16 15:49:28 --> Router Class Initialized
INFO - 2021-04-16 15:49:28 --> Output Class Initialized
INFO - 2021-04-16 15:49:28 --> Security Class Initialized
DEBUG - 2021-04-16 15:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:49:28 --> Input Class Initialized
INFO - 2021-04-16 15:49:28 --> Language Class Initialized
ERROR - 2021-04-16 15:49:28 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 15:49:29 --> Config Class Initialized
INFO - 2021-04-16 15:49:29 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:49:29 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:49:29 --> Utf8 Class Initialized
INFO - 2021-04-16 15:49:29 --> URI Class Initialized
INFO - 2021-04-16 15:49:29 --> Router Class Initialized
INFO - 2021-04-16 15:49:29 --> Output Class Initialized
INFO - 2021-04-16 15:49:29 --> Security Class Initialized
DEBUG - 2021-04-16 15:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:49:29 --> Input Class Initialized
INFO - 2021-04-16 15:49:29 --> Language Class Initialized
ERROR - 2021-04-16 15:49:29 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:49:29 --> Config Class Initialized
INFO - 2021-04-16 15:49:29 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:49:29 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:49:29 --> Utf8 Class Initialized
INFO - 2021-04-16 15:49:29 --> URI Class Initialized
INFO - 2021-04-16 15:49:29 --> Router Class Initialized
INFO - 2021-04-16 15:49:29 --> Output Class Initialized
INFO - 2021-04-16 15:49:29 --> Security Class Initialized
DEBUG - 2021-04-16 15:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:49:29 --> Input Class Initialized
INFO - 2021-04-16 15:49:29 --> Language Class Initialized
ERROR - 2021-04-16 15:49:29 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:49:29 --> Config Class Initialized
INFO - 2021-04-16 15:49:29 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:49:29 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:49:29 --> Utf8 Class Initialized
INFO - 2021-04-16 15:49:29 --> URI Class Initialized
INFO - 2021-04-16 15:49:29 --> Router Class Initialized
INFO - 2021-04-16 15:49:29 --> Output Class Initialized
INFO - 2021-04-16 15:49:29 --> Security Class Initialized
DEBUG - 2021-04-16 15:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:49:29 --> Input Class Initialized
INFO - 2021-04-16 15:49:29 --> Language Class Initialized
ERROR - 2021-04-16 15:49:29 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 15:49:29 --> Config Class Initialized
INFO - 2021-04-16 15:49:29 --> Hooks Class Initialized
DEBUG - 2021-04-16 15:49:29 --> UTF-8 Support Enabled
INFO - 2021-04-16 15:49:29 --> Utf8 Class Initialized
INFO - 2021-04-16 15:49:29 --> URI Class Initialized
INFO - 2021-04-16 15:49:29 --> Router Class Initialized
INFO - 2021-04-16 15:49:29 --> Output Class Initialized
INFO - 2021-04-16 15:49:29 --> Security Class Initialized
DEBUG - 2021-04-16 15:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 15:49:29 --> Input Class Initialized
INFO - 2021-04-16 15:49:29 --> Language Class Initialized
ERROR - 2021-04-16 15:49:29 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 16:52:56 --> Config Class Initialized
INFO - 2021-04-16 16:52:56 --> Hooks Class Initialized
DEBUG - 2021-04-16 16:52:56 --> UTF-8 Support Enabled
INFO - 2021-04-16 16:52:56 --> Utf8 Class Initialized
INFO - 2021-04-16 16:52:56 --> URI Class Initialized
INFO - 2021-04-16 16:52:56 --> Router Class Initialized
INFO - 2021-04-16 16:52:56 --> Output Class Initialized
INFO - 2021-04-16 16:52:56 --> Security Class Initialized
DEBUG - 2021-04-16 16:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 16:52:56 --> Input Class Initialized
INFO - 2021-04-16 16:52:56 --> Language Class Initialized
ERROR - 2021-04-16 16:52:56 --> Severity: error --> Exception: syntax error, unexpected '<<' (T_SL) C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 10
INFO - 2021-04-16 16:53:42 --> Config Class Initialized
INFO - 2021-04-16 16:53:42 --> Hooks Class Initialized
DEBUG - 2021-04-16 16:53:42 --> UTF-8 Support Enabled
INFO - 2021-04-16 16:53:42 --> Utf8 Class Initialized
INFO - 2021-04-16 16:53:42 --> URI Class Initialized
INFO - 2021-04-16 16:53:42 --> Router Class Initialized
INFO - 2021-04-16 16:53:42 --> Output Class Initialized
INFO - 2021-04-16 16:53:42 --> Security Class Initialized
DEBUG - 2021-04-16 16:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 16:53:42 --> Input Class Initialized
INFO - 2021-04-16 16:53:42 --> Language Class Initialized
ERROR - 2021-04-16 16:53:42 --> Severity: error --> Exception: syntax error, unexpected '<<' (T_SL) C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 10
INFO - 2021-04-16 16:53:58 --> Config Class Initialized
INFO - 2021-04-16 16:53:58 --> Hooks Class Initialized
DEBUG - 2021-04-16 16:53:58 --> UTF-8 Support Enabled
INFO - 2021-04-16 16:53:58 --> Utf8 Class Initialized
INFO - 2021-04-16 16:53:58 --> URI Class Initialized
INFO - 2021-04-16 16:53:58 --> Router Class Initialized
INFO - 2021-04-16 16:53:58 --> Output Class Initialized
INFO - 2021-04-16 16:53:58 --> Security Class Initialized
DEBUG - 2021-04-16 16:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 16:53:58 --> Input Class Initialized
INFO - 2021-04-16 16:53:58 --> Language Class Initialized
ERROR - 2021-04-16 16:53:58 --> Severity: error --> Exception: syntax error, unexpected '<<' (T_SL) C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 10
INFO - 2021-04-16 16:54:02 --> Config Class Initialized
INFO - 2021-04-16 16:54:02 --> Hooks Class Initialized
DEBUG - 2021-04-16 16:54:02 --> UTF-8 Support Enabled
INFO - 2021-04-16 16:54:02 --> Utf8 Class Initialized
INFO - 2021-04-16 16:54:02 --> URI Class Initialized
INFO - 2021-04-16 16:54:02 --> Router Class Initialized
INFO - 2021-04-16 16:54:02 --> Output Class Initialized
INFO - 2021-04-16 16:54:02 --> Security Class Initialized
DEBUG - 2021-04-16 16:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 16:54:02 --> Input Class Initialized
INFO - 2021-04-16 16:54:02 --> Language Class Initialized
ERROR - 2021-04-16 16:54:02 --> Severity: error --> Exception: syntax error, unexpected '<<' (T_SL) C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 10
INFO - 2021-04-16 16:55:11 --> Config Class Initialized
INFO - 2021-04-16 16:55:11 --> Hooks Class Initialized
DEBUG - 2021-04-16 16:55:11 --> UTF-8 Support Enabled
INFO - 2021-04-16 16:55:11 --> Utf8 Class Initialized
INFO - 2021-04-16 16:55:11 --> URI Class Initialized
INFO - 2021-04-16 16:55:11 --> Router Class Initialized
INFO - 2021-04-16 16:55:11 --> Output Class Initialized
INFO - 2021-04-16 16:55:11 --> Security Class Initialized
DEBUG - 2021-04-16 16:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 16:55:11 --> Input Class Initialized
INFO - 2021-04-16 16:55:11 --> Language Class Initialized
INFO - 2021-04-16 16:55:11 --> Loader Class Initialized
INFO - 2021-04-16 16:55:11 --> Helper loaded: url_helper
INFO - 2021-04-16 16:55:11 --> Helper loaded: form_helper
INFO - 2021-04-16 16:55:11 --> Helper loaded: common_helper
INFO - 2021-04-16 16:55:11 --> Helper loaded: util_helper
INFO - 2021-04-16 16:55:11 --> Helper loaded: user_helper
INFO - 2021-04-16 16:55:11 --> Database Driver Class Initialized
DEBUG - 2021-04-16 16:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 16:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 16:55:11 --> Form Validation Class Initialized
INFO - 2021-04-16 16:55:11 --> Model Class Initialized
INFO - 2021-04-16 16:55:11 --> Controller Class Initialized
INFO - 2021-04-16 16:55:11 --> Model Class Initialized
ERROR - 2021-04-16 16:55:11 --> Severity: error --> Exception: Call to undefined method Account_m::get_row() C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 32
INFO - 2021-04-16 16:55:29 --> Config Class Initialized
INFO - 2021-04-16 16:55:29 --> Hooks Class Initialized
DEBUG - 2021-04-16 16:55:29 --> UTF-8 Support Enabled
INFO - 2021-04-16 16:55:29 --> Utf8 Class Initialized
INFO - 2021-04-16 16:55:29 --> URI Class Initialized
INFO - 2021-04-16 16:55:29 --> Router Class Initialized
INFO - 2021-04-16 16:55:29 --> Output Class Initialized
INFO - 2021-04-16 16:55:29 --> Security Class Initialized
DEBUG - 2021-04-16 16:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 16:55:29 --> Input Class Initialized
INFO - 2021-04-16 16:55:29 --> Language Class Initialized
INFO - 2021-04-16 16:55:29 --> Loader Class Initialized
INFO - 2021-04-16 16:55:29 --> Helper loaded: url_helper
INFO - 2021-04-16 16:55:29 --> Helper loaded: form_helper
INFO - 2021-04-16 16:55:29 --> Helper loaded: common_helper
INFO - 2021-04-16 16:55:29 --> Helper loaded: util_helper
INFO - 2021-04-16 16:55:29 --> Helper loaded: user_helper
INFO - 2021-04-16 16:55:29 --> Database Driver Class Initialized
DEBUG - 2021-04-16 16:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 16:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 16:55:29 --> Form Validation Class Initialized
INFO - 2021-04-16 16:55:29 --> Model Class Initialized
INFO - 2021-04-16 16:55:29 --> Controller Class Initialized
INFO - 2021-04-16 16:55:29 --> Model Class Initialized
INFO - 2021-04-16 16:55:44 --> Config Class Initialized
INFO - 2021-04-16 16:55:44 --> Hooks Class Initialized
DEBUG - 2021-04-16 16:55:44 --> UTF-8 Support Enabled
INFO - 2021-04-16 16:55:44 --> Utf8 Class Initialized
INFO - 2021-04-16 16:55:44 --> URI Class Initialized
INFO - 2021-04-16 16:55:44 --> Router Class Initialized
INFO - 2021-04-16 16:55:44 --> Output Class Initialized
INFO - 2021-04-16 16:55:44 --> Security Class Initialized
DEBUG - 2021-04-16 16:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 16:55:44 --> Input Class Initialized
INFO - 2021-04-16 16:55:44 --> Language Class Initialized
INFO - 2021-04-16 16:55:44 --> Loader Class Initialized
INFO - 2021-04-16 16:55:44 --> Helper loaded: url_helper
INFO - 2021-04-16 16:55:44 --> Helper loaded: form_helper
INFO - 2021-04-16 16:55:44 --> Helper loaded: common_helper
INFO - 2021-04-16 16:55:44 --> Helper loaded: util_helper
INFO - 2021-04-16 16:55:44 --> Helper loaded: user_helper
INFO - 2021-04-16 16:55:44 --> Database Driver Class Initialized
DEBUG - 2021-04-16 16:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 16:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 16:55:44 --> Form Validation Class Initialized
INFO - 2021-04-16 16:55:44 --> Model Class Initialized
INFO - 2021-04-16 16:55:44 --> Controller Class Initialized
INFO - 2021-04-16 16:55:44 --> Model Class Initialized
INFO - 2021-04-16 16:55:45 --> Config Class Initialized
INFO - 2021-04-16 16:55:45 --> Hooks Class Initialized
DEBUG - 2021-04-16 16:55:45 --> UTF-8 Support Enabled
INFO - 2021-04-16 16:55:45 --> Utf8 Class Initialized
INFO - 2021-04-16 16:55:45 --> URI Class Initialized
INFO - 2021-04-16 16:55:45 --> Router Class Initialized
INFO - 2021-04-16 16:55:45 --> Output Class Initialized
INFO - 2021-04-16 16:55:45 --> Security Class Initialized
DEBUG - 2021-04-16 16:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 16:55:45 --> Input Class Initialized
INFO - 2021-04-16 16:55:45 --> Language Class Initialized
INFO - 2021-04-16 16:55:45 --> Loader Class Initialized
INFO - 2021-04-16 16:55:45 --> Helper loaded: url_helper
INFO - 2021-04-16 16:55:45 --> Helper loaded: form_helper
INFO - 2021-04-16 16:55:45 --> Helper loaded: common_helper
INFO - 2021-04-16 16:55:45 --> Helper loaded: util_helper
INFO - 2021-04-16 16:55:45 --> Helper loaded: user_helper
INFO - 2021-04-16 16:55:45 --> Database Driver Class Initialized
DEBUG - 2021-04-16 16:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 16:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 16:55:45 --> Form Validation Class Initialized
INFO - 2021-04-16 16:55:45 --> Model Class Initialized
INFO - 2021-04-16 16:55:45 --> Controller Class Initialized
INFO - 2021-04-16 16:55:45 --> Model Class Initialized
INFO - 2021-04-16 16:55:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 16:55:45 --> Final output sent to browser
DEBUG - 2021-04-16 16:55:45 --> Total execution time: 0.0271
INFO - 2021-04-16 16:55:49 --> Config Class Initialized
INFO - 2021-04-16 16:55:49 --> Hooks Class Initialized
DEBUG - 2021-04-16 16:55:49 --> UTF-8 Support Enabled
INFO - 2021-04-16 16:55:49 --> Utf8 Class Initialized
INFO - 2021-04-16 16:55:49 --> URI Class Initialized
DEBUG - 2021-04-16 16:55:49 --> No URI present. Default controller set.
INFO - 2021-04-16 16:55:49 --> Router Class Initialized
INFO - 2021-04-16 16:55:49 --> Output Class Initialized
INFO - 2021-04-16 16:55:49 --> Security Class Initialized
DEBUG - 2021-04-16 16:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 16:55:49 --> Input Class Initialized
INFO - 2021-04-16 16:55:49 --> Language Class Initialized
INFO - 2021-04-16 16:55:49 --> Loader Class Initialized
INFO - 2021-04-16 16:55:49 --> Helper loaded: url_helper
INFO - 2021-04-16 16:55:49 --> Helper loaded: form_helper
INFO - 2021-04-16 16:55:49 --> Helper loaded: common_helper
INFO - 2021-04-16 16:55:49 --> Helper loaded: util_helper
INFO - 2021-04-16 16:55:49 --> Helper loaded: user_helper
INFO - 2021-04-16 16:55:49 --> Database Driver Class Initialized
DEBUG - 2021-04-16 16:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 16:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 16:55:49 --> Form Validation Class Initialized
INFO - 2021-04-16 16:55:49 --> Model Class Initialized
INFO - 2021-04-16 16:55:49 --> Controller Class Initialized
INFO - 2021-04-16 16:55:49 --> Model Class Initialized
INFO - 2021-04-16 16:55:49 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 16:55:49 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 16:55:49 --> Final output sent to browser
DEBUG - 2021-04-16 16:55:49 --> Total execution time: 0.0274
INFO - 2021-04-16 16:55:51 --> Config Class Initialized
INFO - 2021-04-16 16:55:51 --> Hooks Class Initialized
DEBUG - 2021-04-16 16:55:51 --> UTF-8 Support Enabled
INFO - 2021-04-16 16:55:51 --> Utf8 Class Initialized
INFO - 2021-04-16 16:55:51 --> URI Class Initialized
INFO - 2021-04-16 16:55:51 --> Router Class Initialized
INFO - 2021-04-16 16:55:51 --> Output Class Initialized
INFO - 2021-04-16 16:55:51 --> Security Class Initialized
DEBUG - 2021-04-16 16:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 16:55:51 --> Input Class Initialized
INFO - 2021-04-16 16:55:51 --> Language Class Initialized
INFO - 2021-04-16 16:55:51 --> Loader Class Initialized
INFO - 2021-04-16 16:55:51 --> Helper loaded: url_helper
INFO - 2021-04-16 16:55:51 --> Helper loaded: form_helper
INFO - 2021-04-16 16:55:51 --> Helper loaded: common_helper
INFO - 2021-04-16 16:55:51 --> Helper loaded: util_helper
INFO - 2021-04-16 16:55:51 --> Helper loaded: user_helper
INFO - 2021-04-16 16:55:51 --> Database Driver Class Initialized
DEBUG - 2021-04-16 16:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 16:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 16:55:51 --> Form Validation Class Initialized
INFO - 2021-04-16 16:55:51 --> Model Class Initialized
INFO - 2021-04-16 16:55:51 --> Controller Class Initialized
INFO - 2021-04-16 16:55:51 --> Model Class Initialized
INFO - 2021-04-16 16:55:51 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 16:55:51 --> Final output sent to browser
DEBUG - 2021-04-16 16:55:51 --> Total execution time: 0.0268
INFO - 2021-04-16 16:56:18 --> Config Class Initialized
INFO - 2021-04-16 16:56:18 --> Hooks Class Initialized
DEBUG - 2021-04-16 16:56:18 --> UTF-8 Support Enabled
INFO - 2021-04-16 16:56:18 --> Utf8 Class Initialized
INFO - 2021-04-16 16:56:18 --> URI Class Initialized
INFO - 2021-04-16 16:56:18 --> Router Class Initialized
INFO - 2021-04-16 16:56:18 --> Output Class Initialized
INFO - 2021-04-16 16:56:18 --> Security Class Initialized
DEBUG - 2021-04-16 16:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 16:56:18 --> Input Class Initialized
INFO - 2021-04-16 16:56:18 --> Language Class Initialized
INFO - 2021-04-16 16:56:18 --> Loader Class Initialized
INFO - 2021-04-16 16:56:18 --> Helper loaded: url_helper
INFO - 2021-04-16 16:56:18 --> Helper loaded: form_helper
INFO - 2021-04-16 16:56:18 --> Helper loaded: common_helper
INFO - 2021-04-16 16:56:18 --> Helper loaded: util_helper
INFO - 2021-04-16 16:56:18 --> Helper loaded: user_helper
INFO - 2021-04-16 16:56:18 --> Database Driver Class Initialized
DEBUG - 2021-04-16 16:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 16:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 16:56:18 --> Form Validation Class Initialized
INFO - 2021-04-16 16:56:18 --> Model Class Initialized
INFO - 2021-04-16 16:56:18 --> Controller Class Initialized
INFO - 2021-04-16 16:56:18 --> Model Class Initialized
INFO - 2021-04-16 16:56:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-16 16:56:18 --> Config Class Initialized
INFO - 2021-04-16 16:56:18 --> Hooks Class Initialized
DEBUG - 2021-04-16 16:56:18 --> UTF-8 Support Enabled
INFO - 2021-04-16 16:56:18 --> Utf8 Class Initialized
INFO - 2021-04-16 16:56:18 --> URI Class Initialized
INFO - 2021-04-16 16:56:18 --> Router Class Initialized
INFO - 2021-04-16 16:56:18 --> Output Class Initialized
INFO - 2021-04-16 16:56:18 --> Security Class Initialized
DEBUG - 2021-04-16 16:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 16:56:18 --> Input Class Initialized
INFO - 2021-04-16 16:56:18 --> Language Class Initialized
INFO - 2021-04-16 16:56:18 --> Loader Class Initialized
INFO - 2021-04-16 16:56:18 --> Helper loaded: url_helper
INFO - 2021-04-16 16:56:18 --> Helper loaded: form_helper
INFO - 2021-04-16 16:56:18 --> Helper loaded: common_helper
INFO - 2021-04-16 16:56:18 --> Helper loaded: util_helper
INFO - 2021-04-16 16:56:18 --> Helper loaded: user_helper
INFO - 2021-04-16 16:56:18 --> Database Driver Class Initialized
DEBUG - 2021-04-16 16:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 16:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 16:56:18 --> Form Validation Class Initialized
INFO - 2021-04-16 16:56:18 --> Model Class Initialized
INFO - 2021-04-16 16:56:18 --> Controller Class Initialized
INFO - 2021-04-16 16:56:18 --> Model Class Initialized
INFO - 2021-04-16 17:02:38 --> Config Class Initialized
INFO - 2021-04-16 17:02:38 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:02:38 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:02:38 --> Utf8 Class Initialized
INFO - 2021-04-16 17:02:38 --> URI Class Initialized
INFO - 2021-04-16 17:02:38 --> Router Class Initialized
INFO - 2021-04-16 17:02:38 --> Output Class Initialized
INFO - 2021-04-16 17:02:38 --> Security Class Initialized
DEBUG - 2021-04-16 17:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:02:38 --> Input Class Initialized
INFO - 2021-04-16 17:02:38 --> Language Class Initialized
INFO - 2021-04-16 17:02:38 --> Loader Class Initialized
INFO - 2021-04-16 17:02:38 --> Helper loaded: url_helper
INFO - 2021-04-16 17:02:38 --> Helper loaded: form_helper
INFO - 2021-04-16 17:02:38 --> Helper loaded: common_helper
INFO - 2021-04-16 17:02:38 --> Helper loaded: util_helper
INFO - 2021-04-16 17:02:38 --> Helper loaded: user_helper
INFO - 2021-04-16 17:02:38 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:02:38 --> Form Validation Class Initialized
INFO - 2021-04-16 17:02:38 --> Model Class Initialized
INFO - 2021-04-16 17:02:38 --> Controller Class Initialized
INFO - 2021-04-16 17:02:38 --> Model Class Initialized
ERROR - 2021-04-16 17:02:38 --> Severity: error --> Exception: Call to undefined method Account_m::get_row() C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 32
INFO - 2021-04-16 17:02:58 --> Config Class Initialized
INFO - 2021-04-16 17:02:58 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:02:58 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:02:58 --> Utf8 Class Initialized
INFO - 2021-04-16 17:02:58 --> URI Class Initialized
INFO - 2021-04-16 17:02:58 --> Router Class Initialized
INFO - 2021-04-16 17:02:58 --> Output Class Initialized
INFO - 2021-04-16 17:02:58 --> Security Class Initialized
DEBUG - 2021-04-16 17:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:02:58 --> Input Class Initialized
INFO - 2021-04-16 17:02:58 --> Language Class Initialized
INFO - 2021-04-16 17:02:58 --> Loader Class Initialized
INFO - 2021-04-16 17:02:58 --> Helper loaded: url_helper
INFO - 2021-04-16 17:02:58 --> Helper loaded: form_helper
INFO - 2021-04-16 17:02:58 --> Helper loaded: common_helper
INFO - 2021-04-16 17:02:58 --> Helper loaded: util_helper
INFO - 2021-04-16 17:02:58 --> Helper loaded: user_helper
INFO - 2021-04-16 17:02:58 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:02:58 --> Form Validation Class Initialized
INFO - 2021-04-16 17:02:58 --> Model Class Initialized
INFO - 2021-04-16 17:02:58 --> Controller Class Initialized
INFO - 2021-04-16 17:02:58 --> Model Class Initialized
INFO - 2021-04-16 17:04:04 --> Config Class Initialized
INFO - 2021-04-16 17:04:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:04:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:04:04 --> Utf8 Class Initialized
INFO - 2021-04-16 17:04:04 --> URI Class Initialized
INFO - 2021-04-16 17:04:04 --> Router Class Initialized
INFO - 2021-04-16 17:04:04 --> Output Class Initialized
INFO - 2021-04-16 17:04:04 --> Security Class Initialized
DEBUG - 2021-04-16 17:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:04:04 --> Input Class Initialized
INFO - 2021-04-16 17:04:04 --> Language Class Initialized
INFO - 2021-04-16 17:04:04 --> Loader Class Initialized
INFO - 2021-04-16 17:04:04 --> Helper loaded: url_helper
INFO - 2021-04-16 17:04:04 --> Helper loaded: form_helper
INFO - 2021-04-16 17:04:04 --> Helper loaded: common_helper
INFO - 2021-04-16 17:04:04 --> Helper loaded: util_helper
INFO - 2021-04-16 17:04:04 --> Helper loaded: user_helper
INFO - 2021-04-16 17:04:04 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:04:04 --> Form Validation Class Initialized
INFO - 2021-04-16 17:04:04 --> Model Class Initialized
INFO - 2021-04-16 17:04:04 --> Controller Class Initialized
INFO - 2021-04-16 17:04:04 --> Model Class Initialized
ERROR - 2021-04-16 17:04:04 --> Severity: error --> Exception: Call to undefined method Account_m::get_row() C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 32
INFO - 2021-04-16 17:04:13 --> Config Class Initialized
INFO - 2021-04-16 17:04:13 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:04:13 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:04:13 --> Utf8 Class Initialized
INFO - 2021-04-16 17:04:13 --> URI Class Initialized
INFO - 2021-04-16 17:04:13 --> Router Class Initialized
INFO - 2021-04-16 17:04:13 --> Output Class Initialized
INFO - 2021-04-16 17:04:13 --> Security Class Initialized
DEBUG - 2021-04-16 17:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:04:13 --> Input Class Initialized
INFO - 2021-04-16 17:04:13 --> Language Class Initialized
INFO - 2021-04-16 17:04:13 --> Loader Class Initialized
INFO - 2021-04-16 17:04:13 --> Helper loaded: url_helper
INFO - 2021-04-16 17:04:13 --> Helper loaded: form_helper
INFO - 2021-04-16 17:04:13 --> Helper loaded: common_helper
INFO - 2021-04-16 17:04:13 --> Helper loaded: util_helper
INFO - 2021-04-16 17:04:13 --> Helper loaded: user_helper
INFO - 2021-04-16 17:04:13 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:04:13 --> Form Validation Class Initialized
INFO - 2021-04-16 17:04:13 --> Model Class Initialized
INFO - 2021-04-16 17:04:13 --> Controller Class Initialized
INFO - 2021-04-16 17:04:13 --> Model Class Initialized
INFO - 2021-04-16 17:04:28 --> Config Class Initialized
INFO - 2021-04-16 17:04:28 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:04:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:04:28 --> Utf8 Class Initialized
INFO - 2021-04-16 17:04:28 --> URI Class Initialized
INFO - 2021-04-16 17:04:28 --> Router Class Initialized
INFO - 2021-04-16 17:04:28 --> Output Class Initialized
INFO - 2021-04-16 17:04:28 --> Security Class Initialized
DEBUG - 2021-04-16 17:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:04:28 --> Input Class Initialized
INFO - 2021-04-16 17:04:28 --> Language Class Initialized
INFO - 2021-04-16 17:04:28 --> Loader Class Initialized
INFO - 2021-04-16 17:04:28 --> Helper loaded: url_helper
INFO - 2021-04-16 17:04:28 --> Helper loaded: form_helper
INFO - 2021-04-16 17:04:28 --> Helper loaded: common_helper
INFO - 2021-04-16 17:04:28 --> Helper loaded: util_helper
INFO - 2021-04-16 17:04:28 --> Helper loaded: user_helper
INFO - 2021-04-16 17:04:28 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:04:28 --> Form Validation Class Initialized
INFO - 2021-04-16 17:04:28 --> Model Class Initialized
INFO - 2021-04-16 17:04:28 --> Controller Class Initialized
INFO - 2021-04-16 17:04:28 --> Model Class Initialized
ERROR - 2021-04-16 17:04:28 --> Severity: error --> Exception: Call to undefined method Account_m::get_row() C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 32
INFO - 2021-04-16 17:04:29 --> Config Class Initialized
INFO - 2021-04-16 17:04:29 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:04:29 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:04:29 --> Utf8 Class Initialized
INFO - 2021-04-16 17:04:29 --> URI Class Initialized
INFO - 2021-04-16 17:04:29 --> Router Class Initialized
INFO - 2021-04-16 17:04:29 --> Output Class Initialized
INFO - 2021-04-16 17:04:29 --> Security Class Initialized
DEBUG - 2021-04-16 17:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:04:29 --> Input Class Initialized
INFO - 2021-04-16 17:04:29 --> Language Class Initialized
INFO - 2021-04-16 17:04:29 --> Loader Class Initialized
INFO - 2021-04-16 17:04:29 --> Helper loaded: url_helper
INFO - 2021-04-16 17:04:29 --> Helper loaded: form_helper
INFO - 2021-04-16 17:04:29 --> Helper loaded: common_helper
INFO - 2021-04-16 17:04:29 --> Helper loaded: util_helper
INFO - 2021-04-16 17:04:29 --> Helper loaded: user_helper
INFO - 2021-04-16 17:04:29 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:04:29 --> Form Validation Class Initialized
INFO - 2021-04-16 17:04:29 --> Model Class Initialized
INFO - 2021-04-16 17:04:29 --> Controller Class Initialized
INFO - 2021-04-16 17:04:29 --> Model Class Initialized
ERROR - 2021-04-16 17:04:29 --> Severity: error --> Exception: Call to undefined method Account_m::get_row() C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 32
INFO - 2021-04-16 17:04:29 --> Config Class Initialized
INFO - 2021-04-16 17:04:29 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:04:29 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:04:29 --> Utf8 Class Initialized
INFO - 2021-04-16 17:04:29 --> URI Class Initialized
INFO - 2021-04-16 17:04:29 --> Router Class Initialized
INFO - 2021-04-16 17:04:29 --> Output Class Initialized
INFO - 2021-04-16 17:04:29 --> Security Class Initialized
DEBUG - 2021-04-16 17:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:04:29 --> Input Class Initialized
INFO - 2021-04-16 17:04:29 --> Language Class Initialized
INFO - 2021-04-16 17:04:29 --> Loader Class Initialized
INFO - 2021-04-16 17:04:29 --> Helper loaded: url_helper
INFO - 2021-04-16 17:04:29 --> Helper loaded: form_helper
INFO - 2021-04-16 17:04:29 --> Helper loaded: common_helper
INFO - 2021-04-16 17:04:29 --> Helper loaded: util_helper
INFO - 2021-04-16 17:04:29 --> Helper loaded: user_helper
INFO - 2021-04-16 17:04:29 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:04:29 --> Form Validation Class Initialized
INFO - 2021-04-16 17:04:29 --> Model Class Initialized
INFO - 2021-04-16 17:04:29 --> Controller Class Initialized
INFO - 2021-04-16 17:04:29 --> Model Class Initialized
ERROR - 2021-04-16 17:04:29 --> Severity: error --> Exception: Call to undefined method Account_m::get_row() C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 32
INFO - 2021-04-16 17:04:29 --> Config Class Initialized
INFO - 2021-04-16 17:04:29 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:04:29 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:04:29 --> Utf8 Class Initialized
INFO - 2021-04-16 17:04:29 --> URI Class Initialized
INFO - 2021-04-16 17:04:29 --> Router Class Initialized
INFO - 2021-04-16 17:04:29 --> Output Class Initialized
INFO - 2021-04-16 17:04:29 --> Security Class Initialized
DEBUG - 2021-04-16 17:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:04:29 --> Input Class Initialized
INFO - 2021-04-16 17:04:29 --> Language Class Initialized
INFO - 2021-04-16 17:04:29 --> Loader Class Initialized
INFO - 2021-04-16 17:04:29 --> Helper loaded: url_helper
INFO - 2021-04-16 17:04:29 --> Helper loaded: form_helper
INFO - 2021-04-16 17:04:29 --> Helper loaded: common_helper
INFO - 2021-04-16 17:04:29 --> Helper loaded: util_helper
INFO - 2021-04-16 17:04:29 --> Helper loaded: user_helper
INFO - 2021-04-16 17:04:29 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:04:29 --> Form Validation Class Initialized
INFO - 2021-04-16 17:04:29 --> Model Class Initialized
INFO - 2021-04-16 17:04:29 --> Controller Class Initialized
INFO - 2021-04-16 17:04:29 --> Model Class Initialized
ERROR - 2021-04-16 17:04:29 --> Severity: error --> Exception: Call to undefined method Account_m::get_row() C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 32
INFO - 2021-04-16 17:05:20 --> Config Class Initialized
INFO - 2021-04-16 17:05:20 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:05:20 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:05:20 --> Utf8 Class Initialized
INFO - 2021-04-16 17:05:20 --> URI Class Initialized
INFO - 2021-04-16 17:05:20 --> Router Class Initialized
INFO - 2021-04-16 17:05:20 --> Output Class Initialized
INFO - 2021-04-16 17:05:20 --> Security Class Initialized
DEBUG - 2021-04-16 17:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:05:20 --> Input Class Initialized
INFO - 2021-04-16 17:05:20 --> Language Class Initialized
INFO - 2021-04-16 17:05:20 --> Loader Class Initialized
INFO - 2021-04-16 17:05:20 --> Helper loaded: url_helper
INFO - 2021-04-16 17:05:20 --> Helper loaded: form_helper
INFO - 2021-04-16 17:05:20 --> Helper loaded: common_helper
INFO - 2021-04-16 17:05:20 --> Helper loaded: util_helper
INFO - 2021-04-16 17:05:20 --> Helper loaded: user_helper
INFO - 2021-04-16 17:05:20 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:05:20 --> Form Validation Class Initialized
INFO - 2021-04-16 17:05:20 --> Model Class Initialized
INFO - 2021-04-16 17:05:20 --> Controller Class Initialized
INFO - 2021-04-16 17:05:20 --> Model Class Initialized
INFO - 2021-04-16 17:05:33 --> Config Class Initialized
INFO - 2021-04-16 17:05:33 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:05:33 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:05:33 --> Utf8 Class Initialized
INFO - 2021-04-16 17:05:33 --> URI Class Initialized
INFO - 2021-04-16 17:05:33 --> Router Class Initialized
INFO - 2021-04-16 17:05:33 --> Output Class Initialized
INFO - 2021-04-16 17:05:33 --> Security Class Initialized
DEBUG - 2021-04-16 17:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:05:33 --> Input Class Initialized
INFO - 2021-04-16 17:05:33 --> Language Class Initialized
INFO - 2021-04-16 17:05:33 --> Loader Class Initialized
INFO - 2021-04-16 17:05:33 --> Helper loaded: url_helper
INFO - 2021-04-16 17:05:33 --> Helper loaded: form_helper
INFO - 2021-04-16 17:05:33 --> Helper loaded: common_helper
INFO - 2021-04-16 17:05:33 --> Helper loaded: util_helper
INFO - 2021-04-16 17:05:33 --> Helper loaded: user_helper
INFO - 2021-04-16 17:05:33 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:05:33 --> Form Validation Class Initialized
INFO - 2021-04-16 17:05:33 --> Model Class Initialized
INFO - 2021-04-16 17:05:33 --> Controller Class Initialized
INFO - 2021-04-16 17:05:33 --> Model Class Initialized
INFO - 2021-04-16 17:05:33 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 17:05:33 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 17:05:33 --> Final output sent to browser
DEBUG - 2021-04-16 17:05:33 --> Total execution time: 0.0296
INFO - 2021-04-16 17:05:33 --> Config Class Initialized
INFO - 2021-04-16 17:05:33 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:05:33 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:05:33 --> Utf8 Class Initialized
INFO - 2021-04-16 17:05:33 --> URI Class Initialized
INFO - 2021-04-16 17:05:33 --> Config Class Initialized
INFO - 2021-04-16 17:05:33 --> Hooks Class Initialized
INFO - 2021-04-16 17:05:33 --> Router Class Initialized
INFO - 2021-04-16 17:05:33 --> Output Class Initialized
DEBUG - 2021-04-16 17:05:33 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:05:33 --> Security Class Initialized
DEBUG - 2021-04-16 17:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:05:33 --> Input Class Initialized
INFO - 2021-04-16 17:05:33 --> Utf8 Class Initialized
INFO - 2021-04-16 17:05:33 --> Config Class Initialized
INFO - 2021-04-16 17:05:33 --> Hooks Class Initialized
INFO - 2021-04-16 17:05:33 --> URI Class Initialized
INFO - 2021-04-16 17:05:33 --> Router Class Initialized
DEBUG - 2021-04-16 17:05:33 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:05:33 --> Config Class Initialized
INFO - 2021-04-16 17:05:33 --> Utf8 Class Initialized
INFO - 2021-04-16 17:05:33 --> Hooks Class Initialized
INFO - 2021-04-16 17:05:33 --> Output Class Initialized
INFO - 2021-04-16 17:05:33 --> URI Class Initialized
INFO - 2021-04-16 17:05:33 --> Security Class Initialized
INFO - 2021-04-16 17:05:33 --> Language Class Initialized
INFO - 2021-04-16 17:05:33 --> Router Class Initialized
DEBUG - 2021-04-16 17:05:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:05:33 --> Utf8 Class Initialized
INFO - 2021-04-16 17:05:33 --> Input Class Initialized
INFO - 2021-04-16 17:05:33 --> Language Class Initialized
INFO - 2021-04-16 17:05:33 --> URI Class Initialized
ERROR - 2021-04-16 17:05:33 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-16 17:05:33 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:05:33 --> Router Class Initialized
INFO - 2021-04-16 17:05:33 --> Output Class Initialized
INFO - 2021-04-16 17:05:33 --> Output Class Initialized
INFO - 2021-04-16 17:05:33 --> Security Class Initialized
DEBUG - 2021-04-16 17:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:05:33 --> Config Class Initialized
INFO - 2021-04-16 17:05:33 --> Hooks Class Initialized
INFO - 2021-04-16 17:05:33 --> Input Class Initialized
INFO - 2021-04-16 17:05:33 --> Language Class Initialized
DEBUG - 2021-04-16 17:05:33 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:05:33 --> Utf8 Class Initialized
INFO - 2021-04-16 17:05:33 --> URI Class Initialized
ERROR - 2021-04-16 17:05:33 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:05:33 --> Router Class Initialized
INFO - 2021-04-16 17:05:33 --> Config Class Initialized
INFO - 2021-04-16 17:05:33 --> Hooks Class Initialized
INFO - 2021-04-16 17:05:33 --> Security Class Initialized
INFO - 2021-04-16 17:05:33 --> Output Class Initialized
DEBUG - 2021-04-16 17:05:33 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:05:33 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:05:33 --> URI Class Initialized
INFO - 2021-04-16 17:05:33 --> Security Class Initialized
INFO - 2021-04-16 17:05:33 --> Input Class Initialized
INFO - 2021-04-16 17:05:33 --> Language Class Initialized
INFO - 2021-04-16 17:05:33 --> Router Class Initialized
DEBUG - 2021-04-16 17:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:05:33 --> Input Class Initialized
INFO - 2021-04-16 17:05:33 --> Output Class Initialized
INFO - 2021-04-16 17:05:33 --> Language Class Initialized
INFO - 2021-04-16 17:05:33 --> Security Class Initialized
ERROR - 2021-04-16 17:05:33 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-16 17:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:05:33 --> Input Class Initialized
INFO - 2021-04-16 17:05:33 --> Language Class Initialized
ERROR - 2021-04-16 17:05:33 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-16 17:05:33 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:05:33 --> Config Class Initialized
INFO - 2021-04-16 17:05:33 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:05:33 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:05:33 --> Utf8 Class Initialized
INFO - 2021-04-16 17:05:33 --> Config Class Initialized
INFO - 2021-04-16 17:05:33 --> Hooks Class Initialized
INFO - 2021-04-16 17:05:33 --> URI Class Initialized
DEBUG - 2021-04-16 17:05:33 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:05:33 --> Router Class Initialized
INFO - 2021-04-16 17:05:33 --> Utf8 Class Initialized
INFO - 2021-04-16 17:05:33 --> URI Class Initialized
INFO - 2021-04-16 17:05:33 --> Output Class Initialized
INFO - 2021-04-16 17:05:33 --> Router Class Initialized
INFO - 2021-04-16 17:05:33 --> Security Class Initialized
DEBUG - 2021-04-16 17:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:05:33 --> Input Class Initialized
INFO - 2021-04-16 17:05:33 --> Language Class Initialized
INFO - 2021-04-16 17:05:33 --> Output Class Initialized
ERROR - 2021-04-16 17:05:33 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:05:33 --> Security Class Initialized
DEBUG - 2021-04-16 17:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:05:33 --> Input Class Initialized
INFO - 2021-04-16 17:05:33 --> Language Class Initialized
ERROR - 2021-04-16 17:05:33 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:05:33 --> Config Class Initialized
INFO - 2021-04-16 17:05:33 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:05:33 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:05:33 --> Utf8 Class Initialized
INFO - 2021-04-16 17:05:33 --> URI Class Initialized
INFO - 2021-04-16 17:05:33 --> Router Class Initialized
INFO - 2021-04-16 17:05:33 --> Output Class Initialized
INFO - 2021-04-16 17:05:33 --> Security Class Initialized
DEBUG - 2021-04-16 17:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:05:33 --> Input Class Initialized
INFO - 2021-04-16 17:05:33 --> Language Class Initialized
ERROR - 2021-04-16 17:05:33 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:05:33 --> Config Class Initialized
INFO - 2021-04-16 17:05:33 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:05:33 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:05:33 --> Utf8 Class Initialized
INFO - 2021-04-16 17:05:33 --> URI Class Initialized
INFO - 2021-04-16 17:05:33 --> Router Class Initialized
INFO - 2021-04-16 17:05:33 --> Output Class Initialized
INFO - 2021-04-16 17:05:33 --> Security Class Initialized
DEBUG - 2021-04-16 17:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:05:33 --> Input Class Initialized
INFO - 2021-04-16 17:05:33 --> Language Class Initialized
ERROR - 2021-04-16 17:05:33 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:05:33 --> Config Class Initialized
INFO - 2021-04-16 17:05:33 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:05:33 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:05:33 --> Utf8 Class Initialized
INFO - 2021-04-16 17:05:33 --> URI Class Initialized
INFO - 2021-04-16 17:05:33 --> Router Class Initialized
INFO - 2021-04-16 17:05:33 --> Output Class Initialized
INFO - 2021-04-16 17:05:33 --> Security Class Initialized
DEBUG - 2021-04-16 17:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:05:33 --> Input Class Initialized
INFO - 2021-04-16 17:05:33 --> Language Class Initialized
ERROR - 2021-04-16 17:05:33 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:05:33 --> Config Class Initialized
INFO - 2021-04-16 17:05:33 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:05:33 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:05:33 --> Utf8 Class Initialized
INFO - 2021-04-16 17:05:33 --> URI Class Initialized
INFO - 2021-04-16 17:05:33 --> Router Class Initialized
INFO - 2021-04-16 17:05:33 --> Output Class Initialized
INFO - 2021-04-16 17:05:33 --> Security Class Initialized
DEBUG - 2021-04-16 17:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:05:33 --> Input Class Initialized
INFO - 2021-04-16 17:05:33 --> Language Class Initialized
ERROR - 2021-04-16 17:05:33 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:05:33 --> Config Class Initialized
INFO - 2021-04-16 17:05:33 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:05:33 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:05:33 --> Utf8 Class Initialized
INFO - 2021-04-16 17:05:33 --> URI Class Initialized
INFO - 2021-04-16 17:05:33 --> Router Class Initialized
INFO - 2021-04-16 17:05:33 --> Output Class Initialized
INFO - 2021-04-16 17:05:33 --> Security Class Initialized
DEBUG - 2021-04-16 17:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:05:33 --> Input Class Initialized
INFO - 2021-04-16 17:05:33 --> Language Class Initialized
ERROR - 2021-04-16 17:05:33 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:05:33 --> Config Class Initialized
INFO - 2021-04-16 17:05:33 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:05:33 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:05:33 --> Utf8 Class Initialized
INFO - 2021-04-16 17:05:33 --> URI Class Initialized
INFO - 2021-04-16 17:05:33 --> Router Class Initialized
INFO - 2021-04-16 17:05:33 --> Output Class Initialized
INFO - 2021-04-16 17:05:33 --> Security Class Initialized
DEBUG - 2021-04-16 17:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:05:33 --> Input Class Initialized
INFO - 2021-04-16 17:05:33 --> Language Class Initialized
ERROR - 2021-04-16 17:05:33 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:05:33 --> Config Class Initialized
INFO - 2021-04-16 17:05:33 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:05:33 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:05:33 --> Utf8 Class Initialized
INFO - 2021-04-16 17:05:33 --> URI Class Initialized
INFO - 2021-04-16 17:05:33 --> Router Class Initialized
INFO - 2021-04-16 17:05:33 --> Output Class Initialized
INFO - 2021-04-16 17:05:33 --> Security Class Initialized
DEBUG - 2021-04-16 17:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:05:33 --> Input Class Initialized
INFO - 2021-04-16 17:05:33 --> Language Class Initialized
ERROR - 2021-04-16 17:05:33 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:05:33 --> Config Class Initialized
INFO - 2021-04-16 17:05:33 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:05:34 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:05:34 --> Utf8 Class Initialized
INFO - 2021-04-16 17:05:34 --> URI Class Initialized
INFO - 2021-04-16 17:05:34 --> Router Class Initialized
INFO - 2021-04-16 17:05:34 --> Output Class Initialized
INFO - 2021-04-16 17:05:34 --> Security Class Initialized
DEBUG - 2021-04-16 17:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:05:34 --> Input Class Initialized
INFO - 2021-04-16 17:05:34 --> Language Class Initialized
ERROR - 2021-04-16 17:05:34 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:05:34 --> Config Class Initialized
INFO - 2021-04-16 17:05:34 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:05:34 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:05:34 --> Utf8 Class Initialized
INFO - 2021-04-16 17:05:34 --> URI Class Initialized
INFO - 2021-04-16 17:05:34 --> Router Class Initialized
INFO - 2021-04-16 17:05:34 --> Output Class Initialized
INFO - 2021-04-16 17:05:34 --> Security Class Initialized
DEBUG - 2021-04-16 17:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:05:34 --> Input Class Initialized
INFO - 2021-04-16 17:05:34 --> Language Class Initialized
ERROR - 2021-04-16 17:05:34 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:05:34 --> Config Class Initialized
INFO - 2021-04-16 17:05:34 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:05:34 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:05:34 --> Utf8 Class Initialized
INFO - 2021-04-16 17:05:34 --> URI Class Initialized
INFO - 2021-04-16 17:05:34 --> Router Class Initialized
INFO - 2021-04-16 17:05:34 --> Output Class Initialized
INFO - 2021-04-16 17:05:34 --> Security Class Initialized
DEBUG - 2021-04-16 17:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:05:34 --> Input Class Initialized
INFO - 2021-04-16 17:05:34 --> Language Class Initialized
ERROR - 2021-04-16 17:05:34 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:05:34 --> Config Class Initialized
INFO - 2021-04-16 17:05:34 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:05:34 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:05:34 --> Utf8 Class Initialized
INFO - 2021-04-16 17:05:34 --> URI Class Initialized
INFO - 2021-04-16 17:05:34 --> Router Class Initialized
INFO - 2021-04-16 17:05:34 --> Output Class Initialized
INFO - 2021-04-16 17:05:34 --> Security Class Initialized
DEBUG - 2021-04-16 17:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:05:34 --> Input Class Initialized
INFO - 2021-04-16 17:05:34 --> Language Class Initialized
ERROR - 2021-04-16 17:05:34 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:05:34 --> Config Class Initialized
INFO - 2021-04-16 17:05:34 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:05:34 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:05:34 --> Utf8 Class Initialized
INFO - 2021-04-16 17:05:34 --> URI Class Initialized
INFO - 2021-04-16 17:05:34 --> Router Class Initialized
INFO - 2021-04-16 17:05:34 --> Output Class Initialized
INFO - 2021-04-16 17:05:34 --> Security Class Initialized
DEBUG - 2021-04-16 17:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:05:34 --> Input Class Initialized
INFO - 2021-04-16 17:05:34 --> Language Class Initialized
ERROR - 2021-04-16 17:05:34 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:05:34 --> Config Class Initialized
INFO - 2021-04-16 17:05:34 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:05:34 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:05:34 --> Utf8 Class Initialized
INFO - 2021-04-16 17:05:34 --> URI Class Initialized
INFO - 2021-04-16 17:05:34 --> Router Class Initialized
INFO - 2021-04-16 17:05:34 --> Output Class Initialized
INFO - 2021-04-16 17:05:34 --> Security Class Initialized
DEBUG - 2021-04-16 17:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:05:34 --> Input Class Initialized
INFO - 2021-04-16 17:05:34 --> Language Class Initialized
ERROR - 2021-04-16 17:05:34 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:05:34 --> Config Class Initialized
INFO - 2021-04-16 17:05:34 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:05:34 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:05:34 --> Utf8 Class Initialized
INFO - 2021-04-16 17:05:34 --> URI Class Initialized
INFO - 2021-04-16 17:05:34 --> Router Class Initialized
INFO - 2021-04-16 17:05:34 --> Output Class Initialized
INFO - 2021-04-16 17:05:34 --> Security Class Initialized
DEBUG - 2021-04-16 17:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:05:34 --> Input Class Initialized
INFO - 2021-04-16 17:05:34 --> Language Class Initialized
ERROR - 2021-04-16 17:05:34 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:05:34 --> Config Class Initialized
INFO - 2021-04-16 17:05:34 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:05:34 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:05:34 --> Utf8 Class Initialized
INFO - 2021-04-16 17:05:34 --> URI Class Initialized
INFO - 2021-04-16 17:05:34 --> Router Class Initialized
INFO - 2021-04-16 17:05:34 --> Output Class Initialized
INFO - 2021-04-16 17:05:34 --> Security Class Initialized
DEBUG - 2021-04-16 17:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:05:34 --> Input Class Initialized
INFO - 2021-04-16 17:05:34 --> Language Class Initialized
ERROR - 2021-04-16 17:05:34 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:05:34 --> Config Class Initialized
INFO - 2021-04-16 17:05:34 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:05:34 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:05:34 --> Utf8 Class Initialized
INFO - 2021-04-16 17:05:34 --> URI Class Initialized
INFO - 2021-04-16 17:05:34 --> Router Class Initialized
INFO - 2021-04-16 17:05:34 --> Output Class Initialized
INFO - 2021-04-16 17:05:34 --> Security Class Initialized
DEBUG - 2021-04-16 17:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:05:34 --> Input Class Initialized
INFO - 2021-04-16 17:05:34 --> Language Class Initialized
ERROR - 2021-04-16 17:05:34 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:05:34 --> Config Class Initialized
INFO - 2021-04-16 17:05:34 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:05:34 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:05:34 --> Utf8 Class Initialized
INFO - 2021-04-16 17:05:34 --> URI Class Initialized
INFO - 2021-04-16 17:05:34 --> Router Class Initialized
INFO - 2021-04-16 17:05:34 --> Output Class Initialized
INFO - 2021-04-16 17:05:34 --> Security Class Initialized
DEBUG - 2021-04-16 17:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:05:34 --> Input Class Initialized
INFO - 2021-04-16 17:05:34 --> Language Class Initialized
ERROR - 2021-04-16 17:05:34 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:05:34 --> Config Class Initialized
INFO - 2021-04-16 17:05:34 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:05:34 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:05:34 --> Utf8 Class Initialized
INFO - 2021-04-16 17:05:34 --> URI Class Initialized
INFO - 2021-04-16 17:05:34 --> Router Class Initialized
INFO - 2021-04-16 17:05:34 --> Output Class Initialized
INFO - 2021-04-16 17:05:34 --> Security Class Initialized
DEBUG - 2021-04-16 17:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:05:34 --> Input Class Initialized
INFO - 2021-04-16 17:05:34 --> Language Class Initialized
ERROR - 2021-04-16 17:05:34 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:06:36 --> Config Class Initialized
INFO - 2021-04-16 17:06:36 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:06:36 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:06:36 --> Utf8 Class Initialized
INFO - 2021-04-16 17:06:36 --> URI Class Initialized
INFO - 2021-04-16 17:06:36 --> Router Class Initialized
INFO - 2021-04-16 17:06:36 --> Output Class Initialized
INFO - 2021-04-16 17:06:36 --> Security Class Initialized
DEBUG - 2021-04-16 17:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:06:36 --> Input Class Initialized
INFO - 2021-04-16 17:06:36 --> Language Class Initialized
INFO - 2021-04-16 17:06:36 --> Loader Class Initialized
INFO - 2021-04-16 17:06:36 --> Helper loaded: url_helper
INFO - 2021-04-16 17:06:36 --> Helper loaded: form_helper
INFO - 2021-04-16 17:06:36 --> Helper loaded: common_helper
INFO - 2021-04-16 17:06:36 --> Helper loaded: util_helper
INFO - 2021-04-16 17:06:36 --> Helper loaded: user_helper
INFO - 2021-04-16 17:06:36 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:06:37 --> Form Validation Class Initialized
INFO - 2021-04-16 17:06:37 --> Model Class Initialized
INFO - 2021-04-16 17:06:37 --> Controller Class Initialized
INFO - 2021-04-16 17:06:37 --> Model Class Initialized
INFO - 2021-04-16 17:06:37 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 17:06:37 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 17:06:37 --> Final output sent to browser
DEBUG - 2021-04-16 17:06:37 --> Total execution time: 0.0299
INFO - 2021-04-16 17:06:37 --> Config Class Initialized
INFO - 2021-04-16 17:06:37 --> Hooks Class Initialized
INFO - 2021-04-16 17:06:37 --> Config Class Initialized
INFO - 2021-04-16 17:06:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:06:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:06:37 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:06:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:06:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:06:37 --> URI Class Initialized
INFO - 2021-04-16 17:06:37 --> URI Class Initialized
INFO - 2021-04-16 17:06:37 --> Router Class Initialized
INFO - 2021-04-16 17:06:37 --> Router Class Initialized
INFO - 2021-04-16 17:06:37 --> Output Class Initialized
INFO - 2021-04-16 17:06:37 --> Output Class Initialized
INFO - 2021-04-16 17:06:37 --> Security Class Initialized
INFO - 2021-04-16 17:06:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:06:37 --> Input Class Initialized
DEBUG - 2021-04-16 17:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:06:37 --> Language Class Initialized
INFO - 2021-04-16 17:06:37 --> Input Class Initialized
INFO - 2021-04-16 17:06:37 --> Language Class Initialized
ERROR - 2021-04-16 17:06:37 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-16 17:06:37 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:06:37 --> Config Class Initialized
INFO - 2021-04-16 17:06:37 --> Hooks Class Initialized
INFO - 2021-04-16 17:06:37 --> Config Class Initialized
INFO - 2021-04-16 17:06:37 --> Hooks Class Initialized
INFO - 2021-04-16 17:06:37 --> Config Class Initialized
INFO - 2021-04-16 17:06:37 --> Hooks Class Initialized
INFO - 2021-04-16 17:06:37 --> Config Class Initialized
INFO - 2021-04-16 17:06:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:06:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:06:37 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:06:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:06:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:06:37 --> URI Class Initialized
DEBUG - 2021-04-16 17:06:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:06:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:06:37 --> URI Class Initialized
INFO - 2021-04-16 17:06:37 --> URI Class Initialized
INFO - 2021-04-16 17:06:37 --> Router Class Initialized
INFO - 2021-04-16 17:06:37 --> Router Class Initialized
INFO - 2021-04-16 17:06:37 --> Output Class Initialized
INFO - 2021-04-16 17:06:37 --> Security Class Initialized
INFO - 2021-04-16 17:06:37 --> Output Class Initialized
INFO - 2021-04-16 17:06:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:06:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:06:37 --> Input Class Initialized
INFO - 2021-04-16 17:06:37 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:06:37 --> Language Class Initialized
INFO - 2021-04-16 17:06:37 --> Input Class Initialized
INFO - 2021-04-16 17:06:37 --> Language Class Initialized
INFO - 2021-04-16 17:06:37 --> URI Class Initialized
INFO - 2021-04-16 17:06:37 --> Router Class Initialized
ERROR - 2021-04-16 17:06:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:06:37 --> Router Class Initialized
INFO - 2021-04-16 17:06:37 --> Config Class Initialized
INFO - 2021-04-16 17:06:37 --> Hooks Class Initialized
INFO - 2021-04-16 17:06:37 --> Output Class Initialized
ERROR - 2021-04-16 17:06:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:06:37 --> Output Class Initialized
INFO - 2021-04-16 17:06:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:06:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:06:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:06:37 --> Config Class Initialized
DEBUG - 2021-04-16 17:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:06:37 --> Input Class Initialized
INFO - 2021-04-16 17:06:37 --> Security Class Initialized
INFO - 2021-04-16 17:06:37 --> URI Class Initialized
INFO - 2021-04-16 17:06:37 --> Hooks Class Initialized
INFO - 2021-04-16 17:06:37 --> Language Class Initialized
DEBUG - 2021-04-16 17:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:06:37 --> Input Class Initialized
INFO - 2021-04-16 17:06:37 --> Router Class Initialized
INFO - 2021-04-16 17:06:37 --> Language Class Initialized
ERROR - 2021-04-16 17:06:37 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-16 17:06:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:06:37 --> Output Class Initialized
INFO - 2021-04-16 17:06:37 --> Utf8 Class Initialized
ERROR - 2021-04-16 17:06:37 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:06:37 --> URI Class Initialized
INFO - 2021-04-16 17:06:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:06:37 --> Router Class Initialized
INFO - 2021-04-16 17:06:37 --> Input Class Initialized
INFO - 2021-04-16 17:06:37 --> Language Class Initialized
INFO - 2021-04-16 17:06:37 --> Output Class Initialized
ERROR - 2021-04-16 17:06:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:06:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:06:37 --> Input Class Initialized
INFO - 2021-04-16 17:06:37 --> Language Class Initialized
INFO - 2021-04-16 17:06:37 --> Config Class Initialized
INFO - 2021-04-16 17:06:37 --> Hooks Class Initialized
ERROR - 2021-04-16 17:06:37 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-16 17:06:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:06:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:06:37 --> URI Class Initialized
INFO - 2021-04-16 17:06:37 --> Router Class Initialized
INFO - 2021-04-16 17:06:37 --> Output Class Initialized
INFO - 2021-04-16 17:06:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:06:37 --> Input Class Initialized
INFO - 2021-04-16 17:06:37 --> Language Class Initialized
ERROR - 2021-04-16 17:06:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:06:37 --> Config Class Initialized
INFO - 2021-04-16 17:06:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:06:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:06:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:06:37 --> URI Class Initialized
INFO - 2021-04-16 17:06:37 --> Router Class Initialized
INFO - 2021-04-16 17:06:37 --> Output Class Initialized
INFO - 2021-04-16 17:06:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:06:37 --> Input Class Initialized
INFO - 2021-04-16 17:06:37 --> Language Class Initialized
ERROR - 2021-04-16 17:06:37 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:06:37 --> Config Class Initialized
INFO - 2021-04-16 17:06:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:06:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:06:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:06:37 --> URI Class Initialized
INFO - 2021-04-16 17:06:37 --> Router Class Initialized
INFO - 2021-04-16 17:06:37 --> Output Class Initialized
INFO - 2021-04-16 17:06:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:06:37 --> Input Class Initialized
INFO - 2021-04-16 17:06:37 --> Language Class Initialized
ERROR - 2021-04-16 17:06:37 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:06:37 --> Config Class Initialized
INFO - 2021-04-16 17:06:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:06:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:06:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:06:37 --> URI Class Initialized
INFO - 2021-04-16 17:06:37 --> Router Class Initialized
INFO - 2021-04-16 17:06:37 --> Output Class Initialized
INFO - 2021-04-16 17:06:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:06:37 --> Input Class Initialized
INFO - 2021-04-16 17:06:37 --> Language Class Initialized
ERROR - 2021-04-16 17:06:37 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:06:37 --> Config Class Initialized
INFO - 2021-04-16 17:06:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:06:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:06:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:06:37 --> URI Class Initialized
INFO - 2021-04-16 17:06:37 --> Router Class Initialized
INFO - 2021-04-16 17:06:37 --> Output Class Initialized
INFO - 2021-04-16 17:06:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:06:37 --> Input Class Initialized
INFO - 2021-04-16 17:06:37 --> Language Class Initialized
ERROR - 2021-04-16 17:06:37 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:06:37 --> Config Class Initialized
INFO - 2021-04-16 17:06:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:06:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:06:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:06:37 --> URI Class Initialized
INFO - 2021-04-16 17:06:37 --> Router Class Initialized
INFO - 2021-04-16 17:06:37 --> Output Class Initialized
INFO - 2021-04-16 17:06:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:06:37 --> Input Class Initialized
INFO - 2021-04-16 17:06:37 --> Language Class Initialized
ERROR - 2021-04-16 17:06:37 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:06:37 --> Config Class Initialized
INFO - 2021-04-16 17:06:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:06:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:06:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:06:37 --> URI Class Initialized
INFO - 2021-04-16 17:06:37 --> Router Class Initialized
INFO - 2021-04-16 17:06:37 --> Output Class Initialized
INFO - 2021-04-16 17:06:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:06:37 --> Input Class Initialized
INFO - 2021-04-16 17:06:37 --> Language Class Initialized
ERROR - 2021-04-16 17:06:37 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:06:37 --> Config Class Initialized
INFO - 2021-04-16 17:06:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:06:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:06:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:06:37 --> URI Class Initialized
INFO - 2021-04-16 17:06:37 --> Router Class Initialized
INFO - 2021-04-16 17:06:37 --> Output Class Initialized
INFO - 2021-04-16 17:06:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:06:37 --> Input Class Initialized
INFO - 2021-04-16 17:06:37 --> Language Class Initialized
ERROR - 2021-04-16 17:06:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:06:37 --> Config Class Initialized
INFO - 2021-04-16 17:06:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:06:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:06:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:06:37 --> URI Class Initialized
INFO - 2021-04-16 17:06:37 --> Router Class Initialized
INFO - 2021-04-16 17:06:37 --> Output Class Initialized
INFO - 2021-04-16 17:06:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:06:37 --> Input Class Initialized
INFO - 2021-04-16 17:06:37 --> Language Class Initialized
ERROR - 2021-04-16 17:06:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:06:37 --> Config Class Initialized
INFO - 2021-04-16 17:06:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:06:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:06:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:06:37 --> URI Class Initialized
INFO - 2021-04-16 17:06:37 --> Router Class Initialized
INFO - 2021-04-16 17:06:37 --> Output Class Initialized
INFO - 2021-04-16 17:06:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:06:37 --> Input Class Initialized
INFO - 2021-04-16 17:06:37 --> Language Class Initialized
ERROR - 2021-04-16 17:06:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:06:37 --> Config Class Initialized
INFO - 2021-04-16 17:06:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:06:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:06:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:06:37 --> URI Class Initialized
INFO - 2021-04-16 17:06:37 --> Router Class Initialized
INFO - 2021-04-16 17:06:37 --> Output Class Initialized
INFO - 2021-04-16 17:06:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:06:37 --> Input Class Initialized
INFO - 2021-04-16 17:06:37 --> Language Class Initialized
ERROR - 2021-04-16 17:06:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:06:37 --> Config Class Initialized
INFO - 2021-04-16 17:06:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:06:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:06:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:06:37 --> URI Class Initialized
INFO - 2021-04-16 17:06:37 --> Router Class Initialized
INFO - 2021-04-16 17:06:37 --> Output Class Initialized
INFO - 2021-04-16 17:06:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:06:37 --> Input Class Initialized
INFO - 2021-04-16 17:06:37 --> Language Class Initialized
ERROR - 2021-04-16 17:06:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:06:37 --> Config Class Initialized
INFO - 2021-04-16 17:06:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:06:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:06:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:06:37 --> URI Class Initialized
INFO - 2021-04-16 17:06:37 --> Router Class Initialized
INFO - 2021-04-16 17:06:37 --> Output Class Initialized
INFO - 2021-04-16 17:06:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:06:37 --> Input Class Initialized
INFO - 2021-04-16 17:06:37 --> Language Class Initialized
ERROR - 2021-04-16 17:06:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:06:37 --> Config Class Initialized
INFO - 2021-04-16 17:06:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:06:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:06:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:06:37 --> URI Class Initialized
INFO - 2021-04-16 17:06:37 --> Router Class Initialized
INFO - 2021-04-16 17:06:37 --> Output Class Initialized
INFO - 2021-04-16 17:06:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:06:37 --> Input Class Initialized
INFO - 2021-04-16 17:06:37 --> Language Class Initialized
ERROR - 2021-04-16 17:06:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:06:37 --> Config Class Initialized
INFO - 2021-04-16 17:06:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:06:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:06:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:06:37 --> URI Class Initialized
INFO - 2021-04-16 17:06:37 --> Router Class Initialized
INFO - 2021-04-16 17:06:37 --> Output Class Initialized
INFO - 2021-04-16 17:06:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:06:37 --> Input Class Initialized
INFO - 2021-04-16 17:06:37 --> Language Class Initialized
ERROR - 2021-04-16 17:06:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:07:37 --> Config Class Initialized
INFO - 2021-04-16 17:07:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:07:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:07:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:07:37 --> URI Class Initialized
INFO - 2021-04-16 17:07:37 --> Router Class Initialized
INFO - 2021-04-16 17:07:37 --> Output Class Initialized
INFO - 2021-04-16 17:07:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:07:37 --> Input Class Initialized
INFO - 2021-04-16 17:07:37 --> Language Class Initialized
INFO - 2021-04-16 17:07:37 --> Loader Class Initialized
INFO - 2021-04-16 17:07:37 --> Helper loaded: url_helper
INFO - 2021-04-16 17:07:37 --> Helper loaded: form_helper
INFO - 2021-04-16 17:07:37 --> Helper loaded: common_helper
INFO - 2021-04-16 17:07:37 --> Helper loaded: util_helper
INFO - 2021-04-16 17:07:37 --> Helper loaded: user_helper
INFO - 2021-04-16 17:07:37 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:07:37 --> Form Validation Class Initialized
INFO - 2021-04-16 17:07:37 --> Model Class Initialized
INFO - 2021-04-16 17:07:37 --> Controller Class Initialized
INFO - 2021-04-16 17:07:37 --> Model Class Initialized
INFO - 2021-04-16 17:07:37 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 17:07:37 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 17:07:37 --> Final output sent to browser
DEBUG - 2021-04-16 17:07:37 --> Total execution time: 0.0295
INFO - 2021-04-16 17:07:37 --> Config Class Initialized
INFO - 2021-04-16 17:07:37 --> Hooks Class Initialized
INFO - 2021-04-16 17:07:37 --> Config Class Initialized
INFO - 2021-04-16 17:07:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:07:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:07:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:07:37 --> URI Class Initialized
DEBUG - 2021-04-16 17:07:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:07:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:07:37 --> Router Class Initialized
INFO - 2021-04-16 17:07:37 --> URI Class Initialized
INFO - 2021-04-16 17:07:37 --> Output Class Initialized
INFO - 2021-04-16 17:07:37 --> Router Class Initialized
INFO - 2021-04-16 17:07:37 --> Security Class Initialized
INFO - 2021-04-16 17:07:37 --> Output Class Initialized
DEBUG - 2021-04-16 17:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:07:37 --> Input Class Initialized
INFO - 2021-04-16 17:07:37 --> Security Class Initialized
INFO - 2021-04-16 17:07:37 --> Language Class Initialized
DEBUG - 2021-04-16 17:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:07:37 --> Input Class Initialized
ERROR - 2021-04-16 17:07:37 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:07:37 --> Language Class Initialized
ERROR - 2021-04-16 17:07:37 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:07:37 --> Config Class Initialized
INFO - 2021-04-16 17:07:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:07:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:07:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:07:37 --> URI Class Initialized
INFO - 2021-04-16 17:07:37 --> Router Class Initialized
INFO - 2021-04-16 17:07:37 --> Config Class Initialized
INFO - 2021-04-16 17:07:37 --> Output Class Initialized
INFO - 2021-04-16 17:07:37 --> Hooks Class Initialized
INFO - 2021-04-16 17:07:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:07:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:07:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:07:37 --> Config Class Initialized
INFO - 2021-04-16 17:07:37 --> URI Class Initialized
DEBUG - 2021-04-16 17:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:07:37 --> Hooks Class Initialized
INFO - 2021-04-16 17:07:37 --> Input Class Initialized
INFO - 2021-04-16 17:07:37 --> Config Class Initialized
INFO - 2021-04-16 17:07:37 --> Language Class Initialized
INFO - 2021-04-16 17:07:37 --> Router Class Initialized
DEBUG - 2021-04-16 17:07:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:07:37 --> Utf8 Class Initialized
ERROR - 2021-04-16 17:07:37 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:07:37 --> Output Class Initialized
INFO - 2021-04-16 17:07:37 --> URI Class Initialized
INFO - 2021-04-16 17:07:37 --> Router Class Initialized
INFO - 2021-04-16 17:07:37 --> Security Class Initialized
INFO - 2021-04-16 17:07:37 --> Output Class Initialized
DEBUG - 2021-04-16 17:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:07:37 --> Security Class Initialized
INFO - 2021-04-16 17:07:37 --> Input Class Initialized
INFO - 2021-04-16 17:07:37 --> Language Class Initialized
DEBUG - 2021-04-16 17:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:07:37 --> Input Class Initialized
INFO - 2021-04-16 17:07:37 --> Language Class Initialized
INFO - 2021-04-16 17:07:37 --> Hooks Class Initialized
ERROR - 2021-04-16 17:07:37 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-16 17:07:37 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:07:37 --> Config Class Initialized
INFO - 2021-04-16 17:07:37 --> Config Class Initialized
INFO - 2021-04-16 17:07:37 --> Hooks Class Initialized
INFO - 2021-04-16 17:07:37 --> Config Class Initialized
INFO - 2021-04-16 17:07:37 --> Hooks Class Initialized
INFO - 2021-04-16 17:07:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:07:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:07:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:07:37 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:07:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:07:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:07:37 --> URI Class Initialized
INFO - 2021-04-16 17:07:37 --> URI Class Initialized
INFO - 2021-04-16 17:07:37 --> URI Class Initialized
INFO - 2021-04-16 17:07:37 --> Router Class Initialized
INFO - 2021-04-16 17:07:37 --> Router Class Initialized
INFO - 2021-04-16 17:07:37 --> Router Class Initialized
INFO - 2021-04-16 17:07:37 --> Output Class Initialized
INFO - 2021-04-16 17:07:37 --> Output Class Initialized
INFO - 2021-04-16 17:07:37 --> Security Class Initialized
INFO - 2021-04-16 17:07:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:07:37 --> Input Class Initialized
DEBUG - 2021-04-16 17:07:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:07:37 --> Output Class Initialized
INFO - 2021-04-16 17:07:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:07:37 --> Language Class Initialized
DEBUG - 2021-04-16 17:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:07:37 --> Input Class Initialized
INFO - 2021-04-16 17:07:37 --> URI Class Initialized
INFO - 2021-04-16 17:07:37 --> Config Class Initialized
INFO - 2021-04-16 17:07:37 --> Language Class Initialized
INFO - 2021-04-16 17:07:37 --> Security Class Initialized
INFO - 2021-04-16 17:07:37 --> Hooks Class Initialized
ERROR - 2021-04-16 17:07:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:07:37 --> Router Class Initialized
DEBUG - 2021-04-16 17:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:07:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:07:37 --> Input Class Initialized
DEBUG - 2021-04-16 17:07:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:07:37 --> Language Class Initialized
INFO - 2021-04-16 17:07:37 --> Output Class Initialized
INFO - 2021-04-16 17:07:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:07:37 --> URI Class Initialized
INFO - 2021-04-16 17:07:37 --> Security Class Initialized
ERROR - 2021-04-16 17:07:37 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:07:37 --> Router Class Initialized
DEBUG - 2021-04-16 17:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:07:37 --> Input Class Initialized
INFO - 2021-04-16 17:07:37 --> Language Class Initialized
INFO - 2021-04-16 17:07:37 --> Output Class Initialized
ERROR - 2021-04-16 17:07:37 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:07:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:07:37 --> Input Class Initialized
INFO - 2021-04-16 17:07:37 --> Language Class Initialized
ERROR - 2021-04-16 17:07:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:07:37 --> Config Class Initialized
INFO - 2021-04-16 17:07:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:07:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:07:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:07:37 --> URI Class Initialized
INFO - 2021-04-16 17:07:37 --> Router Class Initialized
INFO - 2021-04-16 17:07:37 --> Output Class Initialized
INFO - 2021-04-16 17:07:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:07:37 --> Input Class Initialized
INFO - 2021-04-16 17:07:37 --> Language Class Initialized
ERROR - 2021-04-16 17:07:37 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:07:37 --> Config Class Initialized
INFO - 2021-04-16 17:07:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:07:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:07:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:07:37 --> URI Class Initialized
INFO - 2021-04-16 17:07:37 --> Router Class Initialized
INFO - 2021-04-16 17:07:37 --> Output Class Initialized
INFO - 2021-04-16 17:07:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:07:37 --> Input Class Initialized
INFO - 2021-04-16 17:07:37 --> Language Class Initialized
ERROR - 2021-04-16 17:07:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:07:37 --> Config Class Initialized
INFO - 2021-04-16 17:07:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:07:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:07:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:07:37 --> URI Class Initialized
INFO - 2021-04-16 17:07:37 --> Router Class Initialized
INFO - 2021-04-16 17:07:37 --> Output Class Initialized
INFO - 2021-04-16 17:07:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:07:37 --> Input Class Initialized
INFO - 2021-04-16 17:07:37 --> Language Class Initialized
ERROR - 2021-04-16 17:07:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:07:37 --> Config Class Initialized
INFO - 2021-04-16 17:07:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:07:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:07:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:07:37 --> URI Class Initialized
INFO - 2021-04-16 17:07:37 --> Router Class Initialized
INFO - 2021-04-16 17:07:37 --> Output Class Initialized
INFO - 2021-04-16 17:07:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:07:37 --> Input Class Initialized
INFO - 2021-04-16 17:07:37 --> Language Class Initialized
ERROR - 2021-04-16 17:07:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:07:37 --> Config Class Initialized
INFO - 2021-04-16 17:07:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:07:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:07:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:07:37 --> URI Class Initialized
INFO - 2021-04-16 17:07:37 --> Router Class Initialized
INFO - 2021-04-16 17:07:37 --> Output Class Initialized
INFO - 2021-04-16 17:07:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:07:37 --> Input Class Initialized
INFO - 2021-04-16 17:07:37 --> Language Class Initialized
ERROR - 2021-04-16 17:07:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:07:37 --> Config Class Initialized
INFO - 2021-04-16 17:07:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:07:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:07:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:07:37 --> URI Class Initialized
INFO - 2021-04-16 17:07:37 --> Router Class Initialized
INFO - 2021-04-16 17:07:37 --> Output Class Initialized
INFO - 2021-04-16 17:07:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:07:37 --> Input Class Initialized
INFO - 2021-04-16 17:07:37 --> Language Class Initialized
ERROR - 2021-04-16 17:07:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:07:37 --> Config Class Initialized
INFO - 2021-04-16 17:07:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:07:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:07:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:07:37 --> URI Class Initialized
INFO - 2021-04-16 17:07:37 --> Router Class Initialized
INFO - 2021-04-16 17:07:37 --> Output Class Initialized
INFO - 2021-04-16 17:07:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:07:37 --> Input Class Initialized
INFO - 2021-04-16 17:07:37 --> Language Class Initialized
ERROR - 2021-04-16 17:07:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:07:37 --> Config Class Initialized
INFO - 2021-04-16 17:07:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:07:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:07:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:07:37 --> URI Class Initialized
INFO - 2021-04-16 17:07:37 --> Router Class Initialized
INFO - 2021-04-16 17:07:37 --> Output Class Initialized
INFO - 2021-04-16 17:07:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:07:37 --> Input Class Initialized
INFO - 2021-04-16 17:07:37 --> Language Class Initialized
ERROR - 2021-04-16 17:07:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:07:37 --> Config Class Initialized
INFO - 2021-04-16 17:07:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:07:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:07:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:07:37 --> URI Class Initialized
INFO - 2021-04-16 17:07:37 --> Router Class Initialized
INFO - 2021-04-16 17:07:37 --> Output Class Initialized
INFO - 2021-04-16 17:07:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:07:37 --> Input Class Initialized
INFO - 2021-04-16 17:07:37 --> Language Class Initialized
ERROR - 2021-04-16 17:07:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:08:48 --> Config Class Initialized
INFO - 2021-04-16 17:08:48 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:08:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:08:48 --> Utf8 Class Initialized
INFO - 2021-04-16 17:08:48 --> URI Class Initialized
INFO - 2021-04-16 17:08:48 --> Router Class Initialized
INFO - 2021-04-16 17:08:48 --> Output Class Initialized
INFO - 2021-04-16 17:08:48 --> Security Class Initialized
DEBUG - 2021-04-16 17:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:08:48 --> Input Class Initialized
INFO - 2021-04-16 17:08:48 --> Language Class Initialized
INFO - 2021-04-16 17:08:48 --> Loader Class Initialized
INFO - 2021-04-16 17:08:48 --> Helper loaded: url_helper
INFO - 2021-04-16 17:08:48 --> Helper loaded: form_helper
INFO - 2021-04-16 17:08:48 --> Helper loaded: common_helper
INFO - 2021-04-16 17:08:48 --> Helper loaded: util_helper
INFO - 2021-04-16 17:08:48 --> Helper loaded: user_helper
INFO - 2021-04-16 17:08:48 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:08:48 --> Form Validation Class Initialized
INFO - 2021-04-16 17:08:48 --> Model Class Initialized
INFO - 2021-04-16 17:08:48 --> Controller Class Initialized
INFO - 2021-04-16 17:08:48 --> Model Class Initialized
INFO - 2021-04-16 17:08:48 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 17:08:48 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 17:08:48 --> Final output sent to browser
DEBUG - 2021-04-16 17:08:48 --> Total execution time: 0.0301
INFO - 2021-04-16 17:08:48 --> Config Class Initialized
INFO - 2021-04-16 17:08:48 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:08:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:08:48 --> Utf8 Class Initialized
INFO - 2021-04-16 17:08:48 --> URI Class Initialized
INFO - 2021-04-16 17:08:48 --> Config Class Initialized
INFO - 2021-04-16 17:08:48 --> Router Class Initialized
INFO - 2021-04-16 17:08:48 --> Output Class Initialized
INFO - 2021-04-16 17:08:48 --> Security Class Initialized
DEBUG - 2021-04-16 17:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:08:48 --> Input Class Initialized
INFO - 2021-04-16 17:08:48 --> Language Class Initialized
INFO - 2021-04-16 17:08:48 --> Hooks Class Initialized
ERROR - 2021-04-16 17:08:48 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:08:48 --> Config Class Initialized
INFO - 2021-04-16 17:08:48 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:08:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:08:48 --> Utf8 Class Initialized
INFO - 2021-04-16 17:08:48 --> Config Class Initialized
INFO - 2021-04-16 17:08:48 --> Hooks Class Initialized
INFO - 2021-04-16 17:08:48 --> URI Class Initialized
INFO - 2021-04-16 17:08:48 --> Router Class Initialized
DEBUG - 2021-04-16 17:08:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:08:48 --> Utf8 Class Initialized
INFO - 2021-04-16 17:08:48 --> Output Class Initialized
INFO - 2021-04-16 17:08:48 --> URI Class Initialized
INFO - 2021-04-16 17:08:48 --> Config Class Initialized
INFO - 2021-04-16 17:08:48 --> Hooks Class Initialized
INFO - 2021-04-16 17:08:48 --> Security Class Initialized
INFO - 2021-04-16 17:08:48 --> Router Class Initialized
DEBUG - 2021-04-16 17:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:08:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:08:48 --> Output Class Initialized
INFO - 2021-04-16 17:08:48 --> Utf8 Class Initialized
INFO - 2021-04-16 17:08:48 --> Input Class Initialized
INFO - 2021-04-16 17:08:48 --> URI Class Initialized
INFO - 2021-04-16 17:08:48 --> Security Class Initialized
INFO - 2021-04-16 17:08:48 --> Language Class Initialized
INFO - 2021-04-16 17:08:48 --> Router Class Initialized
DEBUG - 2021-04-16 17:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:08:48 --> Input Class Initialized
ERROR - 2021-04-16 17:08:48 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:08:48 --> Language Class Initialized
INFO - 2021-04-16 17:08:48 --> Output Class Initialized
INFO - 2021-04-16 17:08:48 --> Security Class Initialized
ERROR - 2021-04-16 17:08:48 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:08:48 --> Config Class Initialized
INFO - 2021-04-16 17:08:48 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:08:48 --> Input Class Initialized
DEBUG - 2021-04-16 17:08:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:08:48 --> Language Class Initialized
ERROR - 2021-04-16 17:08:48 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-16 17:08:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:08:48 --> Utf8 Class Initialized
INFO - 2021-04-16 17:08:48 --> Utf8 Class Initialized
INFO - 2021-04-16 17:08:48 --> URI Class Initialized
INFO - 2021-04-16 17:08:48 --> Router Class Initialized
INFO - 2021-04-16 17:08:48 --> URI Class Initialized
INFO - 2021-04-16 17:08:48 --> Config Class Initialized
INFO - 2021-04-16 17:08:48 --> Config Class Initialized
INFO - 2021-04-16 17:08:48 --> Hooks Class Initialized
INFO - 2021-04-16 17:08:48 --> Hooks Class Initialized
INFO - 2021-04-16 17:08:48 --> Output Class Initialized
DEBUG - 2021-04-16 17:08:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:08:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:08:48 --> Router Class Initialized
INFO - 2021-04-16 17:08:48 --> Utf8 Class Initialized
INFO - 2021-04-16 17:08:48 --> Utf8 Class Initialized
INFO - 2021-04-16 17:08:48 --> Config Class Initialized
INFO - 2021-04-16 17:08:48 --> Hooks Class Initialized
INFO - 2021-04-16 17:08:48 --> URI Class Initialized
INFO - 2021-04-16 17:08:48 --> URI Class Initialized
INFO - 2021-04-16 17:08:48 --> Output Class Initialized
INFO - 2021-04-16 17:08:48 --> Router Class Initialized
INFO - 2021-04-16 17:08:48 --> Router Class Initialized
INFO - 2021-04-16 17:08:48 --> Security Class Initialized
DEBUG - 2021-04-16 17:08:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:08:48 --> Utf8 Class Initialized
INFO - 2021-04-16 17:08:48 --> Output Class Initialized
INFO - 2021-04-16 17:08:48 --> Output Class Initialized
DEBUG - 2021-04-16 17:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:08:48 --> Input Class Initialized
INFO - 2021-04-16 17:08:48 --> URI Class Initialized
INFO - 2021-04-16 17:08:48 --> Security Class Initialized
INFO - 2021-04-16 17:08:48 --> Language Class Initialized
INFO - 2021-04-16 17:08:48 --> Router Class Initialized
DEBUG - 2021-04-16 17:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:08:48 --> Input Class Initialized
INFO - 2021-04-16 17:08:48 --> Security Class Initialized
INFO - 2021-04-16 17:08:48 --> Security Class Initialized
ERROR - 2021-04-16 17:08:48 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:08:48 --> Language Class Initialized
INFO - 2021-04-16 17:08:48 --> Output Class Initialized
DEBUG - 2021-04-16 17:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:08:48 --> Input Class Initialized
DEBUG - 2021-04-16 17:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:08:48 --> Input Class Initialized
ERROR - 2021-04-16 17:08:48 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:08:48 --> Language Class Initialized
INFO - 2021-04-16 17:08:48 --> Language Class Initialized
INFO - 2021-04-16 17:08:48 --> Security Class Initialized
ERROR - 2021-04-16 17:08:48 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-16 17:08:48 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-16 17:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:08:48 --> Input Class Initialized
INFO - 2021-04-16 17:08:48 --> Language Class Initialized
ERROR - 2021-04-16 17:08:48 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:08:48 --> Config Class Initialized
INFO - 2021-04-16 17:08:48 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:08:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:08:48 --> Utf8 Class Initialized
INFO - 2021-04-16 17:08:48 --> URI Class Initialized
INFO - 2021-04-16 17:08:48 --> Router Class Initialized
INFO - 2021-04-16 17:08:48 --> Output Class Initialized
INFO - 2021-04-16 17:08:48 --> Security Class Initialized
DEBUG - 2021-04-16 17:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:08:48 --> Input Class Initialized
INFO - 2021-04-16 17:08:48 --> Language Class Initialized
ERROR - 2021-04-16 17:08:48 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:08:48 --> Config Class Initialized
INFO - 2021-04-16 17:08:48 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:08:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:08:48 --> Utf8 Class Initialized
INFO - 2021-04-16 17:08:48 --> URI Class Initialized
INFO - 2021-04-16 17:08:48 --> Router Class Initialized
INFO - 2021-04-16 17:08:48 --> Output Class Initialized
INFO - 2021-04-16 17:08:48 --> Security Class Initialized
DEBUG - 2021-04-16 17:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:08:48 --> Input Class Initialized
INFO - 2021-04-16 17:08:48 --> Language Class Initialized
ERROR - 2021-04-16 17:08:48 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:08:48 --> Config Class Initialized
INFO - 2021-04-16 17:08:48 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:08:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:08:48 --> Utf8 Class Initialized
INFO - 2021-04-16 17:08:48 --> URI Class Initialized
INFO - 2021-04-16 17:08:48 --> Router Class Initialized
INFO - 2021-04-16 17:08:48 --> Output Class Initialized
INFO - 2021-04-16 17:08:48 --> Security Class Initialized
DEBUG - 2021-04-16 17:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:08:48 --> Input Class Initialized
INFO - 2021-04-16 17:08:48 --> Language Class Initialized
ERROR - 2021-04-16 17:08:48 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:08:48 --> Config Class Initialized
INFO - 2021-04-16 17:08:48 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:08:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:08:48 --> Utf8 Class Initialized
INFO - 2021-04-16 17:08:48 --> URI Class Initialized
INFO - 2021-04-16 17:08:48 --> Router Class Initialized
INFO - 2021-04-16 17:08:48 --> Output Class Initialized
INFO - 2021-04-16 17:08:48 --> Security Class Initialized
DEBUG - 2021-04-16 17:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:08:48 --> Input Class Initialized
INFO - 2021-04-16 17:08:48 --> Language Class Initialized
ERROR - 2021-04-16 17:08:48 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:08:48 --> Config Class Initialized
INFO - 2021-04-16 17:08:48 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:08:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:08:48 --> Utf8 Class Initialized
INFO - 2021-04-16 17:08:48 --> URI Class Initialized
INFO - 2021-04-16 17:08:48 --> Router Class Initialized
INFO - 2021-04-16 17:08:48 --> Output Class Initialized
INFO - 2021-04-16 17:08:48 --> Security Class Initialized
DEBUG - 2021-04-16 17:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:08:48 --> Input Class Initialized
INFO - 2021-04-16 17:08:48 --> Language Class Initialized
ERROR - 2021-04-16 17:08:48 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:08:48 --> Config Class Initialized
INFO - 2021-04-16 17:08:48 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:08:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:08:48 --> Utf8 Class Initialized
INFO - 2021-04-16 17:08:48 --> URI Class Initialized
INFO - 2021-04-16 17:08:48 --> Router Class Initialized
INFO - 2021-04-16 17:08:48 --> Output Class Initialized
INFO - 2021-04-16 17:08:48 --> Security Class Initialized
DEBUG - 2021-04-16 17:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:08:48 --> Input Class Initialized
INFO - 2021-04-16 17:08:48 --> Language Class Initialized
ERROR - 2021-04-16 17:08:48 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:08:48 --> Config Class Initialized
INFO - 2021-04-16 17:08:48 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:08:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:08:48 --> Utf8 Class Initialized
INFO - 2021-04-16 17:08:48 --> URI Class Initialized
INFO - 2021-04-16 17:08:48 --> Router Class Initialized
INFO - 2021-04-16 17:08:48 --> Output Class Initialized
INFO - 2021-04-16 17:08:48 --> Security Class Initialized
DEBUG - 2021-04-16 17:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:08:48 --> Input Class Initialized
INFO - 2021-04-16 17:08:48 --> Language Class Initialized
ERROR - 2021-04-16 17:08:48 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:08:48 --> Config Class Initialized
INFO - 2021-04-16 17:08:48 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:08:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:08:48 --> Utf8 Class Initialized
INFO - 2021-04-16 17:08:48 --> URI Class Initialized
INFO - 2021-04-16 17:08:48 --> Router Class Initialized
INFO - 2021-04-16 17:08:48 --> Output Class Initialized
INFO - 2021-04-16 17:08:48 --> Security Class Initialized
DEBUG - 2021-04-16 17:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:08:48 --> Input Class Initialized
INFO - 2021-04-16 17:08:48 --> Language Class Initialized
ERROR - 2021-04-16 17:08:48 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:08:48 --> Config Class Initialized
INFO - 2021-04-16 17:08:48 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:08:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:08:48 --> Utf8 Class Initialized
INFO - 2021-04-16 17:08:48 --> URI Class Initialized
INFO - 2021-04-16 17:08:48 --> Router Class Initialized
INFO - 2021-04-16 17:08:48 --> Output Class Initialized
INFO - 2021-04-16 17:08:48 --> Security Class Initialized
DEBUG - 2021-04-16 17:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:08:48 --> Input Class Initialized
INFO - 2021-04-16 17:08:48 --> Language Class Initialized
ERROR - 2021-04-16 17:08:48 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:08:48 --> Config Class Initialized
INFO - 2021-04-16 17:08:48 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:08:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:08:48 --> Utf8 Class Initialized
INFO - 2021-04-16 17:08:48 --> URI Class Initialized
INFO - 2021-04-16 17:08:48 --> Router Class Initialized
INFO - 2021-04-16 17:08:48 --> Output Class Initialized
INFO - 2021-04-16 17:08:48 --> Security Class Initialized
DEBUG - 2021-04-16 17:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:08:48 --> Input Class Initialized
INFO - 2021-04-16 17:08:48 --> Language Class Initialized
ERROR - 2021-04-16 17:08:48 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:08:48 --> Config Class Initialized
INFO - 2021-04-16 17:08:48 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:08:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:08:48 --> Utf8 Class Initialized
INFO - 2021-04-16 17:08:48 --> URI Class Initialized
INFO - 2021-04-16 17:08:48 --> Router Class Initialized
INFO - 2021-04-16 17:08:48 --> Output Class Initialized
INFO - 2021-04-16 17:08:48 --> Security Class Initialized
DEBUG - 2021-04-16 17:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:08:48 --> Input Class Initialized
INFO - 2021-04-16 17:08:48 --> Language Class Initialized
ERROR - 2021-04-16 17:08:48 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:09:43 --> Config Class Initialized
INFO - 2021-04-16 17:09:43 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:09:43 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:09:43 --> Utf8 Class Initialized
INFO - 2021-04-16 17:09:43 --> URI Class Initialized
INFO - 2021-04-16 17:09:43 --> Router Class Initialized
INFO - 2021-04-16 17:09:43 --> Output Class Initialized
INFO - 2021-04-16 17:09:43 --> Security Class Initialized
DEBUG - 2021-04-16 17:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:09:43 --> Input Class Initialized
INFO - 2021-04-16 17:09:43 --> Language Class Initialized
INFO - 2021-04-16 17:09:43 --> Loader Class Initialized
INFO - 2021-04-16 17:09:43 --> Helper loaded: url_helper
INFO - 2021-04-16 17:09:43 --> Helper loaded: form_helper
INFO - 2021-04-16 17:09:43 --> Helper loaded: common_helper
INFO - 2021-04-16 17:09:43 --> Helper loaded: util_helper
INFO - 2021-04-16 17:09:43 --> Helper loaded: user_helper
INFO - 2021-04-16 17:09:43 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:09:43 --> Form Validation Class Initialized
INFO - 2021-04-16 17:09:43 --> Model Class Initialized
INFO - 2021-04-16 17:09:43 --> Controller Class Initialized
INFO - 2021-04-16 17:09:43 --> Model Class Initialized
INFO - 2021-04-16 17:09:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 17:09:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 17:09:43 --> Final output sent to browser
DEBUG - 2021-04-16 17:09:43 --> Total execution time: 0.0299
INFO - 2021-04-16 17:09:43 --> Config Class Initialized
INFO - 2021-04-16 17:09:43 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:09:43 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:09:43 --> Utf8 Class Initialized
INFO - 2021-04-16 17:09:43 --> URI Class Initialized
INFO - 2021-04-16 17:09:43 --> Config Class Initialized
INFO - 2021-04-16 17:09:43 --> Hooks Class Initialized
INFO - 2021-04-16 17:09:43 --> Router Class Initialized
DEBUG - 2021-04-16 17:09:43 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:09:43 --> Utf8 Class Initialized
INFO - 2021-04-16 17:09:43 --> Output Class Initialized
INFO - 2021-04-16 17:09:43 --> URI Class Initialized
INFO - 2021-04-16 17:09:43 --> Security Class Initialized
INFO - 2021-04-16 17:09:43 --> Router Class Initialized
DEBUG - 2021-04-16 17:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:09:43 --> Input Class Initialized
INFO - 2021-04-16 17:09:43 --> Language Class Initialized
INFO - 2021-04-16 17:09:43 --> Output Class Initialized
INFO - 2021-04-16 17:09:43 --> Security Class Initialized
ERROR - 2021-04-16 17:09:43 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-16 17:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:09:43 --> Input Class Initialized
INFO - 2021-04-16 17:09:43 --> Language Class Initialized
ERROR - 2021-04-16 17:09:43 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:09:43 --> Config Class Initialized
INFO - 2021-04-16 17:09:43 --> Hooks Class Initialized
INFO - 2021-04-16 17:09:43 --> Config Class Initialized
INFO - 2021-04-16 17:09:43 --> Hooks Class Initialized
INFO - 2021-04-16 17:09:43 --> Config Class Initialized
INFO - 2021-04-16 17:09:43 --> Config Class Initialized
INFO - 2021-04-16 17:09:43 --> Hooks Class Initialized
INFO - 2021-04-16 17:09:43 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:09:43 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:09:43 --> Utf8 Class Initialized
INFO - 2021-04-16 17:09:43 --> URI Class Initialized
DEBUG - 2021-04-16 17:09:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:09:43 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:09:43 --> Utf8 Class Initialized
INFO - 2021-04-16 17:09:43 --> Utf8 Class Initialized
INFO - 2021-04-16 17:09:43 --> Router Class Initialized
INFO - 2021-04-16 17:09:43 --> URI Class Initialized
INFO - 2021-04-16 17:09:43 --> URI Class Initialized
INFO - 2021-04-16 17:09:43 --> Config Class Initialized
INFO - 2021-04-16 17:09:43 --> Hooks Class Initialized
INFO - 2021-04-16 17:09:43 --> Router Class Initialized
INFO - 2021-04-16 17:09:43 --> Router Class Initialized
INFO - 2021-04-16 17:09:43 --> Output Class Initialized
INFO - 2021-04-16 17:09:43 --> Output Class Initialized
INFO - 2021-04-16 17:09:43 --> Security Class Initialized
DEBUG - 2021-04-16 17:09:43 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:09:43 --> Output Class Initialized
INFO - 2021-04-16 17:09:43 --> Utf8 Class Initialized
INFO - 2021-04-16 17:09:43 --> Security Class Initialized
DEBUG - 2021-04-16 17:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:09:43 --> URI Class Initialized
DEBUG - 2021-04-16 17:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:09:43 --> Security Class Initialized
INFO - 2021-04-16 17:09:43 --> Input Class Initialized
DEBUG - 2021-04-16 17:09:43 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:09:43 --> Utf8 Class Initialized
INFO - 2021-04-16 17:09:43 --> Language Class Initialized
INFO - 2021-04-16 17:09:43 --> Router Class Initialized
DEBUG - 2021-04-16 17:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:09:43 --> URI Class Initialized
ERROR - 2021-04-16 17:09:43 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:09:43 --> Output Class Initialized
INFO - 2021-04-16 17:09:43 --> Input Class Initialized
INFO - 2021-04-16 17:09:43 --> Router Class Initialized
INFO - 2021-04-16 17:09:43 --> Security Class Initialized
INFO - 2021-04-16 17:09:43 --> Output Class Initialized
DEBUG - 2021-04-16 17:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:09:43 --> Input Class Initialized
INFO - 2021-04-16 17:09:43 --> Security Class Initialized
INFO - 2021-04-16 17:09:43 --> Language Class Initialized
DEBUG - 2021-04-16 17:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:09:43 --> Input Class Initialized
ERROR - 2021-04-16 17:09:43 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:09:43 --> Language Class Initialized
INFO - 2021-04-16 17:09:43 --> Language Class Initialized
INFO - 2021-04-16 17:09:43 --> Input Class Initialized
ERROR - 2021-04-16 17:09:43 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:09:43 --> Language Class Initialized
ERROR - 2021-04-16 17:09:43 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-16 17:09:43 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:09:43 --> Config Class Initialized
INFO - 2021-04-16 17:09:43 --> Config Class Initialized
INFO - 2021-04-16 17:09:43 --> Hooks Class Initialized
INFO - 2021-04-16 17:09:43 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:09:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:09:43 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:09:43 --> Utf8 Class Initialized
INFO - 2021-04-16 17:09:43 --> Utf8 Class Initialized
INFO - 2021-04-16 17:09:43 --> URI Class Initialized
INFO - 2021-04-16 17:09:43 --> URI Class Initialized
INFO - 2021-04-16 17:09:43 --> Router Class Initialized
INFO - 2021-04-16 17:09:43 --> Router Class Initialized
INFO - 2021-04-16 17:09:43 --> Output Class Initialized
INFO - 2021-04-16 17:09:43 --> Output Class Initialized
INFO - 2021-04-16 17:09:43 --> Security Class Initialized
INFO - 2021-04-16 17:09:43 --> Security Class Initialized
DEBUG - 2021-04-16 17:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:09:43 --> Input Class Initialized
INFO - 2021-04-16 17:09:43 --> Language Class Initialized
INFO - 2021-04-16 17:09:43 --> Config Class Initialized
INFO - 2021-04-16 17:09:43 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:09:43 --> Input Class Initialized
ERROR - 2021-04-16 17:09:43 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:09:43 --> Language Class Initialized
DEBUG - 2021-04-16 17:09:43 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:09:43 --> Utf8 Class Initialized
INFO - 2021-04-16 17:09:43 --> URI Class Initialized
ERROR - 2021-04-16 17:09:43 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:09:43 --> Router Class Initialized
INFO - 2021-04-16 17:09:43 --> Output Class Initialized
INFO - 2021-04-16 17:09:43 --> Security Class Initialized
DEBUG - 2021-04-16 17:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:09:43 --> Input Class Initialized
INFO - 2021-04-16 17:09:43 --> Language Class Initialized
ERROR - 2021-04-16 17:09:43 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:09:43 --> Config Class Initialized
INFO - 2021-04-16 17:09:43 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:09:43 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:09:43 --> Utf8 Class Initialized
INFO - 2021-04-16 17:09:43 --> URI Class Initialized
INFO - 2021-04-16 17:09:43 --> Router Class Initialized
INFO - 2021-04-16 17:09:43 --> Output Class Initialized
INFO - 2021-04-16 17:09:43 --> Security Class Initialized
DEBUG - 2021-04-16 17:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:09:43 --> Input Class Initialized
INFO - 2021-04-16 17:09:43 --> Language Class Initialized
ERROR - 2021-04-16 17:09:43 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:09:43 --> Config Class Initialized
INFO - 2021-04-16 17:09:43 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:09:43 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:09:43 --> Utf8 Class Initialized
INFO - 2021-04-16 17:09:43 --> URI Class Initialized
INFO - 2021-04-16 17:09:43 --> Router Class Initialized
INFO - 2021-04-16 17:09:43 --> Output Class Initialized
INFO - 2021-04-16 17:09:43 --> Security Class Initialized
DEBUG - 2021-04-16 17:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:09:43 --> Input Class Initialized
INFO - 2021-04-16 17:09:43 --> Language Class Initialized
ERROR - 2021-04-16 17:09:43 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:09:43 --> Config Class Initialized
INFO - 2021-04-16 17:09:43 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:09:43 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:09:43 --> Utf8 Class Initialized
INFO - 2021-04-16 17:09:43 --> URI Class Initialized
INFO - 2021-04-16 17:09:43 --> Router Class Initialized
INFO - 2021-04-16 17:09:43 --> Output Class Initialized
INFO - 2021-04-16 17:09:43 --> Security Class Initialized
DEBUG - 2021-04-16 17:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:09:43 --> Input Class Initialized
INFO - 2021-04-16 17:09:43 --> Language Class Initialized
ERROR - 2021-04-16 17:09:43 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:09:43 --> Config Class Initialized
INFO - 2021-04-16 17:09:43 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:09:43 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:09:43 --> Utf8 Class Initialized
INFO - 2021-04-16 17:09:43 --> URI Class Initialized
INFO - 2021-04-16 17:09:43 --> Router Class Initialized
INFO - 2021-04-16 17:09:43 --> Output Class Initialized
INFO - 2021-04-16 17:09:43 --> Security Class Initialized
DEBUG - 2021-04-16 17:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:09:43 --> Input Class Initialized
INFO - 2021-04-16 17:09:43 --> Language Class Initialized
ERROR - 2021-04-16 17:09:43 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:09:43 --> Config Class Initialized
INFO - 2021-04-16 17:09:43 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:09:43 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:09:43 --> Utf8 Class Initialized
INFO - 2021-04-16 17:09:43 --> URI Class Initialized
INFO - 2021-04-16 17:09:43 --> Router Class Initialized
INFO - 2021-04-16 17:09:43 --> Output Class Initialized
INFO - 2021-04-16 17:09:43 --> Security Class Initialized
DEBUG - 2021-04-16 17:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:09:43 --> Input Class Initialized
INFO - 2021-04-16 17:09:43 --> Language Class Initialized
ERROR - 2021-04-16 17:09:43 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:09:43 --> Config Class Initialized
INFO - 2021-04-16 17:09:43 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:09:43 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:09:43 --> Utf8 Class Initialized
INFO - 2021-04-16 17:09:43 --> URI Class Initialized
INFO - 2021-04-16 17:09:43 --> Router Class Initialized
INFO - 2021-04-16 17:09:43 --> Output Class Initialized
INFO - 2021-04-16 17:09:43 --> Security Class Initialized
DEBUG - 2021-04-16 17:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:09:43 --> Input Class Initialized
INFO - 2021-04-16 17:09:43 --> Language Class Initialized
ERROR - 2021-04-16 17:09:43 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:09:43 --> Config Class Initialized
INFO - 2021-04-16 17:09:43 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:09:43 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:09:43 --> Utf8 Class Initialized
INFO - 2021-04-16 17:09:43 --> URI Class Initialized
INFO - 2021-04-16 17:09:43 --> Router Class Initialized
INFO - 2021-04-16 17:09:43 --> Output Class Initialized
INFO - 2021-04-16 17:09:43 --> Security Class Initialized
DEBUG - 2021-04-16 17:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:09:43 --> Input Class Initialized
INFO - 2021-04-16 17:09:43 --> Language Class Initialized
ERROR - 2021-04-16 17:09:43 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:09:43 --> Config Class Initialized
INFO - 2021-04-16 17:09:43 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:09:43 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:09:43 --> Utf8 Class Initialized
INFO - 2021-04-16 17:09:43 --> URI Class Initialized
INFO - 2021-04-16 17:09:43 --> Router Class Initialized
INFO - 2021-04-16 17:09:43 --> Output Class Initialized
INFO - 2021-04-16 17:09:43 --> Security Class Initialized
DEBUG - 2021-04-16 17:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:09:43 --> Input Class Initialized
INFO - 2021-04-16 17:09:43 --> Language Class Initialized
ERROR - 2021-04-16 17:09:43 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:09:43 --> Config Class Initialized
INFO - 2021-04-16 17:09:43 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:09:43 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:09:43 --> Utf8 Class Initialized
INFO - 2021-04-16 17:09:43 --> URI Class Initialized
INFO - 2021-04-16 17:09:43 --> Router Class Initialized
INFO - 2021-04-16 17:09:43 --> Output Class Initialized
INFO - 2021-04-16 17:09:43 --> Security Class Initialized
DEBUG - 2021-04-16 17:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:09:43 --> Input Class Initialized
INFO - 2021-04-16 17:09:43 --> Language Class Initialized
ERROR - 2021-04-16 17:09:43 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:10:15 --> Config Class Initialized
INFO - 2021-04-16 17:10:15 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:15 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:15 --> URI Class Initialized
INFO - 2021-04-16 17:10:15 --> Router Class Initialized
INFO - 2021-04-16 17:10:15 --> Output Class Initialized
INFO - 2021-04-16 17:10:15 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:15 --> Input Class Initialized
INFO - 2021-04-16 17:10:15 --> Language Class Initialized
INFO - 2021-04-16 17:10:15 --> Loader Class Initialized
INFO - 2021-04-16 17:10:15 --> Helper loaded: url_helper
INFO - 2021-04-16 17:10:15 --> Helper loaded: form_helper
INFO - 2021-04-16 17:10:15 --> Helper loaded: common_helper
INFO - 2021-04-16 17:10:15 --> Helper loaded: util_helper
INFO - 2021-04-16 17:10:15 --> Helper loaded: user_helper
INFO - 2021-04-16 17:10:15 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:10:15 --> Form Validation Class Initialized
INFO - 2021-04-16 17:10:15 --> Model Class Initialized
INFO - 2021-04-16 17:10:15 --> Controller Class Initialized
INFO - 2021-04-16 17:10:15 --> Model Class Initialized
INFO - 2021-04-16 17:10:15 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 17:10:15 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 17:10:15 --> Final output sent to browser
DEBUG - 2021-04-16 17:10:15 --> Total execution time: 0.0294
INFO - 2021-04-16 17:10:15 --> Config Class Initialized
INFO - 2021-04-16 17:10:15 --> Config Class Initialized
INFO - 2021-04-16 17:10:15 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:15 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:15 --> Hooks Class Initialized
INFO - 2021-04-16 17:10:15 --> URI Class Initialized
INFO - 2021-04-16 17:10:15 --> Config Class Initialized
INFO - 2021-04-16 17:10:15 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:15 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:15 --> Router Class Initialized
INFO - 2021-04-16 17:10:15 --> URI Class Initialized
DEBUG - 2021-04-16 17:10:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:15 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:15 --> URI Class Initialized
INFO - 2021-04-16 17:10:15 --> Config Class Initialized
INFO - 2021-04-16 17:10:15 --> Hooks Class Initialized
INFO - 2021-04-16 17:10:15 --> Output Class Initialized
INFO - 2021-04-16 17:10:15 --> Router Class Initialized
INFO - 2021-04-16 17:10:15 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:15 --> Output Class Initialized
DEBUG - 2021-04-16 17:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:15 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:15 --> Input Class Initialized
INFO - 2021-04-16 17:10:15 --> Security Class Initialized
INFO - 2021-04-16 17:10:15 --> Language Class Initialized
INFO - 2021-04-16 17:10:15 --> URI Class Initialized
DEBUG - 2021-04-16 17:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:15 --> Input Class Initialized
ERROR - 2021-04-16 17:10:15 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:10:15 --> Language Class Initialized
INFO - 2021-04-16 17:10:15 --> Router Class Initialized
ERROR - 2021-04-16 17:10:15 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:10:15 --> Output Class Initialized
INFO - 2021-04-16 17:10:15 --> Security Class Initialized
INFO - 2021-04-16 17:10:15 --> Config Class Initialized
INFO - 2021-04-16 17:10:15 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:15 --> Input Class Initialized
INFO - 2021-04-16 17:10:15 --> Router Class Initialized
INFO - 2021-04-16 17:10:15 --> Language Class Initialized
DEBUG - 2021-04-16 17:10:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:15 --> Utf8 Class Initialized
ERROR - 2021-04-16 17:10:15 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:10:15 --> Config Class Initialized
INFO - 2021-04-16 17:10:15 --> Hooks Class Initialized
INFO - 2021-04-16 17:10:15 --> Config Class Initialized
INFO - 2021-04-16 17:10:15 --> Hooks Class Initialized
INFO - 2021-04-16 17:10:15 --> URI Class Initialized
DEBUG - 2021-04-16 17:10:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:15 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:15 --> URI Class Initialized
DEBUG - 2021-04-16 17:10:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:15 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:15 --> Router Class Initialized
INFO - 2021-04-16 17:10:15 --> URI Class Initialized
INFO - 2021-04-16 17:10:15 --> Router Class Initialized
INFO - 2021-04-16 17:10:15 --> Output Class Initialized
INFO - 2021-04-16 17:10:15 --> Router Class Initialized
INFO - 2021-04-16 17:10:15 --> Output Class Initialized
INFO - 2021-04-16 17:10:16 --> Output Class Initialized
INFO - 2021-04-16 17:10:16 --> Security Class Initialized
INFO - 2021-04-16 17:10:16 --> Output Class Initialized
INFO - 2021-04-16 17:10:16 --> Security Class Initialized
INFO - 2021-04-16 17:10:16 --> Security Class Initialized
INFO - 2021-04-16 17:10:16 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:16 --> Input Class Initialized
DEBUG - 2021-04-16 17:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:16 --> Input Class Initialized
INFO - 2021-04-16 17:10:16 --> Input Class Initialized
DEBUG - 2021-04-16 17:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:16 --> Language Class Initialized
INFO - 2021-04-16 17:10:16 --> Language Class Initialized
INFO - 2021-04-16 17:10:16 --> Input Class Initialized
INFO - 2021-04-16 17:10:16 --> Config Class Initialized
INFO - 2021-04-16 17:10:16 --> Language Class Initialized
INFO - 2021-04-16 17:10:16 --> Hooks Class Initialized
ERROR - 2021-04-16 17:10:16 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-16 17:10:16 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-16 17:10:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:16 --> Utf8 Class Initialized
ERROR - 2021-04-16 17:10:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:10:16 --> URI Class Initialized
INFO - 2021-04-16 17:10:16 --> Router Class Initialized
INFO - 2021-04-16 17:10:16 --> Config Class Initialized
INFO - 2021-04-16 17:10:16 --> Hooks Class Initialized
INFO - 2021-04-16 17:10:16 --> Language Class Initialized
INFO - 2021-04-16 17:10:16 --> Output Class Initialized
INFO - 2021-04-16 17:10:16 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:16 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:16 --> URI Class Initialized
INFO - 2021-04-16 17:10:16 --> Input Class Initialized
ERROR - 2021-04-16 17:10:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:10:16 --> Language Class Initialized
INFO - 2021-04-16 17:10:16 --> Router Class Initialized
INFO - 2021-04-16 17:10:16 --> Output Class Initialized
ERROR - 2021-04-16 17:10:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:10:16 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:16 --> Input Class Initialized
INFO - 2021-04-16 17:10:16 --> Language Class Initialized
INFO - 2021-04-16 17:10:16 --> Config Class Initialized
INFO - 2021-04-16 17:10:16 --> Hooks Class Initialized
ERROR - 2021-04-16 17:10:16 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-16 17:10:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:16 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:16 --> URI Class Initialized
INFO - 2021-04-16 17:10:16 --> Router Class Initialized
INFO - 2021-04-16 17:10:16 --> Output Class Initialized
INFO - 2021-04-16 17:10:16 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:16 --> Input Class Initialized
INFO - 2021-04-16 17:10:16 --> Language Class Initialized
ERROR - 2021-04-16 17:10:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:10:16 --> Config Class Initialized
INFO - 2021-04-16 17:10:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:16 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:16 --> URI Class Initialized
INFO - 2021-04-16 17:10:16 --> Router Class Initialized
INFO - 2021-04-16 17:10:16 --> Output Class Initialized
INFO - 2021-04-16 17:10:16 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:16 --> Input Class Initialized
INFO - 2021-04-16 17:10:16 --> Language Class Initialized
ERROR - 2021-04-16 17:10:16 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:10:16 --> Config Class Initialized
INFO - 2021-04-16 17:10:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:16 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:16 --> URI Class Initialized
INFO - 2021-04-16 17:10:16 --> Router Class Initialized
INFO - 2021-04-16 17:10:16 --> Output Class Initialized
INFO - 2021-04-16 17:10:16 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:16 --> Input Class Initialized
INFO - 2021-04-16 17:10:16 --> Language Class Initialized
ERROR - 2021-04-16 17:10:16 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:10:16 --> Config Class Initialized
INFO - 2021-04-16 17:10:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:16 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:16 --> URI Class Initialized
INFO - 2021-04-16 17:10:16 --> Router Class Initialized
INFO - 2021-04-16 17:10:16 --> Output Class Initialized
INFO - 2021-04-16 17:10:16 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:16 --> Input Class Initialized
INFO - 2021-04-16 17:10:16 --> Language Class Initialized
ERROR - 2021-04-16 17:10:16 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:10:16 --> Config Class Initialized
INFO - 2021-04-16 17:10:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:16 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:16 --> URI Class Initialized
INFO - 2021-04-16 17:10:16 --> Router Class Initialized
INFO - 2021-04-16 17:10:16 --> Output Class Initialized
INFO - 2021-04-16 17:10:16 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:16 --> Input Class Initialized
INFO - 2021-04-16 17:10:16 --> Language Class Initialized
ERROR - 2021-04-16 17:10:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:10:16 --> Config Class Initialized
INFO - 2021-04-16 17:10:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:16 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:16 --> URI Class Initialized
INFO - 2021-04-16 17:10:16 --> Router Class Initialized
INFO - 2021-04-16 17:10:16 --> Output Class Initialized
INFO - 2021-04-16 17:10:16 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:16 --> Input Class Initialized
INFO - 2021-04-16 17:10:16 --> Language Class Initialized
ERROR - 2021-04-16 17:10:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:10:16 --> Config Class Initialized
INFO - 2021-04-16 17:10:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:16 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:16 --> URI Class Initialized
INFO - 2021-04-16 17:10:16 --> Router Class Initialized
INFO - 2021-04-16 17:10:16 --> Output Class Initialized
INFO - 2021-04-16 17:10:16 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:16 --> Input Class Initialized
INFO - 2021-04-16 17:10:16 --> Language Class Initialized
ERROR - 2021-04-16 17:10:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:10:16 --> Config Class Initialized
INFO - 2021-04-16 17:10:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:16 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:16 --> URI Class Initialized
INFO - 2021-04-16 17:10:16 --> Router Class Initialized
INFO - 2021-04-16 17:10:16 --> Output Class Initialized
INFO - 2021-04-16 17:10:16 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:16 --> Input Class Initialized
INFO - 2021-04-16 17:10:16 --> Language Class Initialized
ERROR - 2021-04-16 17:10:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:10:16 --> Config Class Initialized
INFO - 2021-04-16 17:10:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:16 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:16 --> URI Class Initialized
INFO - 2021-04-16 17:10:16 --> Router Class Initialized
INFO - 2021-04-16 17:10:16 --> Output Class Initialized
INFO - 2021-04-16 17:10:16 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:16 --> Input Class Initialized
INFO - 2021-04-16 17:10:16 --> Language Class Initialized
ERROR - 2021-04-16 17:10:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:10:16 --> Config Class Initialized
INFO - 2021-04-16 17:10:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:16 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:16 --> URI Class Initialized
INFO - 2021-04-16 17:10:16 --> Router Class Initialized
INFO - 2021-04-16 17:10:16 --> Output Class Initialized
INFO - 2021-04-16 17:10:16 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:16 --> Input Class Initialized
INFO - 2021-04-16 17:10:16 --> Language Class Initialized
ERROR - 2021-04-16 17:10:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:10:16 --> Config Class Initialized
INFO - 2021-04-16 17:10:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:16 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:16 --> URI Class Initialized
INFO - 2021-04-16 17:10:16 --> Router Class Initialized
INFO - 2021-04-16 17:10:16 --> Output Class Initialized
INFO - 2021-04-16 17:10:16 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:16 --> Input Class Initialized
INFO - 2021-04-16 17:10:16 --> Language Class Initialized
ERROR - 2021-04-16 17:10:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:10:16 --> Config Class Initialized
INFO - 2021-04-16 17:10:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:16 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:16 --> URI Class Initialized
INFO - 2021-04-16 17:10:16 --> Router Class Initialized
INFO - 2021-04-16 17:10:16 --> Output Class Initialized
INFO - 2021-04-16 17:10:16 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:16 --> Input Class Initialized
INFO - 2021-04-16 17:10:16 --> Language Class Initialized
ERROR - 2021-04-16 17:10:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:10:27 --> Config Class Initialized
INFO - 2021-04-16 17:10:27 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:27 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:27 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:27 --> URI Class Initialized
INFO - 2021-04-16 17:10:27 --> Router Class Initialized
INFO - 2021-04-16 17:10:27 --> Output Class Initialized
INFO - 2021-04-16 17:10:27 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:27 --> Input Class Initialized
INFO - 2021-04-16 17:10:27 --> Language Class Initialized
INFO - 2021-04-16 17:10:27 --> Loader Class Initialized
INFO - 2021-04-16 17:10:27 --> Helper loaded: url_helper
INFO - 2021-04-16 17:10:27 --> Helper loaded: form_helper
INFO - 2021-04-16 17:10:27 --> Helper loaded: common_helper
INFO - 2021-04-16 17:10:27 --> Helper loaded: util_helper
INFO - 2021-04-16 17:10:27 --> Helper loaded: user_helper
INFO - 2021-04-16 17:10:27 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:10:27 --> Form Validation Class Initialized
INFO - 2021-04-16 17:10:27 --> Model Class Initialized
INFO - 2021-04-16 17:10:27 --> Controller Class Initialized
INFO - 2021-04-16 17:10:27 --> Model Class Initialized
INFO - 2021-04-16 17:10:27 --> Config Class Initialized
INFO - 2021-04-16 17:10:27 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:27 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:27 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:27 --> URI Class Initialized
INFO - 2021-04-16 17:10:27 --> Router Class Initialized
INFO - 2021-04-16 17:10:27 --> Output Class Initialized
INFO - 2021-04-16 17:10:27 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:27 --> Input Class Initialized
INFO - 2021-04-16 17:10:27 --> Language Class Initialized
INFO - 2021-04-16 17:10:27 --> Loader Class Initialized
INFO - 2021-04-16 17:10:27 --> Helper loaded: url_helper
INFO - 2021-04-16 17:10:27 --> Helper loaded: form_helper
INFO - 2021-04-16 17:10:27 --> Helper loaded: common_helper
INFO - 2021-04-16 17:10:27 --> Helper loaded: util_helper
INFO - 2021-04-16 17:10:27 --> Helper loaded: user_helper
INFO - 2021-04-16 17:10:27 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:10:27 --> Form Validation Class Initialized
INFO - 2021-04-16 17:10:27 --> Model Class Initialized
INFO - 2021-04-16 17:10:27 --> Controller Class Initialized
INFO - 2021-04-16 17:10:27 --> Model Class Initialized
INFO - 2021-04-16 17:10:27 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 17:10:27 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 17:10:27 --> Final output sent to browser
DEBUG - 2021-04-16 17:10:27 --> Total execution time: 0.0286
INFO - 2021-04-16 17:10:30 --> Config Class Initialized
INFO - 2021-04-16 17:10:30 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:30 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:30 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:30 --> URI Class Initialized
INFO - 2021-04-16 17:10:30 --> Router Class Initialized
INFO - 2021-04-16 17:10:30 --> Output Class Initialized
INFO - 2021-04-16 17:10:30 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:30 --> Input Class Initialized
INFO - 2021-04-16 17:10:30 --> Language Class Initialized
INFO - 2021-04-16 17:10:30 --> Loader Class Initialized
INFO - 2021-04-16 17:10:30 --> Helper loaded: url_helper
INFO - 2021-04-16 17:10:30 --> Helper loaded: form_helper
INFO - 2021-04-16 17:10:30 --> Helper loaded: common_helper
INFO - 2021-04-16 17:10:30 --> Helper loaded: util_helper
INFO - 2021-04-16 17:10:30 --> Helper loaded: user_helper
INFO - 2021-04-16 17:10:30 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:10:30 --> Form Validation Class Initialized
INFO - 2021-04-16 17:10:30 --> Model Class Initialized
INFO - 2021-04-16 17:10:30 --> Controller Class Initialized
INFO - 2021-04-16 17:10:30 --> Model Class Initialized
INFO - 2021-04-16 17:10:30 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 17:10:30 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 17:10:30 --> Final output sent to browser
DEBUG - 2021-04-16 17:10:30 --> Total execution time: 0.0295
INFO - 2021-04-16 17:10:30 --> Config Class Initialized
INFO - 2021-04-16 17:10:30 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:30 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:30 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:30 --> URI Class Initialized
INFO - 2021-04-16 17:10:30 --> Router Class Initialized
INFO - 2021-04-16 17:10:30 --> Output Class Initialized
INFO - 2021-04-16 17:10:30 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:30 --> Input Class Initialized
INFO - 2021-04-16 17:10:30 --> Language Class Initialized
ERROR - 2021-04-16 17:10:30 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:10:31 --> Config Class Initialized
INFO - 2021-04-16 17:10:31 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:31 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:31 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:31 --> URI Class Initialized
INFO - 2021-04-16 17:10:31 --> Router Class Initialized
INFO - 2021-04-16 17:10:31 --> Output Class Initialized
INFO - 2021-04-16 17:10:31 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:31 --> Input Class Initialized
INFO - 2021-04-16 17:10:31 --> Language Class Initialized
INFO - 2021-04-16 17:10:31 --> Loader Class Initialized
INFO - 2021-04-16 17:10:31 --> Helper loaded: url_helper
INFO - 2021-04-16 17:10:31 --> Helper loaded: form_helper
INFO - 2021-04-16 17:10:31 --> Helper loaded: common_helper
INFO - 2021-04-16 17:10:31 --> Helper loaded: util_helper
INFO - 2021-04-16 17:10:31 --> Helper loaded: user_helper
INFO - 2021-04-16 17:10:31 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:10:31 --> Form Validation Class Initialized
INFO - 2021-04-16 17:10:31 --> Model Class Initialized
INFO - 2021-04-16 17:10:31 --> Controller Class Initialized
INFO - 2021-04-16 17:10:31 --> Model Class Initialized
INFO - 2021-04-16 17:10:31 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 17:10:31 --> Final output sent to browser
DEBUG - 2021-04-16 17:10:31 --> Total execution time: 0.0321
INFO - 2021-04-16 17:10:56 --> Config Class Initialized
INFO - 2021-04-16 17:10:56 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:56 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:56 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:56 --> URI Class Initialized
INFO - 2021-04-16 17:10:56 --> Router Class Initialized
INFO - 2021-04-16 17:10:56 --> Output Class Initialized
INFO - 2021-04-16 17:10:56 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:56 --> Input Class Initialized
INFO - 2021-04-16 17:10:56 --> Language Class Initialized
INFO - 2021-04-16 17:10:56 --> Loader Class Initialized
INFO - 2021-04-16 17:10:56 --> Helper loaded: url_helper
INFO - 2021-04-16 17:10:56 --> Helper loaded: form_helper
INFO - 2021-04-16 17:10:56 --> Helper loaded: common_helper
INFO - 2021-04-16 17:10:56 --> Helper loaded: util_helper
INFO - 2021-04-16 17:10:56 --> Helper loaded: user_helper
INFO - 2021-04-16 17:10:56 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:10:56 --> Form Validation Class Initialized
INFO - 2021-04-16 17:10:56 --> Model Class Initialized
INFO - 2021-04-16 17:10:56 --> Controller Class Initialized
INFO - 2021-04-16 17:10:56 --> Model Class Initialized
INFO - 2021-04-16 17:10:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-16 17:10:56 --> Config Class Initialized
INFO - 2021-04-16 17:10:56 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:56 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:56 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:56 --> URI Class Initialized
INFO - 2021-04-16 17:10:56 --> Router Class Initialized
INFO - 2021-04-16 17:10:56 --> Output Class Initialized
INFO - 2021-04-16 17:10:56 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:56 --> Input Class Initialized
INFO - 2021-04-16 17:10:56 --> Language Class Initialized
INFO - 2021-04-16 17:10:56 --> Loader Class Initialized
INFO - 2021-04-16 17:10:56 --> Helper loaded: url_helper
INFO - 2021-04-16 17:10:56 --> Helper loaded: form_helper
INFO - 2021-04-16 17:10:56 --> Helper loaded: common_helper
INFO - 2021-04-16 17:10:56 --> Helper loaded: util_helper
INFO - 2021-04-16 17:10:56 --> Helper loaded: user_helper
INFO - 2021-04-16 17:10:56 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:10:56 --> Form Validation Class Initialized
INFO - 2021-04-16 17:10:56 --> Model Class Initialized
INFO - 2021-04-16 17:10:56 --> Controller Class Initialized
INFO - 2021-04-16 17:10:56 --> Model Class Initialized
INFO - 2021-04-16 17:10:56 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 17:10:56 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 17:10:56 --> Final output sent to browser
DEBUG - 2021-04-16 17:10:56 --> Total execution time: 0.0373
INFO - 2021-04-16 17:10:56 --> Config Class Initialized
INFO - 2021-04-16 17:10:56 --> Hooks Class Initialized
INFO - 2021-04-16 17:10:56 --> Config Class Initialized
INFO - 2021-04-16 17:10:56 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:56 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:56 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:10:56 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:56 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:56 --> URI Class Initialized
INFO - 2021-04-16 17:10:56 --> URI Class Initialized
INFO - 2021-04-16 17:10:56 --> Router Class Initialized
INFO - 2021-04-16 17:10:56 --> Router Class Initialized
INFO - 2021-04-16 17:10:56 --> Output Class Initialized
INFO - 2021-04-16 17:10:56 --> Output Class Initialized
INFO - 2021-04-16 17:10:56 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:56 --> Input Class Initialized
INFO - 2021-04-16 17:10:56 --> Security Class Initialized
INFO - 2021-04-16 17:10:56 --> Language Class Initialized
DEBUG - 2021-04-16 17:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:56 --> Input Class Initialized
ERROR - 2021-04-16 17:10:56 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:10:56 --> Language Class Initialized
ERROR - 2021-04-16 17:10:56 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:10:56 --> Config Class Initialized
INFO - 2021-04-16 17:10:56 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:56 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:56 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:56 --> URI Class Initialized
INFO - 2021-04-16 17:10:56 --> Router Class Initialized
INFO - 2021-04-16 17:10:56 --> Config Class Initialized
INFO - 2021-04-16 17:10:56 --> Hooks Class Initialized
INFO - 2021-04-16 17:10:56 --> Output Class Initialized
DEBUG - 2021-04-16 17:10:56 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:56 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:56 --> Security Class Initialized
INFO - 2021-04-16 17:10:56 --> Config Class Initialized
INFO - 2021-04-16 17:10:56 --> Hooks Class Initialized
INFO - 2021-04-16 17:10:56 --> URI Class Initialized
DEBUG - 2021-04-16 17:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:56 --> Input Class Initialized
INFO - 2021-04-16 17:10:56 --> Language Class Initialized
INFO - 2021-04-16 17:10:56 --> Router Class Initialized
DEBUG - 2021-04-16 17:10:56 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:56 --> Utf8 Class Initialized
ERROR - 2021-04-16 17:10:56 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:10:56 --> URI Class Initialized
INFO - 2021-04-16 17:10:56 --> Output Class Initialized
INFO - 2021-04-16 17:10:56 --> Router Class Initialized
INFO - 2021-04-16 17:10:56 --> Security Class Initialized
INFO - 2021-04-16 17:10:56 --> Output Class Initialized
DEBUG - 2021-04-16 17:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:56 --> Security Class Initialized
INFO - 2021-04-16 17:10:56 --> Input Class Initialized
DEBUG - 2021-04-16 17:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:56 --> Input Class Initialized
INFO - 2021-04-16 17:10:56 --> Language Class Initialized
INFO - 2021-04-16 17:10:56 --> Language Class Initialized
ERROR - 2021-04-16 17:10:56 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-16 17:10:56 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:10:56 --> Config Class Initialized
INFO - 2021-04-16 17:10:56 --> Hooks Class Initialized
INFO - 2021-04-16 17:10:56 --> Config Class Initialized
INFO - 2021-04-16 17:10:56 --> Hooks Class Initialized
INFO - 2021-04-16 17:10:56 --> Config Class Initialized
INFO - 2021-04-16 17:10:56 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:56 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:56 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:10:56 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:56 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:56 --> URI Class Initialized
DEBUG - 2021-04-16 17:10:56 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:56 --> URI Class Initialized
INFO - 2021-04-16 17:10:56 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:56 --> Router Class Initialized
INFO - 2021-04-16 17:10:56 --> URI Class Initialized
INFO - 2021-04-16 17:10:56 --> Router Class Initialized
INFO - 2021-04-16 17:10:56 --> Output Class Initialized
INFO - 2021-04-16 17:10:56 --> Router Class Initialized
INFO - 2021-04-16 17:10:56 --> Output Class Initialized
INFO - 2021-04-16 17:10:56 --> Security Class Initialized
INFO - 2021-04-16 17:10:56 --> Config Class Initialized
INFO - 2021-04-16 17:10:56 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:56 --> Input Class Initialized
INFO - 2021-04-16 17:10:56 --> Security Class Initialized
INFO - 2021-04-16 17:10:56 --> Output Class Initialized
INFO - 2021-04-16 17:10:56 --> Language Class Initialized
DEBUG - 2021-04-16 17:10:56 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:56 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:56 --> Input Class Initialized
ERROR - 2021-04-16 17:10:56 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:10:56 --> Security Class Initialized
INFO - 2021-04-16 17:10:56 --> URI Class Initialized
INFO - 2021-04-16 17:10:56 --> Language Class Initialized
DEBUG - 2021-04-16 17:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:56 --> Router Class Initialized
INFO - 2021-04-16 17:10:56 --> Input Class Initialized
ERROR - 2021-04-16 17:10:56 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:10:56 --> Language Class Initialized
INFO - 2021-04-16 17:10:56 --> Output Class Initialized
ERROR - 2021-04-16 17:10:56 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:10:56 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:56 --> Input Class Initialized
INFO - 2021-04-16 17:10:56 --> Language Class Initialized
INFO - 2021-04-16 17:10:56 --> Config Class Initialized
INFO - 2021-04-16 17:10:56 --> Hooks Class Initialized
ERROR - 2021-04-16 17:10:56 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-16 17:10:56 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:56 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:56 --> URI Class Initialized
INFO - 2021-04-16 17:10:56 --> Router Class Initialized
INFO - 2021-04-16 17:10:56 --> Output Class Initialized
INFO - 2021-04-16 17:10:56 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:56 --> Input Class Initialized
INFO - 2021-04-16 17:10:56 --> Language Class Initialized
ERROR - 2021-04-16 17:10:56 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:10:56 --> Config Class Initialized
INFO - 2021-04-16 17:10:56 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:56 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:56 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:56 --> URI Class Initialized
INFO - 2021-04-16 17:10:56 --> Router Class Initialized
INFO - 2021-04-16 17:10:56 --> Output Class Initialized
INFO - 2021-04-16 17:10:56 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:56 --> Input Class Initialized
INFO - 2021-04-16 17:10:56 --> Language Class Initialized
ERROR - 2021-04-16 17:10:56 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:10:56 --> Config Class Initialized
INFO - 2021-04-16 17:10:56 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:56 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:56 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:56 --> URI Class Initialized
INFO - 2021-04-16 17:10:56 --> Router Class Initialized
INFO - 2021-04-16 17:10:56 --> Output Class Initialized
INFO - 2021-04-16 17:10:56 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:56 --> Input Class Initialized
INFO - 2021-04-16 17:10:56 --> Language Class Initialized
ERROR - 2021-04-16 17:10:56 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:10:56 --> Config Class Initialized
INFO - 2021-04-16 17:10:56 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:56 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:56 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:56 --> URI Class Initialized
INFO - 2021-04-16 17:10:56 --> Router Class Initialized
INFO - 2021-04-16 17:10:56 --> Output Class Initialized
INFO - 2021-04-16 17:10:56 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:56 --> Input Class Initialized
INFO - 2021-04-16 17:10:56 --> Language Class Initialized
ERROR - 2021-04-16 17:10:56 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:10:56 --> Config Class Initialized
INFO - 2021-04-16 17:10:56 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:56 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:56 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:56 --> URI Class Initialized
INFO - 2021-04-16 17:10:56 --> Router Class Initialized
INFO - 2021-04-16 17:10:56 --> Output Class Initialized
INFO - 2021-04-16 17:10:56 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:56 --> Input Class Initialized
INFO - 2021-04-16 17:10:56 --> Language Class Initialized
ERROR - 2021-04-16 17:10:56 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:10:56 --> Config Class Initialized
INFO - 2021-04-16 17:10:56 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:56 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:56 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:56 --> URI Class Initialized
INFO - 2021-04-16 17:10:56 --> Router Class Initialized
INFO - 2021-04-16 17:10:56 --> Output Class Initialized
INFO - 2021-04-16 17:10:56 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:56 --> Input Class Initialized
INFO - 2021-04-16 17:10:56 --> Language Class Initialized
ERROR - 2021-04-16 17:10:56 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:10:56 --> Config Class Initialized
INFO - 2021-04-16 17:10:56 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:56 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:56 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:56 --> URI Class Initialized
INFO - 2021-04-16 17:10:56 --> Router Class Initialized
INFO - 2021-04-16 17:10:56 --> Output Class Initialized
INFO - 2021-04-16 17:10:56 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:56 --> Input Class Initialized
INFO - 2021-04-16 17:10:56 --> Language Class Initialized
ERROR - 2021-04-16 17:10:56 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:10:56 --> Config Class Initialized
INFO - 2021-04-16 17:10:56 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:56 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:56 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:56 --> URI Class Initialized
INFO - 2021-04-16 17:10:56 --> Router Class Initialized
INFO - 2021-04-16 17:10:56 --> Output Class Initialized
INFO - 2021-04-16 17:10:56 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:56 --> Input Class Initialized
INFO - 2021-04-16 17:10:56 --> Language Class Initialized
ERROR - 2021-04-16 17:10:56 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:10:56 --> Config Class Initialized
INFO - 2021-04-16 17:10:56 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:56 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:56 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:56 --> URI Class Initialized
INFO - 2021-04-16 17:10:56 --> Router Class Initialized
INFO - 2021-04-16 17:10:56 --> Output Class Initialized
INFO - 2021-04-16 17:10:56 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:56 --> Input Class Initialized
INFO - 2021-04-16 17:10:56 --> Language Class Initialized
ERROR - 2021-04-16 17:10:56 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:10:56 --> Config Class Initialized
INFO - 2021-04-16 17:10:56 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:10:56 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:10:56 --> Utf8 Class Initialized
INFO - 2021-04-16 17:10:56 --> URI Class Initialized
INFO - 2021-04-16 17:10:56 --> Router Class Initialized
INFO - 2021-04-16 17:10:56 --> Output Class Initialized
INFO - 2021-04-16 17:10:56 --> Security Class Initialized
DEBUG - 2021-04-16 17:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:10:56 --> Input Class Initialized
INFO - 2021-04-16 17:10:56 --> Language Class Initialized
ERROR - 2021-04-16 17:10:56 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:13:04 --> Config Class Initialized
INFO - 2021-04-16 17:13:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:13:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:13:04 --> Utf8 Class Initialized
INFO - 2021-04-16 17:13:04 --> URI Class Initialized
INFO - 2021-04-16 17:13:04 --> Router Class Initialized
INFO - 2021-04-16 17:13:04 --> Output Class Initialized
INFO - 2021-04-16 17:13:04 --> Security Class Initialized
DEBUG - 2021-04-16 17:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:13:04 --> Input Class Initialized
INFO - 2021-04-16 17:13:04 --> Language Class Initialized
INFO - 2021-04-16 17:13:04 --> Loader Class Initialized
INFO - 2021-04-16 17:13:04 --> Helper loaded: url_helper
INFO - 2021-04-16 17:13:04 --> Helper loaded: form_helper
INFO - 2021-04-16 17:13:04 --> Helper loaded: common_helper
INFO - 2021-04-16 17:13:04 --> Helper loaded: util_helper
INFO - 2021-04-16 17:13:04 --> Helper loaded: user_helper
INFO - 2021-04-16 17:13:04 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:13:04 --> Form Validation Class Initialized
INFO - 2021-04-16 17:13:04 --> Model Class Initialized
INFO - 2021-04-16 17:13:04 --> Controller Class Initialized
INFO - 2021-04-16 17:13:04 --> Model Class Initialized
INFO - 2021-04-16 17:13:04 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 17:13:04 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 17:13:04 --> Final output sent to browser
DEBUG - 2021-04-16 17:13:04 --> Total execution time: 0.0286
INFO - 2021-04-16 17:13:04 --> Config Class Initialized
INFO - 2021-04-16 17:13:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:13:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:13:04 --> Utf8 Class Initialized
INFO - 2021-04-16 17:13:04 --> URI Class Initialized
INFO - 2021-04-16 17:13:04 --> Router Class Initialized
INFO - 2021-04-16 17:13:04 --> Config Class Initialized
INFO - 2021-04-16 17:13:04 --> Hooks Class Initialized
INFO - 2021-04-16 17:13:04 --> Config Class Initialized
INFO - 2021-04-16 17:13:04 --> Output Class Initialized
INFO - 2021-04-16 17:13:04 --> Config Class Initialized
DEBUG - 2021-04-16 17:13:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:13:04 --> Hooks Class Initialized
INFO - 2021-04-16 17:13:04 --> Hooks Class Initialized
INFO - 2021-04-16 17:13:04 --> Utf8 Class Initialized
INFO - 2021-04-16 17:13:04 --> Security Class Initialized
INFO - 2021-04-16 17:13:04 --> Config Class Initialized
INFO - 2021-04-16 17:13:04 --> Hooks Class Initialized
INFO - 2021-04-16 17:13:04 --> URI Class Initialized
DEBUG - 2021-04-16 17:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:13:04 --> Input Class Initialized
INFO - 2021-04-16 17:13:04 --> Language Class Initialized
INFO - 2021-04-16 17:13:04 --> Router Class Initialized
DEBUG - 2021-04-16 17:13:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:13:04 --> Utf8 Class Initialized
ERROR - 2021-04-16 17:13:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:13:04 --> Output Class Initialized
DEBUG - 2021-04-16 17:13:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:13:04 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:13:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:13:04 --> Security Class Initialized
INFO - 2021-04-16 17:13:04 --> URI Class Initialized
INFO - 2021-04-16 17:13:04 --> Utf8 Class Initialized
INFO - 2021-04-16 17:13:04 --> URI Class Initialized
DEBUG - 2021-04-16 17:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:13:04 --> URI Class Initialized
INFO - 2021-04-16 17:13:04 --> Input Class Initialized
INFO - 2021-04-16 17:13:04 --> Router Class Initialized
INFO - 2021-04-16 17:13:04 --> Router Class Initialized
INFO - 2021-04-16 17:13:04 --> Language Class Initialized
INFO - 2021-04-16 17:13:04 --> Router Class Initialized
INFO - 2021-04-16 17:13:04 --> Output Class Initialized
INFO - 2021-04-16 17:13:04 --> Output Class Initialized
ERROR - 2021-04-16 17:13:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:13:04 --> Output Class Initialized
INFO - 2021-04-16 17:13:04 --> Security Class Initialized
DEBUG - 2021-04-16 17:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:13:04 --> Input Class Initialized
INFO - 2021-04-16 17:13:04 --> Security Class Initialized
INFO - 2021-04-16 17:13:04 --> Language Class Initialized
INFO - 2021-04-16 17:13:04 --> Config Class Initialized
INFO - 2021-04-16 17:13:04 --> Security Class Initialized
ERROR - 2021-04-16 17:13:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:13:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:13:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:13:04 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:13:04 --> Input Class Initialized
INFO - 2021-04-16 17:13:04 --> URI Class Initialized
INFO - 2021-04-16 17:13:04 --> Language Class Initialized
INFO - 2021-04-16 17:13:04 --> Router Class Initialized
INFO - 2021-04-16 17:13:04 --> Input Class Initialized
INFO - 2021-04-16 17:13:04 --> Config Class Initialized
INFO - 2021-04-16 17:13:04 --> Hooks Class Initialized
INFO - 2021-04-16 17:13:04 --> Language Class Initialized
ERROR - 2021-04-16 17:13:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:13:04 --> Output Class Initialized
DEBUG - 2021-04-16 17:13:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:13:04 --> Utf8 Class Initialized
INFO - 2021-04-16 17:13:04 --> Config Class Initialized
INFO - 2021-04-16 17:13:04 --> Hooks Class Initialized
INFO - 2021-04-16 17:13:04 --> URI Class Initialized
ERROR - 2021-04-16 17:13:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:13:04 --> Router Class Initialized
DEBUG - 2021-04-16 17:13:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:13:04 --> Security Class Initialized
INFO - 2021-04-16 17:13:04 --> Utf8 Class Initialized
INFO - 2021-04-16 17:13:04 --> Output Class Initialized
INFO - 2021-04-16 17:13:04 --> URI Class Initialized
DEBUG - 2021-04-16 17:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:13:04 --> Security Class Initialized
INFO - 2021-04-16 17:13:04 --> Router Class Initialized
INFO - 2021-04-16 17:13:04 --> Input Class Initialized
DEBUG - 2021-04-16 17:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:13:04 --> Input Class Initialized
INFO - 2021-04-16 17:13:04 --> Output Class Initialized
INFO - 2021-04-16 17:13:04 --> Language Class Initialized
INFO - 2021-04-16 17:13:04 --> Language Class Initialized
INFO - 2021-04-16 17:13:04 --> Security Class Initialized
ERROR - 2021-04-16 17:13:04 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-16 17:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:13:04 --> Input Class Initialized
ERROR - 2021-04-16 17:13:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:13:04 --> Language Class Initialized
ERROR - 2021-04-16 17:13:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:13:04 --> Config Class Initialized
INFO - 2021-04-16 17:13:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:13:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:13:04 --> Utf8 Class Initialized
INFO - 2021-04-16 17:13:04 --> URI Class Initialized
INFO - 2021-04-16 17:13:04 --> Router Class Initialized
INFO - 2021-04-16 17:13:04 --> Output Class Initialized
INFO - 2021-04-16 17:13:04 --> Config Class Initialized
INFO - 2021-04-16 17:13:04 --> Hooks Class Initialized
INFO - 2021-04-16 17:13:04 --> Security Class Initialized
DEBUG - 2021-04-16 17:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:13:04 --> Input Class Initialized
INFO - 2021-04-16 17:13:04 --> Language Class Initialized
DEBUG - 2021-04-16 17:13:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:13:04 --> Utf8 Class Initialized
INFO - 2021-04-16 17:13:04 --> URI Class Initialized
ERROR - 2021-04-16 17:13:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:13:04 --> Router Class Initialized
INFO - 2021-04-16 17:13:04 --> Output Class Initialized
INFO - 2021-04-16 17:13:04 --> Security Class Initialized
DEBUG - 2021-04-16 17:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:13:04 --> Input Class Initialized
INFO - 2021-04-16 17:13:04 --> Language Class Initialized
ERROR - 2021-04-16 17:13:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:13:04 --> Config Class Initialized
INFO - 2021-04-16 17:13:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:13:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:13:04 --> Utf8 Class Initialized
INFO - 2021-04-16 17:13:04 --> URI Class Initialized
INFO - 2021-04-16 17:13:04 --> Router Class Initialized
INFO - 2021-04-16 17:13:04 --> Output Class Initialized
INFO - 2021-04-16 17:13:04 --> Security Class Initialized
DEBUG - 2021-04-16 17:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:13:04 --> Input Class Initialized
INFO - 2021-04-16 17:13:04 --> Language Class Initialized
ERROR - 2021-04-16 17:13:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:13:04 --> Config Class Initialized
INFO - 2021-04-16 17:13:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:13:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:13:04 --> Utf8 Class Initialized
INFO - 2021-04-16 17:13:04 --> URI Class Initialized
INFO - 2021-04-16 17:13:04 --> Router Class Initialized
INFO - 2021-04-16 17:13:04 --> Output Class Initialized
INFO - 2021-04-16 17:13:04 --> Security Class Initialized
DEBUG - 2021-04-16 17:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:13:04 --> Input Class Initialized
INFO - 2021-04-16 17:13:04 --> Language Class Initialized
ERROR - 2021-04-16 17:13:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:13:04 --> Config Class Initialized
INFO - 2021-04-16 17:13:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:13:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:13:04 --> Utf8 Class Initialized
INFO - 2021-04-16 17:13:04 --> URI Class Initialized
INFO - 2021-04-16 17:13:04 --> Router Class Initialized
INFO - 2021-04-16 17:13:04 --> Output Class Initialized
INFO - 2021-04-16 17:13:04 --> Security Class Initialized
DEBUG - 2021-04-16 17:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:13:04 --> Input Class Initialized
INFO - 2021-04-16 17:13:04 --> Language Class Initialized
ERROR - 2021-04-16 17:13:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:13:04 --> Config Class Initialized
INFO - 2021-04-16 17:13:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:13:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:13:04 --> Utf8 Class Initialized
INFO - 2021-04-16 17:13:04 --> URI Class Initialized
INFO - 2021-04-16 17:13:04 --> Router Class Initialized
INFO - 2021-04-16 17:13:04 --> Output Class Initialized
INFO - 2021-04-16 17:13:04 --> Security Class Initialized
DEBUG - 2021-04-16 17:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:13:04 --> Input Class Initialized
INFO - 2021-04-16 17:13:04 --> Language Class Initialized
ERROR - 2021-04-16 17:13:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:13:04 --> Config Class Initialized
INFO - 2021-04-16 17:13:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:13:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:13:04 --> Utf8 Class Initialized
INFO - 2021-04-16 17:13:04 --> URI Class Initialized
INFO - 2021-04-16 17:13:04 --> Router Class Initialized
INFO - 2021-04-16 17:13:04 --> Output Class Initialized
INFO - 2021-04-16 17:13:04 --> Security Class Initialized
DEBUG - 2021-04-16 17:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:13:04 --> Input Class Initialized
INFO - 2021-04-16 17:13:04 --> Language Class Initialized
ERROR - 2021-04-16 17:13:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:13:04 --> Config Class Initialized
INFO - 2021-04-16 17:13:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:13:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:13:04 --> Utf8 Class Initialized
INFO - 2021-04-16 17:13:04 --> URI Class Initialized
INFO - 2021-04-16 17:13:04 --> Router Class Initialized
INFO - 2021-04-16 17:13:04 --> Output Class Initialized
INFO - 2021-04-16 17:13:04 --> Security Class Initialized
DEBUG - 2021-04-16 17:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:13:04 --> Input Class Initialized
INFO - 2021-04-16 17:13:04 --> Language Class Initialized
ERROR - 2021-04-16 17:13:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:13:04 --> Config Class Initialized
INFO - 2021-04-16 17:13:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:13:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:13:04 --> Utf8 Class Initialized
INFO - 2021-04-16 17:13:04 --> URI Class Initialized
INFO - 2021-04-16 17:13:04 --> Router Class Initialized
INFO - 2021-04-16 17:13:04 --> Output Class Initialized
INFO - 2021-04-16 17:13:04 --> Security Class Initialized
DEBUG - 2021-04-16 17:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:13:04 --> Input Class Initialized
INFO - 2021-04-16 17:13:04 --> Language Class Initialized
ERROR - 2021-04-16 17:13:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:13:04 --> Config Class Initialized
INFO - 2021-04-16 17:13:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:13:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:13:04 --> Utf8 Class Initialized
INFO - 2021-04-16 17:13:04 --> URI Class Initialized
INFO - 2021-04-16 17:13:04 --> Router Class Initialized
INFO - 2021-04-16 17:13:04 --> Output Class Initialized
INFO - 2021-04-16 17:13:04 --> Security Class Initialized
DEBUG - 2021-04-16 17:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:13:04 --> Input Class Initialized
INFO - 2021-04-16 17:13:04 --> Language Class Initialized
ERROR - 2021-04-16 17:13:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:13:04 --> Config Class Initialized
INFO - 2021-04-16 17:13:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:13:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:13:04 --> Utf8 Class Initialized
INFO - 2021-04-16 17:13:04 --> URI Class Initialized
INFO - 2021-04-16 17:13:04 --> Router Class Initialized
INFO - 2021-04-16 17:13:04 --> Output Class Initialized
INFO - 2021-04-16 17:13:04 --> Security Class Initialized
DEBUG - 2021-04-16 17:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:13:04 --> Input Class Initialized
INFO - 2021-04-16 17:13:04 --> Language Class Initialized
ERROR - 2021-04-16 17:13:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:13:04 --> Config Class Initialized
INFO - 2021-04-16 17:13:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:13:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:13:04 --> Utf8 Class Initialized
INFO - 2021-04-16 17:13:04 --> URI Class Initialized
INFO - 2021-04-16 17:13:04 --> Router Class Initialized
INFO - 2021-04-16 17:13:04 --> Output Class Initialized
INFO - 2021-04-16 17:13:04 --> Security Class Initialized
DEBUG - 2021-04-16 17:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:13:04 --> Input Class Initialized
INFO - 2021-04-16 17:13:04 --> Language Class Initialized
ERROR - 2021-04-16 17:13:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:15:54 --> Config Class Initialized
INFO - 2021-04-16 17:15:54 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:15:54 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:15:54 --> Utf8 Class Initialized
INFO - 2021-04-16 17:15:54 --> URI Class Initialized
INFO - 2021-04-16 17:15:54 --> Router Class Initialized
INFO - 2021-04-16 17:15:54 --> Output Class Initialized
INFO - 2021-04-16 17:15:54 --> Security Class Initialized
DEBUG - 2021-04-16 17:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:15:54 --> Input Class Initialized
INFO - 2021-04-16 17:15:54 --> Language Class Initialized
INFO - 2021-04-16 17:15:54 --> Loader Class Initialized
INFO - 2021-04-16 17:15:54 --> Helper loaded: url_helper
INFO - 2021-04-16 17:15:54 --> Helper loaded: form_helper
INFO - 2021-04-16 17:15:54 --> Helper loaded: common_helper
INFO - 2021-04-16 17:15:54 --> Helper loaded: util_helper
INFO - 2021-04-16 17:15:54 --> Helper loaded: user_helper
INFO - 2021-04-16 17:15:54 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:15:54 --> Form Validation Class Initialized
INFO - 2021-04-16 17:15:54 --> Model Class Initialized
INFO - 2021-04-16 17:15:54 --> Controller Class Initialized
INFO - 2021-04-16 17:15:54 --> Model Class Initialized
INFO - 2021-04-16 17:15:54 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 17:15:54 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 17:15:54 --> Final output sent to browser
DEBUG - 2021-04-16 17:15:54 --> Total execution time: 0.0407
INFO - 2021-04-16 17:15:54 --> Config Class Initialized
INFO - 2021-04-16 17:15:54 --> Hooks Class Initialized
INFO - 2021-04-16 17:15:54 --> Config Class Initialized
INFO - 2021-04-16 17:15:54 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:15:54 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:15:54 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:15:54 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:15:54 --> URI Class Initialized
INFO - 2021-04-16 17:15:54 --> Utf8 Class Initialized
INFO - 2021-04-16 17:15:54 --> URI Class Initialized
INFO - 2021-04-16 17:15:54 --> Router Class Initialized
INFO - 2021-04-16 17:15:54 --> Router Class Initialized
INFO - 2021-04-16 17:15:54 --> Output Class Initialized
INFO - 2021-04-16 17:15:54 --> Security Class Initialized
INFO - 2021-04-16 17:15:54 --> Output Class Initialized
DEBUG - 2021-04-16 17:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:15:54 --> Security Class Initialized
INFO - 2021-04-16 17:15:54 --> Input Class Initialized
INFO - 2021-04-16 17:15:54 --> Language Class Initialized
DEBUG - 2021-04-16 17:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:15:54 --> Input Class Initialized
INFO - 2021-04-16 17:15:54 --> Language Class Initialized
ERROR - 2021-04-16 17:15:54 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-16 17:15:54 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:15:54 --> Config Class Initialized
INFO - 2021-04-16 17:15:54 --> Hooks Class Initialized
INFO - 2021-04-16 17:15:54 --> Config Class Initialized
INFO - 2021-04-16 17:15:54 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:15:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:15:54 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:15:54 --> Utf8 Class Initialized
INFO - 2021-04-16 17:15:54 --> Utf8 Class Initialized
INFO - 2021-04-16 17:15:54 --> URI Class Initialized
INFO - 2021-04-16 17:15:54 --> URI Class Initialized
INFO - 2021-04-16 17:15:54 --> Router Class Initialized
INFO - 2021-04-16 17:15:54 --> Router Class Initialized
INFO - 2021-04-16 17:15:54 --> Config Class Initialized
INFO - 2021-04-16 17:15:54 --> Hooks Class Initialized
INFO - 2021-04-16 17:15:54 --> Output Class Initialized
INFO - 2021-04-16 17:15:54 --> Output Class Initialized
INFO - 2021-04-16 17:15:54 --> Security Class Initialized
DEBUG - 2021-04-16 17:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:15:54 --> Security Class Initialized
DEBUG - 2021-04-16 17:15:54 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:15:54 --> Input Class Initialized
INFO - 2021-04-16 17:15:54 --> Utf8 Class Initialized
INFO - 2021-04-16 17:15:54 --> Language Class Initialized
DEBUG - 2021-04-16 17:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:15:54 --> Input Class Initialized
INFO - 2021-04-16 17:15:54 --> URI Class Initialized
INFO - 2021-04-16 17:15:54 --> Language Class Initialized
ERROR - 2021-04-16 17:15:54 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:15:54 --> Router Class Initialized
ERROR - 2021-04-16 17:15:54 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:15:54 --> Output Class Initialized
INFO - 2021-04-16 17:15:54 --> Config Class Initialized
INFO - 2021-04-16 17:15:54 --> Hooks Class Initialized
INFO - 2021-04-16 17:15:54 --> Security Class Initialized
DEBUG - 2021-04-16 17:15:54 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:15:54 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:15:54 --> Input Class Initialized
INFO - 2021-04-16 17:15:54 --> Language Class Initialized
INFO - 2021-04-16 17:15:54 --> URI Class Initialized
INFO - 2021-04-16 17:15:54 --> Config Class Initialized
INFO - 2021-04-16 17:15:54 --> Hooks Class Initialized
INFO - 2021-04-16 17:15:54 --> Router Class Initialized
ERROR - 2021-04-16 17:15:54 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-16 17:15:54 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:15:54 --> Utf8 Class Initialized
INFO - 2021-04-16 17:15:54 --> Output Class Initialized
INFO - 2021-04-16 17:15:54 --> URI Class Initialized
INFO - 2021-04-16 17:15:54 --> Router Class Initialized
INFO - 2021-04-16 17:15:54 --> Security Class Initialized
INFO - 2021-04-16 17:15:54 --> Output Class Initialized
DEBUG - 2021-04-16 17:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:15:54 --> Security Class Initialized
INFO - 2021-04-16 17:15:54 --> Input Class Initialized
DEBUG - 2021-04-16 17:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:15:54 --> Input Class Initialized
INFO - 2021-04-16 17:15:54 --> Config Class Initialized
INFO - 2021-04-16 17:15:54 --> Language Class Initialized
INFO - 2021-04-16 17:15:54 --> Hooks Class Initialized
INFO - 2021-04-16 17:15:54 --> Config Class Initialized
INFO - 2021-04-16 17:15:54 --> Hooks Class Initialized
ERROR - 2021-04-16 17:15:54 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:15:54 --> Language Class Initialized
DEBUG - 2021-04-16 17:15:54 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:15:54 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:15:54 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:15:54 --> Utf8 Class Initialized
INFO - 2021-04-16 17:15:54 --> URI Class Initialized
INFO - 2021-04-16 17:15:54 --> URI Class Initialized
ERROR - 2021-04-16 17:15:54 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:15:54 --> Router Class Initialized
INFO - 2021-04-16 17:15:54 --> Router Class Initialized
INFO - 2021-04-16 17:15:54 --> Output Class Initialized
INFO - 2021-04-16 17:15:54 --> Output Class Initialized
INFO - 2021-04-16 17:15:54 --> Security Class Initialized
INFO - 2021-04-16 17:15:54 --> Security Class Initialized
DEBUG - 2021-04-16 17:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:15:54 --> Input Class Initialized
INFO - 2021-04-16 17:15:54 --> Language Class Initialized
DEBUG - 2021-04-16 17:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:15:54 --> Input Class Initialized
INFO - 2021-04-16 17:15:54 --> Language Class Initialized
ERROR - 2021-04-16 17:15:54 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-16 17:15:54 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:15:54 --> Config Class Initialized
INFO - 2021-04-16 17:15:54 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:15:54 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:15:54 --> Utf8 Class Initialized
INFO - 2021-04-16 17:15:54 --> URI Class Initialized
INFO - 2021-04-16 17:15:54 --> Config Class Initialized
INFO - 2021-04-16 17:15:54 --> Hooks Class Initialized
INFO - 2021-04-16 17:15:54 --> Router Class Initialized
DEBUG - 2021-04-16 17:15:54 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:15:54 --> Utf8 Class Initialized
INFO - 2021-04-16 17:15:54 --> Output Class Initialized
INFO - 2021-04-16 17:15:54 --> URI Class Initialized
INFO - 2021-04-16 17:15:54 --> Security Class Initialized
INFO - 2021-04-16 17:15:54 --> Router Class Initialized
DEBUG - 2021-04-16 17:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:15:54 --> Input Class Initialized
INFO - 2021-04-16 17:15:54 --> Language Class Initialized
INFO - 2021-04-16 17:15:54 --> Output Class Initialized
INFO - 2021-04-16 17:15:54 --> Security Class Initialized
ERROR - 2021-04-16 17:15:54 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-16 17:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:15:54 --> Input Class Initialized
INFO - 2021-04-16 17:15:54 --> Language Class Initialized
ERROR - 2021-04-16 17:15:54 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:15:54 --> Config Class Initialized
INFO - 2021-04-16 17:15:54 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:15:54 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:15:54 --> Utf8 Class Initialized
INFO - 2021-04-16 17:15:54 --> URI Class Initialized
INFO - 2021-04-16 17:15:54 --> Router Class Initialized
INFO - 2021-04-16 17:15:54 --> Output Class Initialized
INFO - 2021-04-16 17:15:54 --> Security Class Initialized
DEBUG - 2021-04-16 17:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:15:54 --> Input Class Initialized
INFO - 2021-04-16 17:15:54 --> Language Class Initialized
ERROR - 2021-04-16 17:15:54 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:15:54 --> Config Class Initialized
INFO - 2021-04-16 17:15:54 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:15:54 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:15:54 --> Utf8 Class Initialized
INFO - 2021-04-16 17:15:54 --> URI Class Initialized
INFO - 2021-04-16 17:15:54 --> Router Class Initialized
INFO - 2021-04-16 17:15:54 --> Output Class Initialized
INFO - 2021-04-16 17:15:54 --> Security Class Initialized
DEBUG - 2021-04-16 17:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:15:54 --> Input Class Initialized
INFO - 2021-04-16 17:15:54 --> Language Class Initialized
ERROR - 2021-04-16 17:15:54 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:15:54 --> Config Class Initialized
INFO - 2021-04-16 17:15:54 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:15:54 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:15:54 --> Utf8 Class Initialized
INFO - 2021-04-16 17:15:54 --> URI Class Initialized
INFO - 2021-04-16 17:15:55 --> Router Class Initialized
INFO - 2021-04-16 17:15:55 --> Output Class Initialized
INFO - 2021-04-16 17:15:55 --> Security Class Initialized
DEBUG - 2021-04-16 17:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:15:55 --> Input Class Initialized
INFO - 2021-04-16 17:15:55 --> Language Class Initialized
ERROR - 2021-04-16 17:15:55 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:15:55 --> Config Class Initialized
INFO - 2021-04-16 17:15:55 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:15:55 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:15:55 --> Utf8 Class Initialized
INFO - 2021-04-16 17:15:55 --> URI Class Initialized
INFO - 2021-04-16 17:15:55 --> Router Class Initialized
INFO - 2021-04-16 17:15:55 --> Output Class Initialized
INFO - 2021-04-16 17:15:55 --> Security Class Initialized
DEBUG - 2021-04-16 17:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:15:55 --> Input Class Initialized
INFO - 2021-04-16 17:15:55 --> Language Class Initialized
ERROR - 2021-04-16 17:15:55 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:15:55 --> Config Class Initialized
INFO - 2021-04-16 17:15:55 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:15:55 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:15:55 --> Utf8 Class Initialized
INFO - 2021-04-16 17:15:55 --> URI Class Initialized
INFO - 2021-04-16 17:15:55 --> Router Class Initialized
INFO - 2021-04-16 17:15:55 --> Output Class Initialized
INFO - 2021-04-16 17:15:55 --> Security Class Initialized
DEBUG - 2021-04-16 17:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:15:55 --> Input Class Initialized
INFO - 2021-04-16 17:15:55 --> Language Class Initialized
ERROR - 2021-04-16 17:15:55 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:15:55 --> Config Class Initialized
INFO - 2021-04-16 17:15:55 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:15:55 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:15:55 --> Utf8 Class Initialized
INFO - 2021-04-16 17:15:55 --> URI Class Initialized
INFO - 2021-04-16 17:15:55 --> Router Class Initialized
INFO - 2021-04-16 17:15:55 --> Output Class Initialized
INFO - 2021-04-16 17:15:55 --> Security Class Initialized
DEBUG - 2021-04-16 17:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:15:55 --> Input Class Initialized
INFO - 2021-04-16 17:15:55 --> Language Class Initialized
ERROR - 2021-04-16 17:15:55 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:15:55 --> Config Class Initialized
INFO - 2021-04-16 17:15:55 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:15:55 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:15:55 --> Utf8 Class Initialized
INFO - 2021-04-16 17:15:55 --> URI Class Initialized
INFO - 2021-04-16 17:15:55 --> Router Class Initialized
INFO - 2021-04-16 17:15:55 --> Output Class Initialized
INFO - 2021-04-16 17:15:55 --> Security Class Initialized
DEBUG - 2021-04-16 17:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:15:55 --> Input Class Initialized
INFO - 2021-04-16 17:15:55 --> Language Class Initialized
ERROR - 2021-04-16 17:15:55 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:15:55 --> Config Class Initialized
INFO - 2021-04-16 17:15:55 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:15:55 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:15:55 --> Utf8 Class Initialized
INFO - 2021-04-16 17:15:55 --> URI Class Initialized
INFO - 2021-04-16 17:15:55 --> Router Class Initialized
INFO - 2021-04-16 17:15:55 --> Output Class Initialized
INFO - 2021-04-16 17:15:55 --> Security Class Initialized
DEBUG - 2021-04-16 17:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:15:55 --> Input Class Initialized
INFO - 2021-04-16 17:15:55 --> Language Class Initialized
ERROR - 2021-04-16 17:15:55 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:06 --> Config Class Initialized
INFO - 2021-04-16 17:16:06 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:06 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:06 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:06 --> URI Class Initialized
INFO - 2021-04-16 17:16:06 --> Router Class Initialized
INFO - 2021-04-16 17:16:06 --> Output Class Initialized
INFO - 2021-04-16 17:16:06 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:06 --> Input Class Initialized
INFO - 2021-04-16 17:16:06 --> Language Class Initialized
INFO - 2021-04-16 17:16:06 --> Loader Class Initialized
INFO - 2021-04-16 17:16:06 --> Helper loaded: url_helper
INFO - 2021-04-16 17:16:06 --> Helper loaded: form_helper
INFO - 2021-04-16 17:16:06 --> Helper loaded: common_helper
INFO - 2021-04-16 17:16:06 --> Helper loaded: util_helper
INFO - 2021-04-16 17:16:06 --> Helper loaded: user_helper
INFO - 2021-04-16 17:16:06 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:16:06 --> Form Validation Class Initialized
INFO - 2021-04-16 17:16:06 --> Model Class Initialized
INFO - 2021-04-16 17:16:06 --> Controller Class Initialized
INFO - 2021-04-16 17:16:06 --> Model Class Initialized
INFO - 2021-04-16 17:16:06 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 17:16:06 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 17:16:06 --> Final output sent to browser
DEBUG - 2021-04-16 17:16:06 --> Total execution time: 0.0291
INFO - 2021-04-16 17:16:06 --> Config Class Initialized
INFO - 2021-04-16 17:16:06 --> Config Class Initialized
INFO - 2021-04-16 17:16:06 --> Config Class Initialized
INFO - 2021-04-16 17:16:06 --> Hooks Class Initialized
INFO - 2021-04-16 17:16:06 --> Hooks Class Initialized
INFO - 2021-04-16 17:16:06 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:06 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:06 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:16:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:16:06 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:06 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:06 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:06 --> URI Class Initialized
INFO - 2021-04-16 17:16:06 --> URI Class Initialized
INFO - 2021-04-16 17:16:06 --> URI Class Initialized
INFO - 2021-04-16 17:16:06 --> Router Class Initialized
INFO - 2021-04-16 17:16:06 --> Router Class Initialized
INFO - 2021-04-16 17:16:06 --> Router Class Initialized
INFO - 2021-04-16 17:16:06 --> Output Class Initialized
INFO - 2021-04-16 17:16:06 --> Output Class Initialized
INFO - 2021-04-16 17:16:06 --> Output Class Initialized
INFO - 2021-04-16 17:16:06 --> Security Class Initialized
INFO - 2021-04-16 17:16:06 --> Security Class Initialized
INFO - 2021-04-16 17:16:06 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:06 --> Input Class Initialized
DEBUG - 2021-04-16 17:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:06 --> Language Class Initialized
INFO - 2021-04-16 17:16:06 --> Input Class Initialized
INFO - 2021-04-16 17:16:06 --> Input Class Initialized
INFO - 2021-04-16 17:16:06 --> Language Class Initialized
INFO - 2021-04-16 17:16:06 --> Language Class Initialized
ERROR - 2021-04-16 17:16:06 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-16 17:16:06 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-16 17:16:06 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:16:06 --> Config Class Initialized
INFO - 2021-04-16 17:16:06 --> Hooks Class Initialized
INFO - 2021-04-16 17:16:06 --> Config Class Initialized
INFO - 2021-04-16 17:16:06 --> Hooks Class Initialized
INFO - 2021-04-16 17:16:06 --> Config Class Initialized
INFO - 2021-04-16 17:16:06 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:06 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:06 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:16:06 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:06 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:06 --> URI Class Initialized
DEBUG - 2021-04-16 17:16:06 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:06 --> URI Class Initialized
INFO - 2021-04-16 17:16:06 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:06 --> Config Class Initialized
INFO - 2021-04-16 17:16:06 --> URI Class Initialized
INFO - 2021-04-16 17:16:06 --> Router Class Initialized
INFO - 2021-04-16 17:16:06 --> Router Class Initialized
INFO - 2021-04-16 17:16:06 --> Hooks Class Initialized
INFO - 2021-04-16 17:16:06 --> Router Class Initialized
INFO - 2021-04-16 17:16:06 --> Output Class Initialized
DEBUG - 2021-04-16 17:16:06 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:06 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:06 --> Security Class Initialized
INFO - 2021-04-16 17:16:06 --> Output Class Initialized
INFO - 2021-04-16 17:16:06 --> URI Class Initialized
INFO - 2021-04-16 17:16:06 --> Config Class Initialized
DEBUG - 2021-04-16 17:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:06 --> Input Class Initialized
INFO - 2021-04-16 17:16:06 --> Security Class Initialized
INFO - 2021-04-16 17:16:06 --> Hooks Class Initialized
INFO - 2021-04-16 17:16:06 --> Router Class Initialized
INFO - 2021-04-16 17:16:06 --> Language Class Initialized
INFO - 2021-04-16 17:16:06 --> Output Class Initialized
INFO - 2021-04-16 17:16:06 --> Output Class Initialized
ERROR - 2021-04-16 17:16:06 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:06 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:06 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:06 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:06 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:06 --> Input Class Initialized
INFO - 2021-04-16 17:16:06 --> Config Class Initialized
INFO - 2021-04-16 17:16:06 --> Hooks Class Initialized
INFO - 2021-04-16 17:16:06 --> URI Class Initialized
DEBUG - 2021-04-16 17:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:06 --> Language Class Initialized
INFO - 2021-04-16 17:16:06 --> Input Class Initialized
INFO - 2021-04-16 17:16:06 --> Language Class Initialized
INFO - 2021-04-16 17:16:06 --> Router Class Initialized
ERROR - 2021-04-16 17:16:06 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-16 17:16:06 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:06 --> Utf8 Class Initialized
ERROR - 2021-04-16 17:16:06 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:06 --> Output Class Initialized
INFO - 2021-04-16 17:16:06 --> URI Class Initialized
DEBUG - 2021-04-16 17:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:06 --> Input Class Initialized
INFO - 2021-04-16 17:16:06 --> Security Class Initialized
INFO - 2021-04-16 17:16:06 --> Language Class Initialized
INFO - 2021-04-16 17:16:06 --> Router Class Initialized
DEBUG - 2021-04-16 17:16:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:16:06 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:16:06 --> Input Class Initialized
INFO - 2021-04-16 17:16:06 --> Output Class Initialized
INFO - 2021-04-16 17:16:06 --> Language Class Initialized
INFO - 2021-04-16 17:16:06 --> Security Class Initialized
ERROR - 2021-04-16 17:16:06 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-16 17:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:06 --> Input Class Initialized
INFO - 2021-04-16 17:16:06 --> Language Class Initialized
INFO - 2021-04-16 17:16:06 --> Config Class Initialized
INFO - 2021-04-16 17:16:06 --> Hooks Class Initialized
ERROR - 2021-04-16 17:16:06 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-16 17:16:06 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:06 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:06 --> URI Class Initialized
INFO - 2021-04-16 17:16:06 --> Router Class Initialized
INFO - 2021-04-16 17:16:06 --> Output Class Initialized
INFO - 2021-04-16 17:16:06 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:06 --> Input Class Initialized
INFO - 2021-04-16 17:16:06 --> Language Class Initialized
INFO - 2021-04-16 17:16:06 --> Config Class Initialized
INFO - 2021-04-16 17:16:06 --> Hooks Class Initialized
ERROR - 2021-04-16 17:16:06 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-16 17:16:06 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:06 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:06 --> URI Class Initialized
INFO - 2021-04-16 17:16:06 --> Router Class Initialized
INFO - 2021-04-16 17:16:06 --> Output Class Initialized
INFO - 2021-04-16 17:16:06 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:06 --> Input Class Initialized
INFO - 2021-04-16 17:16:06 --> Language Class Initialized
ERROR - 2021-04-16 17:16:06 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:16:06 --> Config Class Initialized
INFO - 2021-04-16 17:16:06 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:06 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:06 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:06 --> URI Class Initialized
INFO - 2021-04-16 17:16:06 --> Router Class Initialized
INFO - 2021-04-16 17:16:06 --> Output Class Initialized
INFO - 2021-04-16 17:16:06 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:06 --> Input Class Initialized
INFO - 2021-04-16 17:16:06 --> Language Class Initialized
ERROR - 2021-04-16 17:16:06 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:16:06 --> Config Class Initialized
INFO - 2021-04-16 17:16:06 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:06 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:06 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:06 --> URI Class Initialized
INFO - 2021-04-16 17:16:06 --> Router Class Initialized
INFO - 2021-04-16 17:16:06 --> Output Class Initialized
INFO - 2021-04-16 17:16:06 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:06 --> Input Class Initialized
INFO - 2021-04-16 17:16:06 --> Language Class Initialized
ERROR - 2021-04-16 17:16:06 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:16:06 --> Config Class Initialized
INFO - 2021-04-16 17:16:06 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:06 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:06 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:06 --> URI Class Initialized
INFO - 2021-04-16 17:16:06 --> Router Class Initialized
INFO - 2021-04-16 17:16:06 --> Output Class Initialized
INFO - 2021-04-16 17:16:06 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:06 --> Input Class Initialized
INFO - 2021-04-16 17:16:06 --> Language Class Initialized
ERROR - 2021-04-16 17:16:06 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:06 --> Config Class Initialized
INFO - 2021-04-16 17:16:06 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:06 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:06 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:06 --> URI Class Initialized
INFO - 2021-04-16 17:16:06 --> Router Class Initialized
INFO - 2021-04-16 17:16:06 --> Output Class Initialized
INFO - 2021-04-16 17:16:06 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:06 --> Input Class Initialized
INFO - 2021-04-16 17:16:06 --> Language Class Initialized
ERROR - 2021-04-16 17:16:06 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:06 --> Config Class Initialized
INFO - 2021-04-16 17:16:06 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:06 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:06 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:06 --> URI Class Initialized
INFO - 2021-04-16 17:16:06 --> Router Class Initialized
INFO - 2021-04-16 17:16:06 --> Output Class Initialized
INFO - 2021-04-16 17:16:06 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:06 --> Input Class Initialized
INFO - 2021-04-16 17:16:06 --> Language Class Initialized
ERROR - 2021-04-16 17:16:06 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:06 --> Config Class Initialized
INFO - 2021-04-16 17:16:06 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:06 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:06 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:06 --> URI Class Initialized
INFO - 2021-04-16 17:16:06 --> Router Class Initialized
INFO - 2021-04-16 17:16:06 --> Output Class Initialized
INFO - 2021-04-16 17:16:06 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:06 --> Input Class Initialized
INFO - 2021-04-16 17:16:06 --> Language Class Initialized
ERROR - 2021-04-16 17:16:06 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:06 --> Config Class Initialized
INFO - 2021-04-16 17:16:06 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:06 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:06 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:06 --> URI Class Initialized
INFO - 2021-04-16 17:16:06 --> Router Class Initialized
INFO - 2021-04-16 17:16:06 --> Output Class Initialized
INFO - 2021-04-16 17:16:06 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:06 --> Input Class Initialized
INFO - 2021-04-16 17:16:06 --> Language Class Initialized
ERROR - 2021-04-16 17:16:06 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:06 --> Config Class Initialized
INFO - 2021-04-16 17:16:06 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:06 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:06 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:06 --> URI Class Initialized
INFO - 2021-04-16 17:16:06 --> Router Class Initialized
INFO - 2021-04-16 17:16:06 --> Output Class Initialized
INFO - 2021-04-16 17:16:06 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:06 --> Input Class Initialized
INFO - 2021-04-16 17:16:06 --> Language Class Initialized
ERROR - 2021-04-16 17:16:06 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:06 --> Config Class Initialized
INFO - 2021-04-16 17:16:06 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:06 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:06 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:06 --> URI Class Initialized
INFO - 2021-04-16 17:16:06 --> Router Class Initialized
INFO - 2021-04-16 17:16:06 --> Output Class Initialized
INFO - 2021-04-16 17:16:06 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:06 --> Input Class Initialized
INFO - 2021-04-16 17:16:06 --> Language Class Initialized
ERROR - 2021-04-16 17:16:06 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:06 --> Config Class Initialized
INFO - 2021-04-16 17:16:06 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:06 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:06 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:06 --> URI Class Initialized
INFO - 2021-04-16 17:16:06 --> Router Class Initialized
INFO - 2021-04-16 17:16:06 --> Output Class Initialized
INFO - 2021-04-16 17:16:06 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:06 --> Input Class Initialized
INFO - 2021-04-16 17:16:06 --> Language Class Initialized
ERROR - 2021-04-16 17:16:06 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:18 --> Config Class Initialized
INFO - 2021-04-16 17:16:18 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:18 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:18 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:18 --> URI Class Initialized
INFO - 2021-04-16 17:16:18 --> Router Class Initialized
INFO - 2021-04-16 17:16:18 --> Output Class Initialized
INFO - 2021-04-16 17:16:18 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:18 --> Input Class Initialized
INFO - 2021-04-16 17:16:18 --> Language Class Initialized
INFO - 2021-04-16 17:16:18 --> Loader Class Initialized
INFO - 2021-04-16 17:16:18 --> Helper loaded: url_helper
INFO - 2021-04-16 17:16:18 --> Helper loaded: form_helper
INFO - 2021-04-16 17:16:18 --> Helper loaded: common_helper
INFO - 2021-04-16 17:16:18 --> Helper loaded: util_helper
INFO - 2021-04-16 17:16:18 --> Helper loaded: user_helper
INFO - 2021-04-16 17:16:18 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:16:18 --> Form Validation Class Initialized
INFO - 2021-04-16 17:16:18 --> Model Class Initialized
INFO - 2021-04-16 17:16:18 --> Controller Class Initialized
INFO - 2021-04-16 17:16:18 --> Model Class Initialized
INFO - 2021-04-16 17:16:18 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 17:16:18 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 17:16:18 --> Final output sent to browser
DEBUG - 2021-04-16 17:16:18 --> Total execution time: 0.0295
INFO - 2021-04-16 17:16:18 --> Config Class Initialized
INFO - 2021-04-16 17:16:18 --> Hooks Class Initialized
INFO - 2021-04-16 17:16:18 --> Config Class Initialized
INFO - 2021-04-16 17:16:18 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:18 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:18 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:16:18 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:18 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:18 --> URI Class Initialized
INFO - 2021-04-16 17:16:18 --> URI Class Initialized
INFO - 2021-04-16 17:16:18 --> Router Class Initialized
INFO - 2021-04-16 17:16:18 --> Router Class Initialized
INFO - 2021-04-16 17:16:18 --> Output Class Initialized
INFO - 2021-04-16 17:16:18 --> Output Class Initialized
INFO - 2021-04-16 17:16:18 --> Security Class Initialized
INFO - 2021-04-16 17:16:18 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:18 --> Input Class Initialized
INFO - 2021-04-16 17:16:18 --> Input Class Initialized
INFO - 2021-04-16 17:16:18 --> Language Class Initialized
INFO - 2021-04-16 17:16:18 --> Language Class Initialized
ERROR - 2021-04-16 17:16:18 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-16 17:16:18 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:16:18 --> Config Class Initialized
INFO - 2021-04-16 17:16:18 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:18 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:18 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:18 --> URI Class Initialized
INFO - 2021-04-16 17:16:18 --> Router Class Initialized
INFO - 2021-04-16 17:16:18 --> Output Class Initialized
INFO - 2021-04-16 17:16:18 --> Config Class Initialized
INFO - 2021-04-16 17:16:18 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:18 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:18 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:18 --> URI Class Initialized
INFO - 2021-04-16 17:16:18 --> Config Class Initialized
INFO - 2021-04-16 17:16:18 --> Hooks Class Initialized
INFO - 2021-04-16 17:16:18 --> Config Class Initialized
INFO - 2021-04-16 17:16:18 --> Hooks Class Initialized
INFO - 2021-04-16 17:16:18 --> Config Class Initialized
INFO - 2021-04-16 17:16:18 --> Router Class Initialized
DEBUG - 2021-04-16 17:16:18 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:18 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:16:18 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:18 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:18 --> Hooks Class Initialized
INFO - 2021-04-16 17:16:18 --> URI Class Initialized
INFO - 2021-04-16 17:16:18 --> URI Class Initialized
INFO - 2021-04-16 17:16:18 --> Output Class Initialized
INFO - 2021-04-16 17:16:18 --> Router Class Initialized
INFO - 2021-04-16 17:16:18 --> Router Class Initialized
INFO - 2021-04-16 17:16:18 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:18 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:18 --> Output Class Initialized
INFO - 2021-04-16 17:16:18 --> Output Class Initialized
INFO - 2021-04-16 17:16:18 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:18 --> Security Class Initialized
INFO - 2021-04-16 17:16:18 --> Input Class Initialized
INFO - 2021-04-16 17:16:18 --> Security Class Initialized
INFO - 2021-04-16 17:16:18 --> URI Class Initialized
INFO - 2021-04-16 17:16:18 --> Language Class Initialized
DEBUG - 2021-04-16 17:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:18 --> Input Class Initialized
INFO - 2021-04-16 17:16:18 --> Input Class Initialized
INFO - 2021-04-16 17:16:18 --> Language Class Initialized
INFO - 2021-04-16 17:16:18 --> Language Class Initialized
INFO - 2021-04-16 17:16:18 --> Router Class Initialized
ERROR - 2021-04-16 17:16:18 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-16 17:16:18 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:16:18 --> Output Class Initialized
ERROR - 2021-04-16 17:16:18 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:18 --> Security Class Initialized
INFO - 2021-04-16 17:16:18 --> Security Class Initialized
INFO - 2021-04-16 17:16:18 --> Config Class Initialized
INFO - 2021-04-16 17:16:18 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:18 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:18 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:18 --> URI Class Initialized
DEBUG - 2021-04-16 17:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:18 --> Input Class Initialized
INFO - 2021-04-16 17:16:18 --> Router Class Initialized
INFO - 2021-04-16 17:16:18 --> Language Class Initialized
INFO - 2021-04-16 17:16:18 --> Config Class Initialized
INFO - 2021-04-16 17:16:18 --> Hooks Class Initialized
INFO - 2021-04-16 17:16:18 --> Output Class Initialized
ERROR - 2021-04-16 17:16:18 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:16:18 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:18 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:18 --> Config Class Initialized
INFO - 2021-04-16 17:16:18 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:18 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:18 --> Input Class Initialized
INFO - 2021-04-16 17:16:18 --> URI Class Initialized
INFO - 2021-04-16 17:16:18 --> Language Class Initialized
DEBUG - 2021-04-16 17:16:18 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:18 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:18 --> Router Class Initialized
INFO - 2021-04-16 17:16:18 --> URI Class Initialized
DEBUG - 2021-04-16 17:16:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:16:18 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:16:18 --> Input Class Initialized
INFO - 2021-04-16 17:16:18 --> Router Class Initialized
INFO - 2021-04-16 17:16:18 --> Language Class Initialized
INFO - 2021-04-16 17:16:18 --> Output Class Initialized
INFO - 2021-04-16 17:16:18 --> Output Class Initialized
INFO - 2021-04-16 17:16:18 --> Security Class Initialized
ERROR - 2021-04-16 17:16:18 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:16:18 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:18 --> Input Class Initialized
INFO - 2021-04-16 17:16:18 --> Language Class Initialized
DEBUG - 2021-04-16 17:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:18 --> Input Class Initialized
INFO - 2021-04-16 17:16:18 --> Language Class Initialized
ERROR - 2021-04-16 17:16:18 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-16 17:16:18 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:18 --> Config Class Initialized
INFO - 2021-04-16 17:16:18 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:18 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:18 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:18 --> URI Class Initialized
INFO - 2021-04-16 17:16:18 --> Router Class Initialized
INFO - 2021-04-16 17:16:18 --> Output Class Initialized
INFO - 2021-04-16 17:16:18 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:18 --> Input Class Initialized
INFO - 2021-04-16 17:16:18 --> Language Class Initialized
ERROR - 2021-04-16 17:16:18 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:16:18 --> Config Class Initialized
INFO - 2021-04-16 17:16:18 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:18 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:18 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:18 --> URI Class Initialized
INFO - 2021-04-16 17:16:18 --> Router Class Initialized
INFO - 2021-04-16 17:16:18 --> Output Class Initialized
INFO - 2021-04-16 17:16:18 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:18 --> Input Class Initialized
INFO - 2021-04-16 17:16:18 --> Language Class Initialized
ERROR - 2021-04-16 17:16:18 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:18 --> Config Class Initialized
INFO - 2021-04-16 17:16:18 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:18 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:18 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:18 --> URI Class Initialized
INFO - 2021-04-16 17:16:18 --> Router Class Initialized
INFO - 2021-04-16 17:16:18 --> Output Class Initialized
INFO - 2021-04-16 17:16:18 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:18 --> Input Class Initialized
INFO - 2021-04-16 17:16:18 --> Language Class Initialized
ERROR - 2021-04-16 17:16:18 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:18 --> Config Class Initialized
INFO - 2021-04-16 17:16:18 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:18 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:18 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:18 --> URI Class Initialized
INFO - 2021-04-16 17:16:18 --> Router Class Initialized
INFO - 2021-04-16 17:16:18 --> Output Class Initialized
INFO - 2021-04-16 17:16:18 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:18 --> Input Class Initialized
INFO - 2021-04-16 17:16:18 --> Language Class Initialized
ERROR - 2021-04-16 17:16:18 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:18 --> Config Class Initialized
INFO - 2021-04-16 17:16:18 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:18 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:18 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:18 --> URI Class Initialized
INFO - 2021-04-16 17:16:18 --> Router Class Initialized
INFO - 2021-04-16 17:16:18 --> Output Class Initialized
INFO - 2021-04-16 17:16:18 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:18 --> Input Class Initialized
INFO - 2021-04-16 17:16:18 --> Language Class Initialized
ERROR - 2021-04-16 17:16:18 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:18 --> Config Class Initialized
INFO - 2021-04-16 17:16:18 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:18 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:18 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:18 --> URI Class Initialized
INFO - 2021-04-16 17:16:18 --> Router Class Initialized
INFO - 2021-04-16 17:16:18 --> Output Class Initialized
INFO - 2021-04-16 17:16:18 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:18 --> Input Class Initialized
INFO - 2021-04-16 17:16:18 --> Language Class Initialized
ERROR - 2021-04-16 17:16:18 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:18 --> Config Class Initialized
INFO - 2021-04-16 17:16:18 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:19 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:19 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:19 --> URI Class Initialized
INFO - 2021-04-16 17:16:19 --> Router Class Initialized
INFO - 2021-04-16 17:16:19 --> Output Class Initialized
INFO - 2021-04-16 17:16:19 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:19 --> Input Class Initialized
INFO - 2021-04-16 17:16:19 --> Language Class Initialized
ERROR - 2021-04-16 17:16:19 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:19 --> Config Class Initialized
INFO - 2021-04-16 17:16:19 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:19 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:19 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:19 --> URI Class Initialized
INFO - 2021-04-16 17:16:19 --> Router Class Initialized
INFO - 2021-04-16 17:16:19 --> Output Class Initialized
INFO - 2021-04-16 17:16:19 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:19 --> Input Class Initialized
INFO - 2021-04-16 17:16:19 --> Language Class Initialized
ERROR - 2021-04-16 17:16:19 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:19 --> Config Class Initialized
INFO - 2021-04-16 17:16:19 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:19 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:19 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:19 --> URI Class Initialized
INFO - 2021-04-16 17:16:19 --> Router Class Initialized
INFO - 2021-04-16 17:16:19 --> Output Class Initialized
INFO - 2021-04-16 17:16:19 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:19 --> Input Class Initialized
INFO - 2021-04-16 17:16:19 --> Language Class Initialized
ERROR - 2021-04-16 17:16:19 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:37 --> Config Class Initialized
INFO - 2021-04-16 17:16:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:37 --> URI Class Initialized
INFO - 2021-04-16 17:16:37 --> Router Class Initialized
INFO - 2021-04-16 17:16:37 --> Output Class Initialized
INFO - 2021-04-16 17:16:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:37 --> Input Class Initialized
INFO - 2021-04-16 17:16:37 --> Language Class Initialized
INFO - 2021-04-16 17:16:37 --> Loader Class Initialized
INFO - 2021-04-16 17:16:37 --> Helper loaded: url_helper
INFO - 2021-04-16 17:16:37 --> Helper loaded: form_helper
INFO - 2021-04-16 17:16:37 --> Helper loaded: common_helper
INFO - 2021-04-16 17:16:37 --> Helper loaded: util_helper
INFO - 2021-04-16 17:16:37 --> Helper loaded: user_helper
INFO - 2021-04-16 17:16:37 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:16:37 --> Form Validation Class Initialized
INFO - 2021-04-16 17:16:37 --> Model Class Initialized
INFO - 2021-04-16 17:16:37 --> Controller Class Initialized
INFO - 2021-04-16 17:16:37 --> Model Class Initialized
INFO - 2021-04-16 17:16:37 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 17:16:37 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 17:16:37 --> Final output sent to browser
DEBUG - 2021-04-16 17:16:37 --> Total execution time: 0.0296
INFO - 2021-04-16 17:16:37 --> Config Class Initialized
INFO - 2021-04-16 17:16:37 --> Hooks Class Initialized
INFO - 2021-04-16 17:16:37 --> Config Class Initialized
INFO - 2021-04-16 17:16:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:16:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:37 --> URI Class Initialized
INFO - 2021-04-16 17:16:37 --> URI Class Initialized
INFO - 2021-04-16 17:16:37 --> Router Class Initialized
INFO - 2021-04-16 17:16:37 --> Router Class Initialized
INFO - 2021-04-16 17:16:37 --> Output Class Initialized
INFO - 2021-04-16 17:16:37 --> Output Class Initialized
INFO - 2021-04-16 17:16:37 --> Security Class Initialized
INFO - 2021-04-16 17:16:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:37 --> Input Class Initialized
INFO - 2021-04-16 17:16:37 --> Input Class Initialized
INFO - 2021-04-16 17:16:37 --> Language Class Initialized
INFO - 2021-04-16 17:16:37 --> Language Class Initialized
INFO - 2021-04-16 17:16:37 --> Config Class Initialized
INFO - 2021-04-16 17:16:37 --> Hooks Class Initialized
ERROR - 2021-04-16 17:16:37 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-16 17:16:37 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-16 17:16:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:37 --> URI Class Initialized
INFO - 2021-04-16 17:16:37 --> Router Class Initialized
INFO - 2021-04-16 17:16:37 --> Output Class Initialized
INFO - 2021-04-16 17:16:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:37 --> Input Class Initialized
INFO - 2021-04-16 17:16:37 --> Language Class Initialized
ERROR - 2021-04-16 17:16:37 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:16:37 --> Config Class Initialized
INFO - 2021-04-16 17:16:37 --> Hooks Class Initialized
INFO - 2021-04-16 17:16:37 --> Config Class Initialized
INFO - 2021-04-16 17:16:37 --> Config Class Initialized
INFO - 2021-04-16 17:16:37 --> Hooks Class Initialized
INFO - 2021-04-16 17:16:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:37 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:16:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:37 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:16:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:37 --> Config Class Initialized
INFO - 2021-04-16 17:16:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:37 --> Hooks Class Initialized
INFO - 2021-04-16 17:16:37 --> URI Class Initialized
INFO - 2021-04-16 17:16:37 --> URI Class Initialized
INFO - 2021-04-16 17:16:37 --> Router Class Initialized
DEBUG - 2021-04-16 17:16:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:37 --> Output Class Initialized
INFO - 2021-04-16 17:16:37 --> URI Class Initialized
INFO - 2021-04-16 17:16:37 --> URI Class Initialized
INFO - 2021-04-16 17:16:37 --> Security Class Initialized
INFO - 2021-04-16 17:16:37 --> Router Class Initialized
DEBUG - 2021-04-16 17:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:37 --> Input Class Initialized
INFO - 2021-04-16 17:16:37 --> Output Class Initialized
INFO - 2021-04-16 17:16:37 --> Language Class Initialized
INFO - 2021-04-16 17:16:37 --> Security Class Initialized
INFO - 2021-04-16 17:16:37 --> Config Class Initialized
INFO - 2021-04-16 17:16:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:37 --> Input Class Initialized
INFO - 2021-04-16 17:16:37 --> Language Class Initialized
DEBUG - 2021-04-16 17:16:37 --> UTF-8 Support Enabled
ERROR - 2021-04-16 17:16:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:37 --> URI Class Initialized
INFO - 2021-04-16 17:16:37 --> Router Class Initialized
ERROR - 2021-04-16 17:16:37 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:16:37 --> Output Class Initialized
INFO - 2021-04-16 17:16:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:37 --> Input Class Initialized
INFO - 2021-04-16 17:16:37 --> Language Class Initialized
ERROR - 2021-04-16 17:16:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:37 --> Config Class Initialized
INFO - 2021-04-16 17:16:37 --> Hooks Class Initialized
INFO - 2021-04-16 17:16:37 --> Router Class Initialized
DEBUG - 2021-04-16 17:16:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:37 --> Router Class Initialized
INFO - 2021-04-16 17:16:37 --> URI Class Initialized
INFO - 2021-04-16 17:16:37 --> Config Class Initialized
INFO - 2021-04-16 17:16:37 --> Output Class Initialized
INFO - 2021-04-16 17:16:37 --> Hooks Class Initialized
INFO - 2021-04-16 17:16:37 --> Router Class Initialized
INFO - 2021-04-16 17:16:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:37 --> Output Class Initialized
INFO - 2021-04-16 17:16:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:37 --> Output Class Initialized
INFO - 2021-04-16 17:16:37 --> URI Class Initialized
DEBUG - 2021-04-16 17:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:37 --> Input Class Initialized
INFO - 2021-04-16 17:16:37 --> Security Class Initialized
INFO - 2021-04-16 17:16:37 --> Security Class Initialized
INFO - 2021-04-16 17:16:37 --> Router Class Initialized
DEBUG - 2021-04-16 17:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:37 --> Language Class Initialized
INFO - 2021-04-16 17:16:37 --> Input Class Initialized
DEBUG - 2021-04-16 17:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:37 --> Language Class Initialized
INFO - 2021-04-16 17:16:37 --> Input Class Initialized
INFO - 2021-04-16 17:16:37 --> Output Class Initialized
ERROR - 2021-04-16 17:16:37 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:16:37 --> Language Class Initialized
ERROR - 2021-04-16 17:16:37 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:16:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:37 --> Input Class Initialized
ERROR - 2021-04-16 17:16:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:37 --> Language Class Initialized
ERROR - 2021-04-16 17:16:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:37 --> Config Class Initialized
INFO - 2021-04-16 17:16:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:37 --> URI Class Initialized
INFO - 2021-04-16 17:16:37 --> Router Class Initialized
INFO - 2021-04-16 17:16:37 --> Output Class Initialized
INFO - 2021-04-16 17:16:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:37 --> Input Class Initialized
INFO - 2021-04-16 17:16:37 --> Language Class Initialized
ERROR - 2021-04-16 17:16:37 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:16:37 --> Config Class Initialized
INFO - 2021-04-16 17:16:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:37 --> URI Class Initialized
INFO - 2021-04-16 17:16:37 --> Router Class Initialized
INFO - 2021-04-16 17:16:37 --> Output Class Initialized
INFO - 2021-04-16 17:16:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:37 --> Input Class Initialized
INFO - 2021-04-16 17:16:37 --> Language Class Initialized
ERROR - 2021-04-16 17:16:37 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:16:37 --> Config Class Initialized
INFO - 2021-04-16 17:16:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:37 --> URI Class Initialized
INFO - 2021-04-16 17:16:37 --> Router Class Initialized
INFO - 2021-04-16 17:16:37 --> Output Class Initialized
INFO - 2021-04-16 17:16:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:37 --> Input Class Initialized
INFO - 2021-04-16 17:16:37 --> Language Class Initialized
ERROR - 2021-04-16 17:16:37 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:16:37 --> Config Class Initialized
INFO - 2021-04-16 17:16:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:37 --> URI Class Initialized
INFO - 2021-04-16 17:16:37 --> Router Class Initialized
INFO - 2021-04-16 17:16:37 --> Output Class Initialized
INFO - 2021-04-16 17:16:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:37 --> Input Class Initialized
INFO - 2021-04-16 17:16:37 --> Language Class Initialized
ERROR - 2021-04-16 17:16:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:37 --> Config Class Initialized
INFO - 2021-04-16 17:16:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:37 --> URI Class Initialized
INFO - 2021-04-16 17:16:37 --> Router Class Initialized
INFO - 2021-04-16 17:16:37 --> Output Class Initialized
INFO - 2021-04-16 17:16:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:37 --> Input Class Initialized
INFO - 2021-04-16 17:16:37 --> Language Class Initialized
ERROR - 2021-04-16 17:16:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:37 --> Config Class Initialized
INFO - 2021-04-16 17:16:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:37 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:37 --> URI Class Initialized
INFO - 2021-04-16 17:16:37 --> Router Class Initialized
INFO - 2021-04-16 17:16:37 --> Output Class Initialized
INFO - 2021-04-16 17:16:37 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:37 --> Input Class Initialized
INFO - 2021-04-16 17:16:37 --> Language Class Initialized
ERROR - 2021-04-16 17:16:37 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:38 --> Config Class Initialized
INFO - 2021-04-16 17:16:38 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:38 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:38 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:38 --> URI Class Initialized
INFO - 2021-04-16 17:16:38 --> Router Class Initialized
INFO - 2021-04-16 17:16:38 --> Output Class Initialized
INFO - 2021-04-16 17:16:38 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:38 --> Input Class Initialized
INFO - 2021-04-16 17:16:38 --> Language Class Initialized
ERROR - 2021-04-16 17:16:38 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:38 --> Config Class Initialized
INFO - 2021-04-16 17:16:38 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:38 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:38 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:38 --> URI Class Initialized
INFO - 2021-04-16 17:16:38 --> Router Class Initialized
INFO - 2021-04-16 17:16:38 --> Output Class Initialized
INFO - 2021-04-16 17:16:38 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:38 --> Input Class Initialized
INFO - 2021-04-16 17:16:38 --> Language Class Initialized
ERROR - 2021-04-16 17:16:38 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:38 --> Config Class Initialized
INFO - 2021-04-16 17:16:38 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:38 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:38 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:38 --> URI Class Initialized
INFO - 2021-04-16 17:16:38 --> Router Class Initialized
INFO - 2021-04-16 17:16:38 --> Output Class Initialized
INFO - 2021-04-16 17:16:38 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:38 --> Input Class Initialized
INFO - 2021-04-16 17:16:38 --> Language Class Initialized
ERROR - 2021-04-16 17:16:38 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:38 --> Config Class Initialized
INFO - 2021-04-16 17:16:38 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:38 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:38 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:38 --> URI Class Initialized
INFO - 2021-04-16 17:16:38 --> Router Class Initialized
INFO - 2021-04-16 17:16:38 --> Output Class Initialized
INFO - 2021-04-16 17:16:38 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:38 --> Input Class Initialized
INFO - 2021-04-16 17:16:38 --> Language Class Initialized
ERROR - 2021-04-16 17:16:38 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:16:38 --> Config Class Initialized
INFO - 2021-04-16 17:16:38 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:16:38 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:16:38 --> Utf8 Class Initialized
INFO - 2021-04-16 17:16:38 --> URI Class Initialized
INFO - 2021-04-16 17:16:38 --> Router Class Initialized
INFO - 2021-04-16 17:16:38 --> Output Class Initialized
INFO - 2021-04-16 17:16:38 --> Security Class Initialized
DEBUG - 2021-04-16 17:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:16:38 --> Input Class Initialized
INFO - 2021-04-16 17:16:38 --> Language Class Initialized
ERROR - 2021-04-16 17:16:38 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:17:38 --> Config Class Initialized
INFO - 2021-04-16 17:17:38 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:17:38 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:17:38 --> Utf8 Class Initialized
INFO - 2021-04-16 17:17:38 --> URI Class Initialized
INFO - 2021-04-16 17:17:38 --> Router Class Initialized
INFO - 2021-04-16 17:17:38 --> Output Class Initialized
INFO - 2021-04-16 17:17:38 --> Security Class Initialized
DEBUG - 2021-04-16 17:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:17:38 --> Input Class Initialized
INFO - 2021-04-16 17:17:38 --> Language Class Initialized
INFO - 2021-04-16 17:17:38 --> Loader Class Initialized
INFO - 2021-04-16 17:17:38 --> Helper loaded: url_helper
INFO - 2021-04-16 17:17:38 --> Helper loaded: form_helper
INFO - 2021-04-16 17:17:38 --> Helper loaded: common_helper
INFO - 2021-04-16 17:17:38 --> Helper loaded: util_helper
INFO - 2021-04-16 17:17:38 --> Helper loaded: user_helper
INFO - 2021-04-16 17:17:38 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:17:38 --> Form Validation Class Initialized
INFO - 2021-04-16 17:17:38 --> Model Class Initialized
INFO - 2021-04-16 17:17:38 --> Controller Class Initialized
INFO - 2021-04-16 17:17:38 --> Model Class Initialized
INFO - 2021-04-16 17:17:38 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 17:17:38 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 17:17:38 --> Final output sent to browser
DEBUG - 2021-04-16 17:17:38 --> Total execution time: 0.0292
INFO - 2021-04-16 17:17:38 --> Config Class Initialized
INFO - 2021-04-16 17:17:38 --> Hooks Class Initialized
INFO - 2021-04-16 17:17:38 --> Config Class Initialized
DEBUG - 2021-04-16 17:17:38 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:17:38 --> Utf8 Class Initialized
INFO - 2021-04-16 17:17:38 --> URI Class Initialized
INFO - 2021-04-16 17:17:38 --> Router Class Initialized
INFO - 2021-04-16 17:17:38 --> Output Class Initialized
INFO - 2021-04-16 17:17:38 --> Hooks Class Initialized
INFO - 2021-04-16 17:17:38 --> Config Class Initialized
INFO - 2021-04-16 17:17:38 --> Config Class Initialized
INFO - 2021-04-16 17:17:38 --> Security Class Initialized
INFO - 2021-04-16 17:17:38 --> Hooks Class Initialized
INFO - 2021-04-16 17:17:38 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:17:38 --> Input Class Initialized
INFO - 2021-04-16 17:17:38 --> Language Class Initialized
DEBUG - 2021-04-16 17:17:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:17:38 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:17:38 --> Utf8 Class Initialized
INFO - 2021-04-16 17:17:38 --> Utf8 Class Initialized
ERROR - 2021-04-16 17:17:38 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:17:38 --> URI Class Initialized
INFO - 2021-04-16 17:17:38 --> URI Class Initialized
INFO - 2021-04-16 17:17:38 --> Router Class Initialized
INFO - 2021-04-16 17:17:38 --> Config Class Initialized
INFO - 2021-04-16 17:17:38 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:17:38 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:17:38 --> Output Class Initialized
INFO - 2021-04-16 17:17:38 --> Utf8 Class Initialized
INFO - 2021-04-16 17:17:38 --> Security Class Initialized
INFO - 2021-04-16 17:17:38 --> URI Class Initialized
DEBUG - 2021-04-16 17:17:38 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:17:38 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:17:38 --> Router Class Initialized
INFO - 2021-04-16 17:17:38 --> Input Class Initialized
INFO - 2021-04-16 17:17:38 --> URI Class Initialized
INFO - 2021-04-16 17:17:38 --> Language Class Initialized
INFO - 2021-04-16 17:17:38 --> Router Class Initialized
INFO - 2021-04-16 17:17:38 --> Output Class Initialized
ERROR - 2021-04-16 17:17:39 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:17:39 --> Security Class Initialized
INFO - 2021-04-16 17:17:39 --> Output Class Initialized
DEBUG - 2021-04-16 17:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:17:39 --> Input Class Initialized
INFO - 2021-04-16 17:17:39 --> Router Class Initialized
INFO - 2021-04-16 17:17:39 --> Language Class Initialized
INFO - 2021-04-16 17:17:39 --> Security Class Initialized
DEBUG - 2021-04-16 17:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:17:39 --> Input Class Initialized
INFO - 2021-04-16 17:17:39 --> Output Class Initialized
INFO - 2021-04-16 17:17:39 --> Language Class Initialized
ERROR - 2021-04-16 17:17:39 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-16 17:17:39 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:17:39 --> Security Class Initialized
DEBUG - 2021-04-16 17:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:17:39 --> Input Class Initialized
INFO - 2021-04-16 17:17:39 --> Config Class Initialized
INFO - 2021-04-16 17:17:39 --> Hooks Class Initialized
INFO - 2021-04-16 17:17:39 --> Language Class Initialized
DEBUG - 2021-04-16 17:17:39 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:17:39 --> Utf8 Class Initialized
ERROR - 2021-04-16 17:17:39 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:17:39 --> URI Class Initialized
INFO - 2021-04-16 17:17:39 --> Router Class Initialized
INFO - 2021-04-16 17:17:39 --> Output Class Initialized
INFO - 2021-04-16 17:17:39 --> Config Class Initialized
INFO - 2021-04-16 17:17:39 --> Hooks Class Initialized
INFO - 2021-04-16 17:17:39 --> Security Class Initialized
DEBUG - 2021-04-16 17:17:39 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:17:39 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:17:39 --> Input Class Initialized
INFO - 2021-04-16 17:17:39 --> URI Class Initialized
INFO - 2021-04-16 17:17:39 --> Language Class Initialized
INFO - 2021-04-16 17:17:39 --> Router Class Initialized
ERROR - 2021-04-16 17:17:39 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:17:39 --> Config Class Initialized
INFO - 2021-04-16 17:17:39 --> Hooks Class Initialized
INFO - 2021-04-16 17:17:39 --> Output Class Initialized
DEBUG - 2021-04-16 17:17:39 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:17:39 --> Utf8 Class Initialized
INFO - 2021-04-16 17:17:39 --> Security Class Initialized
INFO - 2021-04-16 17:17:39 --> URI Class Initialized
INFO - 2021-04-16 17:17:39 --> Config Class Initialized
INFO - 2021-04-16 17:17:39 --> Hooks Class Initialized
INFO - 2021-04-16 17:17:39 --> Router Class Initialized
DEBUG - 2021-04-16 17:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:17:39 --> Input Class Initialized
INFO - 2021-04-16 17:17:39 --> Output Class Initialized
INFO - 2021-04-16 17:17:39 --> Language Class Initialized
DEBUG - 2021-04-16 17:17:39 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:17:39 --> Utf8 Class Initialized
INFO - 2021-04-16 17:17:39 --> Security Class Initialized
INFO - 2021-04-16 17:17:39 --> URI Class Initialized
ERROR - 2021-04-16 17:17:39 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-16 17:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:17:39 --> Input Class Initialized
INFO - 2021-04-16 17:17:39 --> Router Class Initialized
INFO - 2021-04-16 17:17:39 --> Language Class Initialized
INFO - 2021-04-16 17:17:39 --> Config Class Initialized
INFO - 2021-04-16 17:17:39 --> Hooks Class Initialized
ERROR - 2021-04-16 17:17:39 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:17:39 --> Output Class Initialized
INFO - 2021-04-16 17:17:39 --> Security Class Initialized
DEBUG - 2021-04-16 17:17:39 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:17:39 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:17:39 --> Input Class Initialized
INFO - 2021-04-16 17:17:39 --> Language Class Initialized
INFO - 2021-04-16 17:17:39 --> URI Class Initialized
INFO - 2021-04-16 17:17:39 --> Router Class Initialized
ERROR - 2021-04-16 17:17:39 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:17:39 --> Output Class Initialized
INFO - 2021-04-16 17:17:39 --> Security Class Initialized
DEBUG - 2021-04-16 17:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:17:39 --> Input Class Initialized
INFO - 2021-04-16 17:17:39 --> Language Class Initialized
ERROR - 2021-04-16 17:17:39 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:17:39 --> Config Class Initialized
INFO - 2021-04-16 17:17:39 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:17:39 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:17:39 --> Utf8 Class Initialized
INFO - 2021-04-16 17:17:39 --> URI Class Initialized
INFO - 2021-04-16 17:17:39 --> Router Class Initialized
INFO - 2021-04-16 17:17:39 --> Output Class Initialized
INFO - 2021-04-16 17:17:39 --> Security Class Initialized
DEBUG - 2021-04-16 17:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:17:39 --> Input Class Initialized
INFO - 2021-04-16 17:17:39 --> Language Class Initialized
ERROR - 2021-04-16 17:17:39 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:17:39 --> Config Class Initialized
INFO - 2021-04-16 17:17:39 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:17:39 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:17:39 --> Utf8 Class Initialized
INFO - 2021-04-16 17:17:39 --> URI Class Initialized
INFO - 2021-04-16 17:17:39 --> Router Class Initialized
INFO - 2021-04-16 17:17:39 --> Output Class Initialized
INFO - 2021-04-16 17:17:39 --> Security Class Initialized
DEBUG - 2021-04-16 17:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:17:39 --> Input Class Initialized
INFO - 2021-04-16 17:17:39 --> Language Class Initialized
ERROR - 2021-04-16 17:17:39 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:17:39 --> Config Class Initialized
INFO - 2021-04-16 17:17:39 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:17:39 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:17:39 --> Utf8 Class Initialized
INFO - 2021-04-16 17:17:39 --> URI Class Initialized
INFO - 2021-04-16 17:17:39 --> Router Class Initialized
INFO - 2021-04-16 17:17:39 --> Output Class Initialized
INFO - 2021-04-16 17:17:39 --> Security Class Initialized
DEBUG - 2021-04-16 17:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:17:39 --> Input Class Initialized
INFO - 2021-04-16 17:17:39 --> Language Class Initialized
ERROR - 2021-04-16 17:17:39 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:17:39 --> Config Class Initialized
INFO - 2021-04-16 17:17:39 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:17:39 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:17:39 --> Utf8 Class Initialized
INFO - 2021-04-16 17:17:39 --> URI Class Initialized
INFO - 2021-04-16 17:17:39 --> Router Class Initialized
INFO - 2021-04-16 17:17:39 --> Output Class Initialized
INFO - 2021-04-16 17:17:39 --> Security Class Initialized
DEBUG - 2021-04-16 17:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:17:39 --> Input Class Initialized
INFO - 2021-04-16 17:17:39 --> Language Class Initialized
ERROR - 2021-04-16 17:17:39 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:17:39 --> Config Class Initialized
INFO - 2021-04-16 17:17:39 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:17:39 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:17:39 --> Utf8 Class Initialized
INFO - 2021-04-16 17:17:39 --> URI Class Initialized
INFO - 2021-04-16 17:17:39 --> Router Class Initialized
INFO - 2021-04-16 17:17:39 --> Output Class Initialized
INFO - 2021-04-16 17:17:39 --> Security Class Initialized
DEBUG - 2021-04-16 17:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:17:39 --> Input Class Initialized
INFO - 2021-04-16 17:17:39 --> Language Class Initialized
ERROR - 2021-04-16 17:17:39 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:17:39 --> Config Class Initialized
INFO - 2021-04-16 17:17:39 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:17:39 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:17:39 --> Utf8 Class Initialized
INFO - 2021-04-16 17:17:39 --> URI Class Initialized
INFO - 2021-04-16 17:17:39 --> Router Class Initialized
INFO - 2021-04-16 17:17:39 --> Output Class Initialized
INFO - 2021-04-16 17:17:39 --> Security Class Initialized
DEBUG - 2021-04-16 17:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:17:39 --> Input Class Initialized
INFO - 2021-04-16 17:17:39 --> Language Class Initialized
ERROR - 2021-04-16 17:17:39 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:17:39 --> Config Class Initialized
INFO - 2021-04-16 17:17:39 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:17:39 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:17:39 --> Utf8 Class Initialized
INFO - 2021-04-16 17:17:39 --> URI Class Initialized
INFO - 2021-04-16 17:17:39 --> Router Class Initialized
INFO - 2021-04-16 17:17:39 --> Output Class Initialized
INFO - 2021-04-16 17:17:39 --> Security Class Initialized
DEBUG - 2021-04-16 17:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:17:39 --> Input Class Initialized
INFO - 2021-04-16 17:17:39 --> Language Class Initialized
ERROR - 2021-04-16 17:17:39 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:17:39 --> Config Class Initialized
INFO - 2021-04-16 17:17:39 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:17:39 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:17:39 --> Utf8 Class Initialized
INFO - 2021-04-16 17:17:39 --> URI Class Initialized
INFO - 2021-04-16 17:17:39 --> Router Class Initialized
INFO - 2021-04-16 17:17:39 --> Output Class Initialized
INFO - 2021-04-16 17:17:39 --> Security Class Initialized
DEBUG - 2021-04-16 17:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:17:39 --> Input Class Initialized
INFO - 2021-04-16 17:17:39 --> Language Class Initialized
ERROR - 2021-04-16 17:17:39 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:17:39 --> Config Class Initialized
INFO - 2021-04-16 17:17:39 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:17:39 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:17:39 --> Utf8 Class Initialized
INFO - 2021-04-16 17:17:39 --> URI Class Initialized
INFO - 2021-04-16 17:17:39 --> Router Class Initialized
INFO - 2021-04-16 17:17:39 --> Output Class Initialized
INFO - 2021-04-16 17:17:39 --> Security Class Initialized
DEBUG - 2021-04-16 17:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:17:39 --> Input Class Initialized
INFO - 2021-04-16 17:17:39 --> Language Class Initialized
ERROR - 2021-04-16 17:17:39 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:17:39 --> Config Class Initialized
INFO - 2021-04-16 17:17:39 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:17:39 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:17:39 --> Utf8 Class Initialized
INFO - 2021-04-16 17:17:39 --> URI Class Initialized
INFO - 2021-04-16 17:17:39 --> Router Class Initialized
INFO - 2021-04-16 17:17:39 --> Output Class Initialized
INFO - 2021-04-16 17:17:39 --> Security Class Initialized
DEBUG - 2021-04-16 17:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:17:39 --> Input Class Initialized
INFO - 2021-04-16 17:17:39 --> Language Class Initialized
ERROR - 2021-04-16 17:17:39 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:17:39 --> Config Class Initialized
INFO - 2021-04-16 17:17:39 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:17:39 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:17:39 --> Utf8 Class Initialized
INFO - 2021-04-16 17:17:39 --> URI Class Initialized
INFO - 2021-04-16 17:17:39 --> Router Class Initialized
INFO - 2021-04-16 17:17:39 --> Output Class Initialized
INFO - 2021-04-16 17:17:39 --> Security Class Initialized
DEBUG - 2021-04-16 17:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:17:39 --> Input Class Initialized
INFO - 2021-04-16 17:17:39 --> Language Class Initialized
ERROR - 2021-04-16 17:17:39 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:26:57 --> Config Class Initialized
INFO - 2021-04-16 17:26:57 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:26:57 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:26:57 --> Utf8 Class Initialized
INFO - 2021-04-16 17:26:57 --> URI Class Initialized
INFO - 2021-04-16 17:26:57 --> Router Class Initialized
INFO - 2021-04-16 17:26:57 --> Output Class Initialized
INFO - 2021-04-16 17:26:57 --> Security Class Initialized
DEBUG - 2021-04-16 17:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:26:57 --> Input Class Initialized
INFO - 2021-04-16 17:26:57 --> Language Class Initialized
INFO - 2021-04-16 17:26:57 --> Loader Class Initialized
INFO - 2021-04-16 17:26:57 --> Helper loaded: url_helper
INFO - 2021-04-16 17:26:57 --> Helper loaded: form_helper
INFO - 2021-04-16 17:26:57 --> Helper loaded: common_helper
INFO - 2021-04-16 17:26:57 --> Helper loaded: util_helper
INFO - 2021-04-16 17:26:57 --> Helper loaded: user_helper
INFO - 2021-04-16 17:26:57 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:26:57 --> Form Validation Class Initialized
INFO - 2021-04-16 17:26:57 --> Model Class Initialized
INFO - 2021-04-16 17:26:57 --> Controller Class Initialized
INFO - 2021-04-16 17:26:57 --> Model Class Initialized
INFO - 2021-04-16 17:26:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 17:26:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 17:26:57 --> Final output sent to browser
DEBUG - 2021-04-16 17:26:57 --> Total execution time: 0.0416
INFO - 2021-04-16 17:26:57 --> Config Class Initialized
INFO - 2021-04-16 17:26:57 --> Hooks Class Initialized
INFO - 2021-04-16 17:26:57 --> Config Class Initialized
INFO - 2021-04-16 17:26:57 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:26:57 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:26:57 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:26:57 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:26:57 --> Utf8 Class Initialized
INFO - 2021-04-16 17:26:57 --> URI Class Initialized
INFO - 2021-04-16 17:26:57 --> URI Class Initialized
INFO - 2021-04-16 17:26:57 --> Router Class Initialized
INFO - 2021-04-16 17:26:57 --> Router Class Initialized
INFO - 2021-04-16 17:26:57 --> Output Class Initialized
INFO - 2021-04-16 17:26:57 --> Output Class Initialized
INFO - 2021-04-16 17:26:57 --> Security Class Initialized
INFO - 2021-04-16 17:26:57 --> Security Class Initialized
DEBUG - 2021-04-16 17:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:26:57 --> Input Class Initialized
INFO - 2021-04-16 17:26:57 --> Input Class Initialized
INFO - 2021-04-16 17:26:57 --> Language Class Initialized
INFO - 2021-04-16 17:26:57 --> Language Class Initialized
ERROR - 2021-04-16 17:26:57 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-16 17:26:57 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:26:57 --> Config Class Initialized
INFO - 2021-04-16 17:26:57 --> Hooks Class Initialized
INFO - 2021-04-16 17:26:57 --> Config Class Initialized
INFO - 2021-04-16 17:26:57 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:26:57 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:26:57 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:26:57 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:26:57 --> Utf8 Class Initialized
INFO - 2021-04-16 17:26:57 --> URI Class Initialized
INFO - 2021-04-16 17:26:57 --> URI Class Initialized
INFO - 2021-04-16 17:26:57 --> Router Class Initialized
INFO - 2021-04-16 17:26:57 --> Router Class Initialized
INFO - 2021-04-16 17:26:57 --> Output Class Initialized
INFO - 2021-04-16 17:26:57 --> Output Class Initialized
INFO - 2021-04-16 17:26:57 --> Security Class Initialized
DEBUG - 2021-04-16 17:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:26:57 --> Security Class Initialized
INFO - 2021-04-16 17:26:57 --> Input Class Initialized
DEBUG - 2021-04-16 17:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:26:57 --> Language Class Initialized
INFO - 2021-04-16 17:26:57 --> Input Class Initialized
INFO - 2021-04-16 17:26:57 --> Language Class Initialized
INFO - 2021-04-16 17:26:57 --> Config Class Initialized
INFO - 2021-04-16 17:26:57 --> Hooks Class Initialized
ERROR - 2021-04-16 17:26:57 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-16 17:26:57 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-16 17:26:57 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:26:57 --> Utf8 Class Initialized
INFO - 2021-04-16 17:26:57 --> URI Class Initialized
INFO - 2021-04-16 17:26:57 --> Config Class Initialized
INFO - 2021-04-16 17:26:57 --> Hooks Class Initialized
INFO - 2021-04-16 17:26:57 --> Router Class Initialized
DEBUG - 2021-04-16 17:26:57 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:26:57 --> Utf8 Class Initialized
INFO - 2021-04-16 17:26:57 --> Output Class Initialized
INFO - 2021-04-16 17:26:57 --> URI Class Initialized
INFO - 2021-04-16 17:26:57 --> Security Class Initialized
INFO - 2021-04-16 17:26:57 --> Router Class Initialized
DEBUG - 2021-04-16 17:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:26:57 --> Config Class Initialized
INFO - 2021-04-16 17:26:57 --> Hooks Class Initialized
INFO - 2021-04-16 17:26:57 --> Output Class Initialized
INFO - 2021-04-16 17:26:57 --> Config Class Initialized
INFO - 2021-04-16 17:26:57 --> Security Class Initialized
INFO - 2021-04-16 17:26:57 --> Input Class Initialized
INFO - 2021-04-16 17:26:57 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:26:58 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:26:58 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:26:58 --> Input Class Initialized
INFO - 2021-04-16 17:26:58 --> Language Class Initialized
INFO - 2021-04-16 17:26:58 --> URI Class Initialized
INFO - 2021-04-16 17:26:58 --> Language Class Initialized
DEBUG - 2021-04-16 17:26:58 --> UTF-8 Support Enabled
ERROR - 2021-04-16 17:26:58 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:26:58 --> Utf8 Class Initialized
ERROR - 2021-04-16 17:26:58 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:26:58 --> URI Class Initialized
INFO - 2021-04-16 17:26:58 --> Config Class Initialized
INFO - 2021-04-16 17:26:58 --> Hooks Class Initialized
INFO - 2021-04-16 17:26:58 --> Router Class Initialized
INFO - 2021-04-16 17:26:58 --> Router Class Initialized
DEBUG - 2021-04-16 17:26:58 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:26:58 --> Utf8 Class Initialized
INFO - 2021-04-16 17:26:58 --> Output Class Initialized
INFO - 2021-04-16 17:26:58 --> URI Class Initialized
INFO - 2021-04-16 17:26:58 --> Output Class Initialized
INFO - 2021-04-16 17:26:58 --> Security Class Initialized
INFO - 2021-04-16 17:26:58 --> Router Class Initialized
INFO - 2021-04-16 17:26:58 --> Security Class Initialized
DEBUG - 2021-04-16 17:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:26:58 --> Input Class Initialized
INFO - 2021-04-16 17:26:58 --> Output Class Initialized
INFO - 2021-04-16 17:26:58 --> Language Class Initialized
DEBUG - 2021-04-16 17:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:26:58 --> Input Class Initialized
INFO - 2021-04-16 17:26:58 --> Security Class Initialized
INFO - 2021-04-16 17:26:58 --> Language Class Initialized
ERROR - 2021-04-16 17:26:58 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-16 17:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:26:58 --> Input Class Initialized
ERROR - 2021-04-16 17:26:58 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:26:58 --> Language Class Initialized
ERROR - 2021-04-16 17:26:58 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:26:58 --> Config Class Initialized
INFO - 2021-04-16 17:26:58 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:26:58 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:26:58 --> Utf8 Class Initialized
INFO - 2021-04-16 17:26:58 --> URI Class Initialized
INFO - 2021-04-16 17:26:58 --> Router Class Initialized
INFO - 2021-04-16 17:26:58 --> Output Class Initialized
INFO - 2021-04-16 17:26:58 --> Security Class Initialized
DEBUG - 2021-04-16 17:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:26:58 --> Input Class Initialized
INFO - 2021-04-16 17:26:58 --> Language Class Initialized
ERROR - 2021-04-16 17:26:58 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:26:58 --> Config Class Initialized
INFO - 2021-04-16 17:26:58 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:26:58 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:26:58 --> Utf8 Class Initialized
INFO - 2021-04-16 17:26:58 --> URI Class Initialized
INFO - 2021-04-16 17:26:58 --> Router Class Initialized
INFO - 2021-04-16 17:26:58 --> Output Class Initialized
INFO - 2021-04-16 17:26:58 --> Security Class Initialized
DEBUG - 2021-04-16 17:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:26:58 --> Input Class Initialized
INFO - 2021-04-16 17:26:58 --> Language Class Initialized
ERROR - 2021-04-16 17:26:58 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:26:58 --> Config Class Initialized
INFO - 2021-04-16 17:26:58 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:26:58 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:26:58 --> Utf8 Class Initialized
INFO - 2021-04-16 17:26:58 --> URI Class Initialized
INFO - 2021-04-16 17:26:58 --> Router Class Initialized
INFO - 2021-04-16 17:26:58 --> Output Class Initialized
INFO - 2021-04-16 17:26:58 --> Security Class Initialized
DEBUG - 2021-04-16 17:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:26:58 --> Input Class Initialized
INFO - 2021-04-16 17:26:58 --> Language Class Initialized
ERROR - 2021-04-16 17:26:58 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:26:58 --> Config Class Initialized
INFO - 2021-04-16 17:26:58 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:26:58 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:26:58 --> Utf8 Class Initialized
INFO - 2021-04-16 17:26:58 --> URI Class Initialized
INFO - 2021-04-16 17:26:58 --> Router Class Initialized
INFO - 2021-04-16 17:26:58 --> Output Class Initialized
INFO - 2021-04-16 17:26:58 --> Security Class Initialized
DEBUG - 2021-04-16 17:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:26:58 --> Input Class Initialized
INFO - 2021-04-16 17:26:58 --> Language Class Initialized
ERROR - 2021-04-16 17:26:58 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:26:58 --> Config Class Initialized
INFO - 2021-04-16 17:26:58 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:26:58 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:26:58 --> Utf8 Class Initialized
INFO - 2021-04-16 17:26:58 --> URI Class Initialized
INFO - 2021-04-16 17:26:58 --> Router Class Initialized
INFO - 2021-04-16 17:26:58 --> Output Class Initialized
INFO - 2021-04-16 17:26:58 --> Security Class Initialized
DEBUG - 2021-04-16 17:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:26:58 --> Input Class Initialized
INFO - 2021-04-16 17:26:58 --> Language Class Initialized
ERROR - 2021-04-16 17:26:58 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:26:58 --> Config Class Initialized
INFO - 2021-04-16 17:26:58 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:26:58 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:26:58 --> Utf8 Class Initialized
INFO - 2021-04-16 17:26:58 --> URI Class Initialized
INFO - 2021-04-16 17:26:58 --> Router Class Initialized
INFO - 2021-04-16 17:26:58 --> Output Class Initialized
INFO - 2021-04-16 17:26:58 --> Security Class Initialized
DEBUG - 2021-04-16 17:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:26:58 --> Input Class Initialized
INFO - 2021-04-16 17:26:58 --> Language Class Initialized
ERROR - 2021-04-16 17:26:58 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:26:58 --> Config Class Initialized
INFO - 2021-04-16 17:26:58 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:26:58 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:26:58 --> Utf8 Class Initialized
INFO - 2021-04-16 17:26:58 --> URI Class Initialized
INFO - 2021-04-16 17:26:58 --> Router Class Initialized
INFO - 2021-04-16 17:26:58 --> Output Class Initialized
INFO - 2021-04-16 17:26:58 --> Security Class Initialized
DEBUG - 2021-04-16 17:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:26:58 --> Input Class Initialized
INFO - 2021-04-16 17:26:58 --> Language Class Initialized
ERROR - 2021-04-16 17:26:58 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:26:58 --> Config Class Initialized
INFO - 2021-04-16 17:26:58 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:26:58 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:26:58 --> Utf8 Class Initialized
INFO - 2021-04-16 17:26:58 --> URI Class Initialized
INFO - 2021-04-16 17:26:58 --> Router Class Initialized
INFO - 2021-04-16 17:26:58 --> Output Class Initialized
INFO - 2021-04-16 17:26:58 --> Security Class Initialized
DEBUG - 2021-04-16 17:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:26:58 --> Input Class Initialized
INFO - 2021-04-16 17:26:58 --> Language Class Initialized
ERROR - 2021-04-16 17:26:58 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:26:58 --> Config Class Initialized
INFO - 2021-04-16 17:26:58 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:26:58 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:26:58 --> Utf8 Class Initialized
INFO - 2021-04-16 17:26:58 --> URI Class Initialized
INFO - 2021-04-16 17:26:58 --> Router Class Initialized
INFO - 2021-04-16 17:26:58 --> Output Class Initialized
INFO - 2021-04-16 17:26:58 --> Security Class Initialized
DEBUG - 2021-04-16 17:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:26:58 --> Input Class Initialized
INFO - 2021-04-16 17:26:58 --> Language Class Initialized
ERROR - 2021-04-16 17:26:58 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:26:58 --> Config Class Initialized
INFO - 2021-04-16 17:26:58 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:26:58 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:26:58 --> Utf8 Class Initialized
INFO - 2021-04-16 17:26:58 --> URI Class Initialized
INFO - 2021-04-16 17:26:58 --> Router Class Initialized
INFO - 2021-04-16 17:26:58 --> Output Class Initialized
INFO - 2021-04-16 17:26:58 --> Security Class Initialized
DEBUG - 2021-04-16 17:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:26:58 --> Input Class Initialized
INFO - 2021-04-16 17:26:58 --> Language Class Initialized
ERROR - 2021-04-16 17:26:58 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:26:58 --> Config Class Initialized
INFO - 2021-04-16 17:26:58 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:26:58 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:26:58 --> Utf8 Class Initialized
INFO - 2021-04-16 17:26:58 --> URI Class Initialized
INFO - 2021-04-16 17:26:58 --> Router Class Initialized
INFO - 2021-04-16 17:26:58 --> Output Class Initialized
INFO - 2021-04-16 17:26:58 --> Security Class Initialized
DEBUG - 2021-04-16 17:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:26:58 --> Input Class Initialized
INFO - 2021-04-16 17:26:58 --> Language Class Initialized
ERROR - 2021-04-16 17:26:58 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:27:21 --> Config Class Initialized
INFO - 2021-04-16 17:27:21 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:27:21 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:27:21 --> Utf8 Class Initialized
INFO - 2021-04-16 17:27:21 --> URI Class Initialized
INFO - 2021-04-16 17:27:21 --> Router Class Initialized
INFO - 2021-04-16 17:27:21 --> Output Class Initialized
INFO - 2021-04-16 17:27:21 --> Security Class Initialized
DEBUG - 2021-04-16 17:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:27:21 --> Input Class Initialized
INFO - 2021-04-16 17:27:21 --> Language Class Initialized
INFO - 2021-04-16 17:27:21 --> Loader Class Initialized
INFO - 2021-04-16 17:27:21 --> Helper loaded: url_helper
INFO - 2021-04-16 17:27:21 --> Helper loaded: form_helper
INFO - 2021-04-16 17:27:21 --> Helper loaded: common_helper
INFO - 2021-04-16 17:27:21 --> Helper loaded: util_helper
INFO - 2021-04-16 17:27:21 --> Helper loaded: user_helper
INFO - 2021-04-16 17:27:21 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:27:21 --> Form Validation Class Initialized
INFO - 2021-04-16 17:27:21 --> Model Class Initialized
INFO - 2021-04-16 17:27:21 --> Controller Class Initialized
INFO - 2021-04-16 17:27:21 --> Model Class Initialized
INFO - 2021-04-16 17:27:21 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 17:27:21 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 17:27:21 --> Final output sent to browser
DEBUG - 2021-04-16 17:27:21 --> Total execution time: 0.0295
INFO - 2021-04-16 17:27:21 --> Config Class Initialized
INFO - 2021-04-16 17:27:21 --> Hooks Class Initialized
INFO - 2021-04-16 17:27:21 --> Config Class Initialized
INFO - 2021-04-16 17:27:21 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:27:21 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:27:21 --> Utf8 Class Initialized
INFO - 2021-04-16 17:27:21 --> URI Class Initialized
DEBUG - 2021-04-16 17:27:21 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:27:21 --> Utf8 Class Initialized
INFO - 2021-04-16 17:27:21 --> URI Class Initialized
INFO - 2021-04-16 17:27:21 --> Router Class Initialized
INFO - 2021-04-16 17:27:21 --> Router Class Initialized
INFO - 2021-04-16 17:27:21 --> Output Class Initialized
INFO - 2021-04-16 17:27:21 --> Output Class Initialized
INFO - 2021-04-16 17:27:21 --> Security Class Initialized
DEBUG - 2021-04-16 17:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:27:21 --> Security Class Initialized
INFO - 2021-04-16 17:27:21 --> Input Class Initialized
INFO - 2021-04-16 17:27:21 --> Language Class Initialized
DEBUG - 2021-04-16 17:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:27:21 --> Input Class Initialized
INFO - 2021-04-16 17:27:21 --> Language Class Initialized
ERROR - 2021-04-16 17:27:21 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-16 17:27:21 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:27:21 --> Config Class Initialized
INFO - 2021-04-16 17:27:21 --> Hooks Class Initialized
INFO - 2021-04-16 17:27:21 --> Config Class Initialized
INFO - 2021-04-16 17:27:21 --> Hooks Class Initialized
INFO - 2021-04-16 17:27:21 --> Config Class Initialized
DEBUG - 2021-04-16 17:27:21 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:27:21 --> Hooks Class Initialized
INFO - 2021-04-16 17:27:21 --> Config Class Initialized
INFO - 2021-04-16 17:27:21 --> Utf8 Class Initialized
INFO - 2021-04-16 17:27:21 --> Hooks Class Initialized
INFO - 2021-04-16 17:27:21 --> Config Class Initialized
INFO - 2021-04-16 17:27:21 --> Hooks Class Initialized
INFO - 2021-04-16 17:27:21 --> URI Class Initialized
DEBUG - 2021-04-16 17:27:21 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:27:21 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:27:21 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:27:21 --> Utf8 Class Initialized
INFO - 2021-04-16 17:27:21 --> URI Class Initialized
INFO - 2021-04-16 17:27:21 --> Router Class Initialized
DEBUG - 2021-04-16 17:27:21 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:27:21 --> URI Class Initialized
INFO - 2021-04-16 17:27:21 --> Utf8 Class Initialized
INFO - 2021-04-16 17:27:21 --> Router Class Initialized
INFO - 2021-04-16 17:27:21 --> Output Class Initialized
INFO - 2021-04-16 17:27:21 --> Router Class Initialized
INFO - 2021-04-16 17:27:21 --> URI Class Initialized
INFO - 2021-04-16 17:27:21 --> Output Class Initialized
INFO - 2021-04-16 17:27:21 --> Security Class Initialized
INFO - 2021-04-16 17:27:21 --> Output Class Initialized
INFO - 2021-04-16 17:27:21 --> Router Class Initialized
INFO - 2021-04-16 17:27:21 --> Security Class Initialized
DEBUG - 2021-04-16 17:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:27:21 --> Security Class Initialized
DEBUG - 2021-04-16 17:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:27:21 --> Input Class Initialized
INFO - 2021-04-16 17:27:21 --> Language Class Initialized
DEBUG - 2021-04-16 17:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:27:21 --> Input Class Initialized
INFO - 2021-04-16 17:27:21 --> Output Class Initialized
INFO - 2021-04-16 17:27:21 --> Input Class Initialized
INFO - 2021-04-16 17:27:21 --> Language Class Initialized
ERROR - 2021-04-16 17:27:21 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-16 17:27:21 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:27:21 --> Security Class Initialized
INFO - 2021-04-16 17:27:21 --> Language Class Initialized
DEBUG - 2021-04-16 17:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:27:21 --> Input Class Initialized
ERROR - 2021-04-16 17:27:21 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:27:21 --> Language Class Initialized
ERROR - 2021-04-16 17:27:21 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:27:21 --> Config Class Initialized
INFO - 2021-04-16 17:27:21 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:27:21 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:27:21 --> Utf8 Class Initialized
INFO - 2021-04-16 17:27:21 --> URI Class Initialized
DEBUG - 2021-04-16 17:27:21 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:27:21 --> Utf8 Class Initialized
INFO - 2021-04-16 17:27:21 --> Router Class Initialized
INFO - 2021-04-16 17:27:21 --> URI Class Initialized
INFO - 2021-04-16 17:27:21 --> Output Class Initialized
INFO - 2021-04-16 17:27:21 --> Router Class Initialized
INFO - 2021-04-16 17:27:21 --> Security Class Initialized
INFO - 2021-04-16 17:27:21 --> Config Class Initialized
INFO - 2021-04-16 17:27:21 --> Output Class Initialized
INFO - 2021-04-16 17:27:21 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:27:21 --> Security Class Initialized
INFO - 2021-04-16 17:27:21 --> Input Class Initialized
INFO - 2021-04-16 17:27:21 --> Language Class Initialized
DEBUG - 2021-04-16 17:27:21 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:27:21 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:27:21 --> Input Class Initialized
INFO - 2021-04-16 17:27:21 --> URI Class Initialized
INFO - 2021-04-16 17:27:21 --> Language Class Initialized
ERROR - 2021-04-16 17:27:21 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:27:21 --> Router Class Initialized
ERROR - 2021-04-16 17:27:21 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:27:21 --> Output Class Initialized
INFO - 2021-04-16 17:27:21 --> Security Class Initialized
DEBUG - 2021-04-16 17:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:27:21 --> Input Class Initialized
INFO - 2021-04-16 17:27:21 --> Language Class Initialized
ERROR - 2021-04-16 17:27:21 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:27:21 --> Config Class Initialized
INFO - 2021-04-16 17:27:21 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:27:21 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:27:21 --> Utf8 Class Initialized
INFO - 2021-04-16 17:27:21 --> URI Class Initialized
INFO - 2021-04-16 17:27:21 --> Router Class Initialized
INFO - 2021-04-16 17:27:21 --> Output Class Initialized
INFO - 2021-04-16 17:27:21 --> Security Class Initialized
DEBUG - 2021-04-16 17:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:27:21 --> Input Class Initialized
INFO - 2021-04-16 17:27:21 --> Language Class Initialized
ERROR - 2021-04-16 17:27:21 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:27:21 --> Config Class Initialized
INFO - 2021-04-16 17:27:21 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:27:21 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:27:21 --> Utf8 Class Initialized
INFO - 2021-04-16 17:27:21 --> URI Class Initialized
INFO - 2021-04-16 17:27:21 --> Router Class Initialized
INFO - 2021-04-16 17:27:21 --> Output Class Initialized
INFO - 2021-04-16 17:27:21 --> Security Class Initialized
DEBUG - 2021-04-16 17:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:27:21 --> Input Class Initialized
INFO - 2021-04-16 17:27:21 --> Language Class Initialized
ERROR - 2021-04-16 17:27:21 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:27:21 --> Config Class Initialized
INFO - 2021-04-16 17:27:21 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:27:21 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:27:21 --> Utf8 Class Initialized
INFO - 2021-04-16 17:27:21 --> URI Class Initialized
INFO - 2021-04-16 17:27:21 --> Router Class Initialized
INFO - 2021-04-16 17:27:21 --> Output Class Initialized
INFO - 2021-04-16 17:27:21 --> Security Class Initialized
DEBUG - 2021-04-16 17:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:27:21 --> Input Class Initialized
INFO - 2021-04-16 17:27:21 --> Language Class Initialized
ERROR - 2021-04-16 17:27:21 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:27:21 --> Config Class Initialized
INFO - 2021-04-16 17:27:21 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:27:21 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:27:21 --> Utf8 Class Initialized
INFO - 2021-04-16 17:27:21 --> URI Class Initialized
INFO - 2021-04-16 17:27:21 --> Router Class Initialized
INFO - 2021-04-16 17:27:21 --> Output Class Initialized
INFO - 2021-04-16 17:27:21 --> Security Class Initialized
DEBUG - 2021-04-16 17:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:27:21 --> Input Class Initialized
INFO - 2021-04-16 17:27:21 --> Language Class Initialized
ERROR - 2021-04-16 17:27:21 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:27:21 --> Config Class Initialized
INFO - 2021-04-16 17:27:21 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:27:21 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:27:21 --> Utf8 Class Initialized
INFO - 2021-04-16 17:27:21 --> URI Class Initialized
INFO - 2021-04-16 17:27:21 --> Router Class Initialized
INFO - 2021-04-16 17:27:21 --> Output Class Initialized
INFO - 2021-04-16 17:27:21 --> Security Class Initialized
DEBUG - 2021-04-16 17:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:27:21 --> Input Class Initialized
INFO - 2021-04-16 17:27:21 --> Language Class Initialized
ERROR - 2021-04-16 17:27:21 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:27:21 --> Config Class Initialized
INFO - 2021-04-16 17:27:21 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:27:21 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:27:21 --> Utf8 Class Initialized
INFO - 2021-04-16 17:27:21 --> URI Class Initialized
INFO - 2021-04-16 17:27:21 --> Router Class Initialized
INFO - 2021-04-16 17:27:21 --> Output Class Initialized
INFO - 2021-04-16 17:27:21 --> Security Class Initialized
DEBUG - 2021-04-16 17:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:27:21 --> Input Class Initialized
INFO - 2021-04-16 17:27:21 --> Language Class Initialized
ERROR - 2021-04-16 17:27:21 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:27:21 --> Config Class Initialized
INFO - 2021-04-16 17:27:21 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:27:21 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:27:21 --> Utf8 Class Initialized
INFO - 2021-04-16 17:27:21 --> URI Class Initialized
INFO - 2021-04-16 17:27:21 --> Router Class Initialized
INFO - 2021-04-16 17:27:21 --> Output Class Initialized
INFO - 2021-04-16 17:27:21 --> Security Class Initialized
DEBUG - 2021-04-16 17:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:27:21 --> Input Class Initialized
INFO - 2021-04-16 17:27:21 --> Language Class Initialized
ERROR - 2021-04-16 17:27:21 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:51:57 --> Config Class Initialized
INFO - 2021-04-16 17:51:57 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:51:57 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:51:57 --> Utf8 Class Initialized
INFO - 2021-04-16 17:51:57 --> URI Class Initialized
INFO - 2021-04-16 17:51:57 --> Router Class Initialized
INFO - 2021-04-16 17:51:57 --> Output Class Initialized
INFO - 2021-04-16 17:51:57 --> Security Class Initialized
DEBUG - 2021-04-16 17:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:51:57 --> Input Class Initialized
INFO - 2021-04-16 17:51:57 --> Language Class Initialized
INFO - 2021-04-16 17:51:57 --> Loader Class Initialized
INFO - 2021-04-16 17:51:57 --> Helper loaded: url_helper
INFO - 2021-04-16 17:51:57 --> Helper loaded: form_helper
INFO - 2021-04-16 17:51:57 --> Helper loaded: common_helper
INFO - 2021-04-16 17:51:57 --> Helper loaded: util_helper
INFO - 2021-04-16 17:51:57 --> Helper loaded: user_helper
INFO - 2021-04-16 17:51:57 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:51:57 --> Form Validation Class Initialized
INFO - 2021-04-16 17:51:57 --> Model Class Initialized
INFO - 2021-04-16 17:51:57 --> Controller Class Initialized
INFO - 2021-04-16 17:51:57 --> Model Class Initialized
INFO - 2021-04-16 17:51:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 17:51:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 17:51:57 --> Final output sent to browser
DEBUG - 2021-04-16 17:51:57 --> Total execution time: 0.0309
INFO - 2021-04-16 17:51:57 --> Config Class Initialized
INFO - 2021-04-16 17:51:57 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:51:57 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:51:57 --> Utf8 Class Initialized
INFO - 2021-04-16 17:51:57 --> URI Class Initialized
INFO - 2021-04-16 17:51:57 --> Config Class Initialized
INFO - 2021-04-16 17:51:57 --> Hooks Class Initialized
INFO - 2021-04-16 17:51:57 --> Config Class Initialized
INFO - 2021-04-16 17:51:57 --> Hooks Class Initialized
INFO - 2021-04-16 17:51:57 --> Router Class Initialized
INFO - 2021-04-16 17:51:57 --> Config Class Initialized
INFO - 2021-04-16 17:51:57 --> Config Class Initialized
DEBUG - 2021-04-16 17:51:57 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:51:57 --> Hooks Class Initialized
INFO - 2021-04-16 17:51:57 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:51:57 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:51:57 --> Utf8 Class Initialized
INFO - 2021-04-16 17:51:57 --> Utf8 Class Initialized
INFO - 2021-04-16 17:51:57 --> Output Class Initialized
INFO - 2021-04-16 17:51:57 --> URI Class Initialized
INFO - 2021-04-16 17:51:57 --> Security Class Initialized
DEBUG - 2021-04-16 17:51:57 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:51:57 --> URI Class Initialized
DEBUG - 2021-04-16 17:51:57 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:51:57 --> Router Class Initialized
INFO - 2021-04-16 17:51:57 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:51:57 --> Utf8 Class Initialized
INFO - 2021-04-16 17:51:57 --> Input Class Initialized
INFO - 2021-04-16 17:51:57 --> Language Class Initialized
INFO - 2021-04-16 17:51:57 --> Router Class Initialized
INFO - 2021-04-16 17:51:57 --> Output Class Initialized
INFO - 2021-04-16 17:51:57 --> URI Class Initialized
INFO - 2021-04-16 17:51:57 --> URI Class Initialized
INFO - 2021-04-16 17:51:57 --> Security Class Initialized
INFO - 2021-04-16 17:51:57 --> Output Class Initialized
INFO - 2021-04-16 17:51:57 --> Router Class Initialized
ERROR - 2021-04-16 17:51:57 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-16 17:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:51:57 --> Input Class Initialized
INFO - 2021-04-16 17:51:57 --> Router Class Initialized
INFO - 2021-04-16 17:51:57 --> Security Class Initialized
INFO - 2021-04-16 17:51:57 --> Language Class Initialized
INFO - 2021-04-16 17:51:57 --> Output Class Initialized
DEBUG - 2021-04-16 17:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:51:57 --> Input Class Initialized
INFO - 2021-04-16 17:51:57 --> Output Class Initialized
INFO - 2021-04-16 17:51:57 --> Security Class Initialized
ERROR - 2021-04-16 17:51:57 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:51:57 --> Language Class Initialized
INFO - 2021-04-16 17:51:57 --> Security Class Initialized
DEBUG - 2021-04-16 17:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:51:57 --> Input Class Initialized
ERROR - 2021-04-16 17:51:57 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:51:57 --> Language Class Initialized
DEBUG - 2021-04-16 17:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:51:57 --> Input Class Initialized
INFO - 2021-04-16 17:51:57 --> Language Class Initialized
ERROR - 2021-04-16 17:51:57 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-16 17:51:57 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:51:57 --> Config Class Initialized
INFO - 2021-04-16 17:51:57 --> Hooks Class Initialized
INFO - 2021-04-16 17:51:57 --> Config Class Initialized
INFO - 2021-04-16 17:51:57 --> Hooks Class Initialized
INFO - 2021-04-16 17:51:57 --> Config Class Initialized
DEBUG - 2021-04-16 17:51:57 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:51:57 --> Utf8 Class Initialized
INFO - 2021-04-16 17:51:57 --> Hooks Class Initialized
INFO - 2021-04-16 17:51:57 --> URI Class Initialized
DEBUG - 2021-04-16 17:51:57 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:51:57 --> Utf8 Class Initialized
INFO - 2021-04-16 17:51:57 --> Router Class Initialized
INFO - 2021-04-16 17:51:57 --> URI Class Initialized
DEBUG - 2021-04-16 17:51:57 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:51:57 --> Output Class Initialized
INFO - 2021-04-16 17:51:57 --> Utf8 Class Initialized
INFO - 2021-04-16 17:51:57 --> Security Class Initialized
INFO - 2021-04-16 17:51:57 --> Router Class Initialized
INFO - 2021-04-16 17:51:57 --> URI Class Initialized
DEBUG - 2021-04-16 17:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:51:57 --> Input Class Initialized
INFO - 2021-04-16 17:51:57 --> Language Class Initialized
INFO - 2021-04-16 17:51:57 --> Router Class Initialized
INFO - 2021-04-16 17:51:57 --> Output Class Initialized
ERROR - 2021-04-16 17:51:57 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:51:57 --> Security Class Initialized
INFO - 2021-04-16 17:51:57 --> Output Class Initialized
DEBUG - 2021-04-16 17:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:51:57 --> Input Class Initialized
INFO - 2021-04-16 17:51:57 --> Security Class Initialized
INFO - 2021-04-16 17:51:57 --> Language Class Initialized
DEBUG - 2021-04-16 17:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:51:57 --> Input Class Initialized
INFO - 2021-04-16 17:51:57 --> Config Class Initialized
ERROR - 2021-04-16 17:51:57 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:51:57 --> Language Class Initialized
INFO - 2021-04-16 17:51:57 --> Hooks Class Initialized
ERROR - 2021-04-16 17:51:57 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-16 17:51:57 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:51:57 --> Utf8 Class Initialized
INFO - 2021-04-16 17:51:57 --> URI Class Initialized
INFO - 2021-04-16 17:51:57 --> Router Class Initialized
INFO - 2021-04-16 17:51:57 --> Output Class Initialized
INFO - 2021-04-16 17:51:57 --> Security Class Initialized
DEBUG - 2021-04-16 17:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:51:57 --> Input Class Initialized
INFO - 2021-04-16 17:51:57 --> Language Class Initialized
ERROR - 2021-04-16 17:51:57 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:51:57 --> Config Class Initialized
INFO - 2021-04-16 17:51:57 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:51:57 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:51:57 --> Utf8 Class Initialized
INFO - 2021-04-16 17:51:57 --> URI Class Initialized
INFO - 2021-04-16 17:51:57 --> Router Class Initialized
INFO - 2021-04-16 17:51:57 --> Output Class Initialized
INFO - 2021-04-16 17:51:57 --> Security Class Initialized
DEBUG - 2021-04-16 17:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:51:57 --> Input Class Initialized
INFO - 2021-04-16 17:51:57 --> Language Class Initialized
ERROR - 2021-04-16 17:51:57 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:51:57 --> Config Class Initialized
INFO - 2021-04-16 17:51:57 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:51:57 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:51:57 --> Utf8 Class Initialized
INFO - 2021-04-16 17:51:57 --> URI Class Initialized
INFO - 2021-04-16 17:51:57 --> Router Class Initialized
INFO - 2021-04-16 17:51:57 --> Output Class Initialized
INFO - 2021-04-16 17:51:57 --> Security Class Initialized
DEBUG - 2021-04-16 17:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:51:57 --> Input Class Initialized
INFO - 2021-04-16 17:51:57 --> Language Class Initialized
ERROR - 2021-04-16 17:51:57 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:51:57 --> Config Class Initialized
INFO - 2021-04-16 17:51:57 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:51:57 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:51:57 --> Utf8 Class Initialized
INFO - 2021-04-16 17:51:57 --> URI Class Initialized
INFO - 2021-04-16 17:51:57 --> Router Class Initialized
INFO - 2021-04-16 17:51:57 --> Output Class Initialized
INFO - 2021-04-16 17:51:57 --> Security Class Initialized
DEBUG - 2021-04-16 17:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:51:57 --> Input Class Initialized
INFO - 2021-04-16 17:51:57 --> Language Class Initialized
ERROR - 2021-04-16 17:51:57 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:51:57 --> Config Class Initialized
INFO - 2021-04-16 17:51:57 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:51:57 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:51:57 --> Utf8 Class Initialized
INFO - 2021-04-16 17:51:57 --> URI Class Initialized
INFO - 2021-04-16 17:51:57 --> Router Class Initialized
INFO - 2021-04-16 17:51:57 --> Output Class Initialized
INFO - 2021-04-16 17:51:57 --> Security Class Initialized
DEBUG - 2021-04-16 17:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:51:57 --> Input Class Initialized
INFO - 2021-04-16 17:51:57 --> Language Class Initialized
ERROR - 2021-04-16 17:51:57 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:51:57 --> Config Class Initialized
INFO - 2021-04-16 17:51:57 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:51:57 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:51:57 --> Utf8 Class Initialized
INFO - 2021-04-16 17:51:57 --> URI Class Initialized
INFO - 2021-04-16 17:51:57 --> Router Class Initialized
INFO - 2021-04-16 17:51:57 --> Output Class Initialized
INFO - 2021-04-16 17:51:57 --> Security Class Initialized
DEBUG - 2021-04-16 17:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:51:57 --> Input Class Initialized
INFO - 2021-04-16 17:51:57 --> Language Class Initialized
ERROR - 2021-04-16 17:51:57 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:51:57 --> Config Class Initialized
INFO - 2021-04-16 17:51:57 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:51:57 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:51:57 --> Utf8 Class Initialized
INFO - 2021-04-16 17:51:57 --> URI Class Initialized
INFO - 2021-04-16 17:51:57 --> Router Class Initialized
INFO - 2021-04-16 17:51:57 --> Output Class Initialized
INFO - 2021-04-16 17:51:57 --> Security Class Initialized
DEBUG - 2021-04-16 17:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:51:57 --> Input Class Initialized
INFO - 2021-04-16 17:51:57 --> Language Class Initialized
ERROR - 2021-04-16 17:51:57 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:51:57 --> Config Class Initialized
INFO - 2021-04-16 17:51:57 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:51:57 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:51:57 --> Utf8 Class Initialized
INFO - 2021-04-16 17:51:57 --> URI Class Initialized
INFO - 2021-04-16 17:51:57 --> Router Class Initialized
INFO - 2021-04-16 17:51:57 --> Output Class Initialized
INFO - 2021-04-16 17:51:57 --> Security Class Initialized
DEBUG - 2021-04-16 17:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:51:57 --> Input Class Initialized
INFO - 2021-04-16 17:51:57 --> Language Class Initialized
ERROR - 2021-04-16 17:51:57 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:51:57 --> Config Class Initialized
INFO - 2021-04-16 17:51:57 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:51:57 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:51:57 --> Utf8 Class Initialized
INFO - 2021-04-16 17:51:57 --> URI Class Initialized
INFO - 2021-04-16 17:51:57 --> Router Class Initialized
INFO - 2021-04-16 17:51:57 --> Output Class Initialized
INFO - 2021-04-16 17:51:57 --> Security Class Initialized
DEBUG - 2021-04-16 17:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:51:57 --> Input Class Initialized
INFO - 2021-04-16 17:51:57 --> Language Class Initialized
ERROR - 2021-04-16 17:51:57 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:51:57 --> Config Class Initialized
INFO - 2021-04-16 17:51:57 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:51:57 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:51:57 --> Utf8 Class Initialized
INFO - 2021-04-16 17:51:57 --> URI Class Initialized
INFO - 2021-04-16 17:51:57 --> Router Class Initialized
INFO - 2021-04-16 17:51:57 --> Output Class Initialized
INFO - 2021-04-16 17:51:57 --> Security Class Initialized
DEBUG - 2021-04-16 17:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:51:57 --> Input Class Initialized
INFO - 2021-04-16 17:51:57 --> Language Class Initialized
ERROR - 2021-04-16 17:51:57 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:51:57 --> Config Class Initialized
INFO - 2021-04-16 17:51:57 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:51:57 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:51:57 --> Utf8 Class Initialized
INFO - 2021-04-16 17:51:57 --> URI Class Initialized
INFO - 2021-04-16 17:51:57 --> Router Class Initialized
INFO - 2021-04-16 17:51:57 --> Output Class Initialized
INFO - 2021-04-16 17:51:57 --> Security Class Initialized
DEBUG - 2021-04-16 17:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:51:57 --> Input Class Initialized
INFO - 2021-04-16 17:51:57 --> Language Class Initialized
ERROR - 2021-04-16 17:51:57 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:52:15 --> Config Class Initialized
INFO - 2021-04-16 17:52:15 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:52:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:52:15 --> Utf8 Class Initialized
INFO - 2021-04-16 17:52:15 --> URI Class Initialized
INFO - 2021-04-16 17:52:15 --> Router Class Initialized
INFO - 2021-04-16 17:52:15 --> Output Class Initialized
INFO - 2021-04-16 17:52:15 --> Security Class Initialized
DEBUG - 2021-04-16 17:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:52:15 --> Input Class Initialized
INFO - 2021-04-16 17:52:15 --> Language Class Initialized
INFO - 2021-04-16 17:52:15 --> Loader Class Initialized
INFO - 2021-04-16 17:52:15 --> Helper loaded: url_helper
INFO - 2021-04-16 17:52:15 --> Helper loaded: form_helper
INFO - 2021-04-16 17:52:15 --> Helper loaded: common_helper
INFO - 2021-04-16 17:52:15 --> Helper loaded: util_helper
INFO - 2021-04-16 17:52:15 --> Helper loaded: user_helper
INFO - 2021-04-16 17:52:15 --> Database Driver Class Initialized
DEBUG - 2021-04-16 17:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 17:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 17:52:15 --> Form Validation Class Initialized
INFO - 2021-04-16 17:52:15 --> Model Class Initialized
INFO - 2021-04-16 17:52:15 --> Controller Class Initialized
INFO - 2021-04-16 17:52:15 --> Model Class Initialized
INFO - 2021-04-16 17:52:15 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 17:52:15 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 17:52:15 --> Final output sent to browser
DEBUG - 2021-04-16 17:52:15 --> Total execution time: 0.0299
INFO - 2021-04-16 17:52:15 --> Config Class Initialized
INFO - 2021-04-16 17:52:15 --> Config Class Initialized
INFO - 2021-04-16 17:52:15 --> Hooks Class Initialized
INFO - 2021-04-16 17:52:15 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:52:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:52:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:52:15 --> Utf8 Class Initialized
INFO - 2021-04-16 17:52:15 --> Utf8 Class Initialized
INFO - 2021-04-16 17:52:15 --> URI Class Initialized
INFO - 2021-04-16 17:52:15 --> URI Class Initialized
INFO - 2021-04-16 17:52:15 --> Router Class Initialized
INFO - 2021-04-16 17:52:15 --> Router Class Initialized
INFO - 2021-04-16 17:52:15 --> Output Class Initialized
INFO - 2021-04-16 17:52:15 --> Output Class Initialized
INFO - 2021-04-16 17:52:15 --> Config Class Initialized
INFO - 2021-04-16 17:52:15 --> Hooks Class Initialized
INFO - 2021-04-16 17:52:15 --> Security Class Initialized
INFO - 2021-04-16 17:52:15 --> Security Class Initialized
DEBUG - 2021-04-16 17:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:52:15 --> Input Class Initialized
DEBUG - 2021-04-16 17:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:52:15 --> Input Class Initialized
INFO - 2021-04-16 17:52:15 --> Language Class Initialized
DEBUG - 2021-04-16 17:52:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:52:15 --> Language Class Initialized
INFO - 2021-04-16 17:52:15 --> Utf8 Class Initialized
INFO - 2021-04-16 17:52:15 --> URI Class Initialized
ERROR - 2021-04-16 17:52:15 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-16 17:52:15 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:52:15 --> Router Class Initialized
INFO - 2021-04-16 17:52:15 --> Output Class Initialized
INFO - 2021-04-16 17:52:15 --> Security Class Initialized
DEBUG - 2021-04-16 17:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:52:15 --> Input Class Initialized
INFO - 2021-04-16 17:52:15 --> Language Class Initialized
ERROR - 2021-04-16 17:52:15 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:52:15 --> Config Class Initialized
INFO - 2021-04-16 17:52:15 --> Hooks Class Initialized
INFO - 2021-04-16 17:52:15 --> Config Class Initialized
INFO - 2021-04-16 17:52:15 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:52:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:52:15 --> Utf8 Class Initialized
INFO - 2021-04-16 17:52:15 --> URI Class Initialized
DEBUG - 2021-04-16 17:52:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:52:15 --> Utf8 Class Initialized
INFO - 2021-04-16 17:52:15 --> Router Class Initialized
INFO - 2021-04-16 17:52:15 --> URI Class Initialized
INFO - 2021-04-16 17:52:15 --> Router Class Initialized
INFO - 2021-04-16 17:52:15 --> Output Class Initialized
INFO - 2021-04-16 17:52:15 --> Config Class Initialized
INFO - 2021-04-16 17:52:15 --> Hooks Class Initialized
INFO - 2021-04-16 17:52:15 --> Security Class Initialized
INFO - 2021-04-16 17:52:15 --> Output Class Initialized
DEBUG - 2021-04-16 17:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:52:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:52:15 --> Input Class Initialized
INFO - 2021-04-16 17:52:15 --> Security Class Initialized
INFO - 2021-04-16 17:52:15 --> Utf8 Class Initialized
INFO - 2021-04-16 17:52:15 --> Language Class Initialized
INFO - 2021-04-16 17:52:15 --> Config Class Initialized
DEBUG - 2021-04-16 17:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:52:15 --> Hooks Class Initialized
INFO - 2021-04-16 17:52:15 --> URI Class Initialized
INFO - 2021-04-16 17:52:15 --> Input Class Initialized
ERROR - 2021-04-16 17:52:15 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:52:15 --> Language Class Initialized
INFO - 2021-04-16 17:52:15 --> Router Class Initialized
DEBUG - 2021-04-16 17:52:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:52:15 --> Utf8 Class Initialized
ERROR - 2021-04-16 17:52:15 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:52:15 --> URI Class Initialized
INFO - 2021-04-16 17:52:15 --> Router Class Initialized
INFO - 2021-04-16 17:52:15 --> Output Class Initialized
INFO - 2021-04-16 17:52:15 --> Security Class Initialized
DEBUG - 2021-04-16 17:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:52:15 --> Input Class Initialized
INFO - 2021-04-16 17:52:15 --> Config Class Initialized
INFO - 2021-04-16 17:52:15 --> Language Class Initialized
INFO - 2021-04-16 17:52:15 --> Hooks Class Initialized
ERROR - 2021-04-16 17:52:15 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:52:15 --> Output Class Initialized
INFO - 2021-04-16 17:52:15 --> Config Class Initialized
INFO - 2021-04-16 17:52:15 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:52:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:52:15 --> Utf8 Class Initialized
INFO - 2021-04-16 17:52:15 --> Security Class Initialized
INFO - 2021-04-16 17:52:15 --> URI Class Initialized
DEBUG - 2021-04-16 17:52:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:52:15 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:52:15 --> URI Class Initialized
INFO - 2021-04-16 17:52:15 --> Router Class Initialized
INFO - 2021-04-16 17:52:15 --> Input Class Initialized
INFO - 2021-04-16 17:52:15 --> Language Class Initialized
INFO - 2021-04-16 17:52:15 --> Router Class Initialized
INFO - 2021-04-16 17:52:15 --> Output Class Initialized
INFO - 2021-04-16 17:52:15 --> Config Class Initialized
INFO - 2021-04-16 17:52:15 --> Hooks Class Initialized
INFO - 2021-04-16 17:52:15 --> Output Class Initialized
INFO - 2021-04-16 17:52:15 --> Security Class Initialized
ERROR - 2021-04-16 17:52:15 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-16 17:52:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:52:15 --> Utf8 Class Initialized
DEBUG - 2021-04-16 17:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:52:15 --> Security Class Initialized
INFO - 2021-04-16 17:52:15 --> Input Class Initialized
INFO - 2021-04-16 17:52:15 --> URI Class Initialized
INFO - 2021-04-16 17:52:15 --> Language Class Initialized
INFO - 2021-04-16 17:52:15 --> Router Class Initialized
DEBUG - 2021-04-16 17:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:52:15 --> Input Class Initialized
INFO - 2021-04-16 17:52:15 --> Language Class Initialized
INFO - 2021-04-16 17:52:15 --> Output Class Initialized
ERROR - 2021-04-16 17:52:15 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:52:15 --> Security Class Initialized
ERROR - 2021-04-16 17:52:15 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-16 17:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:52:15 --> Input Class Initialized
INFO - 2021-04-16 17:52:15 --> Language Class Initialized
ERROR - 2021-04-16 17:52:15 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:52:15 --> Config Class Initialized
INFO - 2021-04-16 17:52:15 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:52:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:52:15 --> Utf8 Class Initialized
INFO - 2021-04-16 17:52:15 --> URI Class Initialized
INFO - 2021-04-16 17:52:15 --> Router Class Initialized
INFO - 2021-04-16 17:52:15 --> Output Class Initialized
INFO - 2021-04-16 17:52:15 --> Security Class Initialized
DEBUG - 2021-04-16 17:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:52:15 --> Input Class Initialized
INFO - 2021-04-16 17:52:15 --> Language Class Initialized
ERROR - 2021-04-16 17:52:15 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:52:15 --> Config Class Initialized
INFO - 2021-04-16 17:52:15 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:52:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:52:15 --> Utf8 Class Initialized
INFO - 2021-04-16 17:52:15 --> URI Class Initialized
INFO - 2021-04-16 17:52:15 --> Router Class Initialized
INFO - 2021-04-16 17:52:15 --> Output Class Initialized
INFO - 2021-04-16 17:52:15 --> Security Class Initialized
DEBUG - 2021-04-16 17:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:52:15 --> Input Class Initialized
INFO - 2021-04-16 17:52:15 --> Language Class Initialized
ERROR - 2021-04-16 17:52:15 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:52:15 --> Config Class Initialized
INFO - 2021-04-16 17:52:15 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:52:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:52:15 --> Utf8 Class Initialized
INFO - 2021-04-16 17:52:15 --> URI Class Initialized
INFO - 2021-04-16 17:52:15 --> Router Class Initialized
INFO - 2021-04-16 17:52:15 --> Output Class Initialized
INFO - 2021-04-16 17:52:15 --> Security Class Initialized
DEBUG - 2021-04-16 17:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:52:15 --> Input Class Initialized
INFO - 2021-04-16 17:52:15 --> Language Class Initialized
ERROR - 2021-04-16 17:52:15 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 17:52:15 --> Config Class Initialized
INFO - 2021-04-16 17:52:15 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:52:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:52:15 --> Utf8 Class Initialized
INFO - 2021-04-16 17:52:15 --> URI Class Initialized
INFO - 2021-04-16 17:52:15 --> Router Class Initialized
INFO - 2021-04-16 17:52:15 --> Output Class Initialized
INFO - 2021-04-16 17:52:15 --> Security Class Initialized
DEBUG - 2021-04-16 17:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:52:15 --> Input Class Initialized
INFO - 2021-04-16 17:52:15 --> Language Class Initialized
ERROR - 2021-04-16 17:52:15 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:52:15 --> Config Class Initialized
INFO - 2021-04-16 17:52:15 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:52:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:52:15 --> Utf8 Class Initialized
INFO - 2021-04-16 17:52:15 --> URI Class Initialized
INFO - 2021-04-16 17:52:15 --> Router Class Initialized
INFO - 2021-04-16 17:52:15 --> Output Class Initialized
INFO - 2021-04-16 17:52:15 --> Security Class Initialized
DEBUG - 2021-04-16 17:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:52:15 --> Input Class Initialized
INFO - 2021-04-16 17:52:15 --> Language Class Initialized
ERROR - 2021-04-16 17:52:15 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:52:15 --> Config Class Initialized
INFO - 2021-04-16 17:52:15 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:52:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:52:15 --> Utf8 Class Initialized
INFO - 2021-04-16 17:52:15 --> URI Class Initialized
INFO - 2021-04-16 17:52:15 --> Router Class Initialized
INFO - 2021-04-16 17:52:15 --> Output Class Initialized
INFO - 2021-04-16 17:52:15 --> Security Class Initialized
DEBUG - 2021-04-16 17:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:52:15 --> Input Class Initialized
INFO - 2021-04-16 17:52:15 --> Language Class Initialized
ERROR - 2021-04-16 17:52:15 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:52:15 --> Config Class Initialized
INFO - 2021-04-16 17:52:15 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:52:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:52:15 --> Utf8 Class Initialized
INFO - 2021-04-16 17:52:15 --> URI Class Initialized
INFO - 2021-04-16 17:52:15 --> Router Class Initialized
INFO - 2021-04-16 17:52:15 --> Output Class Initialized
INFO - 2021-04-16 17:52:15 --> Security Class Initialized
DEBUG - 2021-04-16 17:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:52:15 --> Input Class Initialized
INFO - 2021-04-16 17:52:15 --> Language Class Initialized
ERROR - 2021-04-16 17:52:15 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:52:15 --> Config Class Initialized
INFO - 2021-04-16 17:52:15 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:52:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:52:15 --> Utf8 Class Initialized
INFO - 2021-04-16 17:52:15 --> URI Class Initialized
INFO - 2021-04-16 17:52:15 --> Router Class Initialized
INFO - 2021-04-16 17:52:15 --> Output Class Initialized
INFO - 2021-04-16 17:52:15 --> Security Class Initialized
DEBUG - 2021-04-16 17:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:52:15 --> Input Class Initialized
INFO - 2021-04-16 17:52:15 --> Language Class Initialized
ERROR - 2021-04-16 17:52:15 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:52:15 --> Config Class Initialized
INFO - 2021-04-16 17:52:15 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:52:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:52:15 --> Utf8 Class Initialized
INFO - 2021-04-16 17:52:15 --> URI Class Initialized
INFO - 2021-04-16 17:52:15 --> Router Class Initialized
INFO - 2021-04-16 17:52:15 --> Output Class Initialized
INFO - 2021-04-16 17:52:15 --> Security Class Initialized
DEBUG - 2021-04-16 17:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:52:15 --> Input Class Initialized
INFO - 2021-04-16 17:52:15 --> Language Class Initialized
ERROR - 2021-04-16 17:52:15 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:52:15 --> Config Class Initialized
INFO - 2021-04-16 17:52:15 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:52:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:52:15 --> Utf8 Class Initialized
INFO - 2021-04-16 17:52:15 --> URI Class Initialized
INFO - 2021-04-16 17:52:15 --> Router Class Initialized
INFO - 2021-04-16 17:52:15 --> Output Class Initialized
INFO - 2021-04-16 17:52:15 --> Security Class Initialized
DEBUG - 2021-04-16 17:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:52:15 --> Input Class Initialized
INFO - 2021-04-16 17:52:15 --> Language Class Initialized
ERROR - 2021-04-16 17:52:15 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 17:52:15 --> Config Class Initialized
INFO - 2021-04-16 17:52:15 --> Hooks Class Initialized
DEBUG - 2021-04-16 17:52:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 17:52:15 --> Utf8 Class Initialized
INFO - 2021-04-16 17:52:15 --> URI Class Initialized
INFO - 2021-04-16 17:52:15 --> Router Class Initialized
INFO - 2021-04-16 17:52:15 --> Output Class Initialized
INFO - 2021-04-16 17:52:15 --> Security Class Initialized
DEBUG - 2021-04-16 17:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 17:52:15 --> Input Class Initialized
INFO - 2021-04-16 17:52:15 --> Language Class Initialized
ERROR - 2021-04-16 17:52:15 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:06:03 --> Config Class Initialized
INFO - 2021-04-16 18:06:03 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:06:03 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:06:03 --> Utf8 Class Initialized
INFO - 2021-04-16 18:06:03 --> URI Class Initialized
INFO - 2021-04-16 18:06:03 --> Router Class Initialized
INFO - 2021-04-16 18:06:03 --> Output Class Initialized
INFO - 2021-04-16 18:06:03 --> Security Class Initialized
DEBUG - 2021-04-16 18:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:06:03 --> Input Class Initialized
INFO - 2021-04-16 18:06:03 --> Language Class Initialized
INFO - 2021-04-16 18:06:03 --> Loader Class Initialized
INFO - 2021-04-16 18:06:04 --> Helper loaded: url_helper
INFO - 2021-04-16 18:06:04 --> Helper loaded: form_helper
INFO - 2021-04-16 18:06:04 --> Helper loaded: common_helper
INFO - 2021-04-16 18:06:04 --> Helper loaded: util_helper
INFO - 2021-04-16 18:06:04 --> Helper loaded: user_helper
INFO - 2021-04-16 18:06:04 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:06:04 --> Form Validation Class Initialized
INFO - 2021-04-16 18:06:04 --> Model Class Initialized
INFO - 2021-04-16 18:06:04 --> Controller Class Initialized
INFO - 2021-04-16 18:06:04 --> Model Class Initialized
INFO - 2021-04-16 18:06:04 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 18:06:04 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 18:06:04 --> Final output sent to browser
DEBUG - 2021-04-16 18:06:04 --> Total execution time: 0.0405
INFO - 2021-04-16 18:06:04 --> Config Class Initialized
INFO - 2021-04-16 18:06:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:06:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:06:04 --> Utf8 Class Initialized
INFO - 2021-04-16 18:06:04 --> Config Class Initialized
INFO - 2021-04-16 18:06:04 --> Hooks Class Initialized
INFO - 2021-04-16 18:06:04 --> URI Class Initialized
INFO - 2021-04-16 18:06:04 --> Router Class Initialized
DEBUG - 2021-04-16 18:06:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:06:04 --> Utf8 Class Initialized
INFO - 2021-04-16 18:06:04 --> Output Class Initialized
INFO - 2021-04-16 18:06:04 --> URI Class Initialized
INFO - 2021-04-16 18:06:04 --> Security Class Initialized
INFO - 2021-04-16 18:06:04 --> Router Class Initialized
DEBUG - 2021-04-16 18:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:06:04 --> Input Class Initialized
INFO - 2021-04-16 18:06:04 --> Language Class Initialized
INFO - 2021-04-16 18:06:04 --> Output Class Initialized
ERROR - 2021-04-16 18:06:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 18:06:04 --> Security Class Initialized
DEBUG - 2021-04-16 18:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:06:04 --> Input Class Initialized
INFO - 2021-04-16 18:06:04 --> Language Class Initialized
INFO - 2021-04-16 18:06:04 --> Config Class Initialized
INFO - 2021-04-16 18:06:04 --> Hooks Class Initialized
ERROR - 2021-04-16 18:06:04 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-16 18:06:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:06:04 --> Utf8 Class Initialized
INFO - 2021-04-16 18:06:04 --> URI Class Initialized
INFO - 2021-04-16 18:06:04 --> Router Class Initialized
INFO - 2021-04-16 18:06:04 --> Output Class Initialized
INFO - 2021-04-16 18:06:04 --> Config Class Initialized
INFO - 2021-04-16 18:06:04 --> Hooks Class Initialized
INFO - 2021-04-16 18:06:04 --> Security Class Initialized
DEBUG - 2021-04-16 18:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:06:04 --> Input Class Initialized
INFO - 2021-04-16 18:06:04 --> Language Class Initialized
DEBUG - 2021-04-16 18:06:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:06:04 --> Utf8 Class Initialized
ERROR - 2021-04-16 18:06:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 18:06:04 --> URI Class Initialized
INFO - 2021-04-16 18:06:04 --> Router Class Initialized
INFO - 2021-04-16 18:06:04 --> Output Class Initialized
INFO - 2021-04-16 18:06:04 --> Security Class Initialized
INFO - 2021-04-16 18:06:04 --> Config Class Initialized
INFO - 2021-04-16 18:06:04 --> Config Class Initialized
INFO - 2021-04-16 18:06:04 --> Config Class Initialized
INFO - 2021-04-16 18:06:04 --> Hooks Class Initialized
INFO - 2021-04-16 18:06:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:06:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:06:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:06:04 --> Hooks Class Initialized
INFO - 2021-04-16 18:06:04 --> Utf8 Class Initialized
INFO - 2021-04-16 18:06:04 --> URI Class Initialized
INFO - 2021-04-16 18:06:04 --> Router Class Initialized
DEBUG - 2021-04-16 18:06:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:06:04 --> Utf8 Class Initialized
INFO - 2021-04-16 18:06:04 --> Output Class Initialized
INFO - 2021-04-16 18:06:04 --> URI Class Initialized
DEBUG - 2021-04-16 18:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:06:04 --> Input Class Initialized
INFO - 2021-04-16 18:06:04 --> Utf8 Class Initialized
INFO - 2021-04-16 18:06:04 --> Language Class Initialized
INFO - 2021-04-16 18:06:04 --> Router Class Initialized
ERROR - 2021-04-16 18:06:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:06:04 --> Security Class Initialized
INFO - 2021-04-16 18:06:04 --> Output Class Initialized
DEBUG - 2021-04-16 18:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:06:04 --> Config Class Initialized
INFO - 2021-04-16 18:06:04 --> Hooks Class Initialized
INFO - 2021-04-16 18:06:04 --> Security Class Initialized
INFO - 2021-04-16 18:06:04 --> Input Class Initialized
INFO - 2021-04-16 18:06:04 --> Config Class Initialized
INFO - 2021-04-16 18:06:04 --> Hooks Class Initialized
INFO - 2021-04-16 18:06:04 --> Language Class Initialized
DEBUG - 2021-04-16 18:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:06:04 --> Input Class Initialized
INFO - 2021-04-16 18:06:04 --> Language Class Initialized
DEBUG - 2021-04-16 18:06:04 --> UTF-8 Support Enabled
ERROR - 2021-04-16 18:06:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:06:04 --> Utf8 Class Initialized
DEBUG - 2021-04-16 18:06:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:06:04 --> URI Class Initialized
INFO - 2021-04-16 18:06:04 --> Utf8 Class Initialized
ERROR - 2021-04-16 18:06:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 18:06:04 --> URI Class Initialized
INFO - 2021-04-16 18:06:04 --> Router Class Initialized
INFO - 2021-04-16 18:06:04 --> Output Class Initialized
INFO - 2021-04-16 18:06:04 --> URI Class Initialized
INFO - 2021-04-16 18:06:04 --> Router Class Initialized
INFO - 2021-04-16 18:06:04 --> Security Class Initialized
DEBUG - 2021-04-16 18:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:06:04 --> Input Class Initialized
INFO - 2021-04-16 18:06:04 --> Output Class Initialized
INFO - 2021-04-16 18:06:04 --> Language Class Initialized
INFO - 2021-04-16 18:06:04 --> Router Class Initialized
INFO - 2021-04-16 18:06:04 --> Security Class Initialized
ERROR - 2021-04-16 18:06:04 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-16 18:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:06:04 --> Input Class Initialized
INFO - 2021-04-16 18:06:04 --> Language Class Initialized
ERROR - 2021-04-16 18:06:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 18:06:04 --> Output Class Initialized
INFO - 2021-04-16 18:06:04 --> Security Class Initialized
INFO - 2021-04-16 18:06:04 --> Config Class Initialized
INFO - 2021-04-16 18:06:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:06:04 --> Input Class Initialized
INFO - 2021-04-16 18:06:04 --> Language Class Initialized
DEBUG - 2021-04-16 18:06:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:06:04 --> Utf8 Class Initialized
ERROR - 2021-04-16 18:06:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:06:04 --> URI Class Initialized
INFO - 2021-04-16 18:06:04 --> Router Class Initialized
INFO - 2021-04-16 18:06:04 --> Output Class Initialized
INFO - 2021-04-16 18:06:04 --> Security Class Initialized
DEBUG - 2021-04-16 18:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:06:04 --> Input Class Initialized
INFO - 2021-04-16 18:06:04 --> Language Class Initialized
ERROR - 2021-04-16 18:06:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 18:06:04 --> Config Class Initialized
INFO - 2021-04-16 18:06:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:06:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:06:04 --> Utf8 Class Initialized
INFO - 2021-04-16 18:06:04 --> URI Class Initialized
INFO - 2021-04-16 18:06:04 --> Router Class Initialized
INFO - 2021-04-16 18:06:04 --> Output Class Initialized
INFO - 2021-04-16 18:06:04 --> Security Class Initialized
DEBUG - 2021-04-16 18:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:06:04 --> Input Class Initialized
INFO - 2021-04-16 18:06:04 --> Language Class Initialized
ERROR - 2021-04-16 18:06:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 18:06:04 --> Config Class Initialized
INFO - 2021-04-16 18:06:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:06:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:06:04 --> Utf8 Class Initialized
INFO - 2021-04-16 18:06:04 --> URI Class Initialized
INFO - 2021-04-16 18:06:04 --> Router Class Initialized
INFO - 2021-04-16 18:06:04 --> Output Class Initialized
INFO - 2021-04-16 18:06:04 --> Security Class Initialized
DEBUG - 2021-04-16 18:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:06:04 --> Input Class Initialized
INFO - 2021-04-16 18:06:04 --> Language Class Initialized
ERROR - 2021-04-16 18:06:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:06:04 --> Config Class Initialized
INFO - 2021-04-16 18:06:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:06:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:06:04 --> Utf8 Class Initialized
INFO - 2021-04-16 18:06:04 --> URI Class Initialized
INFO - 2021-04-16 18:06:04 --> Router Class Initialized
INFO - 2021-04-16 18:06:04 --> Output Class Initialized
INFO - 2021-04-16 18:06:04 --> Security Class Initialized
DEBUG - 2021-04-16 18:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:06:04 --> Input Class Initialized
INFO - 2021-04-16 18:06:04 --> Language Class Initialized
ERROR - 2021-04-16 18:06:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:06:04 --> Config Class Initialized
INFO - 2021-04-16 18:06:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:06:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:06:04 --> Utf8 Class Initialized
INFO - 2021-04-16 18:06:04 --> URI Class Initialized
INFO - 2021-04-16 18:06:04 --> Router Class Initialized
INFO - 2021-04-16 18:06:04 --> Output Class Initialized
INFO - 2021-04-16 18:06:04 --> Security Class Initialized
DEBUG - 2021-04-16 18:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:06:04 --> Input Class Initialized
INFO - 2021-04-16 18:06:04 --> Language Class Initialized
ERROR - 2021-04-16 18:06:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:06:04 --> Config Class Initialized
INFO - 2021-04-16 18:06:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:06:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:06:04 --> Utf8 Class Initialized
INFO - 2021-04-16 18:06:04 --> URI Class Initialized
INFO - 2021-04-16 18:06:04 --> Router Class Initialized
INFO - 2021-04-16 18:06:04 --> Output Class Initialized
INFO - 2021-04-16 18:06:04 --> Security Class Initialized
DEBUG - 2021-04-16 18:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:06:04 --> Input Class Initialized
INFO - 2021-04-16 18:06:04 --> Language Class Initialized
ERROR - 2021-04-16 18:06:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:06:04 --> Config Class Initialized
INFO - 2021-04-16 18:06:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:06:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:06:04 --> Utf8 Class Initialized
INFO - 2021-04-16 18:06:04 --> URI Class Initialized
INFO - 2021-04-16 18:06:04 --> Router Class Initialized
INFO - 2021-04-16 18:06:04 --> Output Class Initialized
INFO - 2021-04-16 18:06:04 --> Security Class Initialized
DEBUG - 2021-04-16 18:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:06:04 --> Input Class Initialized
INFO - 2021-04-16 18:06:04 --> Language Class Initialized
ERROR - 2021-04-16 18:06:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:06:04 --> Config Class Initialized
INFO - 2021-04-16 18:06:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:06:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:06:04 --> Utf8 Class Initialized
INFO - 2021-04-16 18:06:04 --> URI Class Initialized
INFO - 2021-04-16 18:06:04 --> Router Class Initialized
INFO - 2021-04-16 18:06:04 --> Output Class Initialized
INFO - 2021-04-16 18:06:04 --> Security Class Initialized
DEBUG - 2021-04-16 18:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:06:04 --> Input Class Initialized
INFO - 2021-04-16 18:06:04 --> Language Class Initialized
ERROR - 2021-04-16 18:06:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:06:04 --> Config Class Initialized
INFO - 2021-04-16 18:06:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:06:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:06:04 --> Utf8 Class Initialized
INFO - 2021-04-16 18:06:04 --> URI Class Initialized
INFO - 2021-04-16 18:06:04 --> Router Class Initialized
INFO - 2021-04-16 18:06:04 --> Output Class Initialized
INFO - 2021-04-16 18:06:04 --> Security Class Initialized
DEBUG - 2021-04-16 18:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:06:04 --> Input Class Initialized
INFO - 2021-04-16 18:06:04 --> Language Class Initialized
ERROR - 2021-04-16 18:06:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:06:04 --> Config Class Initialized
INFO - 2021-04-16 18:06:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:06:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:06:04 --> Utf8 Class Initialized
INFO - 2021-04-16 18:06:04 --> URI Class Initialized
INFO - 2021-04-16 18:06:04 --> Router Class Initialized
INFO - 2021-04-16 18:06:04 --> Output Class Initialized
INFO - 2021-04-16 18:06:04 --> Security Class Initialized
DEBUG - 2021-04-16 18:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:06:04 --> Input Class Initialized
INFO - 2021-04-16 18:06:04 --> Language Class Initialized
ERROR - 2021-04-16 18:06:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:08:07 --> Config Class Initialized
INFO - 2021-04-16 18:08:07 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:08:07 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:07 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:07 --> URI Class Initialized
INFO - 2021-04-16 18:08:07 --> Router Class Initialized
INFO - 2021-04-16 18:08:07 --> Output Class Initialized
INFO - 2021-04-16 18:08:07 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:07 --> Input Class Initialized
INFO - 2021-04-16 18:08:07 --> Language Class Initialized
INFO - 2021-04-16 18:08:07 --> Loader Class Initialized
INFO - 2021-04-16 18:08:07 --> Helper loaded: url_helper
INFO - 2021-04-16 18:08:07 --> Helper loaded: form_helper
INFO - 2021-04-16 18:08:07 --> Helper loaded: common_helper
INFO - 2021-04-16 18:08:07 --> Helper loaded: util_helper
INFO - 2021-04-16 18:08:07 --> Helper loaded: user_helper
INFO - 2021-04-16 18:08:07 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:08:07 --> Form Validation Class Initialized
INFO - 2021-04-16 18:08:07 --> Model Class Initialized
INFO - 2021-04-16 18:08:07 --> Controller Class Initialized
INFO - 2021-04-16 18:08:07 --> Model Class Initialized
INFO - 2021-04-16 18:08:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 18:08:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 18:08:07 --> Final output sent to browser
DEBUG - 2021-04-16 18:08:07 --> Total execution time: 0.0379
INFO - 2021-04-16 18:08:07 --> Config Class Initialized
INFO - 2021-04-16 18:08:07 --> Hooks Class Initialized
INFO - 2021-04-16 18:08:07 --> Config Class Initialized
INFO - 2021-04-16 18:08:07 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:08:07 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:07 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:07 --> URI Class Initialized
DEBUG - 2021-04-16 18:08:07 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:07 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:07 --> Router Class Initialized
INFO - 2021-04-16 18:08:07 --> URI Class Initialized
INFO - 2021-04-16 18:08:07 --> Output Class Initialized
INFO - 2021-04-16 18:08:07 --> Router Class Initialized
INFO - 2021-04-16 18:08:07 --> Security Class Initialized
INFO - 2021-04-16 18:08:07 --> Output Class Initialized
DEBUG - 2021-04-16 18:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:07 --> Input Class Initialized
INFO - 2021-04-16 18:08:07 --> Security Class Initialized
INFO - 2021-04-16 18:08:07 --> Language Class Initialized
DEBUG - 2021-04-16 18:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:07 --> Input Class Initialized
INFO - 2021-04-16 18:08:07 --> Language Class Initialized
ERROR - 2021-04-16 18:08:07 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 18:08:07 --> Config Class Initialized
INFO - 2021-04-16 18:08:07 --> Config Class Initialized
INFO - 2021-04-16 18:08:07 --> Hooks Class Initialized
INFO - 2021-04-16 18:08:07 --> Hooks Class Initialized
INFO - 2021-04-16 18:08:07 --> Config Class Initialized
INFO - 2021-04-16 18:08:07 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:08:07 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:07 --> Utf8 Class Initialized
DEBUG - 2021-04-16 18:08:07 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:07 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:07 --> URI Class Initialized
DEBUG - 2021-04-16 18:08:07 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:07 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:07 --> URI Class Initialized
INFO - 2021-04-16 18:08:07 --> Router Class Initialized
INFO - 2021-04-16 18:08:07 --> URI Class Initialized
INFO - 2021-04-16 18:08:07 --> Router Class Initialized
INFO - 2021-04-16 18:08:07 --> Output Class Initialized
INFO - 2021-04-16 18:08:07 --> Output Class Initialized
INFO - 2021-04-16 18:08:07 --> Security Class Initialized
INFO - 2021-04-16 18:08:07 --> Config Class Initialized
INFO - 2021-04-16 18:08:07 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:07 --> Input Class Initialized
INFO - 2021-04-16 18:08:07 --> Security Class Initialized
INFO - 2021-04-16 18:08:08 --> Language Class Initialized
DEBUG - 2021-04-16 18:08:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:08 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:08 --> URI Class Initialized
ERROR - 2021-04-16 18:08:08 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 18:08:08 --> Router Class Initialized
INFO - 2021-04-16 18:08:08 --> Router Class Initialized
INFO - 2021-04-16 18:08:08 --> Output Class Initialized
INFO - 2021-04-16 18:08:08 --> Config Class Initialized
INFO - 2021-04-16 18:08:08 --> Hooks Class Initialized
INFO - 2021-04-16 18:08:08 --> Output Class Initialized
INFO - 2021-04-16 18:08:08 --> Security Class Initialized
INFO - 2021-04-16 18:08:08 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:08 --> Input Class Initialized
DEBUG - 2021-04-16 18:08:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:08 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:08 --> Language Class Initialized
INFO - 2021-04-16 18:08:08 --> Input Class Initialized
INFO - 2021-04-16 18:08:08 --> Language Class Initialized
INFO - 2021-04-16 18:08:08 --> URI Class Initialized
ERROR - 2021-04-16 18:08:08 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:08:08 --> Router Class Initialized
ERROR - 2021-04-16 18:08:08 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-16 18:08:08 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 18:08:08 --> Output Class Initialized
DEBUG - 2021-04-16 18:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:08 --> Input Class Initialized
INFO - 2021-04-16 18:08:08 --> Language Class Initialized
INFO - 2021-04-16 18:08:08 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:08:08 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 18:08:08 --> Input Class Initialized
INFO - 2021-04-16 18:08:08 --> Config Class Initialized
INFO - 2021-04-16 18:08:08 --> Hooks Class Initialized
INFO - 2021-04-16 18:08:08 --> Language Class Initialized
ERROR - 2021-04-16 18:08:08 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:08:08 --> Config Class Initialized
DEBUG - 2021-04-16 18:08:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:08 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:08 --> Hooks Class Initialized
INFO - 2021-04-16 18:08:08 --> URI Class Initialized
INFO - 2021-04-16 18:08:08 --> Router Class Initialized
DEBUG - 2021-04-16 18:08:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:08 --> Output Class Initialized
INFO - 2021-04-16 18:08:08 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:08 --> Config Class Initialized
INFO - 2021-04-16 18:08:08 --> Hooks Class Initialized
INFO - 2021-04-16 18:08:08 --> URI Class Initialized
INFO - 2021-04-16 18:08:08 --> Security Class Initialized
INFO - 2021-04-16 18:08:08 --> Router Class Initialized
DEBUG - 2021-04-16 18:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:08 --> Input Class Initialized
DEBUG - 2021-04-16 18:08:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:08 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:08 --> Language Class Initialized
INFO - 2021-04-16 18:08:08 --> Output Class Initialized
INFO - 2021-04-16 18:08:08 --> URI Class Initialized
ERROR - 2021-04-16 18:08:08 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:08:08 --> Security Class Initialized
INFO - 2021-04-16 18:08:08 --> Router Class Initialized
DEBUG - 2021-04-16 18:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:08 --> Output Class Initialized
INFO - 2021-04-16 18:08:08 --> Input Class Initialized
INFO - 2021-04-16 18:08:08 --> Language Class Initialized
INFO - 2021-04-16 18:08:08 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:08 --> Input Class Initialized
ERROR - 2021-04-16 18:08:08 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:08:08 --> Language Class Initialized
ERROR - 2021-04-16 18:08:08 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 18:08:08 --> Config Class Initialized
INFO - 2021-04-16 18:08:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:08:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:08 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:08 --> URI Class Initialized
INFO - 2021-04-16 18:08:08 --> Router Class Initialized
INFO - 2021-04-16 18:08:08 --> Output Class Initialized
INFO - 2021-04-16 18:08:08 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:08 --> Input Class Initialized
INFO - 2021-04-16 18:08:08 --> Language Class Initialized
ERROR - 2021-04-16 18:08:08 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 18:08:08 --> Config Class Initialized
INFO - 2021-04-16 18:08:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:08:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:08 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:08 --> URI Class Initialized
INFO - 2021-04-16 18:08:08 --> Router Class Initialized
INFO - 2021-04-16 18:08:08 --> Output Class Initialized
INFO - 2021-04-16 18:08:08 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:08 --> Input Class Initialized
INFO - 2021-04-16 18:08:08 --> Language Class Initialized
ERROR - 2021-04-16 18:08:08 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 18:08:08 --> Config Class Initialized
INFO - 2021-04-16 18:08:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:08:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:08 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:08 --> URI Class Initialized
INFO - 2021-04-16 18:08:08 --> Router Class Initialized
INFO - 2021-04-16 18:08:08 --> Output Class Initialized
INFO - 2021-04-16 18:08:08 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:08 --> Input Class Initialized
INFO - 2021-04-16 18:08:08 --> Language Class Initialized
ERROR - 2021-04-16 18:08:08 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 18:08:08 --> Config Class Initialized
INFO - 2021-04-16 18:08:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:08:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:08 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:08 --> URI Class Initialized
INFO - 2021-04-16 18:08:08 --> Router Class Initialized
INFO - 2021-04-16 18:08:08 --> Output Class Initialized
INFO - 2021-04-16 18:08:08 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:08 --> Input Class Initialized
INFO - 2021-04-16 18:08:08 --> Language Class Initialized
ERROR - 2021-04-16 18:08:08 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:08:08 --> Config Class Initialized
INFO - 2021-04-16 18:08:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:08:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:08 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:08 --> URI Class Initialized
INFO - 2021-04-16 18:08:08 --> Router Class Initialized
INFO - 2021-04-16 18:08:08 --> Output Class Initialized
INFO - 2021-04-16 18:08:08 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:08 --> Input Class Initialized
INFO - 2021-04-16 18:08:08 --> Language Class Initialized
ERROR - 2021-04-16 18:08:08 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:08:08 --> Config Class Initialized
INFO - 2021-04-16 18:08:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:08:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:08 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:08 --> URI Class Initialized
INFO - 2021-04-16 18:08:08 --> Router Class Initialized
INFO - 2021-04-16 18:08:08 --> Output Class Initialized
INFO - 2021-04-16 18:08:08 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:08 --> Input Class Initialized
INFO - 2021-04-16 18:08:08 --> Language Class Initialized
ERROR - 2021-04-16 18:08:08 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:08:08 --> Config Class Initialized
INFO - 2021-04-16 18:08:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:08:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:08 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:08 --> URI Class Initialized
INFO - 2021-04-16 18:08:08 --> Router Class Initialized
INFO - 2021-04-16 18:08:08 --> Output Class Initialized
INFO - 2021-04-16 18:08:08 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:08 --> Input Class Initialized
INFO - 2021-04-16 18:08:08 --> Language Class Initialized
ERROR - 2021-04-16 18:08:08 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:08:08 --> Config Class Initialized
INFO - 2021-04-16 18:08:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:08:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:08 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:08 --> URI Class Initialized
INFO - 2021-04-16 18:08:08 --> Router Class Initialized
INFO - 2021-04-16 18:08:08 --> Output Class Initialized
INFO - 2021-04-16 18:08:08 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:08 --> Input Class Initialized
INFO - 2021-04-16 18:08:08 --> Language Class Initialized
ERROR - 2021-04-16 18:08:08 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:08:08 --> Config Class Initialized
INFO - 2021-04-16 18:08:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:08:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:08 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:08 --> URI Class Initialized
INFO - 2021-04-16 18:08:08 --> Router Class Initialized
INFO - 2021-04-16 18:08:08 --> Output Class Initialized
INFO - 2021-04-16 18:08:08 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:08 --> Input Class Initialized
INFO - 2021-04-16 18:08:08 --> Language Class Initialized
ERROR - 2021-04-16 18:08:08 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:08:08 --> Config Class Initialized
INFO - 2021-04-16 18:08:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:08:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:08 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:08 --> URI Class Initialized
INFO - 2021-04-16 18:08:08 --> Router Class Initialized
INFO - 2021-04-16 18:08:08 --> Output Class Initialized
INFO - 2021-04-16 18:08:08 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:08 --> Input Class Initialized
INFO - 2021-04-16 18:08:08 --> Language Class Initialized
ERROR - 2021-04-16 18:08:08 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:08:08 --> Config Class Initialized
INFO - 2021-04-16 18:08:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:08:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:08 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:08 --> URI Class Initialized
INFO - 2021-04-16 18:08:08 --> Router Class Initialized
INFO - 2021-04-16 18:08:08 --> Output Class Initialized
INFO - 2021-04-16 18:08:08 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:08 --> Input Class Initialized
INFO - 2021-04-16 18:08:08 --> Language Class Initialized
ERROR - 2021-04-16 18:08:08 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:08:40 --> Config Class Initialized
INFO - 2021-04-16 18:08:40 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:08:40 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:40 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:40 --> URI Class Initialized
INFO - 2021-04-16 18:08:40 --> Router Class Initialized
INFO - 2021-04-16 18:08:40 --> Output Class Initialized
INFO - 2021-04-16 18:08:40 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:40 --> Input Class Initialized
INFO - 2021-04-16 18:08:40 --> Language Class Initialized
INFO - 2021-04-16 18:08:40 --> Loader Class Initialized
INFO - 2021-04-16 18:08:40 --> Helper loaded: url_helper
INFO - 2021-04-16 18:08:40 --> Helper loaded: form_helper
INFO - 2021-04-16 18:08:40 --> Helper loaded: common_helper
INFO - 2021-04-16 18:08:40 --> Helper loaded: util_helper
INFO - 2021-04-16 18:08:40 --> Helper loaded: user_helper
INFO - 2021-04-16 18:08:40 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:08:40 --> Form Validation Class Initialized
INFO - 2021-04-16 18:08:40 --> Model Class Initialized
INFO - 2021-04-16 18:08:40 --> Controller Class Initialized
INFO - 2021-04-16 18:08:40 --> Model Class Initialized
INFO - 2021-04-16 18:08:40 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 18:08:40 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 18:08:40 --> Final output sent to browser
DEBUG - 2021-04-16 18:08:40 --> Total execution time: 0.0292
INFO - 2021-04-16 18:08:40 --> Config Class Initialized
INFO - 2021-04-16 18:08:40 --> Hooks Class Initialized
INFO - 2021-04-16 18:08:40 --> Config Class Initialized
INFO - 2021-04-16 18:08:40 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:08:40 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:40 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:40 --> URI Class Initialized
DEBUG - 2021-04-16 18:08:40 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:40 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:40 --> Router Class Initialized
INFO - 2021-04-16 18:08:40 --> URI Class Initialized
INFO - 2021-04-16 18:08:40 --> Output Class Initialized
INFO - 2021-04-16 18:08:40 --> Router Class Initialized
INFO - 2021-04-16 18:08:40 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:40 --> Input Class Initialized
INFO - 2021-04-16 18:08:40 --> Output Class Initialized
INFO - 2021-04-16 18:08:40 --> Language Class Initialized
INFO - 2021-04-16 18:08:40 --> Security Class Initialized
ERROR - 2021-04-16 18:08:40 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-16 18:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:40 --> Input Class Initialized
INFO - 2021-04-16 18:08:40 --> Config Class Initialized
INFO - 2021-04-16 18:08:40 --> Hooks Class Initialized
INFO - 2021-04-16 18:08:40 --> Language Class Initialized
ERROR - 2021-04-16 18:08:40 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-16 18:08:40 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:40 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:40 --> URI Class Initialized
INFO - 2021-04-16 18:08:40 --> Router Class Initialized
INFO - 2021-04-16 18:08:40 --> Output Class Initialized
INFO - 2021-04-16 18:08:40 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:40 --> Config Class Initialized
INFO - 2021-04-16 18:08:40 --> Hooks Class Initialized
INFO - 2021-04-16 18:08:40 --> Config Class Initialized
DEBUG - 2021-04-16 18:08:40 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:40 --> Config Class Initialized
INFO - 2021-04-16 18:08:40 --> Input Class Initialized
INFO - 2021-04-16 18:08:40 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:40 --> Hooks Class Initialized
INFO - 2021-04-16 18:08:40 --> Hooks Class Initialized
INFO - 2021-04-16 18:08:40 --> URI Class Initialized
INFO - 2021-04-16 18:08:40 --> Language Class Initialized
INFO - 2021-04-16 18:08:40 --> Router Class Initialized
INFO - 2021-04-16 18:08:40 --> Config Class Initialized
INFO - 2021-04-16 18:08:40 --> Hooks Class Initialized
INFO - 2021-04-16 18:08:40 --> Output Class Initialized
DEBUG - 2021-04-16 18:08:40 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:40 --> Config Class Initialized
INFO - 2021-04-16 18:08:40 --> Security Class Initialized
INFO - 2021-04-16 18:08:40 --> Hooks Class Initialized
INFO - 2021-04-16 18:08:40 --> Utf8 Class Initialized
DEBUG - 2021-04-16 18:08:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:40 --> Input Class Initialized
ERROR - 2021-04-16 18:08:40 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 18:08:40 --> Language Class Initialized
DEBUG - 2021-04-16 18:08:40 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:40 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:40 --> URI Class Initialized
INFO - 2021-04-16 18:08:40 --> URI Class Initialized
ERROR - 2021-04-16 18:08:40 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:08:40 --> Utf8 Class Initialized
DEBUG - 2021-04-16 18:08:40 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:40 --> Router Class Initialized
INFO - 2021-04-16 18:08:40 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:40 --> Router Class Initialized
INFO - 2021-04-16 18:08:40 --> URI Class Initialized
INFO - 2021-04-16 18:08:40 --> URI Class Initialized
INFO - 2021-04-16 18:08:40 --> Output Class Initialized
INFO - 2021-04-16 18:08:40 --> Output Class Initialized
INFO - 2021-04-16 18:08:40 --> Router Class Initialized
INFO - 2021-04-16 18:08:40 --> Security Class Initialized
INFO - 2021-04-16 18:08:40 --> Router Class Initialized
INFO - 2021-04-16 18:08:40 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:40 --> Input Class Initialized
INFO - 2021-04-16 18:08:40 --> Output Class Initialized
INFO - 2021-04-16 18:08:40 --> Language Class Initialized
DEBUG - 2021-04-16 18:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:40 --> Output Class Initialized
INFO - 2021-04-16 18:08:40 --> Input Class Initialized
INFO - 2021-04-16 18:08:40 --> Security Class Initialized
ERROR - 2021-04-16 18:08:40 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 18:08:40 --> Language Class Initialized
INFO - 2021-04-16 18:08:40 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:40 --> Input Class Initialized
DEBUG - 2021-04-16 18:08:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:08:40 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 18:08:40 --> Language Class Initialized
INFO - 2021-04-16 18:08:40 --> Input Class Initialized
INFO - 2021-04-16 18:08:40 --> Language Class Initialized
ERROR - 2021-04-16 18:08:40 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-16 18:08:40 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:08:40 --> Config Class Initialized
INFO - 2021-04-16 18:08:40 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:08:40 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:40 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:40 --> URI Class Initialized
INFO - 2021-04-16 18:08:40 --> Router Class Initialized
INFO - 2021-04-16 18:08:40 --> Config Class Initialized
INFO - 2021-04-16 18:08:40 --> Hooks Class Initialized
INFO - 2021-04-16 18:08:40 --> Output Class Initialized
INFO - 2021-04-16 18:08:40 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:40 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:40 --> Utf8 Class Initialized
DEBUG - 2021-04-16 18:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:40 --> Input Class Initialized
INFO - 2021-04-16 18:08:40 --> URI Class Initialized
INFO - 2021-04-16 18:08:40 --> Config Class Initialized
INFO - 2021-04-16 18:08:40 --> Hooks Class Initialized
INFO - 2021-04-16 18:08:40 --> Language Class Initialized
INFO - 2021-04-16 18:08:40 --> Router Class Initialized
ERROR - 2021-04-16 18:08:40 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-16 18:08:40 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:40 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:40 --> Output Class Initialized
INFO - 2021-04-16 18:08:40 --> URI Class Initialized
INFO - 2021-04-16 18:08:40 --> Security Class Initialized
INFO - 2021-04-16 18:08:40 --> Router Class Initialized
DEBUG - 2021-04-16 18:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:40 --> Input Class Initialized
INFO - 2021-04-16 18:08:40 --> Output Class Initialized
INFO - 2021-04-16 18:08:40 --> Language Class Initialized
INFO - 2021-04-16 18:08:40 --> Security Class Initialized
ERROR - 2021-04-16 18:08:40 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-16 18:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:40 --> Input Class Initialized
INFO - 2021-04-16 18:08:40 --> Language Class Initialized
ERROR - 2021-04-16 18:08:40 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 18:08:40 --> Config Class Initialized
INFO - 2021-04-16 18:08:40 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:08:40 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:40 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:40 --> URI Class Initialized
INFO - 2021-04-16 18:08:40 --> Router Class Initialized
INFO - 2021-04-16 18:08:40 --> Output Class Initialized
INFO - 2021-04-16 18:08:40 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:40 --> Input Class Initialized
INFO - 2021-04-16 18:08:40 --> Language Class Initialized
ERROR - 2021-04-16 18:08:40 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 18:08:40 --> Config Class Initialized
INFO - 2021-04-16 18:08:40 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:08:40 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:40 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:40 --> URI Class Initialized
INFO - 2021-04-16 18:08:40 --> Router Class Initialized
INFO - 2021-04-16 18:08:40 --> Output Class Initialized
INFO - 2021-04-16 18:08:40 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:40 --> Input Class Initialized
INFO - 2021-04-16 18:08:40 --> Language Class Initialized
ERROR - 2021-04-16 18:08:40 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:08:40 --> Config Class Initialized
INFO - 2021-04-16 18:08:40 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:08:40 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:40 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:40 --> URI Class Initialized
INFO - 2021-04-16 18:08:40 --> Router Class Initialized
INFO - 2021-04-16 18:08:40 --> Output Class Initialized
INFO - 2021-04-16 18:08:40 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:40 --> Input Class Initialized
INFO - 2021-04-16 18:08:40 --> Language Class Initialized
ERROR - 2021-04-16 18:08:40 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:08:40 --> Config Class Initialized
INFO - 2021-04-16 18:08:40 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:08:40 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:40 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:40 --> URI Class Initialized
INFO - 2021-04-16 18:08:40 --> Router Class Initialized
INFO - 2021-04-16 18:08:40 --> Output Class Initialized
INFO - 2021-04-16 18:08:40 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:40 --> Input Class Initialized
INFO - 2021-04-16 18:08:40 --> Language Class Initialized
ERROR - 2021-04-16 18:08:40 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:08:40 --> Config Class Initialized
INFO - 2021-04-16 18:08:40 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:08:40 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:40 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:40 --> URI Class Initialized
INFO - 2021-04-16 18:08:40 --> Router Class Initialized
INFO - 2021-04-16 18:08:40 --> Output Class Initialized
INFO - 2021-04-16 18:08:40 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:40 --> Input Class Initialized
INFO - 2021-04-16 18:08:40 --> Language Class Initialized
ERROR - 2021-04-16 18:08:40 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:08:40 --> Config Class Initialized
INFO - 2021-04-16 18:08:40 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:08:40 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:40 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:40 --> URI Class Initialized
INFO - 2021-04-16 18:08:40 --> Router Class Initialized
INFO - 2021-04-16 18:08:40 --> Output Class Initialized
INFO - 2021-04-16 18:08:40 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:40 --> Input Class Initialized
INFO - 2021-04-16 18:08:40 --> Language Class Initialized
ERROR - 2021-04-16 18:08:40 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:08:40 --> Config Class Initialized
INFO - 2021-04-16 18:08:40 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:08:40 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:40 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:40 --> URI Class Initialized
INFO - 2021-04-16 18:08:40 --> Router Class Initialized
INFO - 2021-04-16 18:08:40 --> Output Class Initialized
INFO - 2021-04-16 18:08:40 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:40 --> Input Class Initialized
INFO - 2021-04-16 18:08:40 --> Language Class Initialized
ERROR - 2021-04-16 18:08:40 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:08:40 --> Config Class Initialized
INFO - 2021-04-16 18:08:40 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:08:40 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:40 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:40 --> URI Class Initialized
INFO - 2021-04-16 18:08:40 --> Router Class Initialized
INFO - 2021-04-16 18:08:40 --> Output Class Initialized
INFO - 2021-04-16 18:08:40 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:40 --> Input Class Initialized
INFO - 2021-04-16 18:08:40 --> Language Class Initialized
ERROR - 2021-04-16 18:08:40 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:08:40 --> Config Class Initialized
INFO - 2021-04-16 18:08:40 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:08:40 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:08:40 --> Utf8 Class Initialized
INFO - 2021-04-16 18:08:40 --> URI Class Initialized
INFO - 2021-04-16 18:08:40 --> Router Class Initialized
INFO - 2021-04-16 18:08:40 --> Output Class Initialized
INFO - 2021-04-16 18:08:40 --> Security Class Initialized
DEBUG - 2021-04-16 18:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:08:40 --> Input Class Initialized
INFO - 2021-04-16 18:08:40 --> Language Class Initialized
ERROR - 2021-04-16 18:08:40 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:10:28 --> Config Class Initialized
INFO - 2021-04-16 18:10:28 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:10:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:10:28 --> Utf8 Class Initialized
INFO - 2021-04-16 18:10:28 --> URI Class Initialized
INFO - 2021-04-16 18:10:28 --> Router Class Initialized
INFO - 2021-04-16 18:10:28 --> Output Class Initialized
INFO - 2021-04-16 18:10:28 --> Security Class Initialized
DEBUG - 2021-04-16 18:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:10:28 --> Input Class Initialized
INFO - 2021-04-16 18:10:28 --> Language Class Initialized
INFO - 2021-04-16 18:10:28 --> Loader Class Initialized
INFO - 2021-04-16 18:10:28 --> Helper loaded: url_helper
INFO - 2021-04-16 18:10:28 --> Helper loaded: form_helper
INFO - 2021-04-16 18:10:28 --> Helper loaded: common_helper
INFO - 2021-04-16 18:10:28 --> Helper loaded: util_helper
INFO - 2021-04-16 18:10:28 --> Helper loaded: user_helper
INFO - 2021-04-16 18:10:28 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:10:28 --> Form Validation Class Initialized
INFO - 2021-04-16 18:10:28 --> Model Class Initialized
INFO - 2021-04-16 18:10:28 --> Controller Class Initialized
INFO - 2021-04-16 18:10:28 --> Model Class Initialized
INFO - 2021-04-16 18:10:28 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 18:10:28 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 18:10:28 --> Final output sent to browser
DEBUG - 2021-04-16 18:10:28 --> Total execution time: 0.0389
INFO - 2021-04-16 18:10:28 --> Config Class Initialized
INFO - 2021-04-16 18:10:28 --> Hooks Class Initialized
INFO - 2021-04-16 18:10:28 --> Config Class Initialized
INFO - 2021-04-16 18:10:28 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:10:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:10:28 --> Utf8 Class Initialized
DEBUG - 2021-04-16 18:10:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:10:28 --> Utf8 Class Initialized
INFO - 2021-04-16 18:10:28 --> URI Class Initialized
INFO - 2021-04-16 18:10:28 --> URI Class Initialized
INFO - 2021-04-16 18:10:28 --> Router Class Initialized
INFO - 2021-04-16 18:10:28 --> Router Class Initialized
INFO - 2021-04-16 18:10:28 --> Output Class Initialized
INFO - 2021-04-16 18:10:28 --> Output Class Initialized
INFO - 2021-04-16 18:10:28 --> Security Class Initialized
INFO - 2021-04-16 18:10:28 --> Security Class Initialized
DEBUG - 2021-04-16 18:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:10:28 --> Input Class Initialized
INFO - 2021-04-16 18:10:28 --> Input Class Initialized
INFO - 2021-04-16 18:10:28 --> Language Class Initialized
INFO - 2021-04-16 18:10:28 --> Language Class Initialized
ERROR - 2021-04-16 18:10:28 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-16 18:10:28 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 18:10:28 --> Config Class Initialized
INFO - 2021-04-16 18:10:28 --> Hooks Class Initialized
INFO - 2021-04-16 18:10:28 --> Config Class Initialized
INFO - 2021-04-16 18:10:28 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:10:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:10:28 --> Utf8 Class Initialized
INFO - 2021-04-16 18:10:28 --> URI Class Initialized
DEBUG - 2021-04-16 18:10:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:10:28 --> Utf8 Class Initialized
INFO - 2021-04-16 18:10:28 --> Router Class Initialized
INFO - 2021-04-16 18:10:28 --> Config Class Initialized
INFO - 2021-04-16 18:10:28 --> Hooks Class Initialized
INFO - 2021-04-16 18:10:28 --> URI Class Initialized
INFO - 2021-04-16 18:10:28 --> Output Class Initialized
INFO - 2021-04-16 18:10:28 --> Router Class Initialized
DEBUG - 2021-04-16 18:10:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:10:28 --> Security Class Initialized
INFO - 2021-04-16 18:10:28 --> Utf8 Class Initialized
INFO - 2021-04-16 18:10:28 --> Config Class Initialized
INFO - 2021-04-16 18:10:28 --> Hooks Class Initialized
INFO - 2021-04-16 18:10:28 --> URI Class Initialized
INFO - 2021-04-16 18:10:28 --> Output Class Initialized
DEBUG - 2021-04-16 18:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:10:28 --> Router Class Initialized
INFO - 2021-04-16 18:10:28 --> Security Class Initialized
DEBUG - 2021-04-16 18:10:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:10:28 --> Utf8 Class Initialized
INFO - 2021-04-16 18:10:28 --> Output Class Initialized
INFO - 2021-04-16 18:10:28 --> Config Class Initialized
INFO - 2021-04-16 18:10:28 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:10:28 --> URI Class Initialized
INFO - 2021-04-16 18:10:28 --> Input Class Initialized
INFO - 2021-04-16 18:10:28 --> Language Class Initialized
INFO - 2021-04-16 18:10:28 --> Security Class Initialized
INFO - 2021-04-16 18:10:28 --> Router Class Initialized
INFO - 2021-04-16 18:10:28 --> Input Class Initialized
DEBUG - 2021-04-16 18:10:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:10:28 --> Utf8 Class Initialized
ERROR - 2021-04-16 18:10:28 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-16 18:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:10:28 --> URI Class Initialized
INFO - 2021-04-16 18:10:28 --> Input Class Initialized
INFO - 2021-04-16 18:10:28 --> Language Class Initialized
INFO - 2021-04-16 18:10:28 --> Output Class Initialized
INFO - 2021-04-16 18:10:28 --> Language Class Initialized
INFO - 2021-04-16 18:10:28 --> Router Class Initialized
ERROR - 2021-04-16 18:10:28 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 18:10:28 --> Security Class Initialized
ERROR - 2021-04-16 18:10:28 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:10:28 --> Output Class Initialized
DEBUG - 2021-04-16 18:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:10:28 --> Input Class Initialized
INFO - 2021-04-16 18:10:28 --> Language Class Initialized
INFO - 2021-04-16 18:10:28 --> Security Class Initialized
INFO - 2021-04-16 18:10:28 --> Config Class Initialized
INFO - 2021-04-16 18:10:28 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:10:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:10:28 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 18:10:28 --> Input Class Initialized
INFO - 2021-04-16 18:10:28 --> Language Class Initialized
DEBUG - 2021-04-16 18:10:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:10:28 --> Utf8 Class Initialized
ERROR - 2021-04-16 18:10:28 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:10:28 --> URI Class Initialized
INFO - 2021-04-16 18:10:28 --> Router Class Initialized
INFO - 2021-04-16 18:10:28 --> Output Class Initialized
INFO - 2021-04-16 18:10:28 --> Config Class Initialized
INFO - 2021-04-16 18:10:28 --> Hooks Class Initialized
INFO - 2021-04-16 18:10:28 --> Security Class Initialized
DEBUG - 2021-04-16 18:10:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:10:28 --> Utf8 Class Initialized
INFO - 2021-04-16 18:10:28 --> Input Class Initialized
INFO - 2021-04-16 18:10:28 --> Language Class Initialized
INFO - 2021-04-16 18:10:28 --> URI Class Initialized
INFO - 2021-04-16 18:10:28 --> Router Class Initialized
ERROR - 2021-04-16 18:10:28 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 18:10:28 --> Output Class Initialized
INFO - 2021-04-16 18:10:28 --> Security Class Initialized
DEBUG - 2021-04-16 18:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:10:28 --> Input Class Initialized
INFO - 2021-04-16 18:10:28 --> Language Class Initialized
ERROR - 2021-04-16 18:10:28 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:10:28 --> Config Class Initialized
INFO - 2021-04-16 18:10:28 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:10:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:10:28 --> Utf8 Class Initialized
INFO - 2021-04-16 18:10:28 --> URI Class Initialized
INFO - 2021-04-16 18:10:28 --> Router Class Initialized
INFO - 2021-04-16 18:10:28 --> Output Class Initialized
INFO - 2021-04-16 18:10:28 --> Security Class Initialized
DEBUG - 2021-04-16 18:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:10:28 --> Input Class Initialized
INFO - 2021-04-16 18:10:28 --> Language Class Initialized
ERROR - 2021-04-16 18:10:28 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 18:10:28 --> Config Class Initialized
INFO - 2021-04-16 18:10:28 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:10:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:10:28 --> Utf8 Class Initialized
INFO - 2021-04-16 18:10:28 --> URI Class Initialized
INFO - 2021-04-16 18:10:28 --> Router Class Initialized
INFO - 2021-04-16 18:10:28 --> Output Class Initialized
INFO - 2021-04-16 18:10:28 --> Security Class Initialized
DEBUG - 2021-04-16 18:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:10:28 --> Input Class Initialized
INFO - 2021-04-16 18:10:28 --> Language Class Initialized
ERROR - 2021-04-16 18:10:28 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-16 18:10:28 --> Config Class Initialized
INFO - 2021-04-16 18:10:28 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:10:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:10:28 --> Utf8 Class Initialized
INFO - 2021-04-16 18:10:28 --> URI Class Initialized
INFO - 2021-04-16 18:10:28 --> Router Class Initialized
INFO - 2021-04-16 18:10:28 --> Output Class Initialized
INFO - 2021-04-16 18:10:28 --> Security Class Initialized
DEBUG - 2021-04-16 18:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:10:28 --> Input Class Initialized
INFO - 2021-04-16 18:10:28 --> Language Class Initialized
ERROR - 2021-04-16 18:10:28 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:10:28 --> Config Class Initialized
INFO - 2021-04-16 18:10:28 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:10:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:10:28 --> Utf8 Class Initialized
INFO - 2021-04-16 18:10:28 --> URI Class Initialized
INFO - 2021-04-16 18:10:28 --> Router Class Initialized
INFO - 2021-04-16 18:10:28 --> Output Class Initialized
INFO - 2021-04-16 18:10:28 --> Security Class Initialized
DEBUG - 2021-04-16 18:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:10:28 --> Input Class Initialized
INFO - 2021-04-16 18:10:28 --> Language Class Initialized
ERROR - 2021-04-16 18:10:28 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:10:28 --> Config Class Initialized
INFO - 2021-04-16 18:10:28 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:10:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:10:28 --> Utf8 Class Initialized
INFO - 2021-04-16 18:10:28 --> URI Class Initialized
INFO - 2021-04-16 18:10:28 --> Router Class Initialized
INFO - 2021-04-16 18:10:28 --> Output Class Initialized
INFO - 2021-04-16 18:10:28 --> Security Class Initialized
DEBUG - 2021-04-16 18:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:10:28 --> Input Class Initialized
INFO - 2021-04-16 18:10:28 --> Language Class Initialized
ERROR - 2021-04-16 18:10:28 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:10:28 --> Config Class Initialized
INFO - 2021-04-16 18:10:28 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:10:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:10:28 --> Utf8 Class Initialized
INFO - 2021-04-16 18:10:28 --> URI Class Initialized
INFO - 2021-04-16 18:10:28 --> Router Class Initialized
INFO - 2021-04-16 18:10:28 --> Output Class Initialized
INFO - 2021-04-16 18:10:28 --> Security Class Initialized
DEBUG - 2021-04-16 18:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:10:28 --> Input Class Initialized
INFO - 2021-04-16 18:10:28 --> Language Class Initialized
ERROR - 2021-04-16 18:10:28 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:10:28 --> Config Class Initialized
INFO - 2021-04-16 18:10:28 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:10:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:10:28 --> Utf8 Class Initialized
INFO - 2021-04-16 18:10:28 --> URI Class Initialized
INFO - 2021-04-16 18:10:28 --> Router Class Initialized
INFO - 2021-04-16 18:10:28 --> Output Class Initialized
INFO - 2021-04-16 18:10:28 --> Security Class Initialized
DEBUG - 2021-04-16 18:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:10:28 --> Input Class Initialized
INFO - 2021-04-16 18:10:28 --> Language Class Initialized
ERROR - 2021-04-16 18:10:28 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:10:28 --> Config Class Initialized
INFO - 2021-04-16 18:10:28 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:10:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:10:28 --> Utf8 Class Initialized
INFO - 2021-04-16 18:10:28 --> URI Class Initialized
INFO - 2021-04-16 18:10:28 --> Router Class Initialized
INFO - 2021-04-16 18:10:28 --> Output Class Initialized
INFO - 2021-04-16 18:10:28 --> Security Class Initialized
DEBUG - 2021-04-16 18:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:10:28 --> Input Class Initialized
INFO - 2021-04-16 18:10:28 --> Language Class Initialized
ERROR - 2021-04-16 18:10:28 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:10:28 --> Config Class Initialized
INFO - 2021-04-16 18:10:28 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:10:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:10:28 --> Utf8 Class Initialized
INFO - 2021-04-16 18:10:28 --> URI Class Initialized
INFO - 2021-04-16 18:10:28 --> Router Class Initialized
INFO - 2021-04-16 18:10:28 --> Output Class Initialized
INFO - 2021-04-16 18:10:28 --> Security Class Initialized
DEBUG - 2021-04-16 18:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:10:28 --> Input Class Initialized
INFO - 2021-04-16 18:10:28 --> Language Class Initialized
ERROR - 2021-04-16 18:10:28 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:10:28 --> Config Class Initialized
INFO - 2021-04-16 18:10:28 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:10:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:10:28 --> Utf8 Class Initialized
INFO - 2021-04-16 18:10:28 --> URI Class Initialized
INFO - 2021-04-16 18:10:28 --> Router Class Initialized
INFO - 2021-04-16 18:10:28 --> Output Class Initialized
INFO - 2021-04-16 18:10:28 --> Security Class Initialized
DEBUG - 2021-04-16 18:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:10:28 --> Input Class Initialized
INFO - 2021-04-16 18:10:28 --> Language Class Initialized
ERROR - 2021-04-16 18:10:28 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-16 18:20:42 --> Config Class Initialized
INFO - 2021-04-16 18:20:42 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:20:42 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:20:42 --> Utf8 Class Initialized
INFO - 2021-04-16 18:20:42 --> URI Class Initialized
INFO - 2021-04-16 18:20:42 --> Router Class Initialized
INFO - 2021-04-16 18:20:42 --> Output Class Initialized
INFO - 2021-04-16 18:20:42 --> Security Class Initialized
DEBUG - 2021-04-16 18:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:20:42 --> Input Class Initialized
INFO - 2021-04-16 18:20:42 --> Language Class Initialized
INFO - 2021-04-16 18:20:42 --> Loader Class Initialized
INFO - 2021-04-16 18:20:42 --> Helper loaded: url_helper
INFO - 2021-04-16 18:20:42 --> Helper loaded: form_helper
INFO - 2021-04-16 18:20:42 --> Helper loaded: common_helper
INFO - 2021-04-16 18:20:42 --> Helper loaded: util_helper
INFO - 2021-04-16 18:20:42 --> Helper loaded: user_helper
INFO - 2021-04-16 18:20:42 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:20:42 --> Form Validation Class Initialized
INFO - 2021-04-16 18:20:42 --> Model Class Initialized
INFO - 2021-04-16 18:20:42 --> Controller Class Initialized
INFO - 2021-04-16 18:20:42 --> Model Class Initialized
ERROR - 2021-04-16 18:20:42 --> Severity: error --> Exception: Call to undefined method Account_m::get_row() C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 16
INFO - 2021-04-16 18:21:12 --> Config Class Initialized
INFO - 2021-04-16 18:21:12 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:21:12 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:21:12 --> Utf8 Class Initialized
INFO - 2021-04-16 18:21:12 --> URI Class Initialized
INFO - 2021-04-16 18:21:12 --> Router Class Initialized
INFO - 2021-04-16 18:21:12 --> Output Class Initialized
INFO - 2021-04-16 18:21:12 --> Security Class Initialized
DEBUG - 2021-04-16 18:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:21:12 --> Input Class Initialized
INFO - 2021-04-16 18:21:12 --> Language Class Initialized
INFO - 2021-04-16 18:21:12 --> Loader Class Initialized
INFO - 2021-04-16 18:21:12 --> Helper loaded: url_helper
INFO - 2021-04-16 18:21:12 --> Helper loaded: form_helper
INFO - 2021-04-16 18:21:12 --> Helper loaded: common_helper
INFO - 2021-04-16 18:21:12 --> Helper loaded: util_helper
INFO - 2021-04-16 18:21:12 --> Helper loaded: user_helper
INFO - 2021-04-16 18:21:12 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:21:12 --> Form Validation Class Initialized
INFO - 2021-04-16 18:21:12 --> Model Class Initialized
INFO - 2021-04-16 18:21:12 --> Controller Class Initialized
INFO - 2021-04-16 18:21:12 --> Model Class Initialized
ERROR - 2021-04-16 18:21:12 --> Severity: error --> Exception: Call to undefined method Account_m::get_row() C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 16
INFO - 2021-04-16 18:21:13 --> Config Class Initialized
INFO - 2021-04-16 18:21:13 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:21:13 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:21:13 --> Utf8 Class Initialized
INFO - 2021-04-16 18:21:13 --> URI Class Initialized
INFO - 2021-04-16 18:21:13 --> Router Class Initialized
INFO - 2021-04-16 18:21:13 --> Output Class Initialized
INFO - 2021-04-16 18:21:13 --> Security Class Initialized
DEBUG - 2021-04-16 18:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:21:13 --> Input Class Initialized
INFO - 2021-04-16 18:21:13 --> Language Class Initialized
INFO - 2021-04-16 18:21:13 --> Loader Class Initialized
INFO - 2021-04-16 18:21:13 --> Helper loaded: url_helper
INFO - 2021-04-16 18:21:13 --> Helper loaded: form_helper
INFO - 2021-04-16 18:21:13 --> Helper loaded: common_helper
INFO - 2021-04-16 18:21:13 --> Helper loaded: util_helper
INFO - 2021-04-16 18:21:13 --> Helper loaded: user_helper
INFO - 2021-04-16 18:21:13 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:21:13 --> Form Validation Class Initialized
INFO - 2021-04-16 18:21:13 --> Model Class Initialized
INFO - 2021-04-16 18:21:13 --> Controller Class Initialized
INFO - 2021-04-16 18:21:13 --> Model Class Initialized
ERROR - 2021-04-16 18:21:13 --> Severity: error --> Exception: Call to undefined method Account_m::get_row() C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 16
INFO - 2021-04-16 18:21:14 --> Config Class Initialized
INFO - 2021-04-16 18:21:14 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:21:14 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:21:14 --> Utf8 Class Initialized
INFO - 2021-04-16 18:21:14 --> URI Class Initialized
INFO - 2021-04-16 18:21:14 --> Router Class Initialized
INFO - 2021-04-16 18:21:14 --> Output Class Initialized
INFO - 2021-04-16 18:21:14 --> Security Class Initialized
DEBUG - 2021-04-16 18:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:21:14 --> Input Class Initialized
INFO - 2021-04-16 18:21:14 --> Language Class Initialized
INFO - 2021-04-16 18:21:14 --> Loader Class Initialized
INFO - 2021-04-16 18:21:14 --> Helper loaded: url_helper
INFO - 2021-04-16 18:21:14 --> Helper loaded: form_helper
INFO - 2021-04-16 18:21:14 --> Helper loaded: common_helper
INFO - 2021-04-16 18:21:14 --> Helper loaded: util_helper
INFO - 2021-04-16 18:21:14 --> Helper loaded: user_helper
INFO - 2021-04-16 18:21:14 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:21:14 --> Form Validation Class Initialized
INFO - 2021-04-16 18:21:14 --> Model Class Initialized
INFO - 2021-04-16 18:21:14 --> Controller Class Initialized
INFO - 2021-04-16 18:21:14 --> Model Class Initialized
ERROR - 2021-04-16 18:21:14 --> Severity: error --> Exception: Call to undefined method Account_m::get_row() C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 16
INFO - 2021-04-16 18:27:13 --> Config Class Initialized
INFO - 2021-04-16 18:27:13 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:27:13 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:27:13 --> Utf8 Class Initialized
INFO - 2021-04-16 18:27:13 --> URI Class Initialized
INFO - 2021-04-16 18:27:13 --> Router Class Initialized
INFO - 2021-04-16 18:27:13 --> Output Class Initialized
INFO - 2021-04-16 18:27:13 --> Security Class Initialized
DEBUG - 2021-04-16 18:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:27:13 --> Input Class Initialized
INFO - 2021-04-16 18:27:13 --> Language Class Initialized
INFO - 2021-04-16 18:27:13 --> Loader Class Initialized
INFO - 2021-04-16 18:27:13 --> Helper loaded: url_helper
INFO - 2021-04-16 18:27:13 --> Helper loaded: form_helper
INFO - 2021-04-16 18:27:13 --> Helper loaded: common_helper
INFO - 2021-04-16 18:27:13 --> Helper loaded: util_helper
INFO - 2021-04-16 18:27:13 --> Helper loaded: user_helper
INFO - 2021-04-16 18:27:13 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:27:13 --> Form Validation Class Initialized
INFO - 2021-04-16 18:27:13 --> Model Class Initialized
INFO - 2021-04-16 18:27:13 --> Controller Class Initialized
INFO - 2021-04-16 18:27:13 --> Model Class Initialized
ERROR - 2021-04-16 18:27:13 --> Query error: Table 'foodtruck.user_id' doesn't exist - Invalid query: SELECT *
FROM `user_id`
WHERE 4 IS NULL
INFO - 2021-04-16 18:32:07 --> Config Class Initialized
INFO - 2021-04-16 18:32:07 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:32:07 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:32:07 --> Utf8 Class Initialized
INFO - 2021-04-16 18:32:07 --> URI Class Initialized
INFO - 2021-04-16 18:32:07 --> Router Class Initialized
INFO - 2021-04-16 18:32:07 --> Output Class Initialized
INFO - 2021-04-16 18:32:07 --> Security Class Initialized
DEBUG - 2021-04-16 18:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:32:07 --> Input Class Initialized
INFO - 2021-04-16 18:32:07 --> Language Class Initialized
INFO - 2021-04-16 18:32:07 --> Loader Class Initialized
INFO - 2021-04-16 18:32:07 --> Helper loaded: url_helper
INFO - 2021-04-16 18:32:07 --> Helper loaded: form_helper
INFO - 2021-04-16 18:32:07 --> Helper loaded: common_helper
INFO - 2021-04-16 18:32:07 --> Helper loaded: util_helper
INFO - 2021-04-16 18:32:07 --> Helper loaded: user_helper
INFO - 2021-04-16 18:32:07 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:32:07 --> Form Validation Class Initialized
INFO - 2021-04-16 18:32:07 --> Model Class Initialized
INFO - 2021-04-16 18:32:07 --> Controller Class Initialized
INFO - 2021-04-16 18:32:07 --> Model Class Initialized
ERROR - 2021-04-16 18:32:07 --> Query error: Table 'foodtruck.user_id' doesn't exist - Invalid query: SELECT *
FROM `user_id`
WHERE 4 IS NULL
INFO - 2021-04-16 18:32:08 --> Config Class Initialized
INFO - 2021-04-16 18:32:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:32:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:32:08 --> Utf8 Class Initialized
INFO - 2021-04-16 18:32:08 --> URI Class Initialized
INFO - 2021-04-16 18:32:08 --> Router Class Initialized
INFO - 2021-04-16 18:32:08 --> Output Class Initialized
INFO - 2021-04-16 18:32:08 --> Security Class Initialized
DEBUG - 2021-04-16 18:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:32:08 --> Input Class Initialized
INFO - 2021-04-16 18:32:08 --> Language Class Initialized
INFO - 2021-04-16 18:32:08 --> Loader Class Initialized
INFO - 2021-04-16 18:32:08 --> Helper loaded: url_helper
INFO - 2021-04-16 18:32:08 --> Helper loaded: form_helper
INFO - 2021-04-16 18:32:08 --> Helper loaded: common_helper
INFO - 2021-04-16 18:32:08 --> Helper loaded: util_helper
INFO - 2021-04-16 18:32:08 --> Helper loaded: user_helper
INFO - 2021-04-16 18:32:08 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:32:08 --> Form Validation Class Initialized
INFO - 2021-04-16 18:32:08 --> Model Class Initialized
INFO - 2021-04-16 18:32:08 --> Controller Class Initialized
INFO - 2021-04-16 18:32:08 --> Model Class Initialized
ERROR - 2021-04-16 18:32:08 --> Query error: Table 'foodtruck.user_id' doesn't exist - Invalid query: SELECT *
FROM `user_id`
WHERE 4 IS NULL
INFO - 2021-04-16 18:32:24 --> Config Class Initialized
INFO - 2021-04-16 18:32:24 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:32:24 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:32:24 --> Utf8 Class Initialized
INFO - 2021-04-16 18:32:24 --> URI Class Initialized
INFO - 2021-04-16 18:32:24 --> Router Class Initialized
INFO - 2021-04-16 18:32:24 --> Output Class Initialized
INFO - 2021-04-16 18:32:24 --> Security Class Initialized
DEBUG - 2021-04-16 18:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:32:24 --> Input Class Initialized
INFO - 2021-04-16 18:32:24 --> Language Class Initialized
INFO - 2021-04-16 18:32:24 --> Loader Class Initialized
INFO - 2021-04-16 18:32:24 --> Helper loaded: url_helper
INFO - 2021-04-16 18:32:24 --> Helper loaded: form_helper
INFO - 2021-04-16 18:32:24 --> Helper loaded: common_helper
INFO - 2021-04-16 18:32:24 --> Helper loaded: util_helper
INFO - 2021-04-16 18:32:24 --> Helper loaded: user_helper
INFO - 2021-04-16 18:32:24 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:32:24 --> Form Validation Class Initialized
INFO - 2021-04-16 18:32:24 --> Model Class Initialized
INFO - 2021-04-16 18:32:24 --> Controller Class Initialized
INFO - 2021-04-16 18:32:24 --> Model Class Initialized
ERROR - 2021-04-16 18:32:24 --> Query error: Table 'foodtruck.user_id' doesn't exist - Invalid query: SELECT *
FROM `user_id`
WHERE 4 IS NULL
INFO - 2021-04-16 18:32:24 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 18:32:24 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 18:32:24 --> Final output sent to browser
DEBUG - 2021-04-16 18:32:24 --> Total execution time: 0.0302
INFO - 2021-04-16 18:33:21 --> Config Class Initialized
INFO - 2021-04-16 18:33:21 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:33:21 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:33:21 --> Utf8 Class Initialized
INFO - 2021-04-16 18:33:21 --> URI Class Initialized
INFO - 2021-04-16 18:33:21 --> Router Class Initialized
INFO - 2021-04-16 18:33:21 --> Output Class Initialized
INFO - 2021-04-16 18:33:21 --> Security Class Initialized
DEBUG - 2021-04-16 18:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:33:21 --> Input Class Initialized
INFO - 2021-04-16 18:33:21 --> Language Class Initialized
INFO - 2021-04-16 18:33:21 --> Loader Class Initialized
INFO - 2021-04-16 18:33:21 --> Helper loaded: url_helper
INFO - 2021-04-16 18:33:21 --> Helper loaded: form_helper
INFO - 2021-04-16 18:33:21 --> Helper loaded: common_helper
INFO - 2021-04-16 18:33:21 --> Helper loaded: util_helper
INFO - 2021-04-16 18:33:21 --> Helper loaded: user_helper
INFO - 2021-04-16 18:33:21 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:33:21 --> Form Validation Class Initialized
INFO - 2021-04-16 18:33:21 --> Model Class Initialized
INFO - 2021-04-16 18:33:21 --> Controller Class Initialized
INFO - 2021-04-16 18:33:21 --> Model Class Initialized
INFO - 2021-04-16 18:33:21 --> Config Class Initialized
INFO - 2021-04-16 18:33:21 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:33:21 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:33:21 --> Utf8 Class Initialized
INFO - 2021-04-16 18:33:21 --> URI Class Initialized
INFO - 2021-04-16 18:33:21 --> Router Class Initialized
INFO - 2021-04-16 18:33:21 --> Output Class Initialized
INFO - 2021-04-16 18:33:21 --> Security Class Initialized
DEBUG - 2021-04-16 18:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:33:21 --> Input Class Initialized
INFO - 2021-04-16 18:33:21 --> Language Class Initialized
INFO - 2021-04-16 18:33:21 --> Loader Class Initialized
INFO - 2021-04-16 18:33:21 --> Helper loaded: url_helper
INFO - 2021-04-16 18:33:21 --> Helper loaded: form_helper
INFO - 2021-04-16 18:33:21 --> Helper loaded: common_helper
INFO - 2021-04-16 18:33:21 --> Helper loaded: util_helper
INFO - 2021-04-16 18:33:21 --> Helper loaded: user_helper
INFO - 2021-04-16 18:33:21 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:33:21 --> Form Validation Class Initialized
INFO - 2021-04-16 18:33:21 --> Model Class Initialized
INFO - 2021-04-16 18:33:21 --> Controller Class Initialized
INFO - 2021-04-16 18:33:21 --> Model Class Initialized
INFO - 2021-04-16 18:33:21 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 18:33:21 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 18:33:21 --> Final output sent to browser
DEBUG - 2021-04-16 18:33:21 --> Total execution time: 0.0308
INFO - 2021-04-16 18:33:27 --> Config Class Initialized
INFO - 2021-04-16 18:33:27 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:33:27 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:33:27 --> Utf8 Class Initialized
INFO - 2021-04-16 18:33:27 --> URI Class Initialized
INFO - 2021-04-16 18:33:27 --> Router Class Initialized
INFO - 2021-04-16 18:33:27 --> Output Class Initialized
INFO - 2021-04-16 18:33:27 --> Security Class Initialized
DEBUG - 2021-04-16 18:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:33:27 --> Input Class Initialized
INFO - 2021-04-16 18:33:27 --> Language Class Initialized
INFO - 2021-04-16 18:33:27 --> Loader Class Initialized
INFO - 2021-04-16 18:33:27 --> Helper loaded: url_helper
INFO - 2021-04-16 18:33:27 --> Helper loaded: form_helper
INFO - 2021-04-16 18:33:27 --> Helper loaded: common_helper
INFO - 2021-04-16 18:33:27 --> Helper loaded: util_helper
INFO - 2021-04-16 18:33:27 --> Helper loaded: user_helper
INFO - 2021-04-16 18:33:27 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:33:27 --> Form Validation Class Initialized
INFO - 2021-04-16 18:33:27 --> Model Class Initialized
INFO - 2021-04-16 18:33:27 --> Controller Class Initialized
INFO - 2021-04-16 18:33:27 --> Model Class Initialized
INFO - 2021-04-16 18:33:27 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-16 18:33:27 --> Final output sent to browser
DEBUG - 2021-04-16 18:33:27 --> Total execution time: 0.0279
INFO - 2021-04-16 18:33:27 --> Config Class Initialized
INFO - 2021-04-16 18:33:27 --> Hooks Class Initialized
INFO - 2021-04-16 18:33:27 --> Config Class Initialized
INFO - 2021-04-16 18:33:27 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:33:27 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:33:27 --> Utf8 Class Initialized
DEBUG - 2021-04-16 18:33:27 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:33:27 --> Utf8 Class Initialized
INFO - 2021-04-16 18:33:27 --> URI Class Initialized
INFO - 2021-04-16 18:33:27 --> URI Class Initialized
INFO - 2021-04-16 18:33:27 --> Router Class Initialized
INFO - 2021-04-16 18:33:27 --> Router Class Initialized
INFO - 2021-04-16 18:33:27 --> Output Class Initialized
INFO - 2021-04-16 18:33:27 --> Output Class Initialized
INFO - 2021-04-16 18:33:27 --> Security Class Initialized
INFO - 2021-04-16 18:33:27 --> Security Class Initialized
DEBUG - 2021-04-16 18:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:33:27 --> Input Class Initialized
DEBUG - 2021-04-16 18:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:33:27 --> Input Class Initialized
INFO - 2021-04-16 18:33:27 --> Language Class Initialized
INFO - 2021-04-16 18:33:27 --> Language Class Initialized
ERROR - 2021-04-16 18:33:27 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-16 18:33:27 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-16 18:34:13 --> Config Class Initialized
INFO - 2021-04-16 18:34:13 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:34:13 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:34:13 --> Utf8 Class Initialized
INFO - 2021-04-16 18:34:13 --> URI Class Initialized
INFO - 2021-04-16 18:34:13 --> Router Class Initialized
INFO - 2021-04-16 18:34:13 --> Output Class Initialized
INFO - 2021-04-16 18:34:13 --> Security Class Initialized
DEBUG - 2021-04-16 18:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:34:13 --> Input Class Initialized
INFO - 2021-04-16 18:34:13 --> Language Class Initialized
INFO - 2021-04-16 18:34:13 --> Loader Class Initialized
INFO - 2021-04-16 18:34:13 --> Helper loaded: url_helper
INFO - 2021-04-16 18:34:13 --> Helper loaded: form_helper
INFO - 2021-04-16 18:34:13 --> Helper loaded: common_helper
INFO - 2021-04-16 18:34:13 --> Helper loaded: util_helper
INFO - 2021-04-16 18:34:13 --> Helper loaded: user_helper
INFO - 2021-04-16 18:34:13 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:34:13 --> Form Validation Class Initialized
INFO - 2021-04-16 18:34:13 --> Model Class Initialized
INFO - 2021-04-16 18:34:13 --> Controller Class Initialized
INFO - 2021-04-16 18:34:13 --> Model Class Initialized
INFO - 2021-04-16 18:34:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-16 18:34:13 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-16 18:34:13 --> Final output sent to browser
DEBUG - 2021-04-16 18:34:13 --> Total execution time: 0.0308
INFO - 2021-04-16 18:34:31 --> Config Class Initialized
INFO - 2021-04-16 18:34:31 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:34:31 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:34:31 --> Utf8 Class Initialized
INFO - 2021-04-16 18:34:31 --> URI Class Initialized
INFO - 2021-04-16 18:34:31 --> Router Class Initialized
INFO - 2021-04-16 18:34:31 --> Output Class Initialized
INFO - 2021-04-16 18:34:31 --> Security Class Initialized
DEBUG - 2021-04-16 18:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:34:31 --> Input Class Initialized
INFO - 2021-04-16 18:34:31 --> Language Class Initialized
INFO - 2021-04-16 18:34:31 --> Loader Class Initialized
INFO - 2021-04-16 18:34:31 --> Helper loaded: url_helper
INFO - 2021-04-16 18:34:31 --> Helper loaded: form_helper
INFO - 2021-04-16 18:34:31 --> Helper loaded: common_helper
INFO - 2021-04-16 18:34:31 --> Helper loaded: util_helper
INFO - 2021-04-16 18:34:31 --> Helper loaded: user_helper
INFO - 2021-04-16 18:34:31 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:34:31 --> Form Validation Class Initialized
INFO - 2021-04-16 18:34:31 --> Model Class Initialized
INFO - 2021-04-16 18:34:31 --> Controller Class Initialized
INFO - 2021-04-16 18:34:31 --> Model Class Initialized
INFO - 2021-04-16 18:34:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-16 18:34:31 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-16 18:34:31 --> Final output sent to browser
DEBUG - 2021-04-16 18:34:31 --> Total execution time: 0.0366
INFO - 2021-04-16 18:34:44 --> Config Class Initialized
INFO - 2021-04-16 18:34:44 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:34:44 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:34:44 --> Utf8 Class Initialized
INFO - 2021-04-16 18:34:44 --> URI Class Initialized
INFO - 2021-04-16 18:34:44 --> Router Class Initialized
INFO - 2021-04-16 18:34:44 --> Output Class Initialized
INFO - 2021-04-16 18:34:44 --> Security Class Initialized
DEBUG - 2021-04-16 18:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:34:44 --> Input Class Initialized
INFO - 2021-04-16 18:34:44 --> Language Class Initialized
INFO - 2021-04-16 18:34:44 --> Loader Class Initialized
INFO - 2021-04-16 18:34:44 --> Helper loaded: url_helper
INFO - 2021-04-16 18:34:44 --> Helper loaded: form_helper
INFO - 2021-04-16 18:34:44 --> Helper loaded: common_helper
INFO - 2021-04-16 18:34:44 --> Helper loaded: util_helper
INFO - 2021-04-16 18:34:44 --> Helper loaded: user_helper
INFO - 2021-04-16 18:34:44 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:34:44 --> Form Validation Class Initialized
INFO - 2021-04-16 18:34:44 --> Model Class Initialized
INFO - 2021-04-16 18:34:44 --> Controller Class Initialized
INFO - 2021-04-16 18:34:44 --> Model Class Initialized
INFO - 2021-04-16 18:34:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-16 18:34:45 --> Config Class Initialized
INFO - 2021-04-16 18:34:45 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:34:45 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:34:45 --> Utf8 Class Initialized
INFO - 2021-04-16 18:34:45 --> URI Class Initialized
INFO - 2021-04-16 18:34:45 --> Router Class Initialized
INFO - 2021-04-16 18:34:45 --> Output Class Initialized
INFO - 2021-04-16 18:34:45 --> Security Class Initialized
DEBUG - 2021-04-16 18:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:34:45 --> Input Class Initialized
INFO - 2021-04-16 18:34:45 --> Language Class Initialized
INFO - 2021-04-16 18:34:45 --> Loader Class Initialized
INFO - 2021-04-16 18:34:45 --> Helper loaded: url_helper
INFO - 2021-04-16 18:34:45 --> Helper loaded: form_helper
INFO - 2021-04-16 18:34:45 --> Helper loaded: common_helper
INFO - 2021-04-16 18:34:45 --> Helper loaded: util_helper
INFO - 2021-04-16 18:34:45 --> Helper loaded: user_helper
INFO - 2021-04-16 18:34:45 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:34:45 --> Form Validation Class Initialized
INFO - 2021-04-16 18:34:45 --> Model Class Initialized
INFO - 2021-04-16 18:34:45 --> Controller Class Initialized
INFO - 2021-04-16 18:34:45 --> Model Class Initialized
INFO - 2021-04-16 18:34:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-16 18:34:45 --> Final output sent to browser
DEBUG - 2021-04-16 18:34:45 --> Total execution time: 0.0341
INFO - 2021-04-16 18:35:00 --> Config Class Initialized
INFO - 2021-04-16 18:35:00 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:35:00 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:35:00 --> Utf8 Class Initialized
INFO - 2021-04-16 18:35:00 --> URI Class Initialized
INFO - 2021-04-16 18:35:00 --> Router Class Initialized
INFO - 2021-04-16 18:35:00 --> Output Class Initialized
INFO - 2021-04-16 18:35:00 --> Security Class Initialized
DEBUG - 2021-04-16 18:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:35:00 --> Input Class Initialized
INFO - 2021-04-16 18:35:00 --> Language Class Initialized
INFO - 2021-04-16 18:35:00 --> Loader Class Initialized
INFO - 2021-04-16 18:35:00 --> Helper loaded: url_helper
INFO - 2021-04-16 18:35:00 --> Helper loaded: form_helper
INFO - 2021-04-16 18:35:00 --> Helper loaded: common_helper
INFO - 2021-04-16 18:35:00 --> Helper loaded: util_helper
INFO - 2021-04-16 18:35:00 --> Helper loaded: user_helper
INFO - 2021-04-16 18:35:00 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:35:00 --> Form Validation Class Initialized
INFO - 2021-04-16 18:35:00 --> Model Class Initialized
INFO - 2021-04-16 18:35:00 --> Controller Class Initialized
INFO - 2021-04-16 18:35:00 --> Model Class Initialized
INFO - 2021-04-16 18:35:00 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-16 18:35:00 --> Final output sent to browser
DEBUG - 2021-04-16 18:35:00 --> Total execution time: 0.0280
INFO - 2021-04-16 18:35:03 --> Config Class Initialized
INFO - 2021-04-16 18:35:03 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:35:03 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:35:03 --> Utf8 Class Initialized
INFO - 2021-04-16 18:35:03 --> URI Class Initialized
INFO - 2021-04-16 18:35:03 --> Router Class Initialized
INFO - 2021-04-16 18:35:03 --> Output Class Initialized
INFO - 2021-04-16 18:35:03 --> Security Class Initialized
DEBUG - 2021-04-16 18:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:35:03 --> Input Class Initialized
INFO - 2021-04-16 18:35:03 --> Language Class Initialized
INFO - 2021-04-16 18:35:03 --> Loader Class Initialized
INFO - 2021-04-16 18:35:03 --> Helper loaded: url_helper
INFO - 2021-04-16 18:35:03 --> Helper loaded: form_helper
INFO - 2021-04-16 18:35:03 --> Helper loaded: common_helper
INFO - 2021-04-16 18:35:03 --> Helper loaded: util_helper
INFO - 2021-04-16 18:35:03 --> Helper loaded: user_helper
INFO - 2021-04-16 18:35:03 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:35:03 --> Form Validation Class Initialized
INFO - 2021-04-16 18:35:03 --> Model Class Initialized
INFO - 2021-04-16 18:35:03 --> Controller Class Initialized
INFO - 2021-04-16 18:35:03 --> Model Class Initialized
INFO - 2021-04-16 18:35:03 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 18:35:03 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 18:35:03 --> Final output sent to browser
DEBUG - 2021-04-16 18:35:03 --> Total execution time: 0.0280
INFO - 2021-04-16 18:35:04 --> Config Class Initialized
INFO - 2021-04-16 18:35:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:35:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:35:04 --> Utf8 Class Initialized
INFO - 2021-04-16 18:35:04 --> URI Class Initialized
INFO - 2021-04-16 18:35:04 --> Router Class Initialized
INFO - 2021-04-16 18:35:04 --> Output Class Initialized
INFO - 2021-04-16 18:35:04 --> Security Class Initialized
DEBUG - 2021-04-16 18:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:35:04 --> Input Class Initialized
INFO - 2021-04-16 18:35:04 --> Language Class Initialized
INFO - 2021-04-16 18:35:04 --> Loader Class Initialized
INFO - 2021-04-16 18:35:04 --> Helper loaded: url_helper
INFO - 2021-04-16 18:35:04 --> Helper loaded: form_helper
INFO - 2021-04-16 18:35:04 --> Helper loaded: common_helper
INFO - 2021-04-16 18:35:04 --> Helper loaded: util_helper
INFO - 2021-04-16 18:35:04 --> Helper loaded: user_helper
INFO - 2021-04-16 18:35:04 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:35:04 --> Form Validation Class Initialized
INFO - 2021-04-16 18:35:04 --> Model Class Initialized
INFO - 2021-04-16 18:35:04 --> Controller Class Initialized
INFO - 2021-04-16 18:35:04 --> Model Class Initialized
INFO - 2021-04-16 18:35:04 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 18:35:04 --> Final output sent to browser
DEBUG - 2021-04-16 18:35:04 --> Total execution time: 0.0401
INFO - 2021-04-16 18:35:24 --> Config Class Initialized
INFO - 2021-04-16 18:35:24 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:35:24 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:35:24 --> Utf8 Class Initialized
INFO - 2021-04-16 18:35:24 --> URI Class Initialized
INFO - 2021-04-16 18:35:24 --> Router Class Initialized
INFO - 2021-04-16 18:35:24 --> Output Class Initialized
INFO - 2021-04-16 18:35:24 --> Security Class Initialized
DEBUG - 2021-04-16 18:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:35:24 --> Input Class Initialized
INFO - 2021-04-16 18:35:24 --> Language Class Initialized
INFO - 2021-04-16 18:35:24 --> Loader Class Initialized
INFO - 2021-04-16 18:35:24 --> Helper loaded: url_helper
INFO - 2021-04-16 18:35:24 --> Helper loaded: form_helper
INFO - 2021-04-16 18:35:24 --> Helper loaded: common_helper
INFO - 2021-04-16 18:35:24 --> Helper loaded: util_helper
INFO - 2021-04-16 18:35:24 --> Helper loaded: user_helper
INFO - 2021-04-16 18:35:24 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:35:24 --> Form Validation Class Initialized
INFO - 2021-04-16 18:35:24 --> Model Class Initialized
INFO - 2021-04-16 18:35:24 --> Controller Class Initialized
INFO - 2021-04-16 18:35:24 --> Model Class Initialized
INFO - 2021-04-16 18:35:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-16 18:35:24 --> Config Class Initialized
INFO - 2021-04-16 18:35:24 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:35:24 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:35:24 --> Utf8 Class Initialized
INFO - 2021-04-16 18:35:24 --> URI Class Initialized
INFO - 2021-04-16 18:35:24 --> Router Class Initialized
INFO - 2021-04-16 18:35:24 --> Output Class Initialized
INFO - 2021-04-16 18:35:24 --> Security Class Initialized
DEBUG - 2021-04-16 18:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:35:24 --> Input Class Initialized
INFO - 2021-04-16 18:35:24 --> Language Class Initialized
INFO - 2021-04-16 18:35:24 --> Loader Class Initialized
INFO - 2021-04-16 18:35:24 --> Helper loaded: url_helper
INFO - 2021-04-16 18:35:24 --> Helper loaded: form_helper
INFO - 2021-04-16 18:35:24 --> Helper loaded: common_helper
INFO - 2021-04-16 18:35:24 --> Helper loaded: util_helper
INFO - 2021-04-16 18:35:24 --> Helper loaded: user_helper
INFO - 2021-04-16 18:35:24 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:35:24 --> Form Validation Class Initialized
INFO - 2021-04-16 18:35:24 --> Model Class Initialized
INFO - 2021-04-16 18:35:24 --> Controller Class Initialized
INFO - 2021-04-16 18:35:24 --> Model Class Initialized
ERROR - 2021-04-16 18:35:24 --> Query error: Table 'foodtruck.user_id' doesn't exist - Invalid query: SELECT *
FROM `user_id`
WHERE 5 IS NULL
INFO - 2021-04-16 18:35:24 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 18:35:24 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 18:35:24 --> Final output sent to browser
DEBUG - 2021-04-16 18:35:24 --> Total execution time: 0.0319
INFO - 2021-04-16 18:37:23 --> Config Class Initialized
INFO - 2021-04-16 18:37:23 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:37:23 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:37:23 --> Utf8 Class Initialized
INFO - 2021-04-16 18:37:23 --> URI Class Initialized
INFO - 2021-04-16 18:37:23 --> Router Class Initialized
INFO - 2021-04-16 18:37:23 --> Output Class Initialized
INFO - 2021-04-16 18:37:23 --> Security Class Initialized
DEBUG - 2021-04-16 18:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:37:23 --> Input Class Initialized
INFO - 2021-04-16 18:37:23 --> Language Class Initialized
INFO - 2021-04-16 18:37:23 --> Loader Class Initialized
INFO - 2021-04-16 18:37:23 --> Helper loaded: url_helper
INFO - 2021-04-16 18:37:23 --> Helper loaded: form_helper
INFO - 2021-04-16 18:37:23 --> Helper loaded: common_helper
INFO - 2021-04-16 18:37:23 --> Helper loaded: util_helper
INFO - 2021-04-16 18:37:23 --> Helper loaded: user_helper
INFO - 2021-04-16 18:37:23 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:37:23 --> Form Validation Class Initialized
INFO - 2021-04-16 18:37:23 --> Model Class Initialized
INFO - 2021-04-16 18:37:23 --> Controller Class Initialized
INFO - 2021-04-16 18:37:23 --> Model Class Initialized
ERROR - 2021-04-16 18:37:23 --> Query error: Table 'foodtruck.user_id' doesn't exist - Invalid query: SELECT *
FROM `user_id`
WHERE 5 IS NULL
INFO - 2021-04-16 18:39:48 --> Config Class Initialized
INFO - 2021-04-16 18:39:48 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:39:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:39:48 --> Utf8 Class Initialized
INFO - 2021-04-16 18:39:48 --> URI Class Initialized
INFO - 2021-04-16 18:39:48 --> Router Class Initialized
INFO - 2021-04-16 18:39:48 --> Output Class Initialized
INFO - 2021-04-16 18:39:48 --> Security Class Initialized
DEBUG - 2021-04-16 18:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:39:48 --> Input Class Initialized
INFO - 2021-04-16 18:39:48 --> Language Class Initialized
INFO - 2021-04-16 18:39:48 --> Loader Class Initialized
INFO - 2021-04-16 18:39:48 --> Helper loaded: url_helper
INFO - 2021-04-16 18:39:48 --> Helper loaded: form_helper
INFO - 2021-04-16 18:39:48 --> Helper loaded: common_helper
INFO - 2021-04-16 18:39:48 --> Helper loaded: util_helper
INFO - 2021-04-16 18:39:48 --> Helper loaded: user_helper
INFO - 2021-04-16 18:39:48 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:39:48 --> Form Validation Class Initialized
INFO - 2021-04-16 18:39:48 --> Model Class Initialized
INFO - 2021-04-16 18:39:48 --> Controller Class Initialized
INFO - 2021-04-16 18:39:48 --> Model Class Initialized
ERROR - 2021-04-16 18:39:48 --> Query error: Table 'foodtruck.user_id' doesn't exist - Invalid query: SELECT *
FROM `user_id`
INFO - 2021-04-16 18:40:08 --> Config Class Initialized
INFO - 2021-04-16 18:40:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:40:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:40:08 --> Utf8 Class Initialized
INFO - 2021-04-16 18:40:08 --> URI Class Initialized
INFO - 2021-04-16 18:40:08 --> Router Class Initialized
INFO - 2021-04-16 18:40:08 --> Output Class Initialized
INFO - 2021-04-16 18:40:08 --> Security Class Initialized
DEBUG - 2021-04-16 18:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:40:08 --> Input Class Initialized
INFO - 2021-04-16 18:40:08 --> Language Class Initialized
INFO - 2021-04-16 18:40:08 --> Loader Class Initialized
INFO - 2021-04-16 18:40:08 --> Helper loaded: url_helper
INFO - 2021-04-16 18:40:08 --> Helper loaded: form_helper
INFO - 2021-04-16 18:40:08 --> Helper loaded: common_helper
INFO - 2021-04-16 18:40:08 --> Helper loaded: util_helper
INFO - 2021-04-16 18:40:08 --> Helper loaded: user_helper
INFO - 2021-04-16 18:40:08 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:40:08 --> Form Validation Class Initialized
INFO - 2021-04-16 18:40:08 --> Model Class Initialized
INFO - 2021-04-16 18:40:08 --> Controller Class Initialized
INFO - 2021-04-16 18:40:08 --> Model Class Initialized
ERROR - 2021-04-16 18:40:08 --> Query error: Table 'foodtruck.user_id' doesn't exist - Invalid query: SELECT *
FROM `user_id`
INFO - 2021-04-16 18:40:08 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 18:40:08 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 18:40:08 --> Final output sent to browser
DEBUG - 2021-04-16 18:40:08 --> Total execution time: 0.0316
INFO - 2021-04-16 18:40:16 --> Config Class Initialized
INFO - 2021-04-16 18:40:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:40:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:40:16 --> Utf8 Class Initialized
INFO - 2021-04-16 18:40:16 --> URI Class Initialized
INFO - 2021-04-16 18:40:16 --> Router Class Initialized
INFO - 2021-04-16 18:40:16 --> Output Class Initialized
INFO - 2021-04-16 18:40:16 --> Security Class Initialized
DEBUG - 2021-04-16 18:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:40:16 --> Input Class Initialized
INFO - 2021-04-16 18:40:16 --> Language Class Initialized
INFO - 2021-04-16 18:40:16 --> Loader Class Initialized
INFO - 2021-04-16 18:40:16 --> Helper loaded: url_helper
INFO - 2021-04-16 18:40:16 --> Helper loaded: form_helper
INFO - 2021-04-16 18:40:16 --> Helper loaded: common_helper
INFO - 2021-04-16 18:40:16 --> Helper loaded: util_helper
INFO - 2021-04-16 18:40:16 --> Helper loaded: user_helper
INFO - 2021-04-16 18:40:16 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:40:16 --> Form Validation Class Initialized
INFO - 2021-04-16 18:40:16 --> Model Class Initialized
INFO - 2021-04-16 18:40:16 --> Controller Class Initialized
INFO - 2021-04-16 18:40:16 --> Model Class Initialized
INFO - 2021-04-16 18:40:16 --> Config Class Initialized
INFO - 2021-04-16 18:40:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:40:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:40:16 --> Utf8 Class Initialized
INFO - 2021-04-16 18:40:16 --> URI Class Initialized
INFO - 2021-04-16 18:40:16 --> Router Class Initialized
INFO - 2021-04-16 18:40:16 --> Output Class Initialized
INFO - 2021-04-16 18:40:16 --> Security Class Initialized
DEBUG - 2021-04-16 18:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:40:16 --> Input Class Initialized
INFO - 2021-04-16 18:40:16 --> Language Class Initialized
INFO - 2021-04-16 18:40:16 --> Loader Class Initialized
INFO - 2021-04-16 18:40:16 --> Helper loaded: url_helper
INFO - 2021-04-16 18:40:16 --> Helper loaded: form_helper
INFO - 2021-04-16 18:40:16 --> Helper loaded: common_helper
INFO - 2021-04-16 18:40:16 --> Helper loaded: util_helper
INFO - 2021-04-16 18:40:16 --> Helper loaded: user_helper
INFO - 2021-04-16 18:40:16 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:40:16 --> Form Validation Class Initialized
INFO - 2021-04-16 18:40:16 --> Model Class Initialized
INFO - 2021-04-16 18:40:16 --> Controller Class Initialized
INFO - 2021-04-16 18:40:16 --> Model Class Initialized
INFO - 2021-04-16 18:40:16 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 18:40:16 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 18:40:16 --> Final output sent to browser
DEBUG - 2021-04-16 18:40:16 --> Total execution time: 0.0271
INFO - 2021-04-16 18:40:17 --> Config Class Initialized
INFO - 2021-04-16 18:40:17 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:40:17 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:40:17 --> Utf8 Class Initialized
INFO - 2021-04-16 18:40:17 --> URI Class Initialized
INFO - 2021-04-16 18:40:17 --> Router Class Initialized
INFO - 2021-04-16 18:40:17 --> Output Class Initialized
INFO - 2021-04-16 18:40:17 --> Security Class Initialized
DEBUG - 2021-04-16 18:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:40:17 --> Input Class Initialized
INFO - 2021-04-16 18:40:17 --> Language Class Initialized
INFO - 2021-04-16 18:40:17 --> Loader Class Initialized
INFO - 2021-04-16 18:40:17 --> Helper loaded: url_helper
INFO - 2021-04-16 18:40:17 --> Helper loaded: form_helper
INFO - 2021-04-16 18:40:17 --> Helper loaded: common_helper
INFO - 2021-04-16 18:40:17 --> Helper loaded: util_helper
INFO - 2021-04-16 18:40:17 --> Helper loaded: user_helper
INFO - 2021-04-16 18:40:17 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:40:17 --> Form Validation Class Initialized
INFO - 2021-04-16 18:40:17 --> Model Class Initialized
INFO - 2021-04-16 18:40:17 --> Controller Class Initialized
INFO - 2021-04-16 18:40:17 --> Model Class Initialized
INFO - 2021-04-16 18:40:17 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 18:40:17 --> Final output sent to browser
DEBUG - 2021-04-16 18:40:17 --> Total execution time: 0.0298
INFO - 2021-04-16 18:40:17 --> Config Class Initialized
INFO - 2021-04-16 18:40:17 --> Hooks Class Initialized
INFO - 2021-04-16 18:40:17 --> Config Class Initialized
INFO - 2021-04-16 18:40:17 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:40:17 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:40:17 --> Utf8 Class Initialized
INFO - 2021-04-16 18:40:17 --> URI Class Initialized
DEBUG - 2021-04-16 18:40:17 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:40:17 --> Utf8 Class Initialized
INFO - 2021-04-16 18:40:17 --> Router Class Initialized
INFO - 2021-04-16 18:40:17 --> URI Class Initialized
INFO - 2021-04-16 18:40:17 --> Output Class Initialized
INFO - 2021-04-16 18:40:17 --> Router Class Initialized
INFO - 2021-04-16 18:40:17 --> Security Class Initialized
DEBUG - 2021-04-16 18:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:40:17 --> Input Class Initialized
INFO - 2021-04-16 18:40:17 --> Output Class Initialized
INFO - 2021-04-16 18:40:17 --> Language Class Initialized
INFO - 2021-04-16 18:40:17 --> Security Class Initialized
ERROR - 2021-04-16 18:40:17 --> 404 Page Not Found: Fasset/img
DEBUG - 2021-04-16 18:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:40:17 --> Input Class Initialized
INFO - 2021-04-16 18:40:17 --> Language Class Initialized
ERROR - 2021-04-16 18:40:17 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-16 18:40:40 --> Config Class Initialized
INFO - 2021-04-16 18:40:40 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:40:40 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:40:40 --> Utf8 Class Initialized
INFO - 2021-04-16 18:40:40 --> URI Class Initialized
INFO - 2021-04-16 18:40:40 --> Router Class Initialized
INFO - 2021-04-16 18:40:40 --> Output Class Initialized
INFO - 2021-04-16 18:40:40 --> Security Class Initialized
DEBUG - 2021-04-16 18:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:40:40 --> Input Class Initialized
INFO - 2021-04-16 18:40:40 --> Language Class Initialized
INFO - 2021-04-16 18:40:40 --> Loader Class Initialized
INFO - 2021-04-16 18:40:40 --> Helper loaded: url_helper
INFO - 2021-04-16 18:40:40 --> Helper loaded: form_helper
INFO - 2021-04-16 18:40:40 --> Helper loaded: common_helper
INFO - 2021-04-16 18:40:40 --> Helper loaded: util_helper
INFO - 2021-04-16 18:40:40 --> Helper loaded: user_helper
INFO - 2021-04-16 18:40:40 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:40:40 --> Form Validation Class Initialized
INFO - 2021-04-16 18:40:40 --> Model Class Initialized
INFO - 2021-04-16 18:40:40 --> Controller Class Initialized
INFO - 2021-04-16 18:40:40 --> Model Class Initialized
INFO - 2021-04-16 18:40:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-16 18:40:40 --> Config Class Initialized
INFO - 2021-04-16 18:40:40 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:40:40 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:40:40 --> Utf8 Class Initialized
INFO - 2021-04-16 18:40:40 --> URI Class Initialized
INFO - 2021-04-16 18:40:40 --> Router Class Initialized
INFO - 2021-04-16 18:40:40 --> Output Class Initialized
INFO - 2021-04-16 18:40:40 --> Security Class Initialized
DEBUG - 2021-04-16 18:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:40:40 --> Input Class Initialized
INFO - 2021-04-16 18:40:40 --> Language Class Initialized
INFO - 2021-04-16 18:40:40 --> Loader Class Initialized
INFO - 2021-04-16 18:40:40 --> Helper loaded: url_helper
INFO - 2021-04-16 18:40:40 --> Helper loaded: form_helper
INFO - 2021-04-16 18:40:40 --> Helper loaded: common_helper
INFO - 2021-04-16 18:40:40 --> Helper loaded: util_helper
INFO - 2021-04-16 18:40:40 --> Helper loaded: user_helper
INFO - 2021-04-16 18:40:40 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:40:40 --> Form Validation Class Initialized
INFO - 2021-04-16 18:40:40 --> Model Class Initialized
INFO - 2021-04-16 18:40:40 --> Controller Class Initialized
INFO - 2021-04-16 18:40:40 --> Model Class Initialized
ERROR - 2021-04-16 18:40:40 --> Query error: Table 'foodtruck.user_id' doesn't exist - Invalid query: SELECT *
FROM `user_id`
WHERE 5 IS NULL
INFO - 2021-04-16 18:40:40 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 18:40:40 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 18:40:40 --> Final output sent to browser
DEBUG - 2021-04-16 18:40:40 --> Total execution time: 0.0394
INFO - 2021-04-16 18:41:10 --> Config Class Initialized
INFO - 2021-04-16 18:41:10 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:41:10 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:41:10 --> Utf8 Class Initialized
INFO - 2021-04-16 18:41:10 --> URI Class Initialized
INFO - 2021-04-16 18:41:10 --> Router Class Initialized
INFO - 2021-04-16 18:41:10 --> Output Class Initialized
INFO - 2021-04-16 18:41:10 --> Security Class Initialized
DEBUG - 2021-04-16 18:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:41:10 --> Input Class Initialized
INFO - 2021-04-16 18:41:10 --> Language Class Initialized
INFO - 2021-04-16 18:41:10 --> Loader Class Initialized
INFO - 2021-04-16 18:41:10 --> Helper loaded: url_helper
INFO - 2021-04-16 18:41:10 --> Helper loaded: form_helper
INFO - 2021-04-16 18:41:10 --> Helper loaded: common_helper
INFO - 2021-04-16 18:41:10 --> Helper loaded: util_helper
INFO - 2021-04-16 18:41:10 --> Helper loaded: user_helper
INFO - 2021-04-16 18:41:10 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:41:10 --> Form Validation Class Initialized
INFO - 2021-04-16 18:41:10 --> Model Class Initialized
INFO - 2021-04-16 18:41:10 --> Controller Class Initialized
INFO - 2021-04-16 18:41:10 --> Model Class Initialized
INFO - 2021-04-16 18:41:10 --> Config Class Initialized
INFO - 2021-04-16 18:41:10 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:41:10 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:41:10 --> Utf8 Class Initialized
INFO - 2021-04-16 18:41:10 --> URI Class Initialized
INFO - 2021-04-16 18:41:10 --> Router Class Initialized
INFO - 2021-04-16 18:41:10 --> Output Class Initialized
INFO - 2021-04-16 18:41:10 --> Security Class Initialized
DEBUG - 2021-04-16 18:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:41:10 --> Input Class Initialized
INFO - 2021-04-16 18:41:10 --> Language Class Initialized
INFO - 2021-04-16 18:41:10 --> Loader Class Initialized
INFO - 2021-04-16 18:41:10 --> Helper loaded: url_helper
INFO - 2021-04-16 18:41:10 --> Helper loaded: form_helper
INFO - 2021-04-16 18:41:10 --> Helper loaded: common_helper
INFO - 2021-04-16 18:41:10 --> Helper loaded: util_helper
INFO - 2021-04-16 18:41:10 --> Helper loaded: user_helper
INFO - 2021-04-16 18:41:10 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:41:10 --> Form Validation Class Initialized
INFO - 2021-04-16 18:41:10 --> Model Class Initialized
INFO - 2021-04-16 18:41:10 --> Controller Class Initialized
INFO - 2021-04-16 18:41:10 --> Model Class Initialized
INFO - 2021-04-16 18:41:10 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 18:41:10 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 18:41:10 --> Final output sent to browser
DEBUG - 2021-04-16 18:41:10 --> Total execution time: 0.0266
INFO - 2021-04-16 18:41:13 --> Config Class Initialized
INFO - 2021-04-16 18:41:13 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:41:13 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:41:13 --> Utf8 Class Initialized
INFO - 2021-04-16 18:41:13 --> URI Class Initialized
INFO - 2021-04-16 18:41:13 --> Router Class Initialized
INFO - 2021-04-16 18:41:13 --> Output Class Initialized
INFO - 2021-04-16 18:41:13 --> Security Class Initialized
DEBUG - 2021-04-16 18:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:41:13 --> Input Class Initialized
INFO - 2021-04-16 18:41:13 --> Language Class Initialized
INFO - 2021-04-16 18:41:13 --> Loader Class Initialized
INFO - 2021-04-16 18:41:13 --> Helper loaded: url_helper
INFO - 2021-04-16 18:41:13 --> Helper loaded: form_helper
INFO - 2021-04-16 18:41:13 --> Helper loaded: common_helper
INFO - 2021-04-16 18:41:13 --> Helper loaded: util_helper
INFO - 2021-04-16 18:41:13 --> Helper loaded: user_helper
INFO - 2021-04-16 18:41:13 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:41:13 --> Form Validation Class Initialized
INFO - 2021-04-16 18:41:13 --> Model Class Initialized
INFO - 2021-04-16 18:41:13 --> Controller Class Initialized
INFO - 2021-04-16 18:41:13 --> Model Class Initialized
ERROR - 2021-04-16 18:41:13 --> Query error: Table 'foodtruck.user_id' doesn't exist - Invalid query: SELECT *
FROM `user_id`
INFO - 2021-04-16 18:41:13 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 18:41:13 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 18:41:13 --> Final output sent to browser
DEBUG - 2021-04-16 18:41:13 --> Total execution time: 0.0294
INFO - 2021-04-16 18:41:13 --> Config Class Initialized
INFO - 2021-04-16 18:41:13 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:41:13 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:41:13 --> Utf8 Class Initialized
INFO - 2021-04-16 18:41:13 --> URI Class Initialized
INFO - 2021-04-16 18:41:13 --> Router Class Initialized
INFO - 2021-04-16 18:41:13 --> Output Class Initialized
INFO - 2021-04-16 18:41:13 --> Security Class Initialized
DEBUG - 2021-04-16 18:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:41:13 --> Input Class Initialized
INFO - 2021-04-16 18:41:13 --> Language Class Initialized
INFO - 2021-04-16 18:41:13 --> Loader Class Initialized
INFO - 2021-04-16 18:41:13 --> Helper loaded: url_helper
INFO - 2021-04-16 18:41:13 --> Helper loaded: form_helper
INFO - 2021-04-16 18:41:13 --> Helper loaded: common_helper
INFO - 2021-04-16 18:41:13 --> Helper loaded: util_helper
INFO - 2021-04-16 18:41:13 --> Helper loaded: user_helper
INFO - 2021-04-16 18:41:13 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:41:13 --> Form Validation Class Initialized
INFO - 2021-04-16 18:41:13 --> Model Class Initialized
INFO - 2021-04-16 18:41:13 --> Controller Class Initialized
INFO - 2021-04-16 18:41:13 --> Model Class Initialized
INFO - 2021-04-16 18:41:13 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 18:41:13 --> Final output sent to browser
DEBUG - 2021-04-16 18:41:13 --> Total execution time: 0.0421
INFO - 2021-04-16 18:41:15 --> Config Class Initialized
INFO - 2021-04-16 18:41:15 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:41:15 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:41:15 --> Utf8 Class Initialized
INFO - 2021-04-16 18:41:15 --> URI Class Initialized
INFO - 2021-04-16 18:41:15 --> Router Class Initialized
INFO - 2021-04-16 18:41:15 --> Output Class Initialized
INFO - 2021-04-16 18:41:15 --> Security Class Initialized
DEBUG - 2021-04-16 18:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:41:15 --> Input Class Initialized
INFO - 2021-04-16 18:41:15 --> Language Class Initialized
INFO - 2021-04-16 18:41:15 --> Loader Class Initialized
INFO - 2021-04-16 18:41:15 --> Helper loaded: url_helper
INFO - 2021-04-16 18:41:15 --> Helper loaded: form_helper
INFO - 2021-04-16 18:41:15 --> Helper loaded: common_helper
INFO - 2021-04-16 18:41:15 --> Helper loaded: util_helper
INFO - 2021-04-16 18:41:15 --> Helper loaded: user_helper
INFO - 2021-04-16 18:41:15 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:41:15 --> Form Validation Class Initialized
INFO - 2021-04-16 18:41:15 --> Model Class Initialized
INFO - 2021-04-16 18:41:15 --> Controller Class Initialized
INFO - 2021-04-16 18:41:15 --> Model Class Initialized
ERROR - 2021-04-16 18:41:15 --> Query error: Table 'foodtruck.user_id' doesn't exist - Invalid query: SELECT *
FROM `user_id`
INFO - 2021-04-16 18:41:15 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 18:41:15 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 18:41:15 --> Final output sent to browser
DEBUG - 2021-04-16 18:41:15 --> Total execution time: 0.0406
INFO - 2021-04-16 18:41:16 --> Config Class Initialized
INFO - 2021-04-16 18:41:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:41:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:41:16 --> Utf8 Class Initialized
INFO - 2021-04-16 18:41:16 --> URI Class Initialized
INFO - 2021-04-16 18:41:16 --> Router Class Initialized
INFO - 2021-04-16 18:41:16 --> Output Class Initialized
INFO - 2021-04-16 18:41:16 --> Security Class Initialized
DEBUG - 2021-04-16 18:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:41:16 --> Input Class Initialized
INFO - 2021-04-16 18:41:16 --> Language Class Initialized
INFO - 2021-04-16 18:41:16 --> Loader Class Initialized
INFO - 2021-04-16 18:41:16 --> Helper loaded: url_helper
INFO - 2021-04-16 18:41:16 --> Helper loaded: form_helper
INFO - 2021-04-16 18:41:16 --> Helper loaded: common_helper
INFO - 2021-04-16 18:41:16 --> Helper loaded: util_helper
INFO - 2021-04-16 18:41:16 --> Helper loaded: user_helper
INFO - 2021-04-16 18:41:16 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:41:16 --> Form Validation Class Initialized
INFO - 2021-04-16 18:41:16 --> Model Class Initialized
INFO - 2021-04-16 18:41:16 --> Controller Class Initialized
INFO - 2021-04-16 18:41:16 --> Model Class Initialized
INFO - 2021-04-16 18:41:16 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 18:41:16 --> Final output sent to browser
DEBUG - 2021-04-16 18:41:16 --> Total execution time: 0.1319
INFO - 2021-04-16 18:41:17 --> Config Class Initialized
INFO - 2021-04-16 18:41:17 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:41:17 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:41:17 --> Utf8 Class Initialized
INFO - 2021-04-16 18:41:17 --> URI Class Initialized
INFO - 2021-04-16 18:41:17 --> Router Class Initialized
INFO - 2021-04-16 18:41:17 --> Output Class Initialized
INFO - 2021-04-16 18:41:17 --> Security Class Initialized
DEBUG - 2021-04-16 18:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:41:17 --> Input Class Initialized
INFO - 2021-04-16 18:41:17 --> Language Class Initialized
INFO - 2021-04-16 18:41:17 --> Loader Class Initialized
INFO - 2021-04-16 18:41:17 --> Helper loaded: url_helper
INFO - 2021-04-16 18:41:17 --> Helper loaded: form_helper
INFO - 2021-04-16 18:41:17 --> Helper loaded: common_helper
INFO - 2021-04-16 18:41:17 --> Helper loaded: util_helper
INFO - 2021-04-16 18:41:17 --> Helper loaded: user_helper
INFO - 2021-04-16 18:41:17 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:41:17 --> Form Validation Class Initialized
INFO - 2021-04-16 18:41:17 --> Model Class Initialized
INFO - 2021-04-16 18:41:17 --> Controller Class Initialized
INFO - 2021-04-16 18:41:17 --> Model Class Initialized
INFO - 2021-04-16 18:41:17 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 18:41:17 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 18:41:17 --> Final output sent to browser
DEBUG - 2021-04-16 18:41:17 --> Total execution time: 0.0383
INFO - 2021-04-16 18:41:25 --> Config Class Initialized
INFO - 2021-04-16 18:41:25 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:41:25 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:41:25 --> Utf8 Class Initialized
INFO - 2021-04-16 18:41:25 --> URI Class Initialized
INFO - 2021-04-16 18:41:25 --> Router Class Initialized
INFO - 2021-04-16 18:41:25 --> Output Class Initialized
INFO - 2021-04-16 18:41:25 --> Security Class Initialized
DEBUG - 2021-04-16 18:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:41:25 --> Input Class Initialized
INFO - 2021-04-16 18:41:25 --> Language Class Initialized
INFO - 2021-04-16 18:41:25 --> Loader Class Initialized
INFO - 2021-04-16 18:41:25 --> Helper loaded: url_helper
INFO - 2021-04-16 18:41:25 --> Helper loaded: form_helper
INFO - 2021-04-16 18:41:25 --> Helper loaded: common_helper
INFO - 2021-04-16 18:41:25 --> Helper loaded: util_helper
INFO - 2021-04-16 18:41:25 --> Helper loaded: user_helper
INFO - 2021-04-16 18:41:25 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:41:25 --> Form Validation Class Initialized
INFO - 2021-04-16 18:41:25 --> Model Class Initialized
INFO - 2021-04-16 18:41:25 --> Controller Class Initialized
INFO - 2021-04-16 18:41:25 --> Model Class Initialized
INFO - 2021-04-16 18:41:25 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 18:41:25 --> Final output sent to browser
DEBUG - 2021-04-16 18:41:25 --> Total execution time: 0.0266
INFO - 2021-04-16 18:43:53 --> Config Class Initialized
INFO - 2021-04-16 18:43:53 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:43:53 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:43:53 --> Utf8 Class Initialized
INFO - 2021-04-16 18:43:53 --> URI Class Initialized
INFO - 2021-04-16 18:43:53 --> Router Class Initialized
INFO - 2021-04-16 18:43:53 --> Output Class Initialized
INFO - 2021-04-16 18:43:53 --> Security Class Initialized
DEBUG - 2021-04-16 18:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:43:53 --> Input Class Initialized
INFO - 2021-04-16 18:43:53 --> Language Class Initialized
INFO - 2021-04-16 18:43:53 --> Loader Class Initialized
INFO - 2021-04-16 18:43:53 --> Helper loaded: url_helper
INFO - 2021-04-16 18:43:53 --> Helper loaded: form_helper
INFO - 2021-04-16 18:43:53 --> Helper loaded: common_helper
INFO - 2021-04-16 18:43:53 --> Helper loaded: util_helper
INFO - 2021-04-16 18:43:53 --> Helper loaded: user_helper
INFO - 2021-04-16 18:43:53 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:43:53 --> Form Validation Class Initialized
INFO - 2021-04-16 18:43:53 --> Model Class Initialized
INFO - 2021-04-16 18:43:53 --> Controller Class Initialized
INFO - 2021-04-16 18:43:53 --> Model Class Initialized
INFO - 2021-04-16 18:43:53 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 18:43:53 --> Final output sent to browser
DEBUG - 2021-04-16 18:43:53 --> Total execution time: 0.0299
INFO - 2021-04-16 18:44:13 --> Config Class Initialized
INFO - 2021-04-16 18:44:13 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:44:13 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:44:13 --> Utf8 Class Initialized
INFO - 2021-04-16 18:44:13 --> URI Class Initialized
INFO - 2021-04-16 18:44:13 --> Router Class Initialized
INFO - 2021-04-16 18:44:13 --> Output Class Initialized
INFO - 2021-04-16 18:44:13 --> Security Class Initialized
DEBUG - 2021-04-16 18:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:44:13 --> Input Class Initialized
INFO - 2021-04-16 18:44:13 --> Language Class Initialized
INFO - 2021-04-16 18:44:13 --> Loader Class Initialized
INFO - 2021-04-16 18:44:13 --> Helper loaded: url_helper
INFO - 2021-04-16 18:44:13 --> Helper loaded: form_helper
INFO - 2021-04-16 18:44:13 --> Helper loaded: common_helper
INFO - 2021-04-16 18:44:13 --> Helper loaded: util_helper
INFO - 2021-04-16 18:44:13 --> Helper loaded: user_helper
INFO - 2021-04-16 18:44:13 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:44:13 --> Form Validation Class Initialized
INFO - 2021-04-16 18:44:13 --> Model Class Initialized
INFO - 2021-04-16 18:44:13 --> Controller Class Initialized
INFO - 2021-04-16 18:44:13 --> Model Class Initialized
INFO - 2021-04-16 18:44:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-16 18:44:13 --> Config Class Initialized
INFO - 2021-04-16 18:44:13 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:44:13 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:44:13 --> Utf8 Class Initialized
INFO - 2021-04-16 18:44:13 --> URI Class Initialized
INFO - 2021-04-16 18:44:13 --> Router Class Initialized
INFO - 2021-04-16 18:44:13 --> Output Class Initialized
INFO - 2021-04-16 18:44:13 --> Security Class Initialized
DEBUG - 2021-04-16 18:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:44:13 --> Input Class Initialized
INFO - 2021-04-16 18:44:13 --> Language Class Initialized
INFO - 2021-04-16 18:44:13 --> Loader Class Initialized
INFO - 2021-04-16 18:44:13 --> Helper loaded: url_helper
INFO - 2021-04-16 18:44:13 --> Helper loaded: form_helper
INFO - 2021-04-16 18:44:13 --> Helper loaded: common_helper
INFO - 2021-04-16 18:44:13 --> Helper loaded: util_helper
INFO - 2021-04-16 18:44:13 --> Helper loaded: user_helper
INFO - 2021-04-16 18:44:13 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:44:13 --> Form Validation Class Initialized
INFO - 2021-04-16 18:44:13 --> Model Class Initialized
INFO - 2021-04-16 18:44:13 --> Controller Class Initialized
INFO - 2021-04-16 18:44:13 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 18:44:13 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 18:44:13 --> Final output sent to browser
DEBUG - 2021-04-16 18:44:13 --> Total execution time: 0.0317
INFO - 2021-04-16 18:44:27 --> Config Class Initialized
INFO - 2021-04-16 18:44:27 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:44:27 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:44:27 --> Utf8 Class Initialized
INFO - 2021-04-16 18:44:27 --> URI Class Initialized
INFO - 2021-04-16 18:44:27 --> Router Class Initialized
INFO - 2021-04-16 18:44:27 --> Output Class Initialized
INFO - 2021-04-16 18:44:27 --> Security Class Initialized
DEBUG - 2021-04-16 18:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:44:27 --> Input Class Initialized
INFO - 2021-04-16 18:44:27 --> Language Class Initialized
INFO - 2021-04-16 18:44:27 --> Loader Class Initialized
INFO - 2021-04-16 18:44:27 --> Helper loaded: url_helper
INFO - 2021-04-16 18:44:27 --> Helper loaded: form_helper
INFO - 2021-04-16 18:44:27 --> Helper loaded: common_helper
INFO - 2021-04-16 18:44:27 --> Helper loaded: util_helper
INFO - 2021-04-16 18:44:27 --> Helper loaded: user_helper
INFO - 2021-04-16 18:44:27 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:44:27 --> Form Validation Class Initialized
INFO - 2021-04-16 18:44:27 --> Model Class Initialized
INFO - 2021-04-16 18:44:27 --> Controller Class Initialized
INFO - 2021-04-16 18:44:27 --> Model Class Initialized
INFO - 2021-04-16 18:44:27 --> Config Class Initialized
INFO - 2021-04-16 18:44:27 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:44:27 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:44:27 --> Utf8 Class Initialized
INFO - 2021-04-16 18:44:27 --> URI Class Initialized
INFO - 2021-04-16 18:44:27 --> Router Class Initialized
INFO - 2021-04-16 18:44:27 --> Output Class Initialized
INFO - 2021-04-16 18:44:27 --> Security Class Initialized
DEBUG - 2021-04-16 18:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:44:27 --> Input Class Initialized
INFO - 2021-04-16 18:44:27 --> Language Class Initialized
INFO - 2021-04-16 18:44:27 --> Loader Class Initialized
INFO - 2021-04-16 18:44:27 --> Helper loaded: url_helper
INFO - 2021-04-16 18:44:27 --> Helper loaded: form_helper
INFO - 2021-04-16 18:44:27 --> Helper loaded: common_helper
INFO - 2021-04-16 18:44:27 --> Helper loaded: util_helper
INFO - 2021-04-16 18:44:27 --> Helper loaded: user_helper
INFO - 2021-04-16 18:44:27 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:44:27 --> Form Validation Class Initialized
INFO - 2021-04-16 18:44:27 --> Model Class Initialized
INFO - 2021-04-16 18:44:27 --> Controller Class Initialized
INFO - 2021-04-16 18:44:27 --> Model Class Initialized
INFO - 2021-04-16 18:44:27 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 18:44:27 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 18:44:27 --> Final output sent to browser
DEBUG - 2021-04-16 18:44:27 --> Total execution time: 0.0273
INFO - 2021-04-16 18:44:30 --> Config Class Initialized
INFO - 2021-04-16 18:44:30 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:44:30 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:44:30 --> Utf8 Class Initialized
INFO - 2021-04-16 18:44:30 --> URI Class Initialized
INFO - 2021-04-16 18:44:30 --> Router Class Initialized
INFO - 2021-04-16 18:44:30 --> Output Class Initialized
INFO - 2021-04-16 18:44:30 --> Security Class Initialized
DEBUG - 2021-04-16 18:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:44:30 --> Input Class Initialized
INFO - 2021-04-16 18:44:30 --> Language Class Initialized
INFO - 2021-04-16 18:44:30 --> Loader Class Initialized
INFO - 2021-04-16 18:44:30 --> Helper loaded: url_helper
INFO - 2021-04-16 18:44:30 --> Helper loaded: form_helper
INFO - 2021-04-16 18:44:30 --> Helper loaded: common_helper
INFO - 2021-04-16 18:44:30 --> Helper loaded: util_helper
INFO - 2021-04-16 18:44:30 --> Helper loaded: user_helper
INFO - 2021-04-16 18:44:30 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:44:30 --> Form Validation Class Initialized
INFO - 2021-04-16 18:44:30 --> Model Class Initialized
INFO - 2021-04-16 18:44:30 --> Controller Class Initialized
INFO - 2021-04-16 18:44:30 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 18:44:30 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 18:44:30 --> Final output sent to browser
DEBUG - 2021-04-16 18:44:30 --> Total execution time: 0.0370
INFO - 2021-04-16 18:44:30 --> Config Class Initialized
INFO - 2021-04-16 18:44:30 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:44:30 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:44:30 --> Utf8 Class Initialized
INFO - 2021-04-16 18:44:30 --> URI Class Initialized
INFO - 2021-04-16 18:44:30 --> Router Class Initialized
INFO - 2021-04-16 18:44:30 --> Output Class Initialized
INFO - 2021-04-16 18:44:30 --> Security Class Initialized
DEBUG - 2021-04-16 18:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:44:30 --> Input Class Initialized
INFO - 2021-04-16 18:44:30 --> Language Class Initialized
INFO - 2021-04-16 18:44:30 --> Loader Class Initialized
INFO - 2021-04-16 18:44:30 --> Helper loaded: url_helper
INFO - 2021-04-16 18:44:30 --> Helper loaded: form_helper
INFO - 2021-04-16 18:44:30 --> Helper loaded: common_helper
INFO - 2021-04-16 18:44:30 --> Helper loaded: util_helper
INFO - 2021-04-16 18:44:30 --> Helper loaded: user_helper
INFO - 2021-04-16 18:44:30 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:44:30 --> Form Validation Class Initialized
INFO - 2021-04-16 18:44:30 --> Model Class Initialized
INFO - 2021-04-16 18:44:30 --> Controller Class Initialized
INFO - 2021-04-16 18:44:30 --> Model Class Initialized
INFO - 2021-04-16 18:44:30 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 18:44:30 --> Final output sent to browser
DEBUG - 2021-04-16 18:44:30 --> Total execution time: 0.0264
INFO - 2021-04-16 18:45:08 --> Config Class Initialized
INFO - 2021-04-16 18:45:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:45:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:45:08 --> Utf8 Class Initialized
INFO - 2021-04-16 18:45:08 --> URI Class Initialized
INFO - 2021-04-16 18:45:08 --> Router Class Initialized
INFO - 2021-04-16 18:45:08 --> Output Class Initialized
INFO - 2021-04-16 18:45:08 --> Security Class Initialized
DEBUG - 2021-04-16 18:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:45:08 --> Input Class Initialized
INFO - 2021-04-16 18:45:08 --> Language Class Initialized
INFO - 2021-04-16 18:45:08 --> Loader Class Initialized
INFO - 2021-04-16 18:45:08 --> Helper loaded: url_helper
INFO - 2021-04-16 18:45:08 --> Helper loaded: form_helper
INFO - 2021-04-16 18:45:08 --> Helper loaded: common_helper
INFO - 2021-04-16 18:45:08 --> Helper loaded: util_helper
INFO - 2021-04-16 18:45:08 --> Helper loaded: user_helper
INFO - 2021-04-16 18:45:08 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:45:08 --> Form Validation Class Initialized
INFO - 2021-04-16 18:45:08 --> Model Class Initialized
INFO - 2021-04-16 18:45:08 --> Controller Class Initialized
INFO - 2021-04-16 18:45:08 --> Model Class Initialized
INFO - 2021-04-16 18:45:08 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 18:45:08 --> Final output sent to browser
DEBUG - 2021-04-16 18:45:08 --> Total execution time: 0.0272
INFO - 2021-04-16 18:45:25 --> Config Class Initialized
INFO - 2021-04-16 18:45:25 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:45:25 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:45:25 --> Utf8 Class Initialized
INFO - 2021-04-16 18:45:25 --> URI Class Initialized
INFO - 2021-04-16 18:45:25 --> Router Class Initialized
INFO - 2021-04-16 18:45:25 --> Output Class Initialized
INFO - 2021-04-16 18:45:25 --> Security Class Initialized
DEBUG - 2021-04-16 18:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:45:25 --> Input Class Initialized
INFO - 2021-04-16 18:45:25 --> Language Class Initialized
INFO - 2021-04-16 18:45:25 --> Loader Class Initialized
INFO - 2021-04-16 18:45:25 --> Helper loaded: url_helper
INFO - 2021-04-16 18:45:25 --> Helper loaded: form_helper
INFO - 2021-04-16 18:45:25 --> Helper loaded: common_helper
INFO - 2021-04-16 18:45:25 --> Helper loaded: util_helper
INFO - 2021-04-16 18:45:25 --> Helper loaded: user_helper
INFO - 2021-04-16 18:45:25 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:45:25 --> Form Validation Class Initialized
INFO - 2021-04-16 18:45:25 --> Model Class Initialized
INFO - 2021-04-16 18:45:25 --> Controller Class Initialized
INFO - 2021-04-16 18:45:25 --> Model Class Initialized
INFO - 2021-04-16 18:45:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-16 18:45:25 --> Config Class Initialized
INFO - 2021-04-16 18:45:25 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:45:25 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:45:25 --> Utf8 Class Initialized
INFO - 2021-04-16 18:45:25 --> URI Class Initialized
INFO - 2021-04-16 18:45:25 --> Router Class Initialized
INFO - 2021-04-16 18:45:25 --> Output Class Initialized
INFO - 2021-04-16 18:45:25 --> Security Class Initialized
DEBUG - 2021-04-16 18:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:45:25 --> Input Class Initialized
INFO - 2021-04-16 18:45:25 --> Language Class Initialized
INFO - 2021-04-16 18:45:25 --> Loader Class Initialized
INFO - 2021-04-16 18:45:25 --> Helper loaded: url_helper
INFO - 2021-04-16 18:45:25 --> Helper loaded: form_helper
INFO - 2021-04-16 18:45:25 --> Helper loaded: common_helper
INFO - 2021-04-16 18:45:25 --> Helper loaded: util_helper
INFO - 2021-04-16 18:45:25 --> Helper loaded: user_helper
INFO - 2021-04-16 18:45:25 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:45:25 --> Form Validation Class Initialized
INFO - 2021-04-16 18:45:25 --> Model Class Initialized
INFO - 2021-04-16 18:45:25 --> Controller Class Initialized
INFO - 2021-04-16 18:45:25 --> Model Class Initialized
ERROR - 2021-04-16 18:45:25 --> Query error: Table 'foodtruck.user_id' doesn't exist - Invalid query: SELECT *
FROM `user_id`
WHERE 5 IS NULL
INFO - 2021-04-16 18:45:25 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 18:45:25 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 18:45:25 --> Final output sent to browser
DEBUG - 2021-04-16 18:45:25 --> Total execution time: 0.0303
INFO - 2021-04-16 18:46:05 --> Config Class Initialized
INFO - 2021-04-16 18:46:05 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:46:05 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:46:05 --> Utf8 Class Initialized
INFO - 2021-04-16 18:46:05 --> URI Class Initialized
INFO - 2021-04-16 18:46:05 --> Router Class Initialized
INFO - 2021-04-16 18:46:05 --> Output Class Initialized
INFO - 2021-04-16 18:46:05 --> Security Class Initialized
DEBUG - 2021-04-16 18:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:46:05 --> Input Class Initialized
INFO - 2021-04-16 18:46:05 --> Language Class Initialized
INFO - 2021-04-16 18:46:05 --> Loader Class Initialized
INFO - 2021-04-16 18:46:05 --> Helper loaded: url_helper
INFO - 2021-04-16 18:46:05 --> Helper loaded: form_helper
INFO - 2021-04-16 18:46:05 --> Helper loaded: common_helper
INFO - 2021-04-16 18:46:05 --> Helper loaded: util_helper
INFO - 2021-04-16 18:46:05 --> Helper loaded: user_helper
INFO - 2021-04-16 18:46:05 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:46:05 --> Form Validation Class Initialized
INFO - 2021-04-16 18:46:05 --> Model Class Initialized
INFO - 2021-04-16 18:46:05 --> Controller Class Initialized
INFO - 2021-04-16 18:46:05 --> Model Class Initialized
INFO - 2021-04-16 18:46:05 --> Config Class Initialized
INFO - 2021-04-16 18:46:05 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:46:05 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:46:05 --> Utf8 Class Initialized
INFO - 2021-04-16 18:46:05 --> URI Class Initialized
INFO - 2021-04-16 18:46:05 --> Router Class Initialized
INFO - 2021-04-16 18:46:05 --> Output Class Initialized
INFO - 2021-04-16 18:46:05 --> Security Class Initialized
DEBUG - 2021-04-16 18:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:46:05 --> Input Class Initialized
INFO - 2021-04-16 18:46:05 --> Language Class Initialized
INFO - 2021-04-16 18:46:05 --> Loader Class Initialized
INFO - 2021-04-16 18:46:05 --> Helper loaded: url_helper
INFO - 2021-04-16 18:46:05 --> Helper loaded: form_helper
INFO - 2021-04-16 18:46:05 --> Helper loaded: common_helper
INFO - 2021-04-16 18:46:05 --> Helper loaded: util_helper
INFO - 2021-04-16 18:46:05 --> Helper loaded: user_helper
INFO - 2021-04-16 18:46:05 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:46:05 --> Form Validation Class Initialized
INFO - 2021-04-16 18:46:05 --> Model Class Initialized
INFO - 2021-04-16 18:46:05 --> Controller Class Initialized
INFO - 2021-04-16 18:46:05 --> Model Class Initialized
INFO - 2021-04-16 18:46:05 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 18:46:05 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 18:46:05 --> Final output sent to browser
DEBUG - 2021-04-16 18:46:05 --> Total execution time: 0.0281
INFO - 2021-04-16 18:46:08 --> Config Class Initialized
INFO - 2021-04-16 18:46:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:46:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:46:08 --> Utf8 Class Initialized
INFO - 2021-04-16 18:46:08 --> URI Class Initialized
INFO - 2021-04-16 18:46:08 --> Router Class Initialized
INFO - 2021-04-16 18:46:08 --> Output Class Initialized
INFO - 2021-04-16 18:46:08 --> Security Class Initialized
DEBUG - 2021-04-16 18:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:46:08 --> Input Class Initialized
INFO - 2021-04-16 18:46:08 --> Language Class Initialized
INFO - 2021-04-16 18:46:08 --> Loader Class Initialized
INFO - 2021-04-16 18:46:08 --> Helper loaded: url_helper
INFO - 2021-04-16 18:46:08 --> Helper loaded: form_helper
INFO - 2021-04-16 18:46:08 --> Helper loaded: common_helper
INFO - 2021-04-16 18:46:08 --> Helper loaded: util_helper
INFO - 2021-04-16 18:46:08 --> Helper loaded: user_helper
INFO - 2021-04-16 18:46:08 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:46:08 --> Form Validation Class Initialized
INFO - 2021-04-16 18:46:08 --> Model Class Initialized
INFO - 2021-04-16 18:46:08 --> Controller Class Initialized
INFO - 2021-04-16 18:46:08 --> Model Class Initialized
INFO - 2021-04-16 18:46:08 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 18:46:08 --> Final output sent to browser
DEBUG - 2021-04-16 18:46:08 --> Total execution time: 0.0273
INFO - 2021-04-16 18:46:24 --> Config Class Initialized
INFO - 2021-04-16 18:46:24 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:46:24 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:46:24 --> Utf8 Class Initialized
INFO - 2021-04-16 18:46:24 --> URI Class Initialized
INFO - 2021-04-16 18:46:24 --> Router Class Initialized
INFO - 2021-04-16 18:46:24 --> Output Class Initialized
INFO - 2021-04-16 18:46:24 --> Security Class Initialized
DEBUG - 2021-04-16 18:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:46:24 --> Input Class Initialized
INFO - 2021-04-16 18:46:24 --> Language Class Initialized
INFO - 2021-04-16 18:46:24 --> Loader Class Initialized
INFO - 2021-04-16 18:46:24 --> Helper loaded: url_helper
INFO - 2021-04-16 18:46:24 --> Helper loaded: form_helper
INFO - 2021-04-16 18:46:24 --> Helper loaded: common_helper
INFO - 2021-04-16 18:46:24 --> Helper loaded: util_helper
INFO - 2021-04-16 18:46:24 --> Helper loaded: user_helper
INFO - 2021-04-16 18:46:25 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:46:25 --> Form Validation Class Initialized
INFO - 2021-04-16 18:46:25 --> Model Class Initialized
INFO - 2021-04-16 18:46:25 --> Controller Class Initialized
INFO - 2021-04-16 18:46:25 --> Model Class Initialized
INFO - 2021-04-16 18:46:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-16 18:46:25 --> Config Class Initialized
INFO - 2021-04-16 18:46:25 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:46:25 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:46:25 --> Utf8 Class Initialized
INFO - 2021-04-16 18:46:25 --> URI Class Initialized
INFO - 2021-04-16 18:46:25 --> Router Class Initialized
INFO - 2021-04-16 18:46:25 --> Output Class Initialized
INFO - 2021-04-16 18:46:25 --> Security Class Initialized
DEBUG - 2021-04-16 18:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:46:25 --> Input Class Initialized
INFO - 2021-04-16 18:46:25 --> Language Class Initialized
INFO - 2021-04-16 18:46:25 --> Loader Class Initialized
INFO - 2021-04-16 18:46:25 --> Helper loaded: url_helper
INFO - 2021-04-16 18:46:25 --> Helper loaded: form_helper
INFO - 2021-04-16 18:46:25 --> Helper loaded: common_helper
INFO - 2021-04-16 18:46:25 --> Helper loaded: util_helper
INFO - 2021-04-16 18:46:25 --> Helper loaded: user_helper
INFO - 2021-04-16 18:46:25 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:46:25 --> Form Validation Class Initialized
INFO - 2021-04-16 18:46:25 --> Model Class Initialized
INFO - 2021-04-16 18:46:25 --> Controller Class Initialized
INFO - 2021-04-16 18:46:25 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 18:46:25 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 18:46:25 --> Final output sent to browser
DEBUG - 2021-04-16 18:46:25 --> Total execution time: 0.0285
INFO - 2021-04-16 18:46:34 --> Config Class Initialized
INFO - 2021-04-16 18:46:34 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:46:34 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:46:34 --> Utf8 Class Initialized
INFO - 2021-04-16 18:46:34 --> URI Class Initialized
INFO - 2021-04-16 18:46:34 --> Router Class Initialized
INFO - 2021-04-16 18:46:34 --> Output Class Initialized
INFO - 2021-04-16 18:46:34 --> Security Class Initialized
DEBUG - 2021-04-16 18:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:46:34 --> Input Class Initialized
INFO - 2021-04-16 18:46:34 --> Language Class Initialized
INFO - 2021-04-16 18:46:34 --> Loader Class Initialized
INFO - 2021-04-16 18:46:34 --> Helper loaded: url_helper
INFO - 2021-04-16 18:46:34 --> Helper loaded: form_helper
INFO - 2021-04-16 18:46:34 --> Helper loaded: common_helper
INFO - 2021-04-16 18:46:34 --> Helper loaded: util_helper
INFO - 2021-04-16 18:46:34 --> Helper loaded: user_helper
INFO - 2021-04-16 18:46:34 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:46:34 --> Form Validation Class Initialized
INFO - 2021-04-16 18:46:34 --> Model Class Initialized
INFO - 2021-04-16 18:46:34 --> Controller Class Initialized
INFO - 2021-04-16 18:46:34 --> Model Class Initialized
INFO - 2021-04-16 18:46:34 --> Config Class Initialized
INFO - 2021-04-16 18:46:34 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:46:34 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:46:34 --> Utf8 Class Initialized
INFO - 2021-04-16 18:46:34 --> URI Class Initialized
INFO - 2021-04-16 18:46:34 --> Router Class Initialized
INFO - 2021-04-16 18:46:34 --> Output Class Initialized
INFO - 2021-04-16 18:46:34 --> Security Class Initialized
DEBUG - 2021-04-16 18:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:46:34 --> Input Class Initialized
INFO - 2021-04-16 18:46:34 --> Language Class Initialized
INFO - 2021-04-16 18:46:34 --> Loader Class Initialized
INFO - 2021-04-16 18:46:34 --> Helper loaded: url_helper
INFO - 2021-04-16 18:46:34 --> Helper loaded: form_helper
INFO - 2021-04-16 18:46:34 --> Helper loaded: common_helper
INFO - 2021-04-16 18:46:34 --> Helper loaded: util_helper
INFO - 2021-04-16 18:46:34 --> Helper loaded: user_helper
INFO - 2021-04-16 18:46:34 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:46:34 --> Form Validation Class Initialized
INFO - 2021-04-16 18:46:34 --> Model Class Initialized
INFO - 2021-04-16 18:46:34 --> Controller Class Initialized
INFO - 2021-04-16 18:46:34 --> Model Class Initialized
INFO - 2021-04-16 18:46:34 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 18:46:34 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 18:46:34 --> Final output sent to browser
DEBUG - 2021-04-16 18:46:34 --> Total execution time: 0.0372
INFO - 2021-04-16 18:46:37 --> Config Class Initialized
INFO - 2021-04-16 18:46:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:46:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:46:37 --> Utf8 Class Initialized
INFO - 2021-04-16 18:46:37 --> URI Class Initialized
INFO - 2021-04-16 18:46:37 --> Router Class Initialized
INFO - 2021-04-16 18:46:37 --> Output Class Initialized
INFO - 2021-04-16 18:46:37 --> Security Class Initialized
DEBUG - 2021-04-16 18:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:46:37 --> Input Class Initialized
INFO - 2021-04-16 18:46:37 --> Language Class Initialized
INFO - 2021-04-16 18:46:37 --> Loader Class Initialized
INFO - 2021-04-16 18:46:37 --> Helper loaded: url_helper
INFO - 2021-04-16 18:46:37 --> Helper loaded: form_helper
INFO - 2021-04-16 18:46:37 --> Helper loaded: common_helper
INFO - 2021-04-16 18:46:37 --> Helper loaded: util_helper
INFO - 2021-04-16 18:46:37 --> Helper loaded: user_helper
INFO - 2021-04-16 18:46:37 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:46:37 --> Form Validation Class Initialized
INFO - 2021-04-16 18:46:37 --> Model Class Initialized
INFO - 2021-04-16 18:46:37 --> Controller Class Initialized
INFO - 2021-04-16 18:46:37 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 18:46:37 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 18:46:37 --> Final output sent to browser
DEBUG - 2021-04-16 18:46:37 --> Total execution time: 0.0268
INFO - 2021-04-16 18:46:37 --> Config Class Initialized
INFO - 2021-04-16 18:46:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:46:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:46:37 --> Utf8 Class Initialized
INFO - 2021-04-16 18:46:37 --> URI Class Initialized
INFO - 2021-04-16 18:46:37 --> Router Class Initialized
INFO - 2021-04-16 18:46:37 --> Output Class Initialized
INFO - 2021-04-16 18:46:37 --> Security Class Initialized
DEBUG - 2021-04-16 18:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:46:37 --> Input Class Initialized
INFO - 2021-04-16 18:46:37 --> Language Class Initialized
INFO - 2021-04-16 18:46:37 --> Loader Class Initialized
INFO - 2021-04-16 18:46:37 --> Helper loaded: url_helper
INFO - 2021-04-16 18:46:37 --> Helper loaded: form_helper
INFO - 2021-04-16 18:46:37 --> Helper loaded: common_helper
INFO - 2021-04-16 18:46:37 --> Helper loaded: util_helper
INFO - 2021-04-16 18:46:37 --> Helper loaded: user_helper
INFO - 2021-04-16 18:46:37 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:46:37 --> Form Validation Class Initialized
INFO - 2021-04-16 18:46:37 --> Model Class Initialized
INFO - 2021-04-16 18:46:37 --> Controller Class Initialized
INFO - 2021-04-16 18:46:37 --> Model Class Initialized
INFO - 2021-04-16 18:46:37 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 18:46:37 --> Final output sent to browser
DEBUG - 2021-04-16 18:46:37 --> Total execution time: 0.0278
INFO - 2021-04-16 18:47:24 --> Config Class Initialized
INFO - 2021-04-16 18:47:24 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:47:24 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:47:24 --> Utf8 Class Initialized
INFO - 2021-04-16 18:47:24 --> URI Class Initialized
INFO - 2021-04-16 18:47:24 --> Router Class Initialized
INFO - 2021-04-16 18:47:24 --> Output Class Initialized
INFO - 2021-04-16 18:47:24 --> Security Class Initialized
DEBUG - 2021-04-16 18:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:47:24 --> Input Class Initialized
INFO - 2021-04-16 18:47:24 --> Language Class Initialized
INFO - 2021-04-16 18:47:24 --> Loader Class Initialized
INFO - 2021-04-16 18:47:24 --> Helper loaded: url_helper
INFO - 2021-04-16 18:47:24 --> Helper loaded: form_helper
INFO - 2021-04-16 18:47:24 --> Helper loaded: common_helper
INFO - 2021-04-16 18:47:24 --> Helper loaded: util_helper
INFO - 2021-04-16 18:47:24 --> Helper loaded: user_helper
INFO - 2021-04-16 18:47:24 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:47:24 --> Form Validation Class Initialized
INFO - 2021-04-16 18:47:24 --> Model Class Initialized
INFO - 2021-04-16 18:47:24 --> Controller Class Initialized
INFO - 2021-04-16 18:47:24 --> Model Class Initialized
INFO - 2021-04-16 18:47:24 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 18:47:24 --> Final output sent to browser
DEBUG - 2021-04-16 18:47:24 --> Total execution time: 0.0291
INFO - 2021-04-16 18:49:17 --> Config Class Initialized
INFO - 2021-04-16 18:49:17 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:49:17 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:49:17 --> Utf8 Class Initialized
INFO - 2021-04-16 18:49:17 --> URI Class Initialized
INFO - 2021-04-16 18:49:17 --> Router Class Initialized
INFO - 2021-04-16 18:49:17 --> Output Class Initialized
INFO - 2021-04-16 18:49:17 --> Security Class Initialized
DEBUG - 2021-04-16 18:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:49:17 --> Input Class Initialized
INFO - 2021-04-16 18:49:17 --> Language Class Initialized
INFO - 2021-04-16 18:49:17 --> Loader Class Initialized
INFO - 2021-04-16 18:49:17 --> Helper loaded: url_helper
INFO - 2021-04-16 18:49:17 --> Helper loaded: form_helper
INFO - 2021-04-16 18:49:17 --> Helper loaded: common_helper
INFO - 2021-04-16 18:49:17 --> Helper loaded: util_helper
INFO - 2021-04-16 18:49:17 --> Helper loaded: user_helper
INFO - 2021-04-16 18:49:17 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:49:17 --> Form Validation Class Initialized
INFO - 2021-04-16 18:49:17 --> Model Class Initialized
INFO - 2021-04-16 18:49:17 --> Controller Class Initialized
INFO - 2021-04-16 18:49:17 --> Model Class Initialized
INFO - 2021-04-16 18:49:17 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 18:49:17 --> Final output sent to browser
DEBUG - 2021-04-16 18:49:17 --> Total execution time: 0.0367
INFO - 2021-04-16 18:49:33 --> Config Class Initialized
INFO - 2021-04-16 18:49:33 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:49:33 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:49:33 --> Utf8 Class Initialized
INFO - 2021-04-16 18:49:33 --> URI Class Initialized
INFO - 2021-04-16 18:49:33 --> Router Class Initialized
INFO - 2021-04-16 18:49:33 --> Output Class Initialized
INFO - 2021-04-16 18:49:33 --> Security Class Initialized
DEBUG - 2021-04-16 18:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:49:33 --> Input Class Initialized
INFO - 2021-04-16 18:49:33 --> Language Class Initialized
INFO - 2021-04-16 18:49:33 --> Loader Class Initialized
INFO - 2021-04-16 18:49:33 --> Helper loaded: url_helper
INFO - 2021-04-16 18:49:33 --> Helper loaded: form_helper
INFO - 2021-04-16 18:49:33 --> Helper loaded: common_helper
INFO - 2021-04-16 18:49:33 --> Helper loaded: util_helper
INFO - 2021-04-16 18:49:33 --> Helper loaded: user_helper
INFO - 2021-04-16 18:49:33 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:49:33 --> Form Validation Class Initialized
INFO - 2021-04-16 18:49:33 --> Model Class Initialized
INFO - 2021-04-16 18:49:33 --> Controller Class Initialized
INFO - 2021-04-16 18:49:33 --> Model Class Initialized
INFO - 2021-04-16 18:49:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-16 18:49:33 --> Config Class Initialized
INFO - 2021-04-16 18:49:33 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:49:33 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:49:33 --> Utf8 Class Initialized
INFO - 2021-04-16 18:49:33 --> URI Class Initialized
INFO - 2021-04-16 18:49:33 --> Router Class Initialized
INFO - 2021-04-16 18:49:33 --> Output Class Initialized
INFO - 2021-04-16 18:49:33 --> Security Class Initialized
DEBUG - 2021-04-16 18:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:49:33 --> Input Class Initialized
INFO - 2021-04-16 18:49:33 --> Language Class Initialized
INFO - 2021-04-16 18:49:33 --> Loader Class Initialized
INFO - 2021-04-16 18:49:33 --> Helper loaded: url_helper
INFO - 2021-04-16 18:49:33 --> Helper loaded: form_helper
INFO - 2021-04-16 18:49:33 --> Helper loaded: common_helper
INFO - 2021-04-16 18:49:33 --> Helper loaded: util_helper
INFO - 2021-04-16 18:49:33 --> Helper loaded: user_helper
INFO - 2021-04-16 18:49:33 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:49:33 --> Form Validation Class Initialized
INFO - 2021-04-16 18:49:33 --> Model Class Initialized
INFO - 2021-04-16 18:49:33 --> Controller Class Initialized
INFO - 2021-04-16 18:49:33 --> Model Class Initialized
ERROR - 2021-04-16 18:49:33 --> Query error: Table 'foodtruck.user_id' doesn't exist - Invalid query: SELECT *
FROM `user_id`
 LIMIT 5
INFO - 2021-04-16 18:51:46 --> Config Class Initialized
INFO - 2021-04-16 18:51:46 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:51:46 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:51:46 --> Utf8 Class Initialized
INFO - 2021-04-16 18:51:46 --> URI Class Initialized
INFO - 2021-04-16 18:51:46 --> Router Class Initialized
INFO - 2021-04-16 18:51:46 --> Output Class Initialized
INFO - 2021-04-16 18:51:46 --> Security Class Initialized
DEBUG - 2021-04-16 18:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:51:46 --> Input Class Initialized
INFO - 2021-04-16 18:51:46 --> Language Class Initialized
INFO - 2021-04-16 18:51:46 --> Loader Class Initialized
INFO - 2021-04-16 18:51:46 --> Helper loaded: url_helper
INFO - 2021-04-16 18:51:46 --> Helper loaded: form_helper
INFO - 2021-04-16 18:51:46 --> Helper loaded: common_helper
INFO - 2021-04-16 18:51:46 --> Helper loaded: util_helper
INFO - 2021-04-16 18:51:46 --> Helper loaded: user_helper
INFO - 2021-04-16 18:51:46 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:51:46 --> Form Validation Class Initialized
INFO - 2021-04-16 18:51:46 --> Model Class Initialized
INFO - 2021-04-16 18:51:46 --> Controller Class Initialized
INFO - 2021-04-16 18:51:46 --> Model Class Initialized
ERROR - 2021-04-16 18:51:46 --> Query error: Table 'foodtruck.user_id' doesn't exist - Invalid query: SELECT *
FROM `user_id`
 LIMIT 5
INFO - 2021-04-16 18:51:46 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 18:51:46 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 18:51:46 --> Final output sent to browser
DEBUG - 2021-04-16 18:51:46 --> Total execution time: 0.0474
INFO - 2021-04-16 18:51:47 --> Config Class Initialized
INFO - 2021-04-16 18:51:47 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:51:47 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:51:47 --> Utf8 Class Initialized
INFO - 2021-04-16 18:51:47 --> URI Class Initialized
INFO - 2021-04-16 18:51:47 --> Router Class Initialized
INFO - 2021-04-16 18:51:47 --> Output Class Initialized
INFO - 2021-04-16 18:51:47 --> Security Class Initialized
DEBUG - 2021-04-16 18:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:51:47 --> Input Class Initialized
INFO - 2021-04-16 18:51:47 --> Language Class Initialized
INFO - 2021-04-16 18:51:47 --> Loader Class Initialized
INFO - 2021-04-16 18:51:47 --> Helper loaded: url_helper
INFO - 2021-04-16 18:51:47 --> Helper loaded: form_helper
INFO - 2021-04-16 18:51:47 --> Helper loaded: common_helper
INFO - 2021-04-16 18:51:47 --> Helper loaded: util_helper
INFO - 2021-04-16 18:51:47 --> Helper loaded: user_helper
INFO - 2021-04-16 18:51:47 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:51:47 --> Form Validation Class Initialized
INFO - 2021-04-16 18:51:47 --> Model Class Initialized
INFO - 2021-04-16 18:51:47 --> Controller Class Initialized
INFO - 2021-04-16 18:51:47 --> Model Class Initialized
INFO - 2021-04-16 18:51:47 --> Config Class Initialized
INFO - 2021-04-16 18:51:47 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:51:47 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:51:47 --> Utf8 Class Initialized
INFO - 2021-04-16 18:51:47 --> URI Class Initialized
INFO - 2021-04-16 18:51:47 --> Router Class Initialized
INFO - 2021-04-16 18:51:47 --> Output Class Initialized
INFO - 2021-04-16 18:51:47 --> Security Class Initialized
DEBUG - 2021-04-16 18:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:51:47 --> Input Class Initialized
INFO - 2021-04-16 18:51:47 --> Language Class Initialized
INFO - 2021-04-16 18:51:47 --> Loader Class Initialized
INFO - 2021-04-16 18:51:47 --> Helper loaded: url_helper
INFO - 2021-04-16 18:51:47 --> Helper loaded: form_helper
INFO - 2021-04-16 18:51:47 --> Helper loaded: common_helper
INFO - 2021-04-16 18:51:47 --> Helper loaded: util_helper
INFO - 2021-04-16 18:51:47 --> Helper loaded: user_helper
INFO - 2021-04-16 18:51:47 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:51:47 --> Form Validation Class Initialized
INFO - 2021-04-16 18:51:47 --> Model Class Initialized
INFO - 2021-04-16 18:51:47 --> Controller Class Initialized
INFO - 2021-04-16 18:51:47 --> Model Class Initialized
INFO - 2021-04-16 18:51:47 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 18:51:47 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 18:51:47 --> Final output sent to browser
DEBUG - 2021-04-16 18:51:47 --> Total execution time: 0.0380
INFO - 2021-04-16 18:52:02 --> Config Class Initialized
INFO - 2021-04-16 18:52:02 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:52:02 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:52:02 --> Utf8 Class Initialized
INFO - 2021-04-16 18:52:02 --> URI Class Initialized
INFO - 2021-04-16 18:52:02 --> Router Class Initialized
INFO - 2021-04-16 18:52:02 --> Output Class Initialized
INFO - 2021-04-16 18:52:02 --> Security Class Initialized
DEBUG - 2021-04-16 18:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:52:02 --> Input Class Initialized
INFO - 2021-04-16 18:52:02 --> Language Class Initialized
INFO - 2021-04-16 18:52:02 --> Loader Class Initialized
INFO - 2021-04-16 18:52:02 --> Helper loaded: url_helper
INFO - 2021-04-16 18:52:02 --> Helper loaded: form_helper
INFO - 2021-04-16 18:52:02 --> Helper loaded: common_helper
INFO - 2021-04-16 18:52:02 --> Helper loaded: util_helper
INFO - 2021-04-16 18:52:02 --> Helper loaded: user_helper
INFO - 2021-04-16 18:52:02 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:52:02 --> Form Validation Class Initialized
INFO - 2021-04-16 18:52:02 --> Model Class Initialized
INFO - 2021-04-16 18:52:02 --> Controller Class Initialized
INFO - 2021-04-16 18:52:02 --> Model Class Initialized
INFO - 2021-04-16 18:52:02 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 18:52:02 --> Final output sent to browser
DEBUG - 2021-04-16 18:52:02 --> Total execution time: 0.0377
INFO - 2021-04-16 18:52:02 --> Config Class Initialized
INFO - 2021-04-16 18:52:02 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:52:02 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:52:02 --> Utf8 Class Initialized
INFO - 2021-04-16 18:52:02 --> URI Class Initialized
INFO - 2021-04-16 18:52:02 --> Config Class Initialized
INFO - 2021-04-16 18:52:02 --> Hooks Class Initialized
INFO - 2021-04-16 18:52:02 --> Router Class Initialized
INFO - 2021-04-16 18:52:02 --> Output Class Initialized
DEBUG - 2021-04-16 18:52:02 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:52:02 --> Utf8 Class Initialized
INFO - 2021-04-16 18:52:02 --> Security Class Initialized
INFO - 2021-04-16 18:52:02 --> URI Class Initialized
DEBUG - 2021-04-16 18:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:52:02 --> Input Class Initialized
INFO - 2021-04-16 18:52:02 --> Language Class Initialized
INFO - 2021-04-16 18:52:02 --> Router Class Initialized
ERROR - 2021-04-16 18:52:02 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-16 18:52:02 --> Output Class Initialized
INFO - 2021-04-16 18:52:02 --> Security Class Initialized
DEBUG - 2021-04-16 18:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:52:02 --> Input Class Initialized
INFO - 2021-04-16 18:52:02 --> Language Class Initialized
ERROR - 2021-04-16 18:52:02 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-16 18:52:20 --> Config Class Initialized
INFO - 2021-04-16 18:52:20 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:52:20 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:52:20 --> Utf8 Class Initialized
INFO - 2021-04-16 18:52:20 --> URI Class Initialized
INFO - 2021-04-16 18:52:20 --> Router Class Initialized
INFO - 2021-04-16 18:52:20 --> Output Class Initialized
INFO - 2021-04-16 18:52:20 --> Security Class Initialized
DEBUG - 2021-04-16 18:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:52:20 --> Input Class Initialized
INFO - 2021-04-16 18:52:20 --> Language Class Initialized
INFO - 2021-04-16 18:52:20 --> Loader Class Initialized
INFO - 2021-04-16 18:52:20 --> Helper loaded: url_helper
INFO - 2021-04-16 18:52:20 --> Helper loaded: form_helper
INFO - 2021-04-16 18:52:20 --> Helper loaded: common_helper
INFO - 2021-04-16 18:52:20 --> Helper loaded: util_helper
INFO - 2021-04-16 18:52:20 --> Helper loaded: user_helper
INFO - 2021-04-16 18:52:20 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:52:20 --> Form Validation Class Initialized
INFO - 2021-04-16 18:52:20 --> Model Class Initialized
INFO - 2021-04-16 18:52:20 --> Controller Class Initialized
INFO - 2021-04-16 18:52:20 --> Model Class Initialized
INFO - 2021-04-16 18:52:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-16 18:52:20 --> Config Class Initialized
INFO - 2021-04-16 18:52:20 --> Hooks Class Initialized
DEBUG - 2021-04-16 18:52:20 --> UTF-8 Support Enabled
INFO - 2021-04-16 18:52:20 --> Utf8 Class Initialized
INFO - 2021-04-16 18:52:20 --> URI Class Initialized
INFO - 2021-04-16 18:52:20 --> Router Class Initialized
INFO - 2021-04-16 18:52:20 --> Output Class Initialized
INFO - 2021-04-16 18:52:20 --> Security Class Initialized
DEBUG - 2021-04-16 18:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 18:52:20 --> Input Class Initialized
INFO - 2021-04-16 18:52:20 --> Language Class Initialized
INFO - 2021-04-16 18:52:20 --> Loader Class Initialized
INFO - 2021-04-16 18:52:20 --> Helper loaded: url_helper
INFO - 2021-04-16 18:52:20 --> Helper loaded: form_helper
INFO - 2021-04-16 18:52:20 --> Helper loaded: common_helper
INFO - 2021-04-16 18:52:20 --> Helper loaded: util_helper
INFO - 2021-04-16 18:52:20 --> Helper loaded: user_helper
INFO - 2021-04-16 18:52:20 --> Database Driver Class Initialized
DEBUG - 2021-04-16 18:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 18:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 18:52:20 --> Form Validation Class Initialized
INFO - 2021-04-16 18:52:20 --> Model Class Initialized
INFO - 2021-04-16 18:52:20 --> Controller Class Initialized
INFO - 2021-04-16 18:52:20 --> Model Class Initialized
ERROR - 2021-04-16 18:52:20 --> Query error: Table 'foodtruck.user_id' doesn't exist - Invalid query: SELECT *
FROM `user_id`
 LIMIT 5
INFO - 2021-04-16 18:52:20 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 18:52:20 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 18:52:20 --> Final output sent to browser
DEBUG - 2021-04-16 18:52:20 --> Total execution time: 0.0431
INFO - 2021-04-16 19:32:01 --> Config Class Initialized
INFO - 2021-04-16 19:32:01 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:32:01 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:32:01 --> Utf8 Class Initialized
INFO - 2021-04-16 19:32:01 --> URI Class Initialized
INFO - 2021-04-16 19:32:01 --> Router Class Initialized
INFO - 2021-04-16 19:32:01 --> Output Class Initialized
INFO - 2021-04-16 19:32:01 --> Security Class Initialized
DEBUG - 2021-04-16 19:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:32:01 --> Input Class Initialized
INFO - 2021-04-16 19:32:01 --> Language Class Initialized
INFO - 2021-04-16 19:32:01 --> Loader Class Initialized
INFO - 2021-04-16 19:32:01 --> Helper loaded: url_helper
INFO - 2021-04-16 19:32:01 --> Helper loaded: form_helper
INFO - 2021-04-16 19:32:01 --> Helper loaded: common_helper
INFO - 2021-04-16 19:32:01 --> Helper loaded: util_helper
INFO - 2021-04-16 19:32:01 --> Helper loaded: user_helper
INFO - 2021-04-16 19:32:01 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:32:01 --> Form Validation Class Initialized
INFO - 2021-04-16 19:32:01 --> Model Class Initialized
INFO - 2021-04-16 19:32:01 --> Controller Class Initialized
INFO - 2021-04-16 19:32:01 --> Model Class Initialized
INFO - 2021-04-16 19:32:01 --> Config Class Initialized
INFO - 2021-04-16 19:32:01 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:32:01 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:32:01 --> Utf8 Class Initialized
INFO - 2021-04-16 19:32:01 --> URI Class Initialized
INFO - 2021-04-16 19:32:01 --> Router Class Initialized
INFO - 2021-04-16 19:32:01 --> Output Class Initialized
INFO - 2021-04-16 19:32:01 --> Security Class Initialized
DEBUG - 2021-04-16 19:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:32:01 --> Input Class Initialized
INFO - 2021-04-16 19:32:01 --> Language Class Initialized
INFO - 2021-04-16 19:32:01 --> Loader Class Initialized
INFO - 2021-04-16 19:32:01 --> Helper loaded: url_helper
INFO - 2021-04-16 19:32:01 --> Helper loaded: form_helper
INFO - 2021-04-16 19:32:01 --> Helper loaded: common_helper
INFO - 2021-04-16 19:32:01 --> Helper loaded: util_helper
INFO - 2021-04-16 19:32:01 --> Helper loaded: user_helper
INFO - 2021-04-16 19:32:01 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:32:01 --> Form Validation Class Initialized
INFO - 2021-04-16 19:32:01 --> Model Class Initialized
INFO - 2021-04-16 19:32:01 --> Controller Class Initialized
INFO - 2021-04-16 19:32:01 --> Model Class Initialized
INFO - 2021-04-16 19:32:01 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 19:32:01 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 19:32:01 --> Final output sent to browser
DEBUG - 2021-04-16 19:32:01 --> Total execution time: 0.0262
INFO - 2021-04-16 19:32:03 --> Config Class Initialized
INFO - 2021-04-16 19:32:03 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:32:03 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:32:03 --> Utf8 Class Initialized
INFO - 2021-04-16 19:32:03 --> URI Class Initialized
INFO - 2021-04-16 19:32:03 --> Router Class Initialized
INFO - 2021-04-16 19:32:03 --> Output Class Initialized
INFO - 2021-04-16 19:32:03 --> Security Class Initialized
DEBUG - 2021-04-16 19:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:32:03 --> Input Class Initialized
INFO - 2021-04-16 19:32:03 --> Language Class Initialized
INFO - 2021-04-16 19:32:03 --> Loader Class Initialized
INFO - 2021-04-16 19:32:03 --> Helper loaded: url_helper
INFO - 2021-04-16 19:32:03 --> Helper loaded: form_helper
INFO - 2021-04-16 19:32:03 --> Helper loaded: common_helper
INFO - 2021-04-16 19:32:03 --> Helper loaded: util_helper
INFO - 2021-04-16 19:32:03 --> Helper loaded: user_helper
INFO - 2021-04-16 19:32:03 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:32:03 --> Form Validation Class Initialized
INFO - 2021-04-16 19:32:03 --> Model Class Initialized
INFO - 2021-04-16 19:32:03 --> Controller Class Initialized
INFO - 2021-04-16 19:32:03 --> Model Class Initialized
INFO - 2021-04-16 19:32:03 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 19:32:03 --> Final output sent to browser
DEBUG - 2021-04-16 19:32:03 --> Total execution time: 0.0272
INFO - 2021-04-16 19:32:03 --> Config Class Initialized
INFO - 2021-04-16 19:32:03 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:32:03 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:32:03 --> Utf8 Class Initialized
INFO - 2021-04-16 19:32:03 --> URI Class Initialized
INFO - 2021-04-16 19:32:03 --> Router Class Initialized
INFO - 2021-04-16 19:32:03 --> Config Class Initialized
INFO - 2021-04-16 19:32:03 --> Hooks Class Initialized
INFO - 2021-04-16 19:32:03 --> Output Class Initialized
INFO - 2021-04-16 19:32:03 --> Security Class Initialized
DEBUG - 2021-04-16 19:32:03 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:32:03 --> Utf8 Class Initialized
DEBUG - 2021-04-16 19:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:32:03 --> Input Class Initialized
INFO - 2021-04-16 19:32:03 --> URI Class Initialized
INFO - 2021-04-16 19:32:03 --> Language Class Initialized
INFO - 2021-04-16 19:32:03 --> Router Class Initialized
ERROR - 2021-04-16 19:32:03 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-16 19:32:03 --> Output Class Initialized
INFO - 2021-04-16 19:32:03 --> Security Class Initialized
DEBUG - 2021-04-16 19:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:32:03 --> Input Class Initialized
INFO - 2021-04-16 19:32:03 --> Language Class Initialized
ERROR - 2021-04-16 19:32:03 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-16 19:32:39 --> Config Class Initialized
INFO - 2021-04-16 19:32:39 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:32:39 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:32:39 --> Utf8 Class Initialized
INFO - 2021-04-16 19:32:39 --> URI Class Initialized
INFO - 2021-04-16 19:32:39 --> Router Class Initialized
INFO - 2021-04-16 19:32:39 --> Output Class Initialized
INFO - 2021-04-16 19:32:39 --> Security Class Initialized
DEBUG - 2021-04-16 19:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:32:39 --> Input Class Initialized
INFO - 2021-04-16 19:32:39 --> Language Class Initialized
INFO - 2021-04-16 19:32:39 --> Loader Class Initialized
INFO - 2021-04-16 19:32:39 --> Helper loaded: url_helper
INFO - 2021-04-16 19:32:39 --> Helper loaded: form_helper
INFO - 2021-04-16 19:32:39 --> Helper loaded: common_helper
INFO - 2021-04-16 19:32:39 --> Helper loaded: util_helper
INFO - 2021-04-16 19:32:39 --> Helper loaded: user_helper
INFO - 2021-04-16 19:32:39 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:32:39 --> Form Validation Class Initialized
INFO - 2021-04-16 19:32:39 --> Model Class Initialized
INFO - 2021-04-16 19:32:39 --> Controller Class Initialized
INFO - 2021-04-16 19:32:39 --> Model Class Initialized
INFO - 2021-04-16 19:32:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-16 19:32:39 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 19:32:39 --> Final output sent to browser
DEBUG - 2021-04-16 19:32:39 --> Total execution time: 0.0461
INFO - 2021-04-16 19:32:40 --> Config Class Initialized
INFO - 2021-04-16 19:32:40 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:32:40 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:32:40 --> Utf8 Class Initialized
INFO - 2021-04-16 19:32:40 --> URI Class Initialized
INFO - 2021-04-16 19:32:40 --> Router Class Initialized
INFO - 2021-04-16 19:32:40 --> Output Class Initialized
INFO - 2021-04-16 19:32:40 --> Security Class Initialized
DEBUG - 2021-04-16 19:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:32:40 --> Input Class Initialized
INFO - 2021-04-16 19:32:40 --> Language Class Initialized
INFO - 2021-04-16 19:32:40 --> Loader Class Initialized
INFO - 2021-04-16 19:32:40 --> Helper loaded: url_helper
INFO - 2021-04-16 19:32:40 --> Helper loaded: form_helper
INFO - 2021-04-16 19:32:40 --> Helper loaded: common_helper
INFO - 2021-04-16 19:32:40 --> Helper loaded: util_helper
INFO - 2021-04-16 19:32:40 --> Helper loaded: user_helper
INFO - 2021-04-16 19:32:40 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:32:40 --> Form Validation Class Initialized
INFO - 2021-04-16 19:32:40 --> Model Class Initialized
INFO - 2021-04-16 19:32:40 --> Controller Class Initialized
INFO - 2021-04-16 19:32:40 --> Model Class Initialized
INFO - 2021-04-16 19:32:40 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 19:32:40 --> Final output sent to browser
DEBUG - 2021-04-16 19:32:40 --> Total execution time: 0.0293
INFO - 2021-04-16 19:33:48 --> Config Class Initialized
INFO - 2021-04-16 19:33:48 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:33:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:33:48 --> Utf8 Class Initialized
INFO - 2021-04-16 19:33:48 --> URI Class Initialized
INFO - 2021-04-16 19:33:48 --> Router Class Initialized
INFO - 2021-04-16 19:33:48 --> Output Class Initialized
INFO - 2021-04-16 19:33:48 --> Security Class Initialized
DEBUG - 2021-04-16 19:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:33:48 --> Input Class Initialized
INFO - 2021-04-16 19:33:48 --> Language Class Initialized
INFO - 2021-04-16 19:33:48 --> Loader Class Initialized
INFO - 2021-04-16 19:33:48 --> Helper loaded: url_helper
INFO - 2021-04-16 19:33:48 --> Helper loaded: form_helper
INFO - 2021-04-16 19:33:48 --> Helper loaded: common_helper
INFO - 2021-04-16 19:33:48 --> Helper loaded: util_helper
INFO - 2021-04-16 19:33:48 --> Helper loaded: user_helper
INFO - 2021-04-16 19:33:48 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:33:48 --> Form Validation Class Initialized
INFO - 2021-04-16 19:33:48 --> Model Class Initialized
INFO - 2021-04-16 19:33:48 --> Controller Class Initialized
INFO - 2021-04-16 19:33:48 --> Model Class Initialized
INFO - 2021-04-16 19:33:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-16 19:33:48 --> Config Class Initialized
INFO - 2021-04-16 19:33:48 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:33:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:33:48 --> Utf8 Class Initialized
INFO - 2021-04-16 19:33:48 --> URI Class Initialized
INFO - 2021-04-16 19:33:48 --> Router Class Initialized
INFO - 2021-04-16 19:33:48 --> Output Class Initialized
INFO - 2021-04-16 19:33:48 --> Security Class Initialized
DEBUG - 2021-04-16 19:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:33:48 --> Input Class Initialized
INFO - 2021-04-16 19:33:48 --> Language Class Initialized
INFO - 2021-04-16 19:33:48 --> Loader Class Initialized
INFO - 2021-04-16 19:33:48 --> Helper loaded: url_helper
INFO - 2021-04-16 19:33:48 --> Helper loaded: form_helper
INFO - 2021-04-16 19:33:48 --> Helper loaded: common_helper
INFO - 2021-04-16 19:33:48 --> Helper loaded: util_helper
INFO - 2021-04-16 19:33:48 --> Helper loaded: user_helper
INFO - 2021-04-16 19:33:48 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:33:48 --> Form Validation Class Initialized
INFO - 2021-04-16 19:33:48 --> Model Class Initialized
INFO - 2021-04-16 19:33:48 --> Controller Class Initialized
INFO - 2021-04-16 19:33:48 --> Model Class Initialized
ERROR - 2021-04-16 19:33:48 --> Query error: Table 'foodtruck.user_id' doesn't exist - Invalid query: SELECT *
FROM `user_id`
 LIMIT 5
INFO - 2021-04-16 19:33:48 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 19:33:48 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 19:33:48 --> Final output sent to browser
DEBUG - 2021-04-16 19:33:48 --> Total execution time: 0.0332
INFO - 2021-04-16 19:34:38 --> Config Class Initialized
INFO - 2021-04-16 19:34:38 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:34:38 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:34:38 --> Utf8 Class Initialized
INFO - 2021-04-16 19:34:38 --> URI Class Initialized
INFO - 2021-04-16 19:34:38 --> Router Class Initialized
INFO - 2021-04-16 19:34:38 --> Output Class Initialized
INFO - 2021-04-16 19:34:38 --> Security Class Initialized
DEBUG - 2021-04-16 19:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:34:38 --> Input Class Initialized
INFO - 2021-04-16 19:34:38 --> Language Class Initialized
INFO - 2021-04-16 19:34:38 --> Loader Class Initialized
INFO - 2021-04-16 19:34:38 --> Helper loaded: url_helper
INFO - 2021-04-16 19:34:38 --> Helper loaded: form_helper
INFO - 2021-04-16 19:34:38 --> Helper loaded: common_helper
INFO - 2021-04-16 19:34:38 --> Helper loaded: util_helper
INFO - 2021-04-16 19:34:38 --> Helper loaded: user_helper
INFO - 2021-04-16 19:34:38 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:34:38 --> Form Validation Class Initialized
INFO - 2021-04-16 19:34:38 --> Model Class Initialized
INFO - 2021-04-16 19:34:38 --> Controller Class Initialized
INFO - 2021-04-16 19:34:38 --> Model Class Initialized
INFO - 2021-04-16 19:34:38 --> Config Class Initialized
INFO - 2021-04-16 19:34:38 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:34:38 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:34:38 --> Utf8 Class Initialized
INFO - 2021-04-16 19:34:38 --> URI Class Initialized
INFO - 2021-04-16 19:34:38 --> Router Class Initialized
INFO - 2021-04-16 19:34:38 --> Output Class Initialized
INFO - 2021-04-16 19:34:38 --> Security Class Initialized
DEBUG - 2021-04-16 19:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:34:38 --> Input Class Initialized
INFO - 2021-04-16 19:34:38 --> Language Class Initialized
INFO - 2021-04-16 19:34:38 --> Loader Class Initialized
INFO - 2021-04-16 19:34:38 --> Helper loaded: url_helper
INFO - 2021-04-16 19:34:38 --> Helper loaded: form_helper
INFO - 2021-04-16 19:34:38 --> Helper loaded: common_helper
INFO - 2021-04-16 19:34:38 --> Helper loaded: util_helper
INFO - 2021-04-16 19:34:38 --> Helper loaded: user_helper
INFO - 2021-04-16 19:34:38 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:34:38 --> Form Validation Class Initialized
INFO - 2021-04-16 19:34:38 --> Model Class Initialized
INFO - 2021-04-16 19:34:38 --> Controller Class Initialized
INFO - 2021-04-16 19:34:38 --> Model Class Initialized
INFO - 2021-04-16 19:34:38 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 19:34:38 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 19:34:38 --> Final output sent to browser
DEBUG - 2021-04-16 19:34:38 --> Total execution time: 0.0385
INFO - 2021-04-16 19:34:39 --> Config Class Initialized
INFO - 2021-04-16 19:34:39 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:34:39 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:34:39 --> Utf8 Class Initialized
INFO - 2021-04-16 19:34:39 --> URI Class Initialized
INFO - 2021-04-16 19:34:39 --> Router Class Initialized
INFO - 2021-04-16 19:34:39 --> Output Class Initialized
INFO - 2021-04-16 19:34:39 --> Security Class Initialized
DEBUG - 2021-04-16 19:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:34:39 --> Input Class Initialized
INFO - 2021-04-16 19:34:39 --> Language Class Initialized
INFO - 2021-04-16 19:34:39 --> Loader Class Initialized
INFO - 2021-04-16 19:34:39 --> Helper loaded: url_helper
INFO - 2021-04-16 19:34:39 --> Helper loaded: form_helper
INFO - 2021-04-16 19:34:39 --> Helper loaded: common_helper
INFO - 2021-04-16 19:34:39 --> Helper loaded: util_helper
INFO - 2021-04-16 19:34:39 --> Helper loaded: user_helper
INFO - 2021-04-16 19:34:39 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:34:39 --> Form Validation Class Initialized
INFO - 2021-04-16 19:34:39 --> Model Class Initialized
INFO - 2021-04-16 19:34:39 --> Controller Class Initialized
INFO - 2021-04-16 19:34:39 --> Model Class Initialized
INFO - 2021-04-16 19:34:39 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 19:34:39 --> Final output sent to browser
DEBUG - 2021-04-16 19:34:39 --> Total execution time: 0.0281
INFO - 2021-04-16 19:34:56 --> Config Class Initialized
INFO - 2021-04-16 19:34:56 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:34:56 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:34:56 --> Utf8 Class Initialized
INFO - 2021-04-16 19:34:56 --> URI Class Initialized
INFO - 2021-04-16 19:34:56 --> Router Class Initialized
INFO - 2021-04-16 19:34:56 --> Output Class Initialized
INFO - 2021-04-16 19:34:56 --> Security Class Initialized
DEBUG - 2021-04-16 19:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:34:56 --> Input Class Initialized
INFO - 2021-04-16 19:34:56 --> Language Class Initialized
INFO - 2021-04-16 19:34:56 --> Loader Class Initialized
INFO - 2021-04-16 19:34:56 --> Helper loaded: url_helper
INFO - 2021-04-16 19:34:56 --> Helper loaded: form_helper
INFO - 2021-04-16 19:34:56 --> Helper loaded: common_helper
INFO - 2021-04-16 19:34:56 --> Helper loaded: util_helper
INFO - 2021-04-16 19:34:56 --> Helper loaded: user_helper
INFO - 2021-04-16 19:34:56 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:34:56 --> Form Validation Class Initialized
INFO - 2021-04-16 19:34:56 --> Model Class Initialized
INFO - 2021-04-16 19:34:56 --> Controller Class Initialized
INFO - 2021-04-16 19:34:56 --> Model Class Initialized
INFO - 2021-04-16 19:34:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-16 19:34:56 --> Config Class Initialized
INFO - 2021-04-16 19:34:56 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:34:56 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:34:56 --> Utf8 Class Initialized
INFO - 2021-04-16 19:34:56 --> URI Class Initialized
INFO - 2021-04-16 19:34:56 --> Router Class Initialized
INFO - 2021-04-16 19:34:56 --> Output Class Initialized
INFO - 2021-04-16 19:34:56 --> Security Class Initialized
DEBUG - 2021-04-16 19:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:34:56 --> Input Class Initialized
INFO - 2021-04-16 19:34:56 --> Language Class Initialized
INFO - 2021-04-16 19:34:56 --> Loader Class Initialized
INFO - 2021-04-16 19:34:56 --> Helper loaded: url_helper
INFO - 2021-04-16 19:34:56 --> Helper loaded: form_helper
INFO - 2021-04-16 19:34:56 --> Helper loaded: common_helper
INFO - 2021-04-16 19:34:56 --> Helper loaded: util_helper
INFO - 2021-04-16 19:34:56 --> Helper loaded: user_helper
INFO - 2021-04-16 19:34:56 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:34:56 --> Form Validation Class Initialized
INFO - 2021-04-16 19:34:56 --> Model Class Initialized
INFO - 2021-04-16 19:34:56 --> Controller Class Initialized
INFO - 2021-04-16 19:34:56 --> Model Class Initialized
ERROR - 2021-04-16 19:34:56 --> Query error: Table 'foodtruck.user_id' doesn't exist - Invalid query: SELECT *
FROM `user_id`
 LIMIT 5
INFO - 2021-04-16 19:34:56 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 19:34:56 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 19:34:56 --> Final output sent to browser
DEBUG - 2021-04-16 19:34:56 --> Total execution time: 0.0360
INFO - 2021-04-16 19:35:09 --> Config Class Initialized
INFO - 2021-04-16 19:35:09 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:35:09 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:35:09 --> Utf8 Class Initialized
INFO - 2021-04-16 19:35:09 --> URI Class Initialized
INFO - 2021-04-16 19:35:09 --> Router Class Initialized
INFO - 2021-04-16 19:35:09 --> Output Class Initialized
INFO - 2021-04-16 19:35:09 --> Security Class Initialized
DEBUG - 2021-04-16 19:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:35:09 --> Input Class Initialized
INFO - 2021-04-16 19:35:09 --> Language Class Initialized
INFO - 2021-04-16 19:35:09 --> Loader Class Initialized
INFO - 2021-04-16 19:35:09 --> Helper loaded: url_helper
INFO - 2021-04-16 19:35:09 --> Helper loaded: form_helper
INFO - 2021-04-16 19:35:09 --> Helper loaded: common_helper
INFO - 2021-04-16 19:35:09 --> Helper loaded: util_helper
INFO - 2021-04-16 19:35:09 --> Helper loaded: user_helper
INFO - 2021-04-16 19:35:09 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:35:09 --> Form Validation Class Initialized
INFO - 2021-04-16 19:35:09 --> Model Class Initialized
INFO - 2021-04-16 19:35:09 --> Controller Class Initialized
INFO - 2021-04-16 19:35:09 --> Model Class Initialized
ERROR - 2021-04-16 19:35:09 --> Query error: Table 'foodtruck.user_id' doesn't exist - Invalid query: SELECT *
FROM `user_id`
 LIMIT 5
INFO - 2021-04-16 19:35:09 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 19:35:09 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 19:35:09 --> Final output sent to browser
DEBUG - 2021-04-16 19:35:09 --> Total execution time: 0.0337
INFO - 2021-04-16 19:35:10 --> Config Class Initialized
INFO - 2021-04-16 19:35:10 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:35:10 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:35:10 --> Utf8 Class Initialized
INFO - 2021-04-16 19:35:10 --> URI Class Initialized
INFO - 2021-04-16 19:35:10 --> Router Class Initialized
INFO - 2021-04-16 19:35:10 --> Output Class Initialized
INFO - 2021-04-16 19:35:10 --> Security Class Initialized
DEBUG - 2021-04-16 19:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:35:10 --> Input Class Initialized
INFO - 2021-04-16 19:35:10 --> Language Class Initialized
INFO - 2021-04-16 19:35:10 --> Loader Class Initialized
INFO - 2021-04-16 19:35:10 --> Helper loaded: url_helper
INFO - 2021-04-16 19:35:10 --> Helper loaded: form_helper
INFO - 2021-04-16 19:35:10 --> Helper loaded: common_helper
INFO - 2021-04-16 19:35:10 --> Helper loaded: util_helper
INFO - 2021-04-16 19:35:10 --> Helper loaded: user_helper
INFO - 2021-04-16 19:35:10 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:35:10 --> Form Validation Class Initialized
INFO - 2021-04-16 19:35:10 --> Model Class Initialized
INFO - 2021-04-16 19:35:10 --> Controller Class Initialized
INFO - 2021-04-16 19:35:10 --> Model Class Initialized
ERROR - 2021-04-16 19:35:10 --> Query error: Table 'foodtruck.user_id' doesn't exist - Invalid query: SELECT *
FROM `user_id`
 LIMIT 5
INFO - 2021-04-16 19:35:10 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 19:35:10 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 19:35:10 --> Final output sent to browser
DEBUG - 2021-04-16 19:35:10 --> Total execution time: 0.0289
INFO - 2021-04-16 19:35:10 --> Config Class Initialized
INFO - 2021-04-16 19:35:10 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:35:10 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:35:10 --> Utf8 Class Initialized
INFO - 2021-04-16 19:35:10 --> URI Class Initialized
INFO - 2021-04-16 19:35:10 --> Router Class Initialized
INFO - 2021-04-16 19:35:10 --> Output Class Initialized
INFO - 2021-04-16 19:35:10 --> Security Class Initialized
DEBUG - 2021-04-16 19:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:35:10 --> Input Class Initialized
INFO - 2021-04-16 19:35:10 --> Language Class Initialized
INFO - 2021-04-16 19:35:10 --> Loader Class Initialized
INFO - 2021-04-16 19:35:10 --> Helper loaded: url_helper
INFO - 2021-04-16 19:35:10 --> Helper loaded: form_helper
INFO - 2021-04-16 19:35:10 --> Helper loaded: common_helper
INFO - 2021-04-16 19:35:10 --> Helper loaded: util_helper
INFO - 2021-04-16 19:35:10 --> Helper loaded: user_helper
INFO - 2021-04-16 19:35:10 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:35:10 --> Form Validation Class Initialized
INFO - 2021-04-16 19:35:10 --> Model Class Initialized
INFO - 2021-04-16 19:35:10 --> Controller Class Initialized
INFO - 2021-04-16 19:35:10 --> Model Class Initialized
ERROR - 2021-04-16 19:35:10 --> Query error: Table 'foodtruck.user_id' doesn't exist - Invalid query: SELECT *
FROM `user_id`
 LIMIT 5
INFO - 2021-04-16 19:35:10 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 19:35:10 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 19:35:10 --> Final output sent to browser
DEBUG - 2021-04-16 19:35:10 --> Total execution time: 0.0401
INFO - 2021-04-16 19:35:16 --> Config Class Initialized
INFO - 2021-04-16 19:35:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:35:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:35:16 --> Utf8 Class Initialized
INFO - 2021-04-16 19:35:16 --> URI Class Initialized
INFO - 2021-04-16 19:35:16 --> Router Class Initialized
INFO - 2021-04-16 19:35:16 --> Output Class Initialized
INFO - 2021-04-16 19:35:16 --> Security Class Initialized
DEBUG - 2021-04-16 19:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:35:16 --> Input Class Initialized
INFO - 2021-04-16 19:35:16 --> Language Class Initialized
INFO - 2021-04-16 19:35:16 --> Loader Class Initialized
INFO - 2021-04-16 19:35:16 --> Helper loaded: url_helper
INFO - 2021-04-16 19:35:16 --> Helper loaded: form_helper
INFO - 2021-04-16 19:35:16 --> Helper loaded: common_helper
INFO - 2021-04-16 19:35:16 --> Helper loaded: util_helper
INFO - 2021-04-16 19:35:16 --> Helper loaded: user_helper
INFO - 2021-04-16 19:35:16 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:35:16 --> Form Validation Class Initialized
INFO - 2021-04-16 19:35:16 --> Model Class Initialized
INFO - 2021-04-16 19:35:16 --> Controller Class Initialized
INFO - 2021-04-16 19:35:16 --> Model Class Initialized
INFO - 2021-04-16 19:35:16 --> Config Class Initialized
INFO - 2021-04-16 19:35:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:35:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:35:16 --> Utf8 Class Initialized
INFO - 2021-04-16 19:35:16 --> URI Class Initialized
INFO - 2021-04-16 19:35:16 --> Router Class Initialized
INFO - 2021-04-16 19:35:16 --> Output Class Initialized
INFO - 2021-04-16 19:35:16 --> Security Class Initialized
DEBUG - 2021-04-16 19:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:35:16 --> Input Class Initialized
INFO - 2021-04-16 19:35:16 --> Language Class Initialized
INFO - 2021-04-16 19:35:16 --> Loader Class Initialized
INFO - 2021-04-16 19:35:16 --> Helper loaded: url_helper
INFO - 2021-04-16 19:35:16 --> Helper loaded: form_helper
INFO - 2021-04-16 19:35:16 --> Helper loaded: common_helper
INFO - 2021-04-16 19:35:16 --> Helper loaded: util_helper
INFO - 2021-04-16 19:35:16 --> Helper loaded: user_helper
INFO - 2021-04-16 19:35:16 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:35:16 --> Form Validation Class Initialized
INFO - 2021-04-16 19:35:16 --> Model Class Initialized
INFO - 2021-04-16 19:35:16 --> Controller Class Initialized
INFO - 2021-04-16 19:35:16 --> Model Class Initialized
INFO - 2021-04-16 19:35:16 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 19:35:16 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 19:35:16 --> Final output sent to browser
DEBUG - 2021-04-16 19:35:16 --> Total execution time: 0.0269
INFO - 2021-04-16 19:35:19 --> Config Class Initialized
INFO - 2021-04-16 19:35:19 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:35:19 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:35:19 --> Utf8 Class Initialized
INFO - 2021-04-16 19:35:19 --> URI Class Initialized
INFO - 2021-04-16 19:35:19 --> Router Class Initialized
INFO - 2021-04-16 19:35:19 --> Output Class Initialized
INFO - 2021-04-16 19:35:19 --> Security Class Initialized
DEBUG - 2021-04-16 19:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:35:19 --> Input Class Initialized
INFO - 2021-04-16 19:35:19 --> Language Class Initialized
INFO - 2021-04-16 19:35:19 --> Loader Class Initialized
INFO - 2021-04-16 19:35:19 --> Helper loaded: url_helper
INFO - 2021-04-16 19:35:19 --> Helper loaded: form_helper
INFO - 2021-04-16 19:35:19 --> Helper loaded: common_helper
INFO - 2021-04-16 19:35:19 --> Helper loaded: util_helper
INFO - 2021-04-16 19:35:19 --> Helper loaded: user_helper
INFO - 2021-04-16 19:35:19 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:35:19 --> Form Validation Class Initialized
INFO - 2021-04-16 19:35:19 --> Model Class Initialized
INFO - 2021-04-16 19:35:19 --> Controller Class Initialized
INFO - 2021-04-16 19:35:19 --> Model Class Initialized
INFO - 2021-04-16 19:35:19 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 19:35:19 --> Final output sent to browser
DEBUG - 2021-04-16 19:35:19 --> Total execution time: 0.0285
INFO - 2021-04-16 19:35:36 --> Config Class Initialized
INFO - 2021-04-16 19:35:36 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:35:36 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:35:36 --> Utf8 Class Initialized
INFO - 2021-04-16 19:35:36 --> URI Class Initialized
INFO - 2021-04-16 19:35:36 --> Router Class Initialized
INFO - 2021-04-16 19:35:36 --> Output Class Initialized
INFO - 2021-04-16 19:35:36 --> Security Class Initialized
DEBUG - 2021-04-16 19:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:35:36 --> Input Class Initialized
INFO - 2021-04-16 19:35:36 --> Language Class Initialized
INFO - 2021-04-16 19:35:36 --> Loader Class Initialized
INFO - 2021-04-16 19:35:36 --> Helper loaded: url_helper
INFO - 2021-04-16 19:35:36 --> Helper loaded: form_helper
INFO - 2021-04-16 19:35:36 --> Helper loaded: common_helper
INFO - 2021-04-16 19:35:36 --> Helper loaded: util_helper
INFO - 2021-04-16 19:35:36 --> Helper loaded: user_helper
INFO - 2021-04-16 19:35:36 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:35:36 --> Form Validation Class Initialized
INFO - 2021-04-16 19:35:36 --> Model Class Initialized
INFO - 2021-04-16 19:35:36 --> Controller Class Initialized
INFO - 2021-04-16 19:35:36 --> Model Class Initialized
INFO - 2021-04-16 19:35:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-16 19:35:36 --> Config Class Initialized
INFO - 2021-04-16 19:35:36 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:35:36 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:35:36 --> Utf8 Class Initialized
INFO - 2021-04-16 19:35:36 --> URI Class Initialized
INFO - 2021-04-16 19:35:36 --> Router Class Initialized
INFO - 2021-04-16 19:35:36 --> Output Class Initialized
INFO - 2021-04-16 19:35:36 --> Security Class Initialized
DEBUG - 2021-04-16 19:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:35:36 --> Input Class Initialized
INFO - 2021-04-16 19:35:36 --> Language Class Initialized
INFO - 2021-04-16 19:35:36 --> Loader Class Initialized
INFO - 2021-04-16 19:35:36 --> Helper loaded: url_helper
INFO - 2021-04-16 19:35:36 --> Helper loaded: form_helper
INFO - 2021-04-16 19:35:36 --> Helper loaded: common_helper
INFO - 2021-04-16 19:35:36 --> Helper loaded: util_helper
INFO - 2021-04-16 19:35:36 --> Helper loaded: user_helper
INFO - 2021-04-16 19:35:36 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:35:36 --> Form Validation Class Initialized
INFO - 2021-04-16 19:35:36 --> Model Class Initialized
INFO - 2021-04-16 19:35:36 --> Controller Class Initialized
INFO - 2021-04-16 19:35:36 --> Model Class Initialized
ERROR - 2021-04-16 19:35:36 --> Query error: Table 'foodtruck.user_id' doesn't exist - Invalid query: SELECT *
FROM `user_id`
 LIMIT 5
INFO - 2021-04-16 19:35:36 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 19:35:36 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 19:35:36 --> Final output sent to browser
DEBUG - 2021-04-16 19:35:36 --> Total execution time: 0.0404
INFO - 2021-04-16 19:37:26 --> Config Class Initialized
INFO - 2021-04-16 19:37:26 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:37:26 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:37:26 --> Utf8 Class Initialized
INFO - 2021-04-16 19:37:26 --> URI Class Initialized
INFO - 2021-04-16 19:37:26 --> Router Class Initialized
INFO - 2021-04-16 19:37:26 --> Output Class Initialized
INFO - 2021-04-16 19:37:26 --> Security Class Initialized
DEBUG - 2021-04-16 19:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:37:26 --> Input Class Initialized
INFO - 2021-04-16 19:37:26 --> Language Class Initialized
INFO - 2021-04-16 19:37:26 --> Loader Class Initialized
INFO - 2021-04-16 19:37:26 --> Helper loaded: url_helper
INFO - 2021-04-16 19:37:26 --> Helper loaded: form_helper
INFO - 2021-04-16 19:37:26 --> Helper loaded: common_helper
INFO - 2021-04-16 19:37:26 --> Helper loaded: util_helper
INFO - 2021-04-16 19:37:26 --> Helper loaded: user_helper
INFO - 2021-04-16 19:37:26 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:37:26 --> Form Validation Class Initialized
INFO - 2021-04-16 19:37:26 --> Model Class Initialized
INFO - 2021-04-16 19:37:26 --> Controller Class Initialized
INFO - 2021-04-16 19:37:26 --> Model Class Initialized
INFO - 2021-04-16 19:37:26 --> Config Class Initialized
INFO - 2021-04-16 19:37:26 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:37:26 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:37:26 --> Utf8 Class Initialized
INFO - 2021-04-16 19:37:26 --> URI Class Initialized
INFO - 2021-04-16 19:37:26 --> Router Class Initialized
INFO - 2021-04-16 19:37:26 --> Output Class Initialized
INFO - 2021-04-16 19:37:26 --> Security Class Initialized
DEBUG - 2021-04-16 19:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:37:26 --> Input Class Initialized
INFO - 2021-04-16 19:37:26 --> Language Class Initialized
INFO - 2021-04-16 19:37:26 --> Loader Class Initialized
INFO - 2021-04-16 19:37:26 --> Helper loaded: url_helper
INFO - 2021-04-16 19:37:26 --> Helper loaded: form_helper
INFO - 2021-04-16 19:37:26 --> Helper loaded: common_helper
INFO - 2021-04-16 19:37:26 --> Helper loaded: util_helper
INFO - 2021-04-16 19:37:26 --> Helper loaded: user_helper
INFO - 2021-04-16 19:37:26 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:37:26 --> Form Validation Class Initialized
INFO - 2021-04-16 19:37:26 --> Model Class Initialized
INFO - 2021-04-16 19:37:26 --> Controller Class Initialized
INFO - 2021-04-16 19:37:26 --> Model Class Initialized
INFO - 2021-04-16 19:37:26 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 19:37:26 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 19:37:26 --> Final output sent to browser
DEBUG - 2021-04-16 19:37:26 --> Total execution time: 0.0298
INFO - 2021-04-16 19:37:28 --> Config Class Initialized
INFO - 2021-04-16 19:37:28 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:37:28 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:37:28 --> Utf8 Class Initialized
INFO - 2021-04-16 19:37:28 --> URI Class Initialized
INFO - 2021-04-16 19:37:28 --> Router Class Initialized
INFO - 2021-04-16 19:37:28 --> Output Class Initialized
INFO - 2021-04-16 19:37:28 --> Security Class Initialized
DEBUG - 2021-04-16 19:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:37:28 --> Input Class Initialized
INFO - 2021-04-16 19:37:28 --> Language Class Initialized
INFO - 2021-04-16 19:37:28 --> Loader Class Initialized
INFO - 2021-04-16 19:37:28 --> Helper loaded: url_helper
INFO - 2021-04-16 19:37:28 --> Helper loaded: form_helper
INFO - 2021-04-16 19:37:28 --> Helper loaded: common_helper
INFO - 2021-04-16 19:37:28 --> Helper loaded: util_helper
INFO - 2021-04-16 19:37:28 --> Helper loaded: user_helper
INFO - 2021-04-16 19:37:28 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:37:28 --> Form Validation Class Initialized
INFO - 2021-04-16 19:37:28 --> Model Class Initialized
INFO - 2021-04-16 19:37:28 --> Controller Class Initialized
INFO - 2021-04-16 19:37:28 --> Model Class Initialized
INFO - 2021-04-16 19:37:28 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 19:37:28 --> Final output sent to browser
DEBUG - 2021-04-16 19:37:28 --> Total execution time: 0.0274
INFO - 2021-04-16 19:37:44 --> Config Class Initialized
INFO - 2021-04-16 19:37:44 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:37:44 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:37:44 --> Utf8 Class Initialized
INFO - 2021-04-16 19:37:44 --> URI Class Initialized
INFO - 2021-04-16 19:37:44 --> Router Class Initialized
INFO - 2021-04-16 19:37:44 --> Output Class Initialized
INFO - 2021-04-16 19:37:44 --> Security Class Initialized
DEBUG - 2021-04-16 19:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:37:44 --> Input Class Initialized
INFO - 2021-04-16 19:37:44 --> Language Class Initialized
INFO - 2021-04-16 19:37:44 --> Loader Class Initialized
INFO - 2021-04-16 19:37:44 --> Helper loaded: url_helper
INFO - 2021-04-16 19:37:44 --> Helper loaded: form_helper
INFO - 2021-04-16 19:37:44 --> Helper loaded: common_helper
INFO - 2021-04-16 19:37:44 --> Helper loaded: util_helper
INFO - 2021-04-16 19:37:44 --> Helper loaded: user_helper
INFO - 2021-04-16 19:37:44 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:37:44 --> Form Validation Class Initialized
INFO - 2021-04-16 19:37:44 --> Model Class Initialized
INFO - 2021-04-16 19:37:44 --> Controller Class Initialized
INFO - 2021-04-16 19:37:44 --> Model Class Initialized
INFO - 2021-04-16 19:37:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-16 19:37:45 --> Config Class Initialized
INFO - 2021-04-16 19:37:45 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:37:45 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:37:45 --> Utf8 Class Initialized
INFO - 2021-04-16 19:37:45 --> URI Class Initialized
INFO - 2021-04-16 19:37:45 --> Router Class Initialized
INFO - 2021-04-16 19:37:45 --> Output Class Initialized
INFO - 2021-04-16 19:37:45 --> Security Class Initialized
DEBUG - 2021-04-16 19:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:37:45 --> Input Class Initialized
INFO - 2021-04-16 19:37:45 --> Language Class Initialized
INFO - 2021-04-16 19:37:45 --> Loader Class Initialized
INFO - 2021-04-16 19:37:45 --> Helper loaded: url_helper
INFO - 2021-04-16 19:37:45 --> Helper loaded: form_helper
INFO - 2021-04-16 19:37:45 --> Helper loaded: common_helper
INFO - 2021-04-16 19:37:45 --> Helper loaded: util_helper
INFO - 2021-04-16 19:37:45 --> Helper loaded: user_helper
INFO - 2021-04-16 19:37:45 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:37:45 --> Form Validation Class Initialized
INFO - 2021-04-16 19:37:45 --> Model Class Initialized
INFO - 2021-04-16 19:37:45 --> Controller Class Initialized
INFO - 2021-04-16 19:37:45 --> Model Class Initialized
ERROR - 2021-04-16 19:37:45 --> Query error: Table 'foodtruck.user_id' doesn't exist - Invalid query: SELECT *
FROM `user_id`
 LIMIT 5
INFO - 2021-04-16 19:37:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 19:37:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 19:37:45 --> Final output sent to browser
DEBUG - 2021-04-16 19:37:45 --> Total execution time: 0.0315
INFO - 2021-04-16 19:39:03 --> Config Class Initialized
INFO - 2021-04-16 19:39:03 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:39:03 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:39:03 --> Utf8 Class Initialized
INFO - 2021-04-16 19:39:03 --> URI Class Initialized
INFO - 2021-04-16 19:39:03 --> Router Class Initialized
INFO - 2021-04-16 19:39:03 --> Output Class Initialized
INFO - 2021-04-16 19:39:03 --> Security Class Initialized
DEBUG - 2021-04-16 19:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:39:03 --> Input Class Initialized
INFO - 2021-04-16 19:39:03 --> Language Class Initialized
INFO - 2021-04-16 19:39:03 --> Loader Class Initialized
INFO - 2021-04-16 19:39:03 --> Helper loaded: url_helper
INFO - 2021-04-16 19:39:03 --> Helper loaded: form_helper
INFO - 2021-04-16 19:39:03 --> Helper loaded: common_helper
INFO - 2021-04-16 19:39:03 --> Helper loaded: util_helper
INFO - 2021-04-16 19:39:03 --> Helper loaded: user_helper
INFO - 2021-04-16 19:39:03 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:39:03 --> Form Validation Class Initialized
INFO - 2021-04-16 19:39:03 --> Model Class Initialized
INFO - 2021-04-16 19:39:03 --> Controller Class Initialized
INFO - 2021-04-16 19:39:03 --> Model Class Initialized
INFO - 2021-04-16 19:39:03 --> Config Class Initialized
INFO - 2021-04-16 19:39:03 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:39:03 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:39:03 --> Utf8 Class Initialized
INFO - 2021-04-16 19:39:03 --> URI Class Initialized
INFO - 2021-04-16 19:39:03 --> Router Class Initialized
INFO - 2021-04-16 19:39:03 --> Output Class Initialized
INFO - 2021-04-16 19:39:03 --> Security Class Initialized
DEBUG - 2021-04-16 19:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:39:03 --> Input Class Initialized
INFO - 2021-04-16 19:39:03 --> Language Class Initialized
INFO - 2021-04-16 19:39:03 --> Loader Class Initialized
INFO - 2021-04-16 19:39:03 --> Helper loaded: url_helper
INFO - 2021-04-16 19:39:03 --> Helper loaded: form_helper
INFO - 2021-04-16 19:39:03 --> Helper loaded: common_helper
INFO - 2021-04-16 19:39:03 --> Helper loaded: util_helper
INFO - 2021-04-16 19:39:03 --> Helper loaded: user_helper
INFO - 2021-04-16 19:39:03 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:39:03 --> Form Validation Class Initialized
INFO - 2021-04-16 19:39:03 --> Model Class Initialized
INFO - 2021-04-16 19:39:03 --> Controller Class Initialized
INFO - 2021-04-16 19:39:03 --> Model Class Initialized
INFO - 2021-04-16 19:39:03 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 19:39:03 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 19:39:03 --> Final output sent to browser
DEBUG - 2021-04-16 19:39:03 --> Total execution time: 0.0304
INFO - 2021-04-16 19:39:04 --> Config Class Initialized
INFO - 2021-04-16 19:39:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:39:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:39:04 --> Utf8 Class Initialized
INFO - 2021-04-16 19:39:04 --> URI Class Initialized
INFO - 2021-04-16 19:39:04 --> Router Class Initialized
INFO - 2021-04-16 19:39:04 --> Output Class Initialized
INFO - 2021-04-16 19:39:04 --> Security Class Initialized
DEBUG - 2021-04-16 19:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:39:04 --> Input Class Initialized
INFO - 2021-04-16 19:39:04 --> Language Class Initialized
INFO - 2021-04-16 19:39:04 --> Loader Class Initialized
INFO - 2021-04-16 19:39:04 --> Helper loaded: url_helper
INFO - 2021-04-16 19:39:04 --> Helper loaded: form_helper
INFO - 2021-04-16 19:39:04 --> Helper loaded: common_helper
INFO - 2021-04-16 19:39:04 --> Helper loaded: util_helper
INFO - 2021-04-16 19:39:04 --> Helper loaded: user_helper
INFO - 2021-04-16 19:39:04 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:39:04 --> Form Validation Class Initialized
INFO - 2021-04-16 19:39:04 --> Model Class Initialized
INFO - 2021-04-16 19:39:04 --> Controller Class Initialized
INFO - 2021-04-16 19:39:04 --> Model Class Initialized
INFO - 2021-04-16 19:39:04 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 19:39:04 --> Final output sent to browser
DEBUG - 2021-04-16 19:39:04 --> Total execution time: 0.0344
INFO - 2021-04-16 19:39:21 --> Config Class Initialized
INFO - 2021-04-16 19:39:21 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:39:21 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:39:21 --> Utf8 Class Initialized
INFO - 2021-04-16 19:39:21 --> URI Class Initialized
INFO - 2021-04-16 19:39:21 --> Router Class Initialized
INFO - 2021-04-16 19:39:21 --> Output Class Initialized
INFO - 2021-04-16 19:39:21 --> Security Class Initialized
DEBUG - 2021-04-16 19:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:39:21 --> Input Class Initialized
INFO - 2021-04-16 19:39:21 --> Language Class Initialized
INFO - 2021-04-16 19:39:21 --> Loader Class Initialized
INFO - 2021-04-16 19:39:21 --> Helper loaded: url_helper
INFO - 2021-04-16 19:39:21 --> Helper loaded: form_helper
INFO - 2021-04-16 19:39:21 --> Helper loaded: common_helper
INFO - 2021-04-16 19:39:21 --> Helper loaded: util_helper
INFO - 2021-04-16 19:39:21 --> Helper loaded: user_helper
INFO - 2021-04-16 19:39:21 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:39:21 --> Form Validation Class Initialized
INFO - 2021-04-16 19:39:21 --> Model Class Initialized
INFO - 2021-04-16 19:39:21 --> Controller Class Initialized
INFO - 2021-04-16 19:39:21 --> Model Class Initialized
INFO - 2021-04-16 19:39:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-16 19:39:21 --> Config Class Initialized
INFO - 2021-04-16 19:39:21 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:39:21 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:39:21 --> Utf8 Class Initialized
INFO - 2021-04-16 19:39:21 --> URI Class Initialized
INFO - 2021-04-16 19:39:21 --> Router Class Initialized
INFO - 2021-04-16 19:39:21 --> Output Class Initialized
INFO - 2021-04-16 19:39:21 --> Security Class Initialized
DEBUG - 2021-04-16 19:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:39:21 --> Input Class Initialized
INFO - 2021-04-16 19:39:21 --> Language Class Initialized
INFO - 2021-04-16 19:39:21 --> Loader Class Initialized
INFO - 2021-04-16 19:39:21 --> Helper loaded: url_helper
INFO - 2021-04-16 19:39:21 --> Helper loaded: form_helper
INFO - 2021-04-16 19:39:21 --> Helper loaded: common_helper
INFO - 2021-04-16 19:39:21 --> Helper loaded: util_helper
INFO - 2021-04-16 19:39:21 --> Helper loaded: user_helper
INFO - 2021-04-16 19:39:21 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:39:21 --> Form Validation Class Initialized
INFO - 2021-04-16 19:39:21 --> Model Class Initialized
INFO - 2021-04-16 19:39:21 --> Controller Class Initialized
INFO - 2021-04-16 19:39:21 --> Model Class Initialized
INFO - 2021-04-16 19:39:21 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 19:39:21 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 19:39:21 --> Final output sent to browser
DEBUG - 2021-04-16 19:39:21 --> Total execution time: 0.0325
INFO - 2021-04-16 19:40:22 --> Config Class Initialized
INFO - 2021-04-16 19:40:22 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:40:22 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:40:22 --> Utf8 Class Initialized
INFO - 2021-04-16 19:40:22 --> URI Class Initialized
INFO - 2021-04-16 19:40:22 --> Router Class Initialized
INFO - 2021-04-16 19:40:22 --> Output Class Initialized
INFO - 2021-04-16 19:40:22 --> Security Class Initialized
DEBUG - 2021-04-16 19:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:40:22 --> Input Class Initialized
INFO - 2021-04-16 19:40:22 --> Language Class Initialized
INFO - 2021-04-16 19:40:22 --> Loader Class Initialized
INFO - 2021-04-16 19:40:22 --> Helper loaded: url_helper
INFO - 2021-04-16 19:40:22 --> Helper loaded: form_helper
INFO - 2021-04-16 19:40:22 --> Helper loaded: common_helper
INFO - 2021-04-16 19:40:22 --> Helper loaded: util_helper
INFO - 2021-04-16 19:40:22 --> Helper loaded: user_helper
INFO - 2021-04-16 19:40:22 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:40:22 --> Form Validation Class Initialized
INFO - 2021-04-16 19:40:22 --> Model Class Initialized
INFO - 2021-04-16 19:40:22 --> Controller Class Initialized
INFO - 2021-04-16 19:40:22 --> Model Class Initialized
INFO - 2021-04-16 19:40:22 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 19:40:22 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 19:40:22 --> Final output sent to browser
DEBUG - 2021-04-16 19:40:22 --> Total execution time: 0.0311
INFO - 2021-04-16 19:41:16 --> Config Class Initialized
INFO - 2021-04-16 19:41:16 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:41:16 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:41:16 --> Utf8 Class Initialized
INFO - 2021-04-16 19:41:16 --> URI Class Initialized
INFO - 2021-04-16 19:41:16 --> Router Class Initialized
INFO - 2021-04-16 19:41:16 --> Output Class Initialized
INFO - 2021-04-16 19:41:16 --> Security Class Initialized
DEBUG - 2021-04-16 19:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:41:16 --> Input Class Initialized
INFO - 2021-04-16 19:41:16 --> Language Class Initialized
INFO - 2021-04-16 19:41:16 --> Loader Class Initialized
INFO - 2021-04-16 19:41:16 --> Helper loaded: url_helper
INFO - 2021-04-16 19:41:16 --> Helper loaded: form_helper
INFO - 2021-04-16 19:41:16 --> Helper loaded: common_helper
INFO - 2021-04-16 19:41:16 --> Helper loaded: util_helper
INFO - 2021-04-16 19:41:16 --> Helper loaded: user_helper
INFO - 2021-04-16 19:41:16 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:41:16 --> Form Validation Class Initialized
INFO - 2021-04-16 19:41:16 --> Model Class Initialized
INFO - 2021-04-16 19:41:16 --> Controller Class Initialized
INFO - 2021-04-16 19:41:16 --> Model Class Initialized
INFO - 2021-04-16 19:41:16 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 19:41:16 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 19:41:16 --> Final output sent to browser
DEBUG - 2021-04-16 19:41:16 --> Total execution time: 0.0299
INFO - 2021-04-16 19:42:27 --> Config Class Initialized
INFO - 2021-04-16 19:42:27 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:42:27 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:42:27 --> Utf8 Class Initialized
INFO - 2021-04-16 19:42:27 --> URI Class Initialized
INFO - 2021-04-16 19:42:27 --> Router Class Initialized
INFO - 2021-04-16 19:42:27 --> Output Class Initialized
INFO - 2021-04-16 19:42:27 --> Security Class Initialized
DEBUG - 2021-04-16 19:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:42:27 --> Input Class Initialized
INFO - 2021-04-16 19:42:27 --> Language Class Initialized
INFO - 2021-04-16 19:42:27 --> Loader Class Initialized
INFO - 2021-04-16 19:42:27 --> Helper loaded: url_helper
INFO - 2021-04-16 19:42:27 --> Helper loaded: form_helper
INFO - 2021-04-16 19:42:27 --> Helper loaded: common_helper
INFO - 2021-04-16 19:42:27 --> Helper loaded: util_helper
INFO - 2021-04-16 19:42:27 --> Helper loaded: user_helper
INFO - 2021-04-16 19:42:27 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:42:27 --> Form Validation Class Initialized
INFO - 2021-04-16 19:42:27 --> Model Class Initialized
INFO - 2021-04-16 19:42:27 --> Controller Class Initialized
INFO - 2021-04-16 19:42:27 --> Model Class Initialized
INFO - 2021-04-16 19:42:53 --> Config Class Initialized
INFO - 2021-04-16 19:42:53 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:42:53 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:42:53 --> Utf8 Class Initialized
INFO - 2021-04-16 19:42:53 --> URI Class Initialized
INFO - 2021-04-16 19:42:53 --> Router Class Initialized
INFO - 2021-04-16 19:42:53 --> Output Class Initialized
INFO - 2021-04-16 19:42:53 --> Security Class Initialized
DEBUG - 2021-04-16 19:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:42:53 --> Input Class Initialized
INFO - 2021-04-16 19:42:53 --> Language Class Initialized
INFO - 2021-04-16 19:42:53 --> Loader Class Initialized
INFO - 2021-04-16 19:42:53 --> Helper loaded: url_helper
INFO - 2021-04-16 19:42:53 --> Helper loaded: form_helper
INFO - 2021-04-16 19:42:53 --> Helper loaded: common_helper
INFO - 2021-04-16 19:42:53 --> Helper loaded: util_helper
INFO - 2021-04-16 19:42:53 --> Helper loaded: user_helper
INFO - 2021-04-16 19:42:53 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:42:53 --> Form Validation Class Initialized
INFO - 2021-04-16 19:42:53 --> Model Class Initialized
INFO - 2021-04-16 19:42:53 --> Controller Class Initialized
INFO - 2021-04-16 19:42:53 --> Model Class Initialized
INFO - 2021-04-16 19:42:53 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 19:42:53 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 19:42:53 --> Final output sent to browser
DEBUG - 2021-04-16 19:42:53 --> Total execution time: 0.0321
INFO - 2021-04-16 19:46:36 --> Config Class Initialized
INFO - 2021-04-16 19:46:36 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:46:36 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:46:36 --> Utf8 Class Initialized
INFO - 2021-04-16 19:46:36 --> URI Class Initialized
INFO - 2021-04-16 19:46:36 --> Router Class Initialized
INFO - 2021-04-16 19:46:36 --> Output Class Initialized
INFO - 2021-04-16 19:46:36 --> Security Class Initialized
DEBUG - 2021-04-16 19:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:46:36 --> Input Class Initialized
INFO - 2021-04-16 19:46:36 --> Language Class Initialized
INFO - 2021-04-16 19:46:36 --> Loader Class Initialized
INFO - 2021-04-16 19:46:36 --> Helper loaded: url_helper
INFO - 2021-04-16 19:46:36 --> Helper loaded: form_helper
INFO - 2021-04-16 19:46:36 --> Helper loaded: common_helper
INFO - 2021-04-16 19:46:36 --> Helper loaded: util_helper
INFO - 2021-04-16 19:46:36 --> Helper loaded: user_helper
INFO - 2021-04-16 19:46:36 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:46:36 --> Form Validation Class Initialized
INFO - 2021-04-16 19:46:36 --> Model Class Initialized
INFO - 2021-04-16 19:46:36 --> Controller Class Initialized
INFO - 2021-04-16 19:46:36 --> Model Class Initialized
INFO - 2021-04-16 19:46:37 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 19:46:37 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 19:46:37 --> Final output sent to browser
DEBUG - 2021-04-16 19:46:37 --> Total execution time: 0.0746
INFO - 2021-04-16 19:46:40 --> Config Class Initialized
INFO - 2021-04-16 19:46:40 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:46:40 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:46:40 --> Utf8 Class Initialized
INFO - 2021-04-16 19:46:40 --> URI Class Initialized
INFO - 2021-04-16 19:46:40 --> Router Class Initialized
INFO - 2021-04-16 19:46:40 --> Output Class Initialized
INFO - 2021-04-16 19:46:40 --> Security Class Initialized
DEBUG - 2021-04-16 19:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:46:40 --> Input Class Initialized
INFO - 2021-04-16 19:46:40 --> Language Class Initialized
INFO - 2021-04-16 19:46:40 --> Loader Class Initialized
INFO - 2021-04-16 19:46:40 --> Helper loaded: url_helper
INFO - 2021-04-16 19:46:40 --> Helper loaded: form_helper
INFO - 2021-04-16 19:46:40 --> Helper loaded: common_helper
INFO - 2021-04-16 19:46:40 --> Helper loaded: util_helper
INFO - 2021-04-16 19:46:40 --> Helper loaded: user_helper
INFO - 2021-04-16 19:46:40 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:46:40 --> Form Validation Class Initialized
INFO - 2021-04-16 19:46:40 --> Model Class Initialized
INFO - 2021-04-16 19:46:40 --> Controller Class Initialized
INFO - 2021-04-16 19:46:40 --> Model Class Initialized
INFO - 2021-04-16 19:46:40 --> Config Class Initialized
INFO - 2021-04-16 19:46:40 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:46:40 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:46:40 --> Utf8 Class Initialized
INFO - 2021-04-16 19:46:40 --> URI Class Initialized
INFO - 2021-04-16 19:46:40 --> Router Class Initialized
INFO - 2021-04-16 19:46:40 --> Output Class Initialized
INFO - 2021-04-16 19:46:40 --> Security Class Initialized
DEBUG - 2021-04-16 19:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:46:40 --> Input Class Initialized
INFO - 2021-04-16 19:46:40 --> Language Class Initialized
INFO - 2021-04-16 19:46:40 --> Loader Class Initialized
INFO - 2021-04-16 19:46:40 --> Helper loaded: url_helper
INFO - 2021-04-16 19:46:40 --> Helper loaded: form_helper
INFO - 2021-04-16 19:46:40 --> Helper loaded: common_helper
INFO - 2021-04-16 19:46:40 --> Helper loaded: util_helper
INFO - 2021-04-16 19:46:40 --> Helper loaded: user_helper
INFO - 2021-04-16 19:46:40 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:46:40 --> Form Validation Class Initialized
INFO - 2021-04-16 19:46:40 --> Model Class Initialized
INFO - 2021-04-16 19:46:40 --> Controller Class Initialized
INFO - 2021-04-16 19:46:40 --> Model Class Initialized
INFO - 2021-04-16 19:46:40 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 19:46:40 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 19:46:40 --> Final output sent to browser
DEBUG - 2021-04-16 19:46:40 --> Total execution time: 0.0264
INFO - 2021-04-16 19:46:41 --> Config Class Initialized
INFO - 2021-04-16 19:46:41 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:46:41 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:46:41 --> Utf8 Class Initialized
INFO - 2021-04-16 19:46:41 --> URI Class Initialized
INFO - 2021-04-16 19:46:41 --> Router Class Initialized
INFO - 2021-04-16 19:46:41 --> Output Class Initialized
INFO - 2021-04-16 19:46:41 --> Security Class Initialized
DEBUG - 2021-04-16 19:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:46:41 --> Input Class Initialized
INFO - 2021-04-16 19:46:41 --> Language Class Initialized
INFO - 2021-04-16 19:46:41 --> Loader Class Initialized
INFO - 2021-04-16 19:46:41 --> Helper loaded: url_helper
INFO - 2021-04-16 19:46:41 --> Helper loaded: form_helper
INFO - 2021-04-16 19:46:41 --> Helper loaded: common_helper
INFO - 2021-04-16 19:46:41 --> Helper loaded: util_helper
INFO - 2021-04-16 19:46:41 --> Helper loaded: user_helper
INFO - 2021-04-16 19:46:41 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:46:41 --> Form Validation Class Initialized
INFO - 2021-04-16 19:46:41 --> Model Class Initialized
INFO - 2021-04-16 19:46:41 --> Controller Class Initialized
INFO - 2021-04-16 19:46:41 --> Model Class Initialized
INFO - 2021-04-16 19:46:41 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 19:46:41 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 19:46:41 --> Final output sent to browser
DEBUG - 2021-04-16 19:46:41 --> Total execution time: 0.0296
INFO - 2021-04-16 19:46:42 --> Config Class Initialized
INFO - 2021-04-16 19:46:42 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:46:42 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:46:42 --> Utf8 Class Initialized
INFO - 2021-04-16 19:46:42 --> URI Class Initialized
INFO - 2021-04-16 19:46:42 --> Router Class Initialized
INFO - 2021-04-16 19:46:42 --> Output Class Initialized
INFO - 2021-04-16 19:46:42 --> Security Class Initialized
DEBUG - 2021-04-16 19:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:46:42 --> Input Class Initialized
INFO - 2021-04-16 19:46:42 --> Language Class Initialized
INFO - 2021-04-16 19:46:42 --> Loader Class Initialized
INFO - 2021-04-16 19:46:42 --> Helper loaded: url_helper
INFO - 2021-04-16 19:46:42 --> Helper loaded: form_helper
INFO - 2021-04-16 19:46:42 --> Helper loaded: common_helper
INFO - 2021-04-16 19:46:42 --> Helper loaded: util_helper
INFO - 2021-04-16 19:46:42 --> Helper loaded: user_helper
INFO - 2021-04-16 19:46:42 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:46:42 --> Form Validation Class Initialized
INFO - 2021-04-16 19:46:42 --> Model Class Initialized
INFO - 2021-04-16 19:46:42 --> Controller Class Initialized
INFO - 2021-04-16 19:46:42 --> Model Class Initialized
INFO - 2021-04-16 19:46:42 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 19:46:42 --> Final output sent to browser
DEBUG - 2021-04-16 19:46:42 --> Total execution time: 0.0288
INFO - 2021-04-16 19:46:42 --> Config Class Initialized
INFO - 2021-04-16 19:46:42 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:46:42 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:46:42 --> Utf8 Class Initialized
INFO - 2021-04-16 19:46:42 --> URI Class Initialized
INFO - 2021-04-16 19:46:42 --> Router Class Initialized
INFO - 2021-04-16 19:46:42 --> Output Class Initialized
INFO - 2021-04-16 19:46:42 --> Security Class Initialized
DEBUG - 2021-04-16 19:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:46:42 --> Input Class Initialized
INFO - 2021-04-16 19:46:42 --> Language Class Initialized
INFO - 2021-04-16 19:46:42 --> Loader Class Initialized
INFO - 2021-04-16 19:46:42 --> Helper loaded: url_helper
INFO - 2021-04-16 19:46:42 --> Helper loaded: form_helper
INFO - 2021-04-16 19:46:42 --> Helper loaded: common_helper
INFO - 2021-04-16 19:46:42 --> Helper loaded: util_helper
INFO - 2021-04-16 19:46:42 --> Helper loaded: user_helper
INFO - 2021-04-16 19:46:42 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:46:43 --> Form Validation Class Initialized
INFO - 2021-04-16 19:46:43 --> Model Class Initialized
INFO - 2021-04-16 19:46:43 --> Controller Class Initialized
INFO - 2021-04-16 19:46:43 --> Model Class Initialized
INFO - 2021-04-16 19:46:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 19:46:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 19:46:43 --> Final output sent to browser
DEBUG - 2021-04-16 19:46:43 --> Total execution time: 0.0270
INFO - 2021-04-16 19:46:43 --> Config Class Initialized
INFO - 2021-04-16 19:46:43 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:46:43 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:46:43 --> Utf8 Class Initialized
INFO - 2021-04-16 19:46:43 --> URI Class Initialized
INFO - 2021-04-16 19:46:43 --> Router Class Initialized
INFO - 2021-04-16 19:46:43 --> Output Class Initialized
INFO - 2021-04-16 19:46:43 --> Security Class Initialized
DEBUG - 2021-04-16 19:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:46:43 --> Input Class Initialized
INFO - 2021-04-16 19:46:43 --> Language Class Initialized
INFO - 2021-04-16 19:46:43 --> Loader Class Initialized
INFO - 2021-04-16 19:46:43 --> Helper loaded: url_helper
INFO - 2021-04-16 19:46:43 --> Helper loaded: form_helper
INFO - 2021-04-16 19:46:43 --> Helper loaded: common_helper
INFO - 2021-04-16 19:46:43 --> Helper loaded: util_helper
INFO - 2021-04-16 19:46:43 --> Helper loaded: user_helper
INFO - 2021-04-16 19:46:43 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:46:43 --> Form Validation Class Initialized
INFO - 2021-04-16 19:46:43 --> Model Class Initialized
INFO - 2021-04-16 19:46:43 --> Controller Class Initialized
INFO - 2021-04-16 19:46:43 --> Model Class Initialized
INFO - 2021-04-16 19:46:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 19:46:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 19:46:43 --> Final output sent to browser
DEBUG - 2021-04-16 19:46:43 --> Total execution time: 0.0417
INFO - 2021-04-16 19:46:43 --> Config Class Initialized
INFO - 2021-04-16 19:46:43 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:46:43 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:46:43 --> Utf8 Class Initialized
INFO - 2021-04-16 19:46:43 --> URI Class Initialized
INFO - 2021-04-16 19:46:43 --> Router Class Initialized
INFO - 2021-04-16 19:46:43 --> Output Class Initialized
INFO - 2021-04-16 19:46:43 --> Security Class Initialized
DEBUG - 2021-04-16 19:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:46:43 --> Input Class Initialized
INFO - 2021-04-16 19:46:43 --> Language Class Initialized
INFO - 2021-04-16 19:46:43 --> Loader Class Initialized
INFO - 2021-04-16 19:46:43 --> Helper loaded: url_helper
INFO - 2021-04-16 19:46:43 --> Helper loaded: form_helper
INFO - 2021-04-16 19:46:43 --> Helper loaded: common_helper
INFO - 2021-04-16 19:46:43 --> Helper loaded: util_helper
INFO - 2021-04-16 19:46:43 --> Helper loaded: user_helper
INFO - 2021-04-16 19:46:43 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:46:43 --> Form Validation Class Initialized
INFO - 2021-04-16 19:46:43 --> Model Class Initialized
INFO - 2021-04-16 19:46:43 --> Controller Class Initialized
INFO - 2021-04-16 19:46:43 --> Model Class Initialized
INFO - 2021-04-16 19:46:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 19:46:43 --> Final output sent to browser
DEBUG - 2021-04-16 19:46:43 --> Total execution time: 0.0290
INFO - 2021-04-16 19:46:43 --> Config Class Initialized
INFO - 2021-04-16 19:46:43 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:46:43 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:46:43 --> Utf8 Class Initialized
INFO - 2021-04-16 19:46:43 --> URI Class Initialized
INFO - 2021-04-16 19:46:43 --> Router Class Initialized
INFO - 2021-04-16 19:46:43 --> Output Class Initialized
INFO - 2021-04-16 19:46:43 --> Security Class Initialized
DEBUG - 2021-04-16 19:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:46:43 --> Input Class Initialized
INFO - 2021-04-16 19:46:43 --> Language Class Initialized
INFO - 2021-04-16 19:46:43 --> Loader Class Initialized
INFO - 2021-04-16 19:46:43 --> Helper loaded: url_helper
INFO - 2021-04-16 19:46:43 --> Helper loaded: form_helper
INFO - 2021-04-16 19:46:43 --> Helper loaded: common_helper
INFO - 2021-04-16 19:46:43 --> Helper loaded: util_helper
INFO - 2021-04-16 19:46:43 --> Helper loaded: user_helper
INFO - 2021-04-16 19:46:43 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:46:43 --> Form Validation Class Initialized
INFO - 2021-04-16 19:46:43 --> Model Class Initialized
INFO - 2021-04-16 19:46:43 --> Controller Class Initialized
INFO - 2021-04-16 19:46:43 --> Model Class Initialized
INFO - 2021-04-16 19:46:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 19:46:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 19:46:43 --> Final output sent to browser
DEBUG - 2021-04-16 19:46:43 --> Total execution time: 0.0383
INFO - 2021-04-16 19:46:43 --> Config Class Initialized
INFO - 2021-04-16 19:46:43 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:46:43 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:46:43 --> Utf8 Class Initialized
INFO - 2021-04-16 19:46:43 --> URI Class Initialized
INFO - 2021-04-16 19:46:43 --> Router Class Initialized
INFO - 2021-04-16 19:46:43 --> Output Class Initialized
INFO - 2021-04-16 19:46:43 --> Security Class Initialized
DEBUG - 2021-04-16 19:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:46:43 --> Input Class Initialized
INFO - 2021-04-16 19:46:43 --> Language Class Initialized
INFO - 2021-04-16 19:46:43 --> Loader Class Initialized
INFO - 2021-04-16 19:46:43 --> Helper loaded: url_helper
INFO - 2021-04-16 19:46:43 --> Helper loaded: form_helper
INFO - 2021-04-16 19:46:43 --> Helper loaded: common_helper
INFO - 2021-04-16 19:46:43 --> Helper loaded: util_helper
INFO - 2021-04-16 19:46:43 --> Helper loaded: user_helper
INFO - 2021-04-16 19:46:43 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:46:43 --> Form Validation Class Initialized
INFO - 2021-04-16 19:46:43 --> Model Class Initialized
INFO - 2021-04-16 19:46:43 --> Controller Class Initialized
INFO - 2021-04-16 19:46:43 --> Model Class Initialized
INFO - 2021-04-16 19:46:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 19:46:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 19:46:43 --> Final output sent to browser
DEBUG - 2021-04-16 19:46:43 --> Total execution time: 0.0289
INFO - 2021-04-16 19:46:44 --> Config Class Initialized
INFO - 2021-04-16 19:46:44 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:46:44 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:46:44 --> Utf8 Class Initialized
INFO - 2021-04-16 19:46:44 --> URI Class Initialized
INFO - 2021-04-16 19:46:44 --> Router Class Initialized
INFO - 2021-04-16 19:46:44 --> Output Class Initialized
INFO - 2021-04-16 19:46:44 --> Security Class Initialized
DEBUG - 2021-04-16 19:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:46:44 --> Input Class Initialized
INFO - 2021-04-16 19:46:44 --> Language Class Initialized
INFO - 2021-04-16 19:46:44 --> Loader Class Initialized
INFO - 2021-04-16 19:46:44 --> Helper loaded: url_helper
INFO - 2021-04-16 19:46:44 --> Helper loaded: form_helper
INFO - 2021-04-16 19:46:44 --> Helper loaded: common_helper
INFO - 2021-04-16 19:46:44 --> Helper loaded: util_helper
INFO - 2021-04-16 19:46:44 --> Helper loaded: user_helper
INFO - 2021-04-16 19:46:44 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:46:44 --> Form Validation Class Initialized
INFO - 2021-04-16 19:46:44 --> Model Class Initialized
INFO - 2021-04-16 19:46:44 --> Controller Class Initialized
INFO - 2021-04-16 19:46:44 --> Model Class Initialized
INFO - 2021-04-16 19:46:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 19:46:44 --> Final output sent to browser
DEBUG - 2021-04-16 19:46:44 --> Total execution time: 0.0347
INFO - 2021-04-16 19:46:45 --> Config Class Initialized
INFO - 2021-04-16 19:46:45 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:46:45 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:46:45 --> Utf8 Class Initialized
INFO - 2021-04-16 19:46:45 --> URI Class Initialized
INFO - 2021-04-16 19:46:45 --> Router Class Initialized
INFO - 2021-04-16 19:46:45 --> Output Class Initialized
INFO - 2021-04-16 19:46:45 --> Security Class Initialized
DEBUG - 2021-04-16 19:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:46:45 --> Input Class Initialized
INFO - 2021-04-16 19:46:45 --> Language Class Initialized
INFO - 2021-04-16 19:46:45 --> Loader Class Initialized
INFO - 2021-04-16 19:46:45 --> Helper loaded: url_helper
INFO - 2021-04-16 19:46:45 --> Helper loaded: form_helper
INFO - 2021-04-16 19:46:45 --> Helper loaded: common_helper
INFO - 2021-04-16 19:46:45 --> Helper loaded: util_helper
INFO - 2021-04-16 19:46:45 --> Helper loaded: user_helper
INFO - 2021-04-16 19:46:45 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:46:45 --> Form Validation Class Initialized
INFO - 2021-04-16 19:46:45 --> Model Class Initialized
INFO - 2021-04-16 19:46:45 --> Controller Class Initialized
INFO - 2021-04-16 19:46:45 --> Model Class Initialized
INFO - 2021-04-16 19:46:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 19:46:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 19:46:45 --> Final output sent to browser
DEBUG - 2021-04-16 19:46:45 --> Total execution time: 0.0318
INFO - 2021-04-16 19:46:46 --> Config Class Initialized
INFO - 2021-04-16 19:46:46 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:46:46 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:46:46 --> Utf8 Class Initialized
INFO - 2021-04-16 19:46:46 --> URI Class Initialized
INFO - 2021-04-16 19:46:46 --> Router Class Initialized
INFO - 2021-04-16 19:46:46 --> Output Class Initialized
INFO - 2021-04-16 19:46:46 --> Security Class Initialized
DEBUG - 2021-04-16 19:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:46:46 --> Input Class Initialized
INFO - 2021-04-16 19:46:46 --> Language Class Initialized
INFO - 2021-04-16 19:46:46 --> Loader Class Initialized
INFO - 2021-04-16 19:46:46 --> Helper loaded: url_helper
INFO - 2021-04-16 19:46:46 --> Helper loaded: form_helper
INFO - 2021-04-16 19:46:46 --> Helper loaded: common_helper
INFO - 2021-04-16 19:46:46 --> Helper loaded: util_helper
INFO - 2021-04-16 19:46:46 --> Helper loaded: user_helper
INFO - 2021-04-16 19:46:46 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:46:46 --> Form Validation Class Initialized
INFO - 2021-04-16 19:46:46 --> Model Class Initialized
INFO - 2021-04-16 19:46:46 --> Controller Class Initialized
INFO - 2021-04-16 19:46:46 --> Model Class Initialized
INFO - 2021-04-16 19:46:46 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 19:46:46 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 19:46:46 --> Final output sent to browser
DEBUG - 2021-04-16 19:46:46 --> Total execution time: 0.0349
INFO - 2021-04-16 19:46:46 --> Config Class Initialized
INFO - 2021-04-16 19:46:46 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:46:46 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:46:46 --> Utf8 Class Initialized
INFO - 2021-04-16 19:46:46 --> URI Class Initialized
INFO - 2021-04-16 19:46:46 --> Router Class Initialized
INFO - 2021-04-16 19:46:46 --> Output Class Initialized
INFO - 2021-04-16 19:46:46 --> Security Class Initialized
DEBUG - 2021-04-16 19:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:46:46 --> Input Class Initialized
INFO - 2021-04-16 19:46:46 --> Language Class Initialized
INFO - 2021-04-16 19:46:46 --> Loader Class Initialized
INFO - 2021-04-16 19:46:46 --> Helper loaded: url_helper
INFO - 2021-04-16 19:46:46 --> Helper loaded: form_helper
INFO - 2021-04-16 19:46:46 --> Helper loaded: common_helper
INFO - 2021-04-16 19:46:46 --> Helper loaded: util_helper
INFO - 2021-04-16 19:46:46 --> Helper loaded: user_helper
INFO - 2021-04-16 19:46:46 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:46:46 --> Form Validation Class Initialized
INFO - 2021-04-16 19:46:46 --> Model Class Initialized
INFO - 2021-04-16 19:46:46 --> Controller Class Initialized
INFO - 2021-04-16 19:46:46 --> Model Class Initialized
INFO - 2021-04-16 19:46:46 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 19:46:46 --> Final output sent to browser
DEBUG - 2021-04-16 19:46:46 --> Total execution time: 0.0273
INFO - 2021-04-16 19:46:46 --> Config Class Initialized
INFO - 2021-04-16 19:46:46 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:46:46 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:46:46 --> Utf8 Class Initialized
INFO - 2021-04-16 19:46:46 --> URI Class Initialized
INFO - 2021-04-16 19:46:46 --> Router Class Initialized
INFO - 2021-04-16 19:46:46 --> Output Class Initialized
INFO - 2021-04-16 19:46:46 --> Security Class Initialized
DEBUG - 2021-04-16 19:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:46:46 --> Input Class Initialized
INFO - 2021-04-16 19:46:46 --> Language Class Initialized
INFO - 2021-04-16 19:46:46 --> Loader Class Initialized
INFO - 2021-04-16 19:46:46 --> Helper loaded: url_helper
INFO - 2021-04-16 19:46:46 --> Helper loaded: form_helper
INFO - 2021-04-16 19:46:46 --> Helper loaded: common_helper
INFO - 2021-04-16 19:46:46 --> Helper loaded: util_helper
INFO - 2021-04-16 19:46:46 --> Helper loaded: user_helper
INFO - 2021-04-16 19:46:46 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:46:46 --> Form Validation Class Initialized
INFO - 2021-04-16 19:46:46 --> Model Class Initialized
INFO - 2021-04-16 19:46:46 --> Controller Class Initialized
INFO - 2021-04-16 19:46:46 --> Model Class Initialized
INFO - 2021-04-16 19:46:46 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 19:46:46 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 19:46:46 --> Final output sent to browser
DEBUG - 2021-04-16 19:46:46 --> Total execution time: 0.0315
INFO - 2021-04-16 19:46:46 --> Config Class Initialized
INFO - 2021-04-16 19:46:46 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:46:46 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:46:46 --> Utf8 Class Initialized
INFO - 2021-04-16 19:46:46 --> URI Class Initialized
INFO - 2021-04-16 19:46:46 --> Router Class Initialized
INFO - 2021-04-16 19:46:46 --> Output Class Initialized
INFO - 2021-04-16 19:46:46 --> Security Class Initialized
DEBUG - 2021-04-16 19:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:46:46 --> Input Class Initialized
INFO - 2021-04-16 19:46:46 --> Language Class Initialized
INFO - 2021-04-16 19:46:46 --> Loader Class Initialized
INFO - 2021-04-16 19:46:46 --> Helper loaded: url_helper
INFO - 2021-04-16 19:46:46 --> Helper loaded: form_helper
INFO - 2021-04-16 19:46:46 --> Helper loaded: common_helper
INFO - 2021-04-16 19:46:46 --> Helper loaded: util_helper
INFO - 2021-04-16 19:46:46 --> Helper loaded: user_helper
INFO - 2021-04-16 19:46:46 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:46:46 --> Form Validation Class Initialized
INFO - 2021-04-16 19:46:46 --> Model Class Initialized
INFO - 2021-04-16 19:46:46 --> Controller Class Initialized
INFO - 2021-04-16 19:46:46 --> Model Class Initialized
INFO - 2021-04-16 19:46:46 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 19:46:46 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 19:46:46 --> Final output sent to browser
DEBUG - 2021-04-16 19:46:46 --> Total execution time: 0.0296
INFO - 2021-04-16 19:46:47 --> Config Class Initialized
INFO - 2021-04-16 19:46:47 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:46:47 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:46:47 --> Utf8 Class Initialized
INFO - 2021-04-16 19:46:47 --> URI Class Initialized
INFO - 2021-04-16 19:46:47 --> Router Class Initialized
INFO - 2021-04-16 19:46:47 --> Output Class Initialized
INFO - 2021-04-16 19:46:47 --> Security Class Initialized
DEBUG - 2021-04-16 19:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:46:47 --> Input Class Initialized
INFO - 2021-04-16 19:46:47 --> Language Class Initialized
INFO - 2021-04-16 19:46:47 --> Loader Class Initialized
INFO - 2021-04-16 19:46:47 --> Helper loaded: url_helper
INFO - 2021-04-16 19:46:47 --> Helper loaded: form_helper
INFO - 2021-04-16 19:46:47 --> Helper loaded: common_helper
INFO - 2021-04-16 19:46:47 --> Helper loaded: util_helper
INFO - 2021-04-16 19:46:47 --> Helper loaded: user_helper
INFO - 2021-04-16 19:46:47 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:46:47 --> Form Validation Class Initialized
INFO - 2021-04-16 19:46:47 --> Model Class Initialized
INFO - 2021-04-16 19:46:47 --> Controller Class Initialized
INFO - 2021-04-16 19:46:47 --> Model Class Initialized
INFO - 2021-04-16 19:46:47 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 19:46:47 --> Final output sent to browser
DEBUG - 2021-04-16 19:46:47 --> Total execution time: 0.0375
INFO - 2021-04-16 19:46:47 --> Config Class Initialized
INFO - 2021-04-16 19:46:47 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:46:47 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:46:47 --> Utf8 Class Initialized
INFO - 2021-04-16 19:46:47 --> URI Class Initialized
INFO - 2021-04-16 19:46:47 --> Router Class Initialized
INFO - 2021-04-16 19:46:47 --> Output Class Initialized
INFO - 2021-04-16 19:46:47 --> Security Class Initialized
DEBUG - 2021-04-16 19:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:46:47 --> Input Class Initialized
INFO - 2021-04-16 19:46:47 --> Language Class Initialized
INFO - 2021-04-16 19:46:47 --> Loader Class Initialized
INFO - 2021-04-16 19:46:47 --> Helper loaded: url_helper
INFO - 2021-04-16 19:46:47 --> Helper loaded: form_helper
INFO - 2021-04-16 19:46:47 --> Helper loaded: common_helper
INFO - 2021-04-16 19:46:47 --> Helper loaded: util_helper
INFO - 2021-04-16 19:46:47 --> Helper loaded: user_helper
INFO - 2021-04-16 19:46:47 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:46:47 --> Form Validation Class Initialized
INFO - 2021-04-16 19:46:47 --> Model Class Initialized
INFO - 2021-04-16 19:46:47 --> Controller Class Initialized
INFO - 2021-04-16 19:46:47 --> Model Class Initialized
INFO - 2021-04-16 19:46:47 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 19:46:47 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 19:46:47 --> Final output sent to browser
DEBUG - 2021-04-16 19:46:47 --> Total execution time: 0.0378
INFO - 2021-04-16 19:46:47 --> Config Class Initialized
INFO - 2021-04-16 19:46:47 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:46:47 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:46:47 --> Utf8 Class Initialized
INFO - 2021-04-16 19:46:47 --> URI Class Initialized
INFO - 2021-04-16 19:46:47 --> Router Class Initialized
INFO - 2021-04-16 19:46:47 --> Output Class Initialized
INFO - 2021-04-16 19:46:47 --> Security Class Initialized
DEBUG - 2021-04-16 19:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:46:47 --> Input Class Initialized
INFO - 2021-04-16 19:46:47 --> Language Class Initialized
INFO - 2021-04-16 19:46:47 --> Loader Class Initialized
INFO - 2021-04-16 19:46:47 --> Helper loaded: url_helper
INFO - 2021-04-16 19:46:47 --> Helper loaded: form_helper
INFO - 2021-04-16 19:46:47 --> Helper loaded: common_helper
INFO - 2021-04-16 19:46:47 --> Helper loaded: util_helper
INFO - 2021-04-16 19:46:47 --> Helper loaded: user_helper
INFO - 2021-04-16 19:46:47 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:46:47 --> Form Validation Class Initialized
INFO - 2021-04-16 19:46:47 --> Model Class Initialized
INFO - 2021-04-16 19:46:47 --> Controller Class Initialized
INFO - 2021-04-16 19:46:47 --> Model Class Initialized
INFO - 2021-04-16 19:46:47 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 19:46:47 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 19:46:47 --> Final output sent to browser
DEBUG - 2021-04-16 19:46:47 --> Total execution time: 0.0336
INFO - 2021-04-16 19:46:48 --> Config Class Initialized
INFO - 2021-04-16 19:46:48 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:46:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:46:48 --> Utf8 Class Initialized
INFO - 2021-04-16 19:46:48 --> URI Class Initialized
INFO - 2021-04-16 19:46:48 --> Router Class Initialized
INFO - 2021-04-16 19:46:48 --> Output Class Initialized
INFO - 2021-04-16 19:46:48 --> Security Class Initialized
DEBUG - 2021-04-16 19:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:46:48 --> Input Class Initialized
INFO - 2021-04-16 19:46:48 --> Language Class Initialized
INFO - 2021-04-16 19:46:48 --> Loader Class Initialized
INFO - 2021-04-16 19:46:48 --> Helper loaded: url_helper
INFO - 2021-04-16 19:46:48 --> Helper loaded: form_helper
INFO - 2021-04-16 19:46:48 --> Helper loaded: common_helper
INFO - 2021-04-16 19:46:48 --> Helper loaded: util_helper
INFO - 2021-04-16 19:46:48 --> Helper loaded: user_helper
INFO - 2021-04-16 19:46:48 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:46:48 --> Form Validation Class Initialized
INFO - 2021-04-16 19:46:48 --> Model Class Initialized
INFO - 2021-04-16 19:46:48 --> Controller Class Initialized
INFO - 2021-04-16 19:46:48 --> Model Class Initialized
INFO - 2021-04-16 19:46:48 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 19:46:48 --> Final output sent to browser
DEBUG - 2021-04-16 19:46:48 --> Total execution time: 0.0292
INFO - 2021-04-16 19:46:48 --> Config Class Initialized
INFO - 2021-04-16 19:46:48 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:46:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:46:48 --> Utf8 Class Initialized
INFO - 2021-04-16 19:46:48 --> URI Class Initialized
INFO - 2021-04-16 19:46:48 --> Router Class Initialized
INFO - 2021-04-16 19:46:48 --> Output Class Initialized
INFO - 2021-04-16 19:46:48 --> Security Class Initialized
DEBUG - 2021-04-16 19:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:46:48 --> Input Class Initialized
INFO - 2021-04-16 19:46:48 --> Language Class Initialized
INFO - 2021-04-16 19:46:48 --> Loader Class Initialized
INFO - 2021-04-16 19:46:48 --> Helper loaded: url_helper
INFO - 2021-04-16 19:46:48 --> Helper loaded: form_helper
INFO - 2021-04-16 19:46:48 --> Helper loaded: common_helper
INFO - 2021-04-16 19:46:48 --> Helper loaded: util_helper
INFO - 2021-04-16 19:46:48 --> Helper loaded: user_helper
INFO - 2021-04-16 19:46:48 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:46:48 --> Form Validation Class Initialized
INFO - 2021-04-16 19:46:48 --> Model Class Initialized
INFO - 2021-04-16 19:46:48 --> Controller Class Initialized
INFO - 2021-04-16 19:46:48 --> Model Class Initialized
INFO - 2021-04-16 19:46:48 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 19:46:48 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 19:46:48 --> Final output sent to browser
DEBUG - 2021-04-16 19:46:48 --> Total execution time: 0.0307
INFO - 2021-04-16 19:46:48 --> Config Class Initialized
INFO - 2021-04-16 19:46:48 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:46:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:46:48 --> Utf8 Class Initialized
INFO - 2021-04-16 19:46:48 --> URI Class Initialized
INFO - 2021-04-16 19:46:48 --> Router Class Initialized
INFO - 2021-04-16 19:46:48 --> Output Class Initialized
INFO - 2021-04-16 19:46:48 --> Security Class Initialized
DEBUG - 2021-04-16 19:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:46:48 --> Input Class Initialized
INFO - 2021-04-16 19:46:48 --> Language Class Initialized
INFO - 2021-04-16 19:46:48 --> Loader Class Initialized
INFO - 2021-04-16 19:46:48 --> Helper loaded: url_helper
INFO - 2021-04-16 19:46:48 --> Helper loaded: form_helper
INFO - 2021-04-16 19:46:48 --> Helper loaded: common_helper
INFO - 2021-04-16 19:46:48 --> Helper loaded: util_helper
INFO - 2021-04-16 19:46:48 --> Helper loaded: user_helper
INFO - 2021-04-16 19:46:48 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:46:48 --> Form Validation Class Initialized
INFO - 2021-04-16 19:46:48 --> Model Class Initialized
INFO - 2021-04-16 19:46:48 --> Controller Class Initialized
INFO - 2021-04-16 19:46:48 --> Model Class Initialized
INFO - 2021-04-16 19:46:48 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 19:46:48 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 19:46:48 --> Final output sent to browser
DEBUG - 2021-04-16 19:46:48 --> Total execution time: 0.0296
INFO - 2021-04-16 19:46:48 --> Config Class Initialized
INFO - 2021-04-16 19:46:48 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:46:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:46:48 --> Utf8 Class Initialized
INFO - 2021-04-16 19:46:48 --> URI Class Initialized
INFO - 2021-04-16 19:46:48 --> Router Class Initialized
INFO - 2021-04-16 19:46:48 --> Output Class Initialized
INFO - 2021-04-16 19:46:48 --> Security Class Initialized
DEBUG - 2021-04-16 19:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:46:48 --> Input Class Initialized
INFO - 2021-04-16 19:46:48 --> Language Class Initialized
INFO - 2021-04-16 19:46:48 --> Loader Class Initialized
INFO - 2021-04-16 19:46:48 --> Helper loaded: url_helper
INFO - 2021-04-16 19:46:48 --> Helper loaded: form_helper
INFO - 2021-04-16 19:46:48 --> Helper loaded: common_helper
INFO - 2021-04-16 19:46:48 --> Helper loaded: util_helper
INFO - 2021-04-16 19:46:48 --> Helper loaded: user_helper
INFO - 2021-04-16 19:46:49 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:46:49 --> Form Validation Class Initialized
INFO - 2021-04-16 19:46:49 --> Model Class Initialized
INFO - 2021-04-16 19:46:49 --> Controller Class Initialized
INFO - 2021-04-16 19:46:49 --> Model Class Initialized
INFO - 2021-04-16 19:46:49 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 19:46:49 --> Final output sent to browser
DEBUG - 2021-04-16 19:46:49 --> Total execution time: 0.0285
INFO - 2021-04-16 19:46:49 --> Config Class Initialized
INFO - 2021-04-16 19:46:49 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:46:49 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:46:49 --> Utf8 Class Initialized
INFO - 2021-04-16 19:46:49 --> URI Class Initialized
INFO - 2021-04-16 19:46:49 --> Router Class Initialized
INFO - 2021-04-16 19:46:49 --> Output Class Initialized
INFO - 2021-04-16 19:46:49 --> Security Class Initialized
DEBUG - 2021-04-16 19:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:46:49 --> Input Class Initialized
INFO - 2021-04-16 19:46:49 --> Language Class Initialized
INFO - 2021-04-16 19:46:49 --> Loader Class Initialized
INFO - 2021-04-16 19:46:49 --> Helper loaded: url_helper
INFO - 2021-04-16 19:46:49 --> Helper loaded: form_helper
INFO - 2021-04-16 19:46:49 --> Helper loaded: common_helper
INFO - 2021-04-16 19:46:49 --> Helper loaded: util_helper
INFO - 2021-04-16 19:46:49 --> Helper loaded: user_helper
INFO - 2021-04-16 19:46:49 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:46:49 --> Form Validation Class Initialized
INFO - 2021-04-16 19:46:49 --> Model Class Initialized
INFO - 2021-04-16 19:46:49 --> Controller Class Initialized
INFO - 2021-04-16 19:46:49 --> Model Class Initialized
INFO - 2021-04-16 19:46:49 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 19:46:49 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 19:46:49 --> Final output sent to browser
DEBUG - 2021-04-16 19:46:49 --> Total execution time: 0.0276
INFO - 2021-04-16 19:46:50 --> Config Class Initialized
INFO - 2021-04-16 19:46:50 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:46:50 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:46:50 --> Utf8 Class Initialized
INFO - 2021-04-16 19:46:50 --> URI Class Initialized
INFO - 2021-04-16 19:46:50 --> Router Class Initialized
INFO - 2021-04-16 19:46:50 --> Output Class Initialized
INFO - 2021-04-16 19:46:50 --> Security Class Initialized
DEBUG - 2021-04-16 19:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:46:50 --> Input Class Initialized
INFO - 2021-04-16 19:46:50 --> Language Class Initialized
INFO - 2021-04-16 19:46:50 --> Loader Class Initialized
INFO - 2021-04-16 19:46:50 --> Helper loaded: url_helper
INFO - 2021-04-16 19:46:50 --> Helper loaded: form_helper
INFO - 2021-04-16 19:46:50 --> Helper loaded: common_helper
INFO - 2021-04-16 19:46:50 --> Helper loaded: util_helper
INFO - 2021-04-16 19:46:50 --> Helper loaded: user_helper
INFO - 2021-04-16 19:46:50 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:46:50 --> Form Validation Class Initialized
INFO - 2021-04-16 19:46:50 --> Model Class Initialized
INFO - 2021-04-16 19:46:50 --> Controller Class Initialized
INFO - 2021-04-16 19:46:50 --> Model Class Initialized
INFO - 2021-04-16 19:46:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 19:46:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 19:46:50 --> Final output sent to browser
DEBUG - 2021-04-16 19:46:50 --> Total execution time: 0.0307
INFO - 2021-04-16 19:46:50 --> Config Class Initialized
INFO - 2021-04-16 19:46:50 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:46:50 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:46:50 --> Utf8 Class Initialized
INFO - 2021-04-16 19:46:50 --> URI Class Initialized
INFO - 2021-04-16 19:46:50 --> Router Class Initialized
INFO - 2021-04-16 19:46:50 --> Output Class Initialized
INFO - 2021-04-16 19:46:50 --> Security Class Initialized
DEBUG - 2021-04-16 19:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:46:50 --> Input Class Initialized
INFO - 2021-04-16 19:46:50 --> Language Class Initialized
INFO - 2021-04-16 19:46:50 --> Loader Class Initialized
INFO - 2021-04-16 19:46:50 --> Helper loaded: url_helper
INFO - 2021-04-16 19:46:50 --> Helper loaded: form_helper
INFO - 2021-04-16 19:46:50 --> Helper loaded: common_helper
INFO - 2021-04-16 19:46:50 --> Helper loaded: util_helper
INFO - 2021-04-16 19:46:50 --> Helper loaded: user_helper
INFO - 2021-04-16 19:46:50 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:46:50 --> Form Validation Class Initialized
INFO - 2021-04-16 19:46:50 --> Model Class Initialized
INFO - 2021-04-16 19:46:50 --> Controller Class Initialized
INFO - 2021-04-16 19:46:50 --> Model Class Initialized
INFO - 2021-04-16 19:46:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 19:46:50 --> Final output sent to browser
DEBUG - 2021-04-16 19:46:50 --> Total execution time: 0.0390
INFO - 2021-04-16 19:46:50 --> Config Class Initialized
INFO - 2021-04-16 19:46:50 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:46:50 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:46:50 --> Utf8 Class Initialized
INFO - 2021-04-16 19:46:50 --> URI Class Initialized
INFO - 2021-04-16 19:46:50 --> Router Class Initialized
INFO - 2021-04-16 19:46:50 --> Output Class Initialized
INFO - 2021-04-16 19:46:50 --> Security Class Initialized
DEBUG - 2021-04-16 19:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:46:50 --> Input Class Initialized
INFO - 2021-04-16 19:46:50 --> Language Class Initialized
INFO - 2021-04-16 19:46:50 --> Loader Class Initialized
INFO - 2021-04-16 19:46:50 --> Helper loaded: url_helper
INFO - 2021-04-16 19:46:50 --> Helper loaded: form_helper
INFO - 2021-04-16 19:46:50 --> Helper loaded: common_helper
INFO - 2021-04-16 19:46:50 --> Helper loaded: util_helper
INFO - 2021-04-16 19:46:50 --> Helper loaded: user_helper
INFO - 2021-04-16 19:46:50 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:46:50 --> Form Validation Class Initialized
INFO - 2021-04-16 19:46:50 --> Model Class Initialized
INFO - 2021-04-16 19:46:50 --> Controller Class Initialized
INFO - 2021-04-16 19:46:50 --> Model Class Initialized
INFO - 2021-04-16 19:46:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 19:46:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 19:46:50 --> Final output sent to browser
DEBUG - 2021-04-16 19:46:50 --> Total execution time: 0.0265
INFO - 2021-04-16 19:46:50 --> Config Class Initialized
INFO - 2021-04-16 19:46:50 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:46:50 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:46:50 --> Utf8 Class Initialized
INFO - 2021-04-16 19:46:50 --> URI Class Initialized
INFO - 2021-04-16 19:46:50 --> Router Class Initialized
INFO - 2021-04-16 19:46:50 --> Output Class Initialized
INFO - 2021-04-16 19:46:50 --> Security Class Initialized
DEBUG - 2021-04-16 19:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:46:50 --> Input Class Initialized
INFO - 2021-04-16 19:46:50 --> Language Class Initialized
INFO - 2021-04-16 19:46:50 --> Loader Class Initialized
INFO - 2021-04-16 19:46:50 --> Helper loaded: url_helper
INFO - 2021-04-16 19:46:50 --> Helper loaded: form_helper
INFO - 2021-04-16 19:46:50 --> Helper loaded: common_helper
INFO - 2021-04-16 19:46:50 --> Helper loaded: util_helper
INFO - 2021-04-16 19:46:50 --> Helper loaded: user_helper
INFO - 2021-04-16 19:46:50 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:46:50 --> Form Validation Class Initialized
INFO - 2021-04-16 19:46:50 --> Model Class Initialized
INFO - 2021-04-16 19:46:50 --> Controller Class Initialized
INFO - 2021-04-16 19:46:50 --> Model Class Initialized
INFO - 2021-04-16 19:46:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 19:46:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 19:46:50 --> Final output sent to browser
DEBUG - 2021-04-16 19:46:50 --> Total execution time: 0.0347
INFO - 2021-04-16 19:47:03 --> Config Class Initialized
INFO - 2021-04-16 19:47:03 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:47:03 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:47:03 --> Utf8 Class Initialized
INFO - 2021-04-16 19:47:03 --> URI Class Initialized
INFO - 2021-04-16 19:47:03 --> Router Class Initialized
INFO - 2021-04-16 19:47:03 --> Output Class Initialized
INFO - 2021-04-16 19:47:03 --> Security Class Initialized
DEBUG - 2021-04-16 19:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:47:03 --> Input Class Initialized
INFO - 2021-04-16 19:47:03 --> Language Class Initialized
INFO - 2021-04-16 19:47:03 --> Loader Class Initialized
INFO - 2021-04-16 19:47:03 --> Helper loaded: url_helper
INFO - 2021-04-16 19:47:03 --> Helper loaded: form_helper
INFO - 2021-04-16 19:47:03 --> Helper loaded: common_helper
INFO - 2021-04-16 19:47:03 --> Helper loaded: util_helper
INFO - 2021-04-16 19:47:03 --> Helper loaded: user_helper
INFO - 2021-04-16 19:47:03 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:47:03 --> Form Validation Class Initialized
INFO - 2021-04-16 19:47:03 --> Model Class Initialized
INFO - 2021-04-16 19:47:03 --> Controller Class Initialized
INFO - 2021-04-16 19:47:03 --> Model Class Initialized
INFO - 2021-04-16 19:47:03 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 19:47:03 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 19:47:03 --> Final output sent to browser
DEBUG - 2021-04-16 19:47:03 --> Total execution time: 0.0322
INFO - 2021-04-16 19:47:09 --> Config Class Initialized
INFO - 2021-04-16 19:47:09 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:47:09 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:47:09 --> Utf8 Class Initialized
INFO - 2021-04-16 19:47:09 --> URI Class Initialized
INFO - 2021-04-16 19:47:09 --> Router Class Initialized
INFO - 2021-04-16 19:47:09 --> Output Class Initialized
INFO - 2021-04-16 19:47:09 --> Security Class Initialized
DEBUG - 2021-04-16 19:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:47:09 --> Input Class Initialized
INFO - 2021-04-16 19:47:09 --> Language Class Initialized
INFO - 2021-04-16 19:47:09 --> Loader Class Initialized
INFO - 2021-04-16 19:47:09 --> Helper loaded: url_helper
INFO - 2021-04-16 19:47:09 --> Helper loaded: form_helper
INFO - 2021-04-16 19:47:09 --> Helper loaded: common_helper
INFO - 2021-04-16 19:47:09 --> Helper loaded: util_helper
INFO - 2021-04-16 19:47:09 --> Helper loaded: user_helper
INFO - 2021-04-16 19:47:09 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:47:09 --> Form Validation Class Initialized
INFO - 2021-04-16 19:47:09 --> Model Class Initialized
INFO - 2021-04-16 19:47:09 --> Controller Class Initialized
INFO - 2021-04-16 19:47:09 --> Model Class Initialized
INFO - 2021-04-16 19:47:09 --> Config Class Initialized
INFO - 2021-04-16 19:47:09 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:47:09 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:47:09 --> Utf8 Class Initialized
INFO - 2021-04-16 19:47:09 --> URI Class Initialized
INFO - 2021-04-16 19:47:09 --> Router Class Initialized
INFO - 2021-04-16 19:47:09 --> Output Class Initialized
INFO - 2021-04-16 19:47:09 --> Security Class Initialized
DEBUG - 2021-04-16 19:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:47:09 --> Input Class Initialized
INFO - 2021-04-16 19:47:09 --> Language Class Initialized
INFO - 2021-04-16 19:47:09 --> Loader Class Initialized
INFO - 2021-04-16 19:47:09 --> Helper loaded: url_helper
INFO - 2021-04-16 19:47:09 --> Helper loaded: form_helper
INFO - 2021-04-16 19:47:09 --> Helper loaded: common_helper
INFO - 2021-04-16 19:47:09 --> Helper loaded: util_helper
INFO - 2021-04-16 19:47:09 --> Helper loaded: user_helper
INFO - 2021-04-16 19:47:09 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:47:09 --> Form Validation Class Initialized
INFO - 2021-04-16 19:47:09 --> Model Class Initialized
INFO - 2021-04-16 19:47:09 --> Controller Class Initialized
INFO - 2021-04-16 19:47:10 --> Model Class Initialized
INFO - 2021-04-16 19:47:10 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 19:47:10 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 19:47:10 --> Final output sent to browser
DEBUG - 2021-04-16 19:47:10 --> Total execution time: 0.0270
INFO - 2021-04-16 19:47:11 --> Config Class Initialized
INFO - 2021-04-16 19:47:11 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:47:11 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:47:11 --> Utf8 Class Initialized
INFO - 2021-04-16 19:47:11 --> URI Class Initialized
INFO - 2021-04-16 19:47:11 --> Router Class Initialized
INFO - 2021-04-16 19:47:11 --> Output Class Initialized
INFO - 2021-04-16 19:47:11 --> Security Class Initialized
DEBUG - 2021-04-16 19:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:47:11 --> Input Class Initialized
INFO - 2021-04-16 19:47:11 --> Language Class Initialized
INFO - 2021-04-16 19:47:11 --> Loader Class Initialized
INFO - 2021-04-16 19:47:11 --> Helper loaded: url_helper
INFO - 2021-04-16 19:47:11 --> Helper loaded: form_helper
INFO - 2021-04-16 19:47:11 --> Helper loaded: common_helper
INFO - 2021-04-16 19:47:11 --> Helper loaded: util_helper
INFO - 2021-04-16 19:47:11 --> Helper loaded: user_helper
INFO - 2021-04-16 19:47:11 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:47:11 --> Form Validation Class Initialized
INFO - 2021-04-16 19:47:11 --> Model Class Initialized
INFO - 2021-04-16 19:47:11 --> Controller Class Initialized
INFO - 2021-04-16 19:47:11 --> Model Class Initialized
INFO - 2021-04-16 19:47:11 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 19:47:11 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 19:47:11 --> Final output sent to browser
DEBUG - 2021-04-16 19:47:11 --> Total execution time: 0.0426
INFO - 2021-04-16 19:47:17 --> Config Class Initialized
INFO - 2021-04-16 19:47:17 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:47:17 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:47:17 --> Utf8 Class Initialized
INFO - 2021-04-16 19:47:17 --> URI Class Initialized
INFO - 2021-04-16 19:47:17 --> Router Class Initialized
INFO - 2021-04-16 19:47:17 --> Output Class Initialized
INFO - 2021-04-16 19:47:17 --> Security Class Initialized
DEBUG - 2021-04-16 19:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:47:17 --> Input Class Initialized
INFO - 2021-04-16 19:47:17 --> Language Class Initialized
INFO - 2021-04-16 19:47:17 --> Loader Class Initialized
INFO - 2021-04-16 19:47:17 --> Helper loaded: url_helper
INFO - 2021-04-16 19:47:17 --> Helper loaded: form_helper
INFO - 2021-04-16 19:47:17 --> Helper loaded: common_helper
INFO - 2021-04-16 19:47:17 --> Helper loaded: util_helper
INFO - 2021-04-16 19:47:17 --> Helper loaded: user_helper
INFO - 2021-04-16 19:47:17 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:47:17 --> Form Validation Class Initialized
INFO - 2021-04-16 19:47:17 --> Model Class Initialized
INFO - 2021-04-16 19:47:17 --> Controller Class Initialized
INFO - 2021-04-16 19:47:17 --> Model Class Initialized
INFO - 2021-04-16 19:47:17 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 19:47:17 --> Final output sent to browser
DEBUG - 2021-04-16 19:47:17 --> Total execution time: 0.0279
INFO - 2021-04-16 19:47:19 --> Config Class Initialized
INFO - 2021-04-16 19:47:19 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:47:19 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:47:19 --> Utf8 Class Initialized
INFO - 2021-04-16 19:47:19 --> URI Class Initialized
INFO - 2021-04-16 19:47:19 --> Router Class Initialized
INFO - 2021-04-16 19:47:19 --> Output Class Initialized
INFO - 2021-04-16 19:47:19 --> Security Class Initialized
DEBUG - 2021-04-16 19:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:47:19 --> Input Class Initialized
INFO - 2021-04-16 19:47:19 --> Language Class Initialized
INFO - 2021-04-16 19:47:19 --> Loader Class Initialized
INFO - 2021-04-16 19:47:19 --> Helper loaded: url_helper
INFO - 2021-04-16 19:47:19 --> Helper loaded: form_helper
INFO - 2021-04-16 19:47:19 --> Helper loaded: common_helper
INFO - 2021-04-16 19:47:19 --> Helper loaded: util_helper
INFO - 2021-04-16 19:47:19 --> Helper loaded: user_helper
INFO - 2021-04-16 19:47:19 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:47:19 --> Form Validation Class Initialized
INFO - 2021-04-16 19:47:19 --> Model Class Initialized
INFO - 2021-04-16 19:47:19 --> Controller Class Initialized
INFO - 2021-04-16 19:47:19 --> Model Class Initialized
INFO - 2021-04-16 19:47:19 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 19:47:19 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 19:47:19 --> Final output sent to browser
DEBUG - 2021-04-16 19:47:19 --> Total execution time: 0.0346
INFO - 2021-04-16 19:47:20 --> Config Class Initialized
INFO - 2021-04-16 19:47:20 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:47:20 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:47:20 --> Utf8 Class Initialized
INFO - 2021-04-16 19:47:20 --> URI Class Initialized
INFO - 2021-04-16 19:47:20 --> Router Class Initialized
INFO - 2021-04-16 19:47:20 --> Output Class Initialized
INFO - 2021-04-16 19:47:20 --> Security Class Initialized
DEBUG - 2021-04-16 19:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:47:20 --> Input Class Initialized
INFO - 2021-04-16 19:47:20 --> Language Class Initialized
INFO - 2021-04-16 19:47:20 --> Loader Class Initialized
INFO - 2021-04-16 19:47:20 --> Helper loaded: url_helper
INFO - 2021-04-16 19:47:20 --> Helper loaded: form_helper
INFO - 2021-04-16 19:47:20 --> Helper loaded: common_helper
INFO - 2021-04-16 19:47:20 --> Helper loaded: util_helper
INFO - 2021-04-16 19:47:20 --> Helper loaded: user_helper
INFO - 2021-04-16 19:47:20 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:47:20 --> Form Validation Class Initialized
INFO - 2021-04-16 19:47:20 --> Model Class Initialized
INFO - 2021-04-16 19:47:20 --> Controller Class Initialized
INFO - 2021-04-16 19:47:20 --> Model Class Initialized
INFO - 2021-04-16 19:47:20 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 19:47:20 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 19:47:20 --> Final output sent to browser
DEBUG - 2021-04-16 19:47:20 --> Total execution time: 0.0322
INFO - 2021-04-16 19:47:20 --> Config Class Initialized
INFO - 2021-04-16 19:47:20 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:47:20 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:47:20 --> Utf8 Class Initialized
INFO - 2021-04-16 19:47:20 --> URI Class Initialized
INFO - 2021-04-16 19:47:20 --> Router Class Initialized
INFO - 2021-04-16 19:47:20 --> Output Class Initialized
INFO - 2021-04-16 19:47:20 --> Security Class Initialized
DEBUG - 2021-04-16 19:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:47:20 --> Input Class Initialized
INFO - 2021-04-16 19:47:20 --> Language Class Initialized
INFO - 2021-04-16 19:47:20 --> Loader Class Initialized
INFO - 2021-04-16 19:47:20 --> Helper loaded: url_helper
INFO - 2021-04-16 19:47:20 --> Helper loaded: form_helper
INFO - 2021-04-16 19:47:20 --> Helper loaded: common_helper
INFO - 2021-04-16 19:47:20 --> Helper loaded: util_helper
INFO - 2021-04-16 19:47:20 --> Helper loaded: user_helper
INFO - 2021-04-16 19:47:20 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:47:20 --> Form Validation Class Initialized
INFO - 2021-04-16 19:47:20 --> Model Class Initialized
INFO - 2021-04-16 19:47:20 --> Controller Class Initialized
INFO - 2021-04-16 19:47:20 --> Model Class Initialized
INFO - 2021-04-16 19:47:20 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 19:47:20 --> Final output sent to browser
DEBUG - 2021-04-16 19:47:20 --> Total execution time: 0.0297
INFO - 2021-04-16 19:47:21 --> Config Class Initialized
INFO - 2021-04-16 19:47:21 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:47:21 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:47:21 --> Utf8 Class Initialized
INFO - 2021-04-16 19:47:21 --> URI Class Initialized
DEBUG - 2021-04-16 19:47:21 --> No URI present. Default controller set.
INFO - 2021-04-16 19:47:21 --> Router Class Initialized
INFO - 2021-04-16 19:47:21 --> Output Class Initialized
INFO - 2021-04-16 19:47:21 --> Security Class Initialized
DEBUG - 2021-04-16 19:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:47:21 --> Input Class Initialized
INFO - 2021-04-16 19:47:21 --> Language Class Initialized
INFO - 2021-04-16 19:47:21 --> Loader Class Initialized
INFO - 2021-04-16 19:47:21 --> Helper loaded: url_helper
INFO - 2021-04-16 19:47:21 --> Helper loaded: form_helper
INFO - 2021-04-16 19:47:21 --> Helper loaded: common_helper
INFO - 2021-04-16 19:47:21 --> Helper loaded: util_helper
INFO - 2021-04-16 19:47:21 --> Helper loaded: user_helper
INFO - 2021-04-16 19:47:21 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:47:21 --> Form Validation Class Initialized
INFO - 2021-04-16 19:47:21 --> Model Class Initialized
INFO - 2021-04-16 19:47:21 --> Controller Class Initialized
INFO - 2021-04-16 19:47:21 --> Model Class Initialized
INFO - 2021-04-16 19:47:21 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 19:47:21 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 19:47:21 --> Final output sent to browser
DEBUG - 2021-04-16 19:47:21 --> Total execution time: 0.0297
INFO - 2021-04-16 19:47:22 --> Config Class Initialized
INFO - 2021-04-16 19:47:22 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:47:22 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:47:22 --> Utf8 Class Initialized
INFO - 2021-04-16 19:47:22 --> URI Class Initialized
DEBUG - 2021-04-16 19:47:22 --> No URI present. Default controller set.
INFO - 2021-04-16 19:47:22 --> Router Class Initialized
INFO - 2021-04-16 19:47:22 --> Output Class Initialized
INFO - 2021-04-16 19:47:22 --> Security Class Initialized
DEBUG - 2021-04-16 19:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:47:22 --> Input Class Initialized
INFO - 2021-04-16 19:47:22 --> Language Class Initialized
INFO - 2021-04-16 19:47:22 --> Loader Class Initialized
INFO - 2021-04-16 19:47:22 --> Helper loaded: url_helper
INFO - 2021-04-16 19:47:22 --> Helper loaded: form_helper
INFO - 2021-04-16 19:47:22 --> Helper loaded: common_helper
INFO - 2021-04-16 19:47:22 --> Helper loaded: util_helper
INFO - 2021-04-16 19:47:22 --> Helper loaded: user_helper
INFO - 2021-04-16 19:47:22 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:47:22 --> Form Validation Class Initialized
INFO - 2021-04-16 19:47:22 --> Model Class Initialized
INFO - 2021-04-16 19:47:22 --> Controller Class Initialized
INFO - 2021-04-16 19:47:22 --> Model Class Initialized
INFO - 2021-04-16 19:47:22 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 19:47:22 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 19:47:22 --> Final output sent to browser
DEBUG - 2021-04-16 19:47:22 --> Total execution time: 0.0365
INFO - 2021-04-16 19:47:29 --> Config Class Initialized
INFO - 2021-04-16 19:47:29 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:47:29 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:47:29 --> Utf8 Class Initialized
INFO - 2021-04-16 19:47:29 --> URI Class Initialized
INFO - 2021-04-16 19:47:29 --> Router Class Initialized
INFO - 2021-04-16 19:47:29 --> Output Class Initialized
INFO - 2021-04-16 19:47:29 --> Security Class Initialized
DEBUG - 2021-04-16 19:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:47:29 --> Input Class Initialized
INFO - 2021-04-16 19:47:29 --> Language Class Initialized
INFO - 2021-04-16 19:47:29 --> Loader Class Initialized
INFO - 2021-04-16 19:47:29 --> Helper loaded: url_helper
INFO - 2021-04-16 19:47:29 --> Helper loaded: form_helper
INFO - 2021-04-16 19:47:29 --> Helper loaded: common_helper
INFO - 2021-04-16 19:47:29 --> Helper loaded: util_helper
INFO - 2021-04-16 19:47:29 --> Helper loaded: user_helper
INFO - 2021-04-16 19:47:29 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:47:29 --> Form Validation Class Initialized
INFO - 2021-04-16 19:47:29 --> Model Class Initialized
INFO - 2021-04-16 19:47:29 --> Controller Class Initialized
INFO - 2021-04-16 19:47:29 --> Model Class Initialized
INFO - 2021-04-16 19:47:29 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 19:47:29 --> Final output sent to browser
DEBUG - 2021-04-16 19:47:29 --> Total execution time: 0.0383
INFO - 2021-04-16 19:47:29 --> Config Class Initialized
INFO - 2021-04-16 19:47:29 --> Hooks Class Initialized
INFO - 2021-04-16 19:47:29 --> Config Class Initialized
INFO - 2021-04-16 19:47:29 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:47:29 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:47:29 --> Utf8 Class Initialized
DEBUG - 2021-04-16 19:47:29 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:47:29 --> Utf8 Class Initialized
INFO - 2021-04-16 19:47:29 --> URI Class Initialized
INFO - 2021-04-16 19:47:29 --> URI Class Initialized
INFO - 2021-04-16 19:47:29 --> Router Class Initialized
INFO - 2021-04-16 19:47:29 --> Router Class Initialized
INFO - 2021-04-16 19:47:29 --> Output Class Initialized
INFO - 2021-04-16 19:47:29 --> Output Class Initialized
INFO - 2021-04-16 19:47:29 --> Security Class Initialized
DEBUG - 2021-04-16 19:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:47:29 --> Security Class Initialized
INFO - 2021-04-16 19:47:29 --> Input Class Initialized
INFO - 2021-04-16 19:47:29 --> Language Class Initialized
DEBUG - 2021-04-16 19:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:47:29 --> Input Class Initialized
INFO - 2021-04-16 19:47:29 --> Language Class Initialized
ERROR - 2021-04-16 19:47:29 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-16 19:47:29 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-16 19:47:56 --> Config Class Initialized
INFO - 2021-04-16 19:47:56 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:47:56 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:47:56 --> Utf8 Class Initialized
INFO - 2021-04-16 19:47:56 --> URI Class Initialized
INFO - 2021-04-16 19:47:56 --> Router Class Initialized
INFO - 2021-04-16 19:47:56 --> Output Class Initialized
INFO - 2021-04-16 19:47:56 --> Security Class Initialized
DEBUG - 2021-04-16 19:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:47:56 --> Input Class Initialized
INFO - 2021-04-16 19:47:56 --> Language Class Initialized
INFO - 2021-04-16 19:47:56 --> Loader Class Initialized
INFO - 2021-04-16 19:47:56 --> Helper loaded: url_helper
INFO - 2021-04-16 19:47:56 --> Helper loaded: form_helper
INFO - 2021-04-16 19:47:56 --> Helper loaded: common_helper
INFO - 2021-04-16 19:47:56 --> Helper loaded: util_helper
INFO - 2021-04-16 19:47:56 --> Helper loaded: user_helper
INFO - 2021-04-16 19:47:56 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:47:56 --> Form Validation Class Initialized
INFO - 2021-04-16 19:47:56 --> Model Class Initialized
INFO - 2021-04-16 19:47:56 --> Controller Class Initialized
INFO - 2021-04-16 19:47:56 --> Model Class Initialized
INFO - 2021-04-16 19:47:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-16 19:47:56 --> Config Class Initialized
INFO - 2021-04-16 19:47:56 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:47:56 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:47:56 --> Utf8 Class Initialized
INFO - 2021-04-16 19:47:56 --> URI Class Initialized
INFO - 2021-04-16 19:47:56 --> Router Class Initialized
INFO - 2021-04-16 19:47:56 --> Output Class Initialized
INFO - 2021-04-16 19:47:56 --> Security Class Initialized
DEBUG - 2021-04-16 19:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:47:56 --> Input Class Initialized
INFO - 2021-04-16 19:47:56 --> Language Class Initialized
INFO - 2021-04-16 19:47:56 --> Loader Class Initialized
INFO - 2021-04-16 19:47:56 --> Helper loaded: url_helper
INFO - 2021-04-16 19:47:56 --> Helper loaded: form_helper
INFO - 2021-04-16 19:47:56 --> Helper loaded: common_helper
INFO - 2021-04-16 19:47:56 --> Helper loaded: util_helper
INFO - 2021-04-16 19:47:56 --> Helper loaded: user_helper
INFO - 2021-04-16 19:47:56 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:47:56 --> Form Validation Class Initialized
INFO - 2021-04-16 19:47:56 --> Model Class Initialized
INFO - 2021-04-16 19:47:56 --> Controller Class Initialized
INFO - 2021-04-16 19:47:56 --> Model Class Initialized
INFO - 2021-04-16 19:47:56 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 19:47:56 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 19:47:56 --> Final output sent to browser
DEBUG - 2021-04-16 19:47:56 --> Total execution time: 0.0312
INFO - 2021-04-16 19:57:31 --> Config Class Initialized
INFO - 2021-04-16 19:57:31 --> Hooks Class Initialized
DEBUG - 2021-04-16 19:57:31 --> UTF-8 Support Enabled
INFO - 2021-04-16 19:57:31 --> Utf8 Class Initialized
INFO - 2021-04-16 19:57:31 --> URI Class Initialized
INFO - 2021-04-16 19:57:31 --> Router Class Initialized
INFO - 2021-04-16 19:57:31 --> Output Class Initialized
INFO - 2021-04-16 19:57:31 --> Security Class Initialized
DEBUG - 2021-04-16 19:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 19:57:31 --> Input Class Initialized
INFO - 2021-04-16 19:57:31 --> Language Class Initialized
INFO - 2021-04-16 19:57:31 --> Loader Class Initialized
INFO - 2021-04-16 19:57:31 --> Helper loaded: url_helper
INFO - 2021-04-16 19:57:31 --> Helper loaded: form_helper
INFO - 2021-04-16 19:57:31 --> Helper loaded: common_helper
INFO - 2021-04-16 19:57:31 --> Helper loaded: util_helper
INFO - 2021-04-16 19:57:31 --> Helper loaded: user_helper
INFO - 2021-04-16 19:57:31 --> Database Driver Class Initialized
DEBUG - 2021-04-16 19:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 19:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 19:57:31 --> Form Validation Class Initialized
INFO - 2021-04-16 19:57:31 --> Model Class Initialized
INFO - 2021-04-16 19:57:31 --> Controller Class Initialized
INFO - 2021-04-16 19:57:31 --> Model Class Initialized
INFO - 2021-04-16 19:57:31 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 19:57:31 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 19:57:31 --> Final output sent to browser
DEBUG - 2021-04-16 19:57:31 --> Total execution time: 0.0414
INFO - 2021-04-16 20:09:27 --> Config Class Initialized
INFO - 2021-04-16 20:09:27 --> Hooks Class Initialized
DEBUG - 2021-04-16 20:09:27 --> UTF-8 Support Enabled
INFO - 2021-04-16 20:09:27 --> Utf8 Class Initialized
INFO - 2021-04-16 20:09:27 --> URI Class Initialized
INFO - 2021-04-16 20:09:27 --> Router Class Initialized
INFO - 2021-04-16 20:09:27 --> Output Class Initialized
INFO - 2021-04-16 20:09:27 --> Security Class Initialized
DEBUG - 2021-04-16 20:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 20:09:27 --> Input Class Initialized
INFO - 2021-04-16 20:09:27 --> Language Class Initialized
INFO - 2021-04-16 20:09:27 --> Loader Class Initialized
INFO - 2021-04-16 20:09:27 --> Helper loaded: url_helper
INFO - 2021-04-16 20:09:27 --> Helper loaded: form_helper
INFO - 2021-04-16 20:09:27 --> Helper loaded: common_helper
INFO - 2021-04-16 20:09:27 --> Helper loaded: util_helper
INFO - 2021-04-16 20:09:27 --> Helper loaded: user_helper
INFO - 2021-04-16 20:09:27 --> Database Driver Class Initialized
DEBUG - 2021-04-16 20:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 20:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 20:09:27 --> Form Validation Class Initialized
INFO - 2021-04-16 20:09:27 --> Model Class Initialized
INFO - 2021-04-16 20:09:27 --> Controller Class Initialized
INFO - 2021-04-16 20:09:27 --> Model Class Initialized
INFO - 2021-04-16 20:09:27 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 20:09:27 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 20:09:27 --> Final output sent to browser
DEBUG - 2021-04-16 20:09:27 --> Total execution time: 0.0400
INFO - 2021-04-16 20:09:36 --> Config Class Initialized
INFO - 2021-04-16 20:09:36 --> Hooks Class Initialized
DEBUG - 2021-04-16 20:09:36 --> UTF-8 Support Enabled
INFO - 2021-04-16 20:09:36 --> Utf8 Class Initialized
INFO - 2021-04-16 20:09:36 --> URI Class Initialized
INFO - 2021-04-16 20:09:36 --> Router Class Initialized
INFO - 2021-04-16 20:09:36 --> Output Class Initialized
INFO - 2021-04-16 20:09:36 --> Security Class Initialized
DEBUG - 2021-04-16 20:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 20:09:36 --> Input Class Initialized
INFO - 2021-04-16 20:09:36 --> Language Class Initialized
INFO - 2021-04-16 20:09:36 --> Loader Class Initialized
INFO - 2021-04-16 20:09:36 --> Helper loaded: url_helper
INFO - 2021-04-16 20:09:36 --> Helper loaded: form_helper
INFO - 2021-04-16 20:09:36 --> Helper loaded: common_helper
INFO - 2021-04-16 20:09:36 --> Helper loaded: util_helper
INFO - 2021-04-16 20:09:36 --> Helper loaded: user_helper
INFO - 2021-04-16 20:09:36 --> Database Driver Class Initialized
DEBUG - 2021-04-16 20:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 20:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 20:09:36 --> Form Validation Class Initialized
INFO - 2021-04-16 20:09:36 --> Model Class Initialized
INFO - 2021-04-16 20:09:36 --> Controller Class Initialized
INFO - 2021-04-16 20:09:36 --> Model Class Initialized
INFO - 2021-04-16 20:09:36 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 20:09:36 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 20:09:36 --> Final output sent to browser
DEBUG - 2021-04-16 20:09:36 --> Total execution time: 0.0389
INFO - 2021-04-16 20:24:02 --> Config Class Initialized
INFO - 2021-04-16 20:24:02 --> Hooks Class Initialized
DEBUG - 2021-04-16 20:24:02 --> UTF-8 Support Enabled
INFO - 2021-04-16 20:24:02 --> Utf8 Class Initialized
INFO - 2021-04-16 20:24:02 --> URI Class Initialized
INFO - 2021-04-16 20:24:02 --> Router Class Initialized
INFO - 2021-04-16 20:24:02 --> Output Class Initialized
INFO - 2021-04-16 20:24:02 --> Security Class Initialized
DEBUG - 2021-04-16 20:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 20:24:02 --> Input Class Initialized
INFO - 2021-04-16 20:24:02 --> Language Class Initialized
INFO - 2021-04-16 20:24:02 --> Loader Class Initialized
INFO - 2021-04-16 20:24:02 --> Helper loaded: url_helper
INFO - 2021-04-16 20:24:02 --> Helper loaded: form_helper
INFO - 2021-04-16 20:24:02 --> Helper loaded: common_helper
INFO - 2021-04-16 20:24:02 --> Helper loaded: util_helper
INFO - 2021-04-16 20:24:02 --> Helper loaded: user_helper
INFO - 2021-04-16 20:24:02 --> Database Driver Class Initialized
DEBUG - 2021-04-16 20:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 20:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 20:24:02 --> Form Validation Class Initialized
INFO - 2021-04-16 20:24:02 --> Model Class Initialized
INFO - 2021-04-16 20:24:02 --> Controller Class Initialized
INFO - 2021-04-16 20:24:02 --> Model Class Initialized
INFO - 2021-04-16 20:24:02 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 20:24:02 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 20:24:02 --> Final output sent to browser
DEBUG - 2021-04-16 20:24:02 --> Total execution time: 0.0301
INFO - 2021-04-16 20:24:08 --> Config Class Initialized
INFO - 2021-04-16 20:24:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 20:24:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 20:24:08 --> Utf8 Class Initialized
INFO - 2021-04-16 20:24:08 --> URI Class Initialized
INFO - 2021-04-16 20:24:08 --> Router Class Initialized
INFO - 2021-04-16 20:24:08 --> Output Class Initialized
INFO - 2021-04-16 20:24:08 --> Security Class Initialized
DEBUG - 2021-04-16 20:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 20:24:08 --> Input Class Initialized
INFO - 2021-04-16 20:24:08 --> Language Class Initialized
ERROR - 2021-04-16 20:24:08 --> 404 Page Not Found: Dashboard/update
INFO - 2021-04-16 20:24:12 --> Config Class Initialized
INFO - 2021-04-16 20:24:12 --> Hooks Class Initialized
DEBUG - 2021-04-16 20:24:12 --> UTF-8 Support Enabled
INFO - 2021-04-16 20:24:12 --> Utf8 Class Initialized
INFO - 2021-04-16 20:24:12 --> URI Class Initialized
INFO - 2021-04-16 20:24:12 --> Router Class Initialized
INFO - 2021-04-16 20:24:12 --> Output Class Initialized
INFO - 2021-04-16 20:24:12 --> Security Class Initialized
DEBUG - 2021-04-16 20:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 20:24:12 --> Input Class Initialized
INFO - 2021-04-16 20:24:12 --> Language Class Initialized
INFO - 2021-04-16 20:24:12 --> Loader Class Initialized
INFO - 2021-04-16 20:24:12 --> Helper loaded: url_helper
INFO - 2021-04-16 20:24:12 --> Helper loaded: form_helper
INFO - 2021-04-16 20:24:12 --> Helper loaded: common_helper
INFO - 2021-04-16 20:24:12 --> Helper loaded: util_helper
INFO - 2021-04-16 20:24:12 --> Helper loaded: user_helper
INFO - 2021-04-16 20:24:12 --> Database Driver Class Initialized
DEBUG - 2021-04-16 20:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 20:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 20:24:12 --> Form Validation Class Initialized
INFO - 2021-04-16 20:24:12 --> Model Class Initialized
INFO - 2021-04-16 20:24:12 --> Controller Class Initialized
INFO - 2021-04-16 20:24:12 --> Model Class Initialized
INFO - 2021-04-16 20:24:12 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 20:24:12 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 20:24:12 --> Final output sent to browser
DEBUG - 2021-04-16 20:24:12 --> Total execution time: 0.0299
INFO - 2021-04-16 20:25:48 --> Config Class Initialized
INFO - 2021-04-16 20:25:48 --> Hooks Class Initialized
DEBUG - 2021-04-16 20:25:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 20:25:48 --> Utf8 Class Initialized
INFO - 2021-04-16 20:25:48 --> URI Class Initialized
INFO - 2021-04-16 20:25:48 --> Router Class Initialized
INFO - 2021-04-16 20:25:48 --> Output Class Initialized
INFO - 2021-04-16 20:25:48 --> Security Class Initialized
DEBUG - 2021-04-16 20:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 20:25:48 --> Input Class Initialized
INFO - 2021-04-16 20:25:48 --> Language Class Initialized
INFO - 2021-04-16 20:25:48 --> Loader Class Initialized
INFO - 2021-04-16 20:25:48 --> Helper loaded: url_helper
INFO - 2021-04-16 20:25:48 --> Helper loaded: form_helper
INFO - 2021-04-16 20:25:48 --> Helper loaded: common_helper
INFO - 2021-04-16 20:25:48 --> Helper loaded: util_helper
INFO - 2021-04-16 20:25:48 --> Helper loaded: user_helper
INFO - 2021-04-16 20:25:48 --> Database Driver Class Initialized
DEBUG - 2021-04-16 20:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 20:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 20:25:48 --> Form Validation Class Initialized
INFO - 2021-04-16 20:25:48 --> Model Class Initialized
INFO - 2021-04-16 20:25:48 --> Controller Class Initialized
INFO - 2021-04-16 20:25:48 --> Model Class Initialized
INFO - 2021-04-16 20:25:48 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 20:25:48 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 20:25:48 --> Final output sent to browser
DEBUG - 2021-04-16 20:25:48 --> Total execution time: 0.0386
INFO - 2021-04-16 20:29:00 --> Config Class Initialized
INFO - 2021-04-16 20:29:00 --> Hooks Class Initialized
DEBUG - 2021-04-16 20:29:00 --> UTF-8 Support Enabled
INFO - 2021-04-16 20:29:00 --> Utf8 Class Initialized
INFO - 2021-04-16 20:29:00 --> URI Class Initialized
INFO - 2021-04-16 20:29:00 --> Router Class Initialized
INFO - 2021-04-16 20:29:00 --> Output Class Initialized
INFO - 2021-04-16 20:29:00 --> Security Class Initialized
DEBUG - 2021-04-16 20:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 20:29:00 --> Input Class Initialized
INFO - 2021-04-16 20:29:00 --> Language Class Initialized
INFO - 2021-04-16 20:29:00 --> Loader Class Initialized
INFO - 2021-04-16 20:29:00 --> Helper loaded: url_helper
INFO - 2021-04-16 20:29:00 --> Helper loaded: form_helper
INFO - 2021-04-16 20:29:00 --> Helper loaded: common_helper
INFO - 2021-04-16 20:29:00 --> Helper loaded: util_helper
INFO - 2021-04-16 20:29:00 --> Helper loaded: user_helper
INFO - 2021-04-16 20:29:00 --> Database Driver Class Initialized
DEBUG - 2021-04-16 20:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 20:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 20:29:00 --> Form Validation Class Initialized
INFO - 2021-04-16 20:29:00 --> Model Class Initialized
INFO - 2021-04-16 20:29:00 --> Controller Class Initialized
INFO - 2021-04-16 20:29:00 --> Model Class Initialized
INFO - 2021-04-16 20:29:01 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 20:29:01 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 20:29:01 --> Final output sent to browser
DEBUG - 2021-04-16 20:29:01 --> Total execution time: 0.0469
INFO - 2021-04-16 20:29:24 --> Config Class Initialized
INFO - 2021-04-16 20:29:24 --> Hooks Class Initialized
DEBUG - 2021-04-16 20:29:24 --> UTF-8 Support Enabled
INFO - 2021-04-16 20:29:24 --> Utf8 Class Initialized
INFO - 2021-04-16 20:29:24 --> URI Class Initialized
INFO - 2021-04-16 20:29:24 --> Router Class Initialized
INFO - 2021-04-16 20:29:24 --> Output Class Initialized
INFO - 2021-04-16 20:29:24 --> Security Class Initialized
DEBUG - 2021-04-16 20:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 20:29:24 --> Input Class Initialized
INFO - 2021-04-16 20:29:24 --> Language Class Initialized
INFO - 2021-04-16 20:29:24 --> Loader Class Initialized
INFO - 2021-04-16 20:29:24 --> Helper loaded: url_helper
INFO - 2021-04-16 20:29:24 --> Helper loaded: form_helper
INFO - 2021-04-16 20:29:24 --> Helper loaded: common_helper
INFO - 2021-04-16 20:29:24 --> Helper loaded: util_helper
INFO - 2021-04-16 20:29:24 --> Helper loaded: user_helper
INFO - 2021-04-16 20:29:24 --> Database Driver Class Initialized
DEBUG - 2021-04-16 20:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 20:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 20:29:24 --> Form Validation Class Initialized
INFO - 2021-04-16 20:29:24 --> Model Class Initialized
INFO - 2021-04-16 20:29:24 --> Controller Class Initialized
INFO - 2021-04-16 20:29:24 --> Model Class Initialized
INFO - 2021-04-16 20:29:24 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 20:29:24 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 20:29:24 --> Final output sent to browser
DEBUG - 2021-04-16 20:29:24 --> Total execution time: 0.0328
INFO - 2021-04-16 20:29:30 --> Config Class Initialized
INFO - 2021-04-16 20:29:30 --> Hooks Class Initialized
DEBUG - 2021-04-16 20:29:30 --> UTF-8 Support Enabled
INFO - 2021-04-16 20:29:30 --> Utf8 Class Initialized
INFO - 2021-04-16 20:29:30 --> URI Class Initialized
INFO - 2021-04-16 20:29:30 --> Router Class Initialized
INFO - 2021-04-16 20:29:30 --> Output Class Initialized
INFO - 2021-04-16 20:29:30 --> Security Class Initialized
DEBUG - 2021-04-16 20:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 20:29:30 --> Input Class Initialized
INFO - 2021-04-16 20:29:30 --> Language Class Initialized
ERROR - 2021-04-16 20:29:30 --> 404 Page Not Found: Dashboard/update
INFO - 2021-04-16 20:29:37 --> Config Class Initialized
INFO - 2021-04-16 20:29:37 --> Hooks Class Initialized
DEBUG - 2021-04-16 20:29:37 --> UTF-8 Support Enabled
INFO - 2021-04-16 20:29:37 --> Utf8 Class Initialized
INFO - 2021-04-16 20:29:37 --> URI Class Initialized
INFO - 2021-04-16 20:29:37 --> Router Class Initialized
INFO - 2021-04-16 20:29:37 --> Output Class Initialized
INFO - 2021-04-16 20:29:37 --> Security Class Initialized
DEBUG - 2021-04-16 20:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 20:29:37 --> Input Class Initialized
INFO - 2021-04-16 20:29:37 --> Language Class Initialized
INFO - 2021-04-16 20:29:37 --> Loader Class Initialized
INFO - 2021-04-16 20:29:37 --> Helper loaded: url_helper
INFO - 2021-04-16 20:29:37 --> Helper loaded: form_helper
INFO - 2021-04-16 20:29:37 --> Helper loaded: common_helper
INFO - 2021-04-16 20:29:37 --> Helper loaded: util_helper
INFO - 2021-04-16 20:29:37 --> Helper loaded: user_helper
INFO - 2021-04-16 20:29:37 --> Database Driver Class Initialized
DEBUG - 2021-04-16 20:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 20:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 20:29:37 --> Form Validation Class Initialized
INFO - 2021-04-16 20:29:37 --> Model Class Initialized
INFO - 2021-04-16 20:29:37 --> Controller Class Initialized
INFO - 2021-04-16 20:29:37 --> Model Class Initialized
INFO - 2021-04-16 20:29:37 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 20:29:37 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 20:29:37 --> Final output sent to browser
DEBUG - 2021-04-16 20:29:37 --> Total execution time: 0.0310
INFO - 2021-04-16 21:01:36 --> Config Class Initialized
INFO - 2021-04-16 21:01:36 --> Hooks Class Initialized
DEBUG - 2021-04-16 21:01:36 --> UTF-8 Support Enabled
INFO - 2021-04-16 21:01:36 --> Utf8 Class Initialized
INFO - 2021-04-16 21:01:36 --> URI Class Initialized
INFO - 2021-04-16 21:01:36 --> Router Class Initialized
INFO - 2021-04-16 21:01:36 --> Output Class Initialized
INFO - 2021-04-16 21:01:36 --> Security Class Initialized
DEBUG - 2021-04-16 21:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 21:01:36 --> Input Class Initialized
INFO - 2021-04-16 21:01:36 --> Language Class Initialized
INFO - 2021-04-16 21:01:36 --> Loader Class Initialized
INFO - 2021-04-16 21:01:36 --> Helper loaded: url_helper
INFO - 2021-04-16 21:01:36 --> Helper loaded: form_helper
INFO - 2021-04-16 21:01:36 --> Helper loaded: common_helper
INFO - 2021-04-16 21:01:36 --> Helper loaded: util_helper
INFO - 2021-04-16 21:01:36 --> Helper loaded: user_helper
INFO - 2021-04-16 21:01:36 --> Database Driver Class Initialized
DEBUG - 2021-04-16 21:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 21:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 21:01:36 --> Form Validation Class Initialized
INFO - 2021-04-16 21:01:36 --> Model Class Initialized
INFO - 2021-04-16 21:01:36 --> Controller Class Initialized
INFO - 2021-04-16 21:01:36 --> Model Class Initialized
INFO - 2021-04-16 21:01:36 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 21:01:36 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 21:01:36 --> Final output sent to browser
DEBUG - 2021-04-16 21:01:36 --> Total execution time: 0.0355
INFO - 2021-04-16 21:01:44 --> Config Class Initialized
INFO - 2021-04-16 21:01:44 --> Hooks Class Initialized
DEBUG - 2021-04-16 21:01:44 --> UTF-8 Support Enabled
INFO - 2021-04-16 21:01:44 --> Utf8 Class Initialized
INFO - 2021-04-16 21:01:44 --> URI Class Initialized
INFO - 2021-04-16 21:01:44 --> Router Class Initialized
INFO - 2021-04-16 21:01:44 --> Output Class Initialized
INFO - 2021-04-16 21:01:44 --> Security Class Initialized
DEBUG - 2021-04-16 21:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 21:01:44 --> Input Class Initialized
INFO - 2021-04-16 21:01:44 --> Language Class Initialized
ERROR - 2021-04-16 21:01:44 --> 404 Page Not Found: Dashboard/update
INFO - 2021-04-16 21:01:46 --> Config Class Initialized
INFO - 2021-04-16 21:01:46 --> Hooks Class Initialized
DEBUG - 2021-04-16 21:01:46 --> UTF-8 Support Enabled
INFO - 2021-04-16 21:01:46 --> Utf8 Class Initialized
INFO - 2021-04-16 21:01:46 --> URI Class Initialized
INFO - 2021-04-16 21:01:46 --> Router Class Initialized
INFO - 2021-04-16 21:01:46 --> Output Class Initialized
INFO - 2021-04-16 21:01:46 --> Security Class Initialized
DEBUG - 2021-04-16 21:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 21:01:46 --> Input Class Initialized
INFO - 2021-04-16 21:01:46 --> Language Class Initialized
INFO - 2021-04-16 21:01:46 --> Loader Class Initialized
INFO - 2021-04-16 21:01:46 --> Helper loaded: url_helper
INFO - 2021-04-16 21:01:46 --> Helper loaded: form_helper
INFO - 2021-04-16 21:01:46 --> Helper loaded: common_helper
INFO - 2021-04-16 21:01:46 --> Helper loaded: util_helper
INFO - 2021-04-16 21:01:46 --> Helper loaded: user_helper
INFO - 2021-04-16 21:01:46 --> Database Driver Class Initialized
DEBUG - 2021-04-16 21:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 21:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 21:01:46 --> Form Validation Class Initialized
INFO - 2021-04-16 21:01:46 --> Model Class Initialized
INFO - 2021-04-16 21:01:46 --> Controller Class Initialized
INFO - 2021-04-16 21:01:46 --> Model Class Initialized
INFO - 2021-04-16 21:01:46 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 21:01:46 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 21:01:46 --> Final output sent to browser
DEBUG - 2021-04-16 21:01:46 --> Total execution time: 0.0288
INFO - 2021-04-16 21:01:48 --> Config Class Initialized
INFO - 2021-04-16 21:01:48 --> Hooks Class Initialized
DEBUG - 2021-04-16 21:01:48 --> UTF-8 Support Enabled
INFO - 2021-04-16 21:01:48 --> Utf8 Class Initialized
INFO - 2021-04-16 21:01:48 --> URI Class Initialized
INFO - 2021-04-16 21:01:48 --> Router Class Initialized
INFO - 2021-04-16 21:01:48 --> Output Class Initialized
INFO - 2021-04-16 21:01:48 --> Security Class Initialized
DEBUG - 2021-04-16 21:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 21:01:48 --> Input Class Initialized
INFO - 2021-04-16 21:01:48 --> Language Class Initialized
INFO - 2021-04-16 21:01:48 --> Loader Class Initialized
INFO - 2021-04-16 21:01:48 --> Helper loaded: url_helper
INFO - 2021-04-16 21:01:48 --> Helper loaded: form_helper
INFO - 2021-04-16 21:01:48 --> Helper loaded: common_helper
INFO - 2021-04-16 21:01:48 --> Helper loaded: util_helper
INFO - 2021-04-16 21:01:48 --> Helper loaded: user_helper
INFO - 2021-04-16 21:01:48 --> Database Driver Class Initialized
DEBUG - 2021-04-16 21:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 21:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 21:01:49 --> Form Validation Class Initialized
INFO - 2021-04-16 21:01:49 --> Model Class Initialized
INFO - 2021-04-16 21:01:49 --> Controller Class Initialized
INFO - 2021-04-16 21:01:49 --> Model Class Initialized
INFO - 2021-04-16 21:01:49 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 21:01:49 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 21:01:49 --> Final output sent to browser
DEBUG - 2021-04-16 21:01:49 --> Total execution time: 0.0423
INFO - 2021-04-16 21:02:56 --> Config Class Initialized
INFO - 2021-04-16 21:02:56 --> Hooks Class Initialized
DEBUG - 2021-04-16 21:02:56 --> UTF-8 Support Enabled
INFO - 2021-04-16 21:02:56 --> Utf8 Class Initialized
INFO - 2021-04-16 21:02:56 --> URI Class Initialized
INFO - 2021-04-16 21:02:56 --> Router Class Initialized
INFO - 2021-04-16 21:02:56 --> Output Class Initialized
INFO - 2021-04-16 21:02:56 --> Security Class Initialized
DEBUG - 2021-04-16 21:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 21:02:56 --> Input Class Initialized
INFO - 2021-04-16 21:02:56 --> Language Class Initialized
INFO - 2021-04-16 21:02:56 --> Loader Class Initialized
INFO - 2021-04-16 21:02:56 --> Helper loaded: url_helper
INFO - 2021-04-16 21:02:56 --> Helper loaded: form_helper
INFO - 2021-04-16 21:02:56 --> Helper loaded: common_helper
INFO - 2021-04-16 21:02:56 --> Helper loaded: util_helper
INFO - 2021-04-16 21:02:56 --> Helper loaded: user_helper
INFO - 2021-04-16 21:02:56 --> Database Driver Class Initialized
DEBUG - 2021-04-16 21:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 21:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 21:02:56 --> Form Validation Class Initialized
INFO - 2021-04-16 21:02:56 --> Model Class Initialized
INFO - 2021-04-16 21:02:56 --> Controller Class Initialized
INFO - 2021-04-16 21:02:56 --> Model Class Initialized
INFO - 2021-04-16 21:02:56 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 21:02:56 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 21:02:56 --> Final output sent to browser
DEBUG - 2021-04-16 21:02:56 --> Total execution time: 0.0301
INFO - 2021-04-16 21:03:01 --> Config Class Initialized
INFO - 2021-04-16 21:03:01 --> Hooks Class Initialized
DEBUG - 2021-04-16 21:03:01 --> UTF-8 Support Enabled
INFO - 2021-04-16 21:03:01 --> Utf8 Class Initialized
INFO - 2021-04-16 21:03:01 --> URI Class Initialized
INFO - 2021-04-16 21:03:01 --> Router Class Initialized
INFO - 2021-04-16 21:03:01 --> Output Class Initialized
INFO - 2021-04-16 21:03:01 --> Security Class Initialized
DEBUG - 2021-04-16 21:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 21:03:01 --> Input Class Initialized
INFO - 2021-04-16 21:03:01 --> Language Class Initialized
INFO - 2021-04-16 21:03:01 --> Loader Class Initialized
INFO - 2021-04-16 21:03:01 --> Helper loaded: url_helper
INFO - 2021-04-16 21:03:01 --> Helper loaded: form_helper
INFO - 2021-04-16 21:03:01 --> Helper loaded: common_helper
INFO - 2021-04-16 21:03:01 --> Helper loaded: util_helper
INFO - 2021-04-16 21:03:01 --> Helper loaded: user_helper
INFO - 2021-04-16 21:03:01 --> Database Driver Class Initialized
DEBUG - 2021-04-16 21:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 21:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 21:03:01 --> Form Validation Class Initialized
INFO - 2021-04-16 21:03:01 --> Model Class Initialized
INFO - 2021-04-16 21:03:01 --> Controller Class Initialized
INFO - 2021-04-16 21:03:01 --> Model Class Initialized
INFO - 2021-04-16 21:03:01 --> Config Class Initialized
INFO - 2021-04-16 21:03:01 --> Hooks Class Initialized
DEBUG - 2021-04-16 21:03:01 --> UTF-8 Support Enabled
INFO - 2021-04-16 21:03:01 --> Utf8 Class Initialized
INFO - 2021-04-16 21:03:01 --> URI Class Initialized
INFO - 2021-04-16 21:03:01 --> Router Class Initialized
INFO - 2021-04-16 21:03:01 --> Output Class Initialized
INFO - 2021-04-16 21:03:01 --> Security Class Initialized
DEBUG - 2021-04-16 21:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 21:03:01 --> Input Class Initialized
INFO - 2021-04-16 21:03:01 --> Language Class Initialized
INFO - 2021-04-16 21:03:01 --> Loader Class Initialized
INFO - 2021-04-16 21:03:01 --> Helper loaded: url_helper
INFO - 2021-04-16 21:03:01 --> Helper loaded: form_helper
INFO - 2021-04-16 21:03:01 --> Helper loaded: common_helper
INFO - 2021-04-16 21:03:01 --> Helper loaded: util_helper
INFO - 2021-04-16 21:03:01 --> Helper loaded: user_helper
INFO - 2021-04-16 21:03:01 --> Database Driver Class Initialized
DEBUG - 2021-04-16 21:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 21:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 21:03:01 --> Form Validation Class Initialized
INFO - 2021-04-16 21:03:01 --> Model Class Initialized
INFO - 2021-04-16 21:03:01 --> Controller Class Initialized
INFO - 2021-04-16 21:03:01 --> Model Class Initialized
INFO - 2021-04-16 21:03:01 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 21:03:01 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 21:03:01 --> Final output sent to browser
DEBUG - 2021-04-16 21:03:01 --> Total execution time: 0.0404
INFO - 2021-04-16 21:06:13 --> Config Class Initialized
INFO - 2021-04-16 21:06:13 --> Hooks Class Initialized
DEBUG - 2021-04-16 21:06:13 --> UTF-8 Support Enabled
INFO - 2021-04-16 21:06:13 --> Utf8 Class Initialized
INFO - 2021-04-16 21:06:13 --> URI Class Initialized
INFO - 2021-04-16 21:06:13 --> Router Class Initialized
INFO - 2021-04-16 21:06:13 --> Output Class Initialized
INFO - 2021-04-16 21:06:13 --> Security Class Initialized
DEBUG - 2021-04-16 21:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 21:06:13 --> Input Class Initialized
INFO - 2021-04-16 21:06:13 --> Language Class Initialized
INFO - 2021-04-16 21:06:13 --> Loader Class Initialized
INFO - 2021-04-16 21:06:13 --> Helper loaded: url_helper
INFO - 2021-04-16 21:06:13 --> Helper loaded: form_helper
INFO - 2021-04-16 21:06:13 --> Helper loaded: common_helper
INFO - 2021-04-16 21:06:13 --> Helper loaded: util_helper
INFO - 2021-04-16 21:06:13 --> Helper loaded: user_helper
INFO - 2021-04-16 21:06:13 --> Database Driver Class Initialized
DEBUG - 2021-04-16 21:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 21:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 21:06:13 --> Form Validation Class Initialized
INFO - 2021-04-16 21:06:13 --> Model Class Initialized
INFO - 2021-04-16 21:06:13 --> Controller Class Initialized
INFO - 2021-04-16 21:06:13 --> Model Class Initialized
INFO - 2021-04-16 21:06:13 --> Config Class Initialized
INFO - 2021-04-16 21:06:13 --> Hooks Class Initialized
DEBUG - 2021-04-16 21:06:13 --> UTF-8 Support Enabled
INFO - 2021-04-16 21:06:13 --> Utf8 Class Initialized
INFO - 2021-04-16 21:06:13 --> URI Class Initialized
INFO - 2021-04-16 21:06:13 --> Router Class Initialized
INFO - 2021-04-16 21:06:13 --> Output Class Initialized
INFO - 2021-04-16 21:06:13 --> Security Class Initialized
DEBUG - 2021-04-16 21:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 21:06:13 --> Input Class Initialized
INFO - 2021-04-16 21:06:13 --> Language Class Initialized
INFO - 2021-04-16 21:06:13 --> Loader Class Initialized
INFO - 2021-04-16 21:06:13 --> Helper loaded: url_helper
INFO - 2021-04-16 21:06:13 --> Helper loaded: form_helper
INFO - 2021-04-16 21:06:13 --> Helper loaded: common_helper
INFO - 2021-04-16 21:06:13 --> Helper loaded: util_helper
INFO - 2021-04-16 21:06:13 --> Helper loaded: user_helper
INFO - 2021-04-16 21:06:13 --> Database Driver Class Initialized
DEBUG - 2021-04-16 21:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 21:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 21:06:13 --> Form Validation Class Initialized
INFO - 2021-04-16 21:06:13 --> Model Class Initialized
INFO - 2021-04-16 21:06:13 --> Controller Class Initialized
INFO - 2021-04-16 21:06:13 --> Model Class Initialized
INFO - 2021-04-16 21:06:13 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 21:06:13 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 21:06:13 --> Final output sent to browser
DEBUG - 2021-04-16 21:06:13 --> Total execution time: 0.0530
INFO - 2021-04-16 21:15:43 --> Config Class Initialized
INFO - 2021-04-16 21:15:43 --> Hooks Class Initialized
DEBUG - 2021-04-16 21:15:43 --> UTF-8 Support Enabled
INFO - 2021-04-16 21:15:43 --> Utf8 Class Initialized
INFO - 2021-04-16 21:15:43 --> URI Class Initialized
INFO - 2021-04-16 21:15:43 --> Router Class Initialized
INFO - 2021-04-16 21:15:43 --> Output Class Initialized
INFO - 2021-04-16 21:15:43 --> Security Class Initialized
DEBUG - 2021-04-16 21:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 21:15:43 --> Input Class Initialized
INFO - 2021-04-16 21:15:43 --> Language Class Initialized
INFO - 2021-04-16 21:15:43 --> Loader Class Initialized
INFO - 2021-04-16 21:15:43 --> Helper loaded: url_helper
INFO - 2021-04-16 21:15:43 --> Helper loaded: form_helper
INFO - 2021-04-16 21:15:43 --> Helper loaded: common_helper
INFO - 2021-04-16 21:15:43 --> Helper loaded: util_helper
INFO - 2021-04-16 21:15:43 --> Helper loaded: user_helper
INFO - 2021-04-16 21:15:43 --> Database Driver Class Initialized
DEBUG - 2021-04-16 21:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 21:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 21:15:43 --> Form Validation Class Initialized
INFO - 2021-04-16 21:15:43 --> Model Class Initialized
INFO - 2021-04-16 21:15:43 --> Controller Class Initialized
INFO - 2021-04-16 21:15:43 --> Model Class Initialized
INFO - 2021-04-16 21:15:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 21:15:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 21:15:43 --> Final output sent to browser
DEBUG - 2021-04-16 21:15:43 --> Total execution time: 0.0313
INFO - 2021-04-16 21:15:50 --> Config Class Initialized
INFO - 2021-04-16 21:15:50 --> Hooks Class Initialized
DEBUG - 2021-04-16 21:15:50 --> UTF-8 Support Enabled
INFO - 2021-04-16 21:15:50 --> Utf8 Class Initialized
INFO - 2021-04-16 21:15:50 --> URI Class Initialized
INFO - 2021-04-16 21:15:50 --> Router Class Initialized
INFO - 2021-04-16 21:15:50 --> Output Class Initialized
INFO - 2021-04-16 21:15:50 --> Security Class Initialized
DEBUG - 2021-04-16 21:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 21:15:50 --> Input Class Initialized
INFO - 2021-04-16 21:15:50 --> Language Class Initialized
INFO - 2021-04-16 21:15:50 --> Loader Class Initialized
INFO - 2021-04-16 21:15:50 --> Helper loaded: url_helper
INFO - 2021-04-16 21:15:50 --> Helper loaded: form_helper
INFO - 2021-04-16 21:15:50 --> Helper loaded: common_helper
INFO - 2021-04-16 21:15:50 --> Helper loaded: util_helper
INFO - 2021-04-16 21:15:50 --> Helper loaded: user_helper
INFO - 2021-04-16 21:15:50 --> Database Driver Class Initialized
DEBUG - 2021-04-16 21:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 21:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 21:15:50 --> Form Validation Class Initialized
INFO - 2021-04-16 21:15:50 --> Model Class Initialized
INFO - 2021-04-16 21:15:50 --> Controller Class Initialized
INFO - 2021-04-16 21:15:50 --> Model Class Initialized
INFO - 2021-04-16 21:15:51 --> Config Class Initialized
INFO - 2021-04-16 21:15:51 --> Hooks Class Initialized
DEBUG - 2021-04-16 21:15:51 --> UTF-8 Support Enabled
INFO - 2021-04-16 21:15:51 --> Utf8 Class Initialized
INFO - 2021-04-16 21:15:51 --> URI Class Initialized
INFO - 2021-04-16 21:15:51 --> Router Class Initialized
INFO - 2021-04-16 21:15:51 --> Output Class Initialized
INFO - 2021-04-16 21:15:51 --> Security Class Initialized
DEBUG - 2021-04-16 21:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 21:15:51 --> Input Class Initialized
INFO - 2021-04-16 21:15:51 --> Language Class Initialized
INFO - 2021-04-16 21:15:51 --> Loader Class Initialized
INFO - 2021-04-16 21:15:51 --> Helper loaded: url_helper
INFO - 2021-04-16 21:15:51 --> Helper loaded: form_helper
INFO - 2021-04-16 21:15:51 --> Helper loaded: common_helper
INFO - 2021-04-16 21:15:51 --> Helper loaded: util_helper
INFO - 2021-04-16 21:15:51 --> Helper loaded: user_helper
INFO - 2021-04-16 21:15:51 --> Database Driver Class Initialized
DEBUG - 2021-04-16 21:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 21:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 21:15:51 --> Form Validation Class Initialized
INFO - 2021-04-16 21:15:51 --> Model Class Initialized
INFO - 2021-04-16 21:15:51 --> Controller Class Initialized
INFO - 2021-04-16 21:15:51 --> Model Class Initialized
INFO - 2021-04-16 21:15:51 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 21:15:51 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 21:15:51 --> Final output sent to browser
DEBUG - 2021-04-16 21:15:51 --> Total execution time: 0.0468
INFO - 2021-04-16 21:16:06 --> Config Class Initialized
INFO - 2021-04-16 21:16:06 --> Hooks Class Initialized
DEBUG - 2021-04-16 21:16:06 --> UTF-8 Support Enabled
INFO - 2021-04-16 21:16:06 --> Utf8 Class Initialized
INFO - 2021-04-16 21:16:06 --> URI Class Initialized
INFO - 2021-04-16 21:16:06 --> Router Class Initialized
INFO - 2021-04-16 21:16:06 --> Output Class Initialized
INFO - 2021-04-16 21:16:06 --> Security Class Initialized
DEBUG - 2021-04-16 21:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 21:16:06 --> Input Class Initialized
INFO - 2021-04-16 21:16:06 --> Language Class Initialized
INFO - 2021-04-16 21:16:06 --> Loader Class Initialized
INFO - 2021-04-16 21:16:06 --> Helper loaded: url_helper
INFO - 2021-04-16 21:16:06 --> Helper loaded: form_helper
INFO - 2021-04-16 21:16:06 --> Helper loaded: common_helper
INFO - 2021-04-16 21:16:06 --> Helper loaded: util_helper
INFO - 2021-04-16 21:16:06 --> Helper loaded: user_helper
INFO - 2021-04-16 21:16:06 --> Database Driver Class Initialized
DEBUG - 2021-04-16 21:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 21:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 21:16:06 --> Form Validation Class Initialized
INFO - 2021-04-16 21:16:06 --> Model Class Initialized
INFO - 2021-04-16 21:16:06 --> Controller Class Initialized
INFO - 2021-04-16 21:16:06 --> Model Class Initialized
INFO - 2021-04-16 21:16:06 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 21:16:06 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 21:16:06 --> Final output sent to browser
DEBUG - 2021-04-16 21:16:06 --> Total execution time: 0.0434
INFO - 2021-04-16 21:16:14 --> Config Class Initialized
INFO - 2021-04-16 21:16:14 --> Hooks Class Initialized
DEBUG - 2021-04-16 21:16:14 --> UTF-8 Support Enabled
INFO - 2021-04-16 21:16:14 --> Utf8 Class Initialized
INFO - 2021-04-16 21:16:14 --> URI Class Initialized
INFO - 2021-04-16 21:16:14 --> Router Class Initialized
INFO - 2021-04-16 21:16:14 --> Output Class Initialized
INFO - 2021-04-16 21:16:14 --> Security Class Initialized
DEBUG - 2021-04-16 21:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 21:16:14 --> Input Class Initialized
INFO - 2021-04-16 21:16:14 --> Language Class Initialized
INFO - 2021-04-16 21:16:14 --> Loader Class Initialized
INFO - 2021-04-16 21:16:14 --> Helper loaded: url_helper
INFO - 2021-04-16 21:16:14 --> Helper loaded: form_helper
INFO - 2021-04-16 21:16:14 --> Helper loaded: common_helper
INFO - 2021-04-16 21:16:14 --> Helper loaded: util_helper
INFO - 2021-04-16 21:16:14 --> Helper loaded: user_helper
INFO - 2021-04-16 21:16:14 --> Database Driver Class Initialized
DEBUG - 2021-04-16 21:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 21:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 21:16:14 --> Form Validation Class Initialized
INFO - 2021-04-16 21:16:14 --> Model Class Initialized
INFO - 2021-04-16 21:16:14 --> Controller Class Initialized
INFO - 2021-04-16 21:16:14 --> Model Class Initialized
INFO - 2021-04-16 21:16:14 --> Config Class Initialized
INFO - 2021-04-16 21:16:14 --> Hooks Class Initialized
DEBUG - 2021-04-16 21:16:14 --> UTF-8 Support Enabled
INFO - 2021-04-16 21:16:14 --> Utf8 Class Initialized
INFO - 2021-04-16 21:16:14 --> URI Class Initialized
INFO - 2021-04-16 21:16:14 --> Router Class Initialized
INFO - 2021-04-16 21:16:14 --> Output Class Initialized
INFO - 2021-04-16 21:16:14 --> Security Class Initialized
DEBUG - 2021-04-16 21:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 21:16:14 --> Input Class Initialized
INFO - 2021-04-16 21:16:14 --> Language Class Initialized
INFO - 2021-04-16 21:16:14 --> Loader Class Initialized
INFO - 2021-04-16 21:16:14 --> Helper loaded: url_helper
INFO - 2021-04-16 21:16:14 --> Helper loaded: form_helper
INFO - 2021-04-16 21:16:14 --> Helper loaded: common_helper
INFO - 2021-04-16 21:16:14 --> Helper loaded: util_helper
INFO - 2021-04-16 21:16:14 --> Helper loaded: user_helper
INFO - 2021-04-16 21:16:14 --> Database Driver Class Initialized
DEBUG - 2021-04-16 21:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 21:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 21:16:14 --> Form Validation Class Initialized
INFO - 2021-04-16 21:16:14 --> Model Class Initialized
INFO - 2021-04-16 21:16:14 --> Controller Class Initialized
INFO - 2021-04-16 21:16:14 --> Model Class Initialized
INFO - 2021-04-16 21:16:14 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 21:16:14 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 21:16:14 --> Final output sent to browser
DEBUG - 2021-04-16 21:16:14 --> Total execution time: 0.0441
INFO - 2021-04-16 21:59:33 --> Config Class Initialized
INFO - 2021-04-16 21:59:33 --> Hooks Class Initialized
DEBUG - 2021-04-16 21:59:33 --> UTF-8 Support Enabled
INFO - 2021-04-16 21:59:33 --> Utf8 Class Initialized
INFO - 2021-04-16 21:59:33 --> URI Class Initialized
INFO - 2021-04-16 21:59:33 --> Router Class Initialized
INFO - 2021-04-16 21:59:33 --> Output Class Initialized
INFO - 2021-04-16 21:59:33 --> Security Class Initialized
DEBUG - 2021-04-16 21:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 21:59:33 --> Input Class Initialized
INFO - 2021-04-16 21:59:33 --> Language Class Initialized
INFO - 2021-04-16 21:59:33 --> Loader Class Initialized
INFO - 2021-04-16 21:59:33 --> Helper loaded: url_helper
INFO - 2021-04-16 21:59:33 --> Helper loaded: form_helper
INFO - 2021-04-16 21:59:33 --> Helper loaded: common_helper
INFO - 2021-04-16 21:59:33 --> Helper loaded: util_helper
INFO - 2021-04-16 21:59:33 --> Helper loaded: user_helper
INFO - 2021-04-16 21:59:33 --> Database Driver Class Initialized
DEBUG - 2021-04-16 21:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 21:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 21:59:33 --> Form Validation Class Initialized
INFO - 2021-04-16 21:59:34 --> Model Class Initialized
INFO - 2021-04-16 21:59:34 --> Controller Class Initialized
INFO - 2021-04-16 21:59:34 --> Model Class Initialized
INFO - 2021-04-16 21:59:34 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 21:59:34 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 21:59:34 --> Final output sent to browser
DEBUG - 2021-04-16 21:59:34 --> Total execution time: 0.5625
INFO - 2021-04-16 21:59:36 --> Config Class Initialized
INFO - 2021-04-16 21:59:36 --> Hooks Class Initialized
DEBUG - 2021-04-16 21:59:36 --> UTF-8 Support Enabled
INFO - 2021-04-16 21:59:36 --> Utf8 Class Initialized
INFO - 2021-04-16 21:59:36 --> URI Class Initialized
INFO - 2021-04-16 21:59:36 --> Router Class Initialized
INFO - 2021-04-16 21:59:36 --> Output Class Initialized
INFO - 2021-04-16 21:59:36 --> Security Class Initialized
DEBUG - 2021-04-16 21:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 21:59:36 --> Input Class Initialized
INFO - 2021-04-16 21:59:36 --> Language Class Initialized
INFO - 2021-04-16 21:59:36 --> Loader Class Initialized
INFO - 2021-04-16 21:59:36 --> Helper loaded: url_helper
INFO - 2021-04-16 21:59:36 --> Helper loaded: form_helper
INFO - 2021-04-16 21:59:36 --> Helper loaded: common_helper
INFO - 2021-04-16 21:59:36 --> Helper loaded: util_helper
INFO - 2021-04-16 21:59:36 --> Helper loaded: user_helper
INFO - 2021-04-16 21:59:36 --> Database Driver Class Initialized
DEBUG - 2021-04-16 21:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 21:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 21:59:36 --> Form Validation Class Initialized
INFO - 2021-04-16 21:59:36 --> Model Class Initialized
INFO - 2021-04-16 21:59:36 --> Controller Class Initialized
INFO - 2021-04-16 21:59:36 --> Model Class Initialized
INFO - 2021-04-16 21:59:36 --> Config Class Initialized
INFO - 2021-04-16 21:59:36 --> Hooks Class Initialized
DEBUG - 2021-04-16 21:59:36 --> UTF-8 Support Enabled
INFO - 2021-04-16 21:59:36 --> Utf8 Class Initialized
INFO - 2021-04-16 21:59:36 --> URI Class Initialized
INFO - 2021-04-16 21:59:36 --> Router Class Initialized
INFO - 2021-04-16 21:59:36 --> Output Class Initialized
INFO - 2021-04-16 21:59:36 --> Security Class Initialized
DEBUG - 2021-04-16 21:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 21:59:36 --> Input Class Initialized
INFO - 2021-04-16 21:59:36 --> Language Class Initialized
INFO - 2021-04-16 21:59:36 --> Loader Class Initialized
INFO - 2021-04-16 21:59:36 --> Helper loaded: url_helper
INFO - 2021-04-16 21:59:36 --> Helper loaded: form_helper
INFO - 2021-04-16 21:59:36 --> Helper loaded: common_helper
INFO - 2021-04-16 21:59:36 --> Helper loaded: util_helper
INFO - 2021-04-16 21:59:36 --> Helper loaded: user_helper
INFO - 2021-04-16 21:59:36 --> Database Driver Class Initialized
DEBUG - 2021-04-16 21:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 21:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 21:59:36 --> Form Validation Class Initialized
INFO - 2021-04-16 21:59:36 --> Model Class Initialized
INFO - 2021-04-16 21:59:36 --> Controller Class Initialized
INFO - 2021-04-16 21:59:36 --> Model Class Initialized
INFO - 2021-04-16 21:59:36 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 21:59:36 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 21:59:36 --> Final output sent to browser
DEBUG - 2021-04-16 21:59:36 --> Total execution time: 0.0267
INFO - 2021-04-16 21:59:39 --> Config Class Initialized
INFO - 2021-04-16 21:59:39 --> Hooks Class Initialized
DEBUG - 2021-04-16 21:59:39 --> UTF-8 Support Enabled
INFO - 2021-04-16 21:59:39 --> Utf8 Class Initialized
INFO - 2021-04-16 21:59:39 --> URI Class Initialized
INFO - 2021-04-16 21:59:39 --> Router Class Initialized
INFO - 2021-04-16 21:59:39 --> Output Class Initialized
INFO - 2021-04-16 21:59:39 --> Security Class Initialized
DEBUG - 2021-04-16 21:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 21:59:39 --> Input Class Initialized
INFO - 2021-04-16 21:59:39 --> Language Class Initialized
INFO - 2021-04-16 21:59:39 --> Loader Class Initialized
INFO - 2021-04-16 21:59:39 --> Helper loaded: url_helper
INFO - 2021-04-16 21:59:39 --> Helper loaded: form_helper
INFO - 2021-04-16 21:59:39 --> Helper loaded: common_helper
INFO - 2021-04-16 21:59:39 --> Helper loaded: util_helper
INFO - 2021-04-16 21:59:39 --> Helper loaded: user_helper
INFO - 2021-04-16 21:59:39 --> Database Driver Class Initialized
DEBUG - 2021-04-16 21:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 21:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 21:59:39 --> Form Validation Class Initialized
INFO - 2021-04-16 21:59:39 --> Model Class Initialized
INFO - 2021-04-16 21:59:39 --> Controller Class Initialized
INFO - 2021-04-16 21:59:39 --> Model Class Initialized
INFO - 2021-04-16 21:59:39 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 21:59:39 --> Final output sent to browser
DEBUG - 2021-04-16 21:59:39 --> Total execution time: 0.0712
INFO - 2021-04-16 21:59:39 --> Config Class Initialized
INFO - 2021-04-16 21:59:39 --> Hooks Class Initialized
DEBUG - 2021-04-16 21:59:39 --> UTF-8 Support Enabled
INFO - 2021-04-16 21:59:39 --> Utf8 Class Initialized
INFO - 2021-04-16 21:59:39 --> URI Class Initialized
INFO - 2021-04-16 21:59:39 --> Config Class Initialized
INFO - 2021-04-16 21:59:39 --> Hooks Class Initialized
INFO - 2021-04-16 21:59:39 --> Router Class Initialized
INFO - 2021-04-16 21:59:39 --> Output Class Initialized
DEBUG - 2021-04-16 21:59:39 --> UTF-8 Support Enabled
INFO - 2021-04-16 21:59:39 --> Utf8 Class Initialized
INFO - 2021-04-16 21:59:39 --> Security Class Initialized
INFO - 2021-04-16 21:59:39 --> URI Class Initialized
DEBUG - 2021-04-16 21:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 21:59:39 --> Input Class Initialized
INFO - 2021-04-16 21:59:39 --> Router Class Initialized
INFO - 2021-04-16 21:59:39 --> Language Class Initialized
INFO - 2021-04-16 21:59:39 --> Output Class Initialized
INFO - 2021-04-16 21:59:39 --> Security Class Initialized
DEBUG - 2021-04-16 21:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 21:59:39 --> Input Class Initialized
INFO - 2021-04-16 21:59:39 --> Language Class Initialized
ERROR - 2021-04-16 21:59:39 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-16 21:59:39 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-16 22:00:11 --> Config Class Initialized
INFO - 2021-04-16 22:00:11 --> Hooks Class Initialized
DEBUG - 2021-04-16 22:00:11 --> UTF-8 Support Enabled
INFO - 2021-04-16 22:00:11 --> Utf8 Class Initialized
INFO - 2021-04-16 22:00:11 --> URI Class Initialized
INFO - 2021-04-16 22:00:11 --> Router Class Initialized
INFO - 2021-04-16 22:00:11 --> Output Class Initialized
INFO - 2021-04-16 22:00:11 --> Security Class Initialized
DEBUG - 2021-04-16 22:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 22:00:11 --> Input Class Initialized
INFO - 2021-04-16 22:00:11 --> Language Class Initialized
INFO - 2021-04-16 22:00:11 --> Loader Class Initialized
INFO - 2021-04-16 22:00:11 --> Helper loaded: url_helper
INFO - 2021-04-16 22:00:11 --> Helper loaded: form_helper
INFO - 2021-04-16 22:00:11 --> Helper loaded: common_helper
INFO - 2021-04-16 22:00:11 --> Helper loaded: util_helper
INFO - 2021-04-16 22:00:11 --> Helper loaded: user_helper
INFO - 2021-04-16 22:00:11 --> Database Driver Class Initialized
DEBUG - 2021-04-16 22:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 22:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 22:00:11 --> Form Validation Class Initialized
INFO - 2021-04-16 22:00:11 --> Model Class Initialized
INFO - 2021-04-16 22:00:11 --> Controller Class Initialized
INFO - 2021-04-16 22:00:11 --> Model Class Initialized
INFO - 2021-04-16 22:00:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-16 22:00:11 --> Config Class Initialized
INFO - 2021-04-16 22:00:11 --> Hooks Class Initialized
DEBUG - 2021-04-16 22:00:12 --> UTF-8 Support Enabled
INFO - 2021-04-16 22:00:12 --> Utf8 Class Initialized
INFO - 2021-04-16 22:00:12 --> URI Class Initialized
INFO - 2021-04-16 22:00:12 --> Router Class Initialized
INFO - 2021-04-16 22:00:12 --> Output Class Initialized
INFO - 2021-04-16 22:00:12 --> Security Class Initialized
DEBUG - 2021-04-16 22:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 22:00:12 --> Input Class Initialized
INFO - 2021-04-16 22:00:12 --> Language Class Initialized
INFO - 2021-04-16 22:00:12 --> Loader Class Initialized
INFO - 2021-04-16 22:00:12 --> Helper loaded: url_helper
INFO - 2021-04-16 22:00:12 --> Helper loaded: form_helper
INFO - 2021-04-16 22:00:12 --> Helper loaded: common_helper
INFO - 2021-04-16 22:00:12 --> Helper loaded: util_helper
INFO - 2021-04-16 22:00:12 --> Helper loaded: user_helper
INFO - 2021-04-16 22:00:12 --> Database Driver Class Initialized
DEBUG - 2021-04-16 22:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 22:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 22:00:12 --> Form Validation Class Initialized
INFO - 2021-04-16 22:00:12 --> Model Class Initialized
INFO - 2021-04-16 22:00:12 --> Controller Class Initialized
INFO - 2021-04-16 22:00:12 --> Model Class Initialized
INFO - 2021-04-16 22:00:12 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 22:00:12 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 22:00:12 --> Final output sent to browser
DEBUG - 2021-04-16 22:00:12 --> Total execution time: 0.0616
INFO - 2021-04-16 22:01:03 --> Config Class Initialized
INFO - 2021-04-16 22:01:03 --> Hooks Class Initialized
DEBUG - 2021-04-16 22:01:03 --> UTF-8 Support Enabled
INFO - 2021-04-16 22:01:03 --> Utf8 Class Initialized
INFO - 2021-04-16 22:01:03 --> URI Class Initialized
INFO - 2021-04-16 22:01:03 --> Router Class Initialized
INFO - 2021-04-16 22:01:03 --> Output Class Initialized
INFO - 2021-04-16 22:01:03 --> Security Class Initialized
DEBUG - 2021-04-16 22:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 22:01:03 --> Input Class Initialized
INFO - 2021-04-16 22:01:03 --> Language Class Initialized
INFO - 2021-04-16 22:01:03 --> Loader Class Initialized
INFO - 2021-04-16 22:01:03 --> Helper loaded: url_helper
INFO - 2021-04-16 22:01:03 --> Helper loaded: form_helper
INFO - 2021-04-16 22:01:03 --> Helper loaded: common_helper
INFO - 2021-04-16 22:01:03 --> Helper loaded: util_helper
INFO - 2021-04-16 22:01:03 --> Helper loaded: user_helper
INFO - 2021-04-16 22:01:03 --> Database Driver Class Initialized
DEBUG - 2021-04-16 22:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 22:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 22:01:04 --> Form Validation Class Initialized
INFO - 2021-04-16 22:01:04 --> Model Class Initialized
INFO - 2021-04-16 22:01:04 --> Controller Class Initialized
INFO - 2021-04-16 22:01:04 --> Model Class Initialized
INFO - 2021-04-16 22:01:04 --> Config Class Initialized
INFO - 2021-04-16 22:01:04 --> Hooks Class Initialized
DEBUG - 2021-04-16 22:01:04 --> UTF-8 Support Enabled
INFO - 2021-04-16 22:01:04 --> Utf8 Class Initialized
INFO - 2021-04-16 22:01:04 --> URI Class Initialized
INFO - 2021-04-16 22:01:04 --> Router Class Initialized
INFO - 2021-04-16 22:01:04 --> Output Class Initialized
INFO - 2021-04-16 22:01:04 --> Security Class Initialized
DEBUG - 2021-04-16 22:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 22:01:04 --> Input Class Initialized
INFO - 2021-04-16 22:01:04 --> Language Class Initialized
INFO - 2021-04-16 22:01:04 --> Loader Class Initialized
INFO - 2021-04-16 22:01:04 --> Helper loaded: url_helper
INFO - 2021-04-16 22:01:04 --> Helper loaded: form_helper
INFO - 2021-04-16 22:01:04 --> Helper loaded: common_helper
INFO - 2021-04-16 22:01:04 --> Helper loaded: util_helper
INFO - 2021-04-16 22:01:04 --> Helper loaded: user_helper
INFO - 2021-04-16 22:01:04 --> Database Driver Class Initialized
DEBUG - 2021-04-16 22:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 22:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 22:01:04 --> Form Validation Class Initialized
INFO - 2021-04-16 22:01:04 --> Model Class Initialized
INFO - 2021-04-16 22:01:04 --> Controller Class Initialized
INFO - 2021-04-16 22:01:04 --> Model Class Initialized
INFO - 2021-04-16 22:01:04 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 22:01:04 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 22:01:04 --> Final output sent to browser
DEBUG - 2021-04-16 22:01:04 --> Total execution time: 0.0335
INFO - 2021-04-16 22:01:06 --> Config Class Initialized
INFO - 2021-04-16 22:01:06 --> Hooks Class Initialized
DEBUG - 2021-04-16 22:01:06 --> UTF-8 Support Enabled
INFO - 2021-04-16 22:01:06 --> Utf8 Class Initialized
INFO - 2021-04-16 22:01:06 --> URI Class Initialized
INFO - 2021-04-16 22:01:06 --> Router Class Initialized
INFO - 2021-04-16 22:01:06 --> Output Class Initialized
INFO - 2021-04-16 22:01:06 --> Security Class Initialized
DEBUG - 2021-04-16 22:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 22:01:06 --> Input Class Initialized
INFO - 2021-04-16 22:01:06 --> Language Class Initialized
INFO - 2021-04-16 22:01:06 --> Loader Class Initialized
INFO - 2021-04-16 22:01:06 --> Helper loaded: url_helper
INFO - 2021-04-16 22:01:06 --> Helper loaded: form_helper
INFO - 2021-04-16 22:01:06 --> Helper loaded: common_helper
INFO - 2021-04-16 22:01:06 --> Helper loaded: util_helper
INFO - 2021-04-16 22:01:06 --> Helper loaded: user_helper
INFO - 2021-04-16 22:01:06 --> Database Driver Class Initialized
DEBUG - 2021-04-16 22:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 22:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 22:01:06 --> Form Validation Class Initialized
INFO - 2021-04-16 22:01:06 --> Model Class Initialized
INFO - 2021-04-16 22:01:06 --> Controller Class Initialized
INFO - 2021-04-16 22:01:06 --> Model Class Initialized
INFO - 2021-04-16 22:01:06 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 22:01:06 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 22:01:06 --> Final output sent to browser
DEBUG - 2021-04-16 22:01:06 --> Total execution time: 0.0289
INFO - 2021-04-16 22:01:06 --> Config Class Initialized
INFO - 2021-04-16 22:01:06 --> Hooks Class Initialized
DEBUG - 2021-04-16 22:01:06 --> UTF-8 Support Enabled
INFO - 2021-04-16 22:01:06 --> Utf8 Class Initialized
INFO - 2021-04-16 22:01:06 --> URI Class Initialized
INFO - 2021-04-16 22:01:06 --> Router Class Initialized
INFO - 2021-04-16 22:01:06 --> Output Class Initialized
INFO - 2021-04-16 22:01:06 --> Security Class Initialized
DEBUG - 2021-04-16 22:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 22:01:06 --> Input Class Initialized
INFO - 2021-04-16 22:01:06 --> Language Class Initialized
INFO - 2021-04-16 22:01:06 --> Loader Class Initialized
INFO - 2021-04-16 22:01:06 --> Helper loaded: url_helper
INFO - 2021-04-16 22:01:06 --> Helper loaded: form_helper
INFO - 2021-04-16 22:01:06 --> Helper loaded: common_helper
INFO - 2021-04-16 22:01:06 --> Helper loaded: util_helper
INFO - 2021-04-16 22:01:06 --> Helper loaded: user_helper
INFO - 2021-04-16 22:01:06 --> Database Driver Class Initialized
DEBUG - 2021-04-16 22:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 22:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 22:01:06 --> Form Validation Class Initialized
INFO - 2021-04-16 22:01:06 --> Model Class Initialized
INFO - 2021-04-16 22:01:06 --> Controller Class Initialized
INFO - 2021-04-16 22:01:06 --> Model Class Initialized
INFO - 2021-04-16 22:01:06 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 22:01:06 --> Final output sent to browser
DEBUG - 2021-04-16 22:01:06 --> Total execution time: 0.0300
INFO - 2021-04-16 22:01:07 --> Config Class Initialized
INFO - 2021-04-16 22:01:07 --> Hooks Class Initialized
DEBUG - 2021-04-16 22:01:07 --> UTF-8 Support Enabled
INFO - 2021-04-16 22:01:07 --> Utf8 Class Initialized
INFO - 2021-04-16 22:01:07 --> URI Class Initialized
INFO - 2021-04-16 22:01:07 --> Router Class Initialized
INFO - 2021-04-16 22:01:07 --> Output Class Initialized
INFO - 2021-04-16 22:01:07 --> Security Class Initialized
DEBUG - 2021-04-16 22:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 22:01:07 --> Input Class Initialized
INFO - 2021-04-16 22:01:07 --> Language Class Initialized
INFO - 2021-04-16 22:01:07 --> Loader Class Initialized
INFO - 2021-04-16 22:01:07 --> Helper loaded: url_helper
INFO - 2021-04-16 22:01:07 --> Helper loaded: form_helper
INFO - 2021-04-16 22:01:07 --> Helper loaded: common_helper
INFO - 2021-04-16 22:01:07 --> Helper loaded: util_helper
INFO - 2021-04-16 22:01:07 --> Helper loaded: user_helper
INFO - 2021-04-16 22:01:07 --> Database Driver Class Initialized
DEBUG - 2021-04-16 22:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 22:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 22:01:07 --> Form Validation Class Initialized
INFO - 2021-04-16 22:01:07 --> Model Class Initialized
INFO - 2021-04-16 22:01:07 --> Controller Class Initialized
INFO - 2021-04-16 22:01:07 --> Model Class Initialized
INFO - 2021-04-16 22:01:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 22:01:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 22:01:07 --> Final output sent to browser
DEBUG - 2021-04-16 22:01:07 --> Total execution time: 0.0271
INFO - 2021-04-16 22:01:07 --> Config Class Initialized
INFO - 2021-04-16 22:01:07 --> Hooks Class Initialized
DEBUG - 2021-04-16 22:01:07 --> UTF-8 Support Enabled
INFO - 2021-04-16 22:01:07 --> Utf8 Class Initialized
INFO - 2021-04-16 22:01:07 --> URI Class Initialized
INFO - 2021-04-16 22:01:07 --> Router Class Initialized
INFO - 2021-04-16 22:01:07 --> Output Class Initialized
INFO - 2021-04-16 22:01:07 --> Security Class Initialized
DEBUG - 2021-04-16 22:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 22:01:07 --> Input Class Initialized
INFO - 2021-04-16 22:01:07 --> Language Class Initialized
INFO - 2021-04-16 22:01:07 --> Loader Class Initialized
INFO - 2021-04-16 22:01:07 --> Helper loaded: url_helper
INFO - 2021-04-16 22:01:07 --> Helper loaded: form_helper
INFO - 2021-04-16 22:01:07 --> Helper loaded: common_helper
INFO - 2021-04-16 22:01:07 --> Helper loaded: util_helper
INFO - 2021-04-16 22:01:07 --> Helper loaded: user_helper
INFO - 2021-04-16 22:01:07 --> Database Driver Class Initialized
DEBUG - 2021-04-16 22:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 22:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 22:01:07 --> Form Validation Class Initialized
INFO - 2021-04-16 22:01:07 --> Model Class Initialized
INFO - 2021-04-16 22:01:07 --> Controller Class Initialized
INFO - 2021-04-16 22:01:07 --> Model Class Initialized
INFO - 2021-04-16 22:01:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 22:01:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 22:01:07 --> Final output sent to browser
DEBUG - 2021-04-16 22:01:07 --> Total execution time: 0.0395
INFO - 2021-04-16 22:01:07 --> Config Class Initialized
INFO - 2021-04-16 22:01:07 --> Hooks Class Initialized
DEBUG - 2021-04-16 22:01:07 --> UTF-8 Support Enabled
INFO - 2021-04-16 22:01:07 --> Utf8 Class Initialized
INFO - 2021-04-16 22:01:07 --> URI Class Initialized
INFO - 2021-04-16 22:01:07 --> Router Class Initialized
INFO - 2021-04-16 22:01:07 --> Output Class Initialized
INFO - 2021-04-16 22:01:07 --> Security Class Initialized
DEBUG - 2021-04-16 22:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 22:01:07 --> Input Class Initialized
INFO - 2021-04-16 22:01:07 --> Language Class Initialized
INFO - 2021-04-16 22:01:07 --> Loader Class Initialized
INFO - 2021-04-16 22:01:07 --> Helper loaded: url_helper
INFO - 2021-04-16 22:01:07 --> Helper loaded: form_helper
INFO - 2021-04-16 22:01:07 --> Helper loaded: common_helper
INFO - 2021-04-16 22:01:07 --> Helper loaded: util_helper
INFO - 2021-04-16 22:01:07 --> Helper loaded: user_helper
INFO - 2021-04-16 22:01:07 --> Database Driver Class Initialized
DEBUG - 2021-04-16 22:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 22:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 22:01:07 --> Form Validation Class Initialized
INFO - 2021-04-16 22:01:07 --> Model Class Initialized
INFO - 2021-04-16 22:01:07 --> Controller Class Initialized
INFO - 2021-04-16 22:01:07 --> Model Class Initialized
INFO - 2021-04-16 22:01:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 22:01:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 22:01:07 --> Final output sent to browser
DEBUG - 2021-04-16 22:01:07 --> Total execution time: 0.0302
INFO - 2021-04-16 22:01:07 --> Config Class Initialized
INFO - 2021-04-16 22:01:07 --> Hooks Class Initialized
DEBUG - 2021-04-16 22:01:07 --> UTF-8 Support Enabled
INFO - 2021-04-16 22:01:07 --> Utf8 Class Initialized
INFO - 2021-04-16 22:01:07 --> URI Class Initialized
INFO - 2021-04-16 22:01:07 --> Router Class Initialized
INFO - 2021-04-16 22:01:07 --> Output Class Initialized
INFO - 2021-04-16 22:01:07 --> Security Class Initialized
DEBUG - 2021-04-16 22:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 22:01:07 --> Input Class Initialized
INFO - 2021-04-16 22:01:07 --> Language Class Initialized
INFO - 2021-04-16 22:01:07 --> Loader Class Initialized
INFO - 2021-04-16 22:01:07 --> Helper loaded: url_helper
INFO - 2021-04-16 22:01:07 --> Helper loaded: form_helper
INFO - 2021-04-16 22:01:07 --> Helper loaded: common_helper
INFO - 2021-04-16 22:01:07 --> Helper loaded: util_helper
INFO - 2021-04-16 22:01:07 --> Helper loaded: user_helper
INFO - 2021-04-16 22:01:07 --> Database Driver Class Initialized
DEBUG - 2021-04-16 22:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 22:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 22:01:07 --> Form Validation Class Initialized
INFO - 2021-04-16 22:01:07 --> Model Class Initialized
INFO - 2021-04-16 22:01:07 --> Controller Class Initialized
INFO - 2021-04-16 22:01:07 --> Model Class Initialized
INFO - 2021-04-16 22:01:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 22:01:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 22:01:07 --> Final output sent to browser
DEBUG - 2021-04-16 22:01:07 --> Total execution time: 0.0405
INFO - 2021-04-16 22:01:08 --> Config Class Initialized
INFO - 2021-04-16 22:01:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 22:01:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 22:01:08 --> Utf8 Class Initialized
INFO - 2021-04-16 22:01:08 --> URI Class Initialized
INFO - 2021-04-16 22:01:08 --> Router Class Initialized
INFO - 2021-04-16 22:01:08 --> Output Class Initialized
INFO - 2021-04-16 22:01:08 --> Security Class Initialized
DEBUG - 2021-04-16 22:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 22:01:08 --> Input Class Initialized
INFO - 2021-04-16 22:01:08 --> Language Class Initialized
INFO - 2021-04-16 22:01:08 --> Loader Class Initialized
INFO - 2021-04-16 22:01:08 --> Helper loaded: url_helper
INFO - 2021-04-16 22:01:08 --> Helper loaded: form_helper
INFO - 2021-04-16 22:01:08 --> Helper loaded: common_helper
INFO - 2021-04-16 22:01:08 --> Helper loaded: util_helper
INFO - 2021-04-16 22:01:08 --> Helper loaded: user_helper
INFO - 2021-04-16 22:01:08 --> Database Driver Class Initialized
DEBUG - 2021-04-16 22:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 22:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 22:01:08 --> Form Validation Class Initialized
INFO - 2021-04-16 22:01:08 --> Model Class Initialized
INFO - 2021-04-16 22:01:08 --> Controller Class Initialized
INFO - 2021-04-16 22:01:08 --> Model Class Initialized
INFO - 2021-04-16 22:01:08 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 22:01:08 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 22:01:08 --> Final output sent to browser
DEBUG - 2021-04-16 22:01:08 --> Total execution time: 0.0299
INFO - 2021-04-16 22:01:08 --> Config Class Initialized
INFO - 2021-04-16 22:01:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 22:01:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 22:01:08 --> Utf8 Class Initialized
INFO - 2021-04-16 22:01:08 --> URI Class Initialized
INFO - 2021-04-16 22:01:08 --> Router Class Initialized
INFO - 2021-04-16 22:01:08 --> Output Class Initialized
INFO - 2021-04-16 22:01:08 --> Security Class Initialized
DEBUG - 2021-04-16 22:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 22:01:08 --> Input Class Initialized
INFO - 2021-04-16 22:01:08 --> Language Class Initialized
INFO - 2021-04-16 22:01:08 --> Loader Class Initialized
INFO - 2021-04-16 22:01:08 --> Helper loaded: url_helper
INFO - 2021-04-16 22:01:08 --> Helper loaded: form_helper
INFO - 2021-04-16 22:01:08 --> Helper loaded: common_helper
INFO - 2021-04-16 22:01:08 --> Helper loaded: util_helper
INFO - 2021-04-16 22:01:08 --> Helper loaded: user_helper
INFO - 2021-04-16 22:01:08 --> Database Driver Class Initialized
DEBUG - 2021-04-16 22:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 22:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 22:01:08 --> Form Validation Class Initialized
INFO - 2021-04-16 22:01:08 --> Model Class Initialized
INFO - 2021-04-16 22:01:08 --> Controller Class Initialized
INFO - 2021-04-16 22:01:08 --> Model Class Initialized
INFO - 2021-04-16 22:01:08 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 22:01:08 --> Final output sent to browser
DEBUG - 2021-04-16 22:01:08 --> Total execution time: 0.0290
INFO - 2021-04-16 22:01:08 --> Config Class Initialized
INFO - 2021-04-16 22:01:08 --> Hooks Class Initialized
DEBUG - 2021-04-16 22:01:08 --> UTF-8 Support Enabled
INFO - 2021-04-16 22:01:08 --> Utf8 Class Initialized
INFO - 2021-04-16 22:01:08 --> URI Class Initialized
DEBUG - 2021-04-16 22:01:08 --> No URI present. Default controller set.
INFO - 2021-04-16 22:01:08 --> Router Class Initialized
INFO - 2021-04-16 22:01:08 --> Output Class Initialized
INFO - 2021-04-16 22:01:08 --> Security Class Initialized
DEBUG - 2021-04-16 22:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 22:01:08 --> Input Class Initialized
INFO - 2021-04-16 22:01:08 --> Language Class Initialized
INFO - 2021-04-16 22:01:08 --> Loader Class Initialized
INFO - 2021-04-16 22:01:08 --> Helper loaded: url_helper
INFO - 2021-04-16 22:01:08 --> Helper loaded: form_helper
INFO - 2021-04-16 22:01:08 --> Helper loaded: common_helper
INFO - 2021-04-16 22:01:08 --> Helper loaded: util_helper
INFO - 2021-04-16 22:01:08 --> Helper loaded: user_helper
INFO - 2021-04-16 22:01:08 --> Database Driver Class Initialized
DEBUG - 2021-04-16 22:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 22:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 22:01:08 --> Form Validation Class Initialized
INFO - 2021-04-16 22:01:08 --> Model Class Initialized
INFO - 2021-04-16 22:01:08 --> Controller Class Initialized
INFO - 2021-04-16 22:01:08 --> Model Class Initialized
INFO - 2021-04-16 22:01:08 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 22:01:08 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 22:01:08 --> Final output sent to browser
DEBUG - 2021-04-16 22:01:08 --> Total execution time: 0.0282
INFO - 2021-04-16 22:01:10 --> Config Class Initialized
INFO - 2021-04-16 22:01:10 --> Hooks Class Initialized
DEBUG - 2021-04-16 22:01:10 --> UTF-8 Support Enabled
INFO - 2021-04-16 22:01:10 --> Utf8 Class Initialized
INFO - 2021-04-16 22:01:10 --> URI Class Initialized
DEBUG - 2021-04-16 22:01:10 --> No URI present. Default controller set.
INFO - 2021-04-16 22:01:10 --> Router Class Initialized
INFO - 2021-04-16 22:01:10 --> Output Class Initialized
INFO - 2021-04-16 22:01:10 --> Security Class Initialized
DEBUG - 2021-04-16 22:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 22:01:10 --> Input Class Initialized
INFO - 2021-04-16 22:01:10 --> Language Class Initialized
INFO - 2021-04-16 22:01:10 --> Loader Class Initialized
INFO - 2021-04-16 22:01:10 --> Helper loaded: url_helper
INFO - 2021-04-16 22:01:10 --> Helper loaded: form_helper
INFO - 2021-04-16 22:01:10 --> Helper loaded: common_helper
INFO - 2021-04-16 22:01:10 --> Helper loaded: util_helper
INFO - 2021-04-16 22:01:10 --> Helper loaded: user_helper
INFO - 2021-04-16 22:01:10 --> Database Driver Class Initialized
DEBUG - 2021-04-16 22:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 22:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 22:01:10 --> Form Validation Class Initialized
INFO - 2021-04-16 22:01:10 --> Model Class Initialized
INFO - 2021-04-16 22:01:10 --> Controller Class Initialized
INFO - 2021-04-16 22:01:10 --> Model Class Initialized
INFO - 2021-04-16 22:01:10 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 22:01:10 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 22:01:10 --> Final output sent to browser
DEBUG - 2021-04-16 22:01:10 --> Total execution time: 0.0308
INFO - 2021-04-16 22:06:53 --> Config Class Initialized
INFO - 2021-04-16 22:06:53 --> Hooks Class Initialized
DEBUG - 2021-04-16 22:06:53 --> UTF-8 Support Enabled
INFO - 2021-04-16 22:06:53 --> Utf8 Class Initialized
INFO - 2021-04-16 22:06:53 --> URI Class Initialized
INFO - 2021-04-16 22:06:53 --> Router Class Initialized
INFO - 2021-04-16 22:06:53 --> Output Class Initialized
INFO - 2021-04-16 22:06:53 --> Security Class Initialized
DEBUG - 2021-04-16 22:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 22:06:53 --> Input Class Initialized
INFO - 2021-04-16 22:06:53 --> Language Class Initialized
INFO - 2021-04-16 22:06:53 --> Loader Class Initialized
INFO - 2021-04-16 22:06:53 --> Helper loaded: url_helper
INFO - 2021-04-16 22:06:53 --> Helper loaded: form_helper
INFO - 2021-04-16 22:06:53 --> Helper loaded: common_helper
INFO - 2021-04-16 22:06:53 --> Helper loaded: util_helper
INFO - 2021-04-16 22:06:53 --> Helper loaded: user_helper
INFO - 2021-04-16 22:06:53 --> Database Driver Class Initialized
DEBUG - 2021-04-16 22:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 22:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 22:06:53 --> Form Validation Class Initialized
INFO - 2021-04-16 22:06:53 --> Model Class Initialized
INFO - 2021-04-16 22:06:53 --> Controller Class Initialized
INFO - 2021-04-16 22:06:53 --> Model Class Initialized
INFO - 2021-04-16 22:06:53 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 22:06:53 --> Final output sent to browser
DEBUG - 2021-04-16 22:06:53 --> Total execution time: 0.0273
INFO - 2021-04-16 22:06:53 --> Config Class Initialized
INFO - 2021-04-16 22:06:53 --> Hooks Class Initialized
INFO - 2021-04-16 22:06:53 --> Config Class Initialized
INFO - 2021-04-16 22:06:53 --> Hooks Class Initialized
DEBUG - 2021-04-16 22:06:53 --> UTF-8 Support Enabled
INFO - 2021-04-16 22:06:53 --> Utf8 Class Initialized
DEBUG - 2021-04-16 22:06:53 --> UTF-8 Support Enabled
INFO - 2021-04-16 22:06:53 --> Utf8 Class Initialized
INFO - 2021-04-16 22:06:53 --> URI Class Initialized
INFO - 2021-04-16 22:06:53 --> URI Class Initialized
INFO - 2021-04-16 22:06:53 --> Router Class Initialized
INFO - 2021-04-16 22:06:53 --> Router Class Initialized
INFO - 2021-04-16 22:06:53 --> Output Class Initialized
INFO - 2021-04-16 22:06:53 --> Output Class Initialized
INFO - 2021-04-16 22:06:53 --> Security Class Initialized
INFO - 2021-04-16 22:06:53 --> Security Class Initialized
DEBUG - 2021-04-16 22:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 22:06:53 --> Input Class Initialized
DEBUG - 2021-04-16 22:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 22:06:53 --> Input Class Initialized
INFO - 2021-04-16 22:06:53 --> Language Class Initialized
INFO - 2021-04-16 22:06:53 --> Language Class Initialized
ERROR - 2021-04-16 22:06:53 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-16 22:06:53 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-16 22:07:21 --> Config Class Initialized
INFO - 2021-04-16 22:07:21 --> Hooks Class Initialized
DEBUG - 2021-04-16 22:07:21 --> UTF-8 Support Enabled
INFO - 2021-04-16 22:07:21 --> Utf8 Class Initialized
INFO - 2021-04-16 22:07:21 --> URI Class Initialized
INFO - 2021-04-16 22:07:21 --> Router Class Initialized
INFO - 2021-04-16 22:07:21 --> Output Class Initialized
INFO - 2021-04-16 22:07:21 --> Security Class Initialized
DEBUG - 2021-04-16 22:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 22:07:21 --> Input Class Initialized
INFO - 2021-04-16 22:07:21 --> Language Class Initialized
INFO - 2021-04-16 22:07:21 --> Loader Class Initialized
INFO - 2021-04-16 22:07:21 --> Helper loaded: url_helper
INFO - 2021-04-16 22:07:21 --> Helper loaded: form_helper
INFO - 2021-04-16 22:07:21 --> Helper loaded: common_helper
INFO - 2021-04-16 22:07:21 --> Helper loaded: util_helper
INFO - 2021-04-16 22:07:21 --> Helper loaded: user_helper
INFO - 2021-04-16 22:07:21 --> Database Driver Class Initialized
DEBUG - 2021-04-16 22:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 22:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 22:07:21 --> Form Validation Class Initialized
INFO - 2021-04-16 22:07:21 --> Model Class Initialized
INFO - 2021-04-16 22:07:21 --> Controller Class Initialized
INFO - 2021-04-16 22:07:21 --> Model Class Initialized
INFO - 2021-04-16 22:07:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-16 22:07:21 --> Config Class Initialized
INFO - 2021-04-16 22:07:21 --> Hooks Class Initialized
DEBUG - 2021-04-16 22:07:21 --> UTF-8 Support Enabled
INFO - 2021-04-16 22:07:21 --> Utf8 Class Initialized
INFO - 2021-04-16 22:07:21 --> URI Class Initialized
INFO - 2021-04-16 22:07:21 --> Router Class Initialized
INFO - 2021-04-16 22:07:21 --> Output Class Initialized
INFO - 2021-04-16 22:07:21 --> Security Class Initialized
DEBUG - 2021-04-16 22:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 22:07:21 --> Input Class Initialized
INFO - 2021-04-16 22:07:21 --> Language Class Initialized
INFO - 2021-04-16 22:07:21 --> Loader Class Initialized
INFO - 2021-04-16 22:07:21 --> Helper loaded: url_helper
INFO - 2021-04-16 22:07:21 --> Helper loaded: form_helper
INFO - 2021-04-16 22:07:21 --> Helper loaded: common_helper
INFO - 2021-04-16 22:07:21 --> Helper loaded: util_helper
INFO - 2021-04-16 22:07:21 --> Helper loaded: user_helper
INFO - 2021-04-16 22:07:21 --> Database Driver Class Initialized
DEBUG - 2021-04-16 22:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 22:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 22:07:21 --> Form Validation Class Initialized
INFO - 2021-04-16 22:07:21 --> Model Class Initialized
INFO - 2021-04-16 22:07:21 --> Controller Class Initialized
INFO - 2021-04-16 22:07:21 --> Model Class Initialized
INFO - 2021-04-16 22:07:21 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 22:07:21 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 22:07:21 --> Final output sent to browser
DEBUG - 2021-04-16 22:07:21 --> Total execution time: 0.0297
INFO - 2021-04-16 22:07:30 --> Config Class Initialized
INFO - 2021-04-16 22:07:30 --> Hooks Class Initialized
DEBUG - 2021-04-16 22:07:30 --> UTF-8 Support Enabled
INFO - 2021-04-16 22:07:30 --> Utf8 Class Initialized
INFO - 2021-04-16 22:07:30 --> URI Class Initialized
INFO - 2021-04-16 22:07:30 --> Router Class Initialized
INFO - 2021-04-16 22:07:30 --> Output Class Initialized
INFO - 2021-04-16 22:07:30 --> Security Class Initialized
DEBUG - 2021-04-16 22:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 22:07:30 --> Input Class Initialized
INFO - 2021-04-16 22:07:30 --> Language Class Initialized
INFO - 2021-04-16 22:07:30 --> Loader Class Initialized
INFO - 2021-04-16 22:07:30 --> Helper loaded: url_helper
INFO - 2021-04-16 22:07:30 --> Helper loaded: form_helper
INFO - 2021-04-16 22:07:30 --> Helper loaded: common_helper
INFO - 2021-04-16 22:07:30 --> Helper loaded: util_helper
INFO - 2021-04-16 22:07:30 --> Helper loaded: user_helper
INFO - 2021-04-16 22:07:30 --> Database Driver Class Initialized
DEBUG - 2021-04-16 22:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 22:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 22:07:30 --> Form Validation Class Initialized
INFO - 2021-04-16 22:07:30 --> Model Class Initialized
INFO - 2021-04-16 22:07:30 --> Controller Class Initialized
INFO - 2021-04-16 22:07:30 --> Model Class Initialized
INFO - 2021-04-16 22:07:30 --> Config Class Initialized
INFO - 2021-04-16 22:07:30 --> Hooks Class Initialized
DEBUG - 2021-04-16 22:07:30 --> UTF-8 Support Enabled
INFO - 2021-04-16 22:07:30 --> Utf8 Class Initialized
INFO - 2021-04-16 22:07:30 --> URI Class Initialized
INFO - 2021-04-16 22:07:30 --> Router Class Initialized
INFO - 2021-04-16 22:07:30 --> Output Class Initialized
INFO - 2021-04-16 22:07:30 --> Security Class Initialized
DEBUG - 2021-04-16 22:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 22:07:30 --> Input Class Initialized
INFO - 2021-04-16 22:07:30 --> Language Class Initialized
INFO - 2021-04-16 22:07:30 --> Loader Class Initialized
INFO - 2021-04-16 22:07:30 --> Helper loaded: url_helper
INFO - 2021-04-16 22:07:30 --> Helper loaded: form_helper
INFO - 2021-04-16 22:07:30 --> Helper loaded: common_helper
INFO - 2021-04-16 22:07:30 --> Helper loaded: util_helper
INFO - 2021-04-16 22:07:30 --> Helper loaded: user_helper
INFO - 2021-04-16 22:07:30 --> Database Driver Class Initialized
DEBUG - 2021-04-16 22:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 22:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 22:07:30 --> Form Validation Class Initialized
INFO - 2021-04-16 22:07:30 --> Model Class Initialized
INFO - 2021-04-16 22:07:30 --> Controller Class Initialized
INFO - 2021-04-16 22:07:30 --> Model Class Initialized
INFO - 2021-04-16 22:07:30 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 22:07:30 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 22:07:30 --> Final output sent to browser
DEBUG - 2021-04-16 22:07:30 --> Total execution time: 0.0289
INFO - 2021-04-16 22:07:38 --> Config Class Initialized
INFO - 2021-04-16 22:07:38 --> Hooks Class Initialized
DEBUG - 2021-04-16 22:07:38 --> UTF-8 Support Enabled
INFO - 2021-04-16 22:07:38 --> Utf8 Class Initialized
INFO - 2021-04-16 22:07:38 --> URI Class Initialized
INFO - 2021-04-16 22:07:38 --> Router Class Initialized
INFO - 2021-04-16 22:07:38 --> Output Class Initialized
INFO - 2021-04-16 22:07:38 --> Security Class Initialized
DEBUG - 2021-04-16 22:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 22:07:38 --> Input Class Initialized
INFO - 2021-04-16 22:07:38 --> Language Class Initialized
INFO - 2021-04-16 22:07:38 --> Loader Class Initialized
INFO - 2021-04-16 22:07:38 --> Helper loaded: url_helper
INFO - 2021-04-16 22:07:38 --> Helper loaded: form_helper
INFO - 2021-04-16 22:07:38 --> Helper loaded: common_helper
INFO - 2021-04-16 22:07:38 --> Helper loaded: util_helper
INFO - 2021-04-16 22:07:38 --> Helper loaded: user_helper
INFO - 2021-04-16 22:07:38 --> Database Driver Class Initialized
DEBUG - 2021-04-16 22:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 22:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 22:07:38 --> Form Validation Class Initialized
INFO - 2021-04-16 22:07:38 --> Model Class Initialized
INFO - 2021-04-16 22:07:38 --> Controller Class Initialized
INFO - 2021-04-16 22:07:38 --> Model Class Initialized
INFO - 2021-04-16 22:07:38 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 22:07:38 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 22:07:38 --> Final output sent to browser
DEBUG - 2021-04-16 22:07:38 --> Total execution time: 0.0313
INFO - 2021-04-16 22:07:41 --> Config Class Initialized
INFO - 2021-04-16 22:07:41 --> Hooks Class Initialized
DEBUG - 2021-04-16 22:07:41 --> UTF-8 Support Enabled
INFO - 2021-04-16 22:07:41 --> Utf8 Class Initialized
INFO - 2021-04-16 22:07:41 --> URI Class Initialized
INFO - 2021-04-16 22:07:41 --> Router Class Initialized
INFO - 2021-04-16 22:07:41 --> Output Class Initialized
INFO - 2021-04-16 22:07:41 --> Security Class Initialized
DEBUG - 2021-04-16 22:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 22:07:41 --> Input Class Initialized
INFO - 2021-04-16 22:07:41 --> Language Class Initialized
INFO - 2021-04-16 22:07:41 --> Loader Class Initialized
INFO - 2021-04-16 22:07:41 --> Helper loaded: url_helper
INFO - 2021-04-16 22:07:41 --> Helper loaded: form_helper
INFO - 2021-04-16 22:07:41 --> Helper loaded: common_helper
INFO - 2021-04-16 22:07:41 --> Helper loaded: util_helper
INFO - 2021-04-16 22:07:41 --> Helper loaded: user_helper
INFO - 2021-04-16 22:07:41 --> Database Driver Class Initialized
DEBUG - 2021-04-16 22:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 22:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 22:07:41 --> Form Validation Class Initialized
INFO - 2021-04-16 22:07:41 --> Model Class Initialized
INFO - 2021-04-16 22:07:41 --> Controller Class Initialized
INFO - 2021-04-16 22:07:41 --> Model Class Initialized
INFO - 2021-04-16 22:07:41 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-16 22:07:41 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/_layout.php
INFO - 2021-04-16 22:07:41 --> Final output sent to browser
DEBUG - 2021-04-16 22:07:41 --> Total execution time: 0.0306
INFO - 2021-04-16 22:07:43 --> Config Class Initialized
INFO - 2021-04-16 22:07:43 --> Hooks Class Initialized
DEBUG - 2021-04-16 22:07:43 --> UTF-8 Support Enabled
INFO - 2021-04-16 22:07:43 --> Utf8 Class Initialized
INFO - 2021-04-16 22:07:43 --> URI Class Initialized
INFO - 2021-04-16 22:07:43 --> Router Class Initialized
INFO - 2021-04-16 22:07:43 --> Output Class Initialized
INFO - 2021-04-16 22:07:43 --> Security Class Initialized
DEBUG - 2021-04-16 22:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 22:07:43 --> Input Class Initialized
INFO - 2021-04-16 22:07:43 --> Language Class Initialized
INFO - 2021-04-16 22:07:43 --> Loader Class Initialized
INFO - 2021-04-16 22:07:43 --> Helper loaded: url_helper
INFO - 2021-04-16 22:07:43 --> Helper loaded: form_helper
INFO - 2021-04-16 22:07:43 --> Helper loaded: common_helper
INFO - 2021-04-16 22:07:43 --> Helper loaded: util_helper
INFO - 2021-04-16 22:07:43 --> Helper loaded: user_helper
INFO - 2021-04-16 22:07:43 --> Database Driver Class Initialized
DEBUG - 2021-04-16 22:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 22:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 22:07:43 --> Form Validation Class Initialized
INFO - 2021-04-16 22:07:43 --> Model Class Initialized
INFO - 2021-04-16 22:07:43 --> Controller Class Initialized
INFO - 2021-04-16 22:07:43 --> Model Class Initialized
INFO - 2021-04-16 22:07:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-16 22:07:43 --> Final output sent to browser
DEBUG - 2021-04-16 22:07:43 --> Total execution time: 0.0281
INFO - 2021-04-16 22:07:44 --> Config Class Initialized
INFO - 2021-04-16 22:07:44 --> Hooks Class Initialized
DEBUG - 2021-04-16 22:07:44 --> UTF-8 Support Enabled
INFO - 2021-04-16 22:07:44 --> Utf8 Class Initialized
INFO - 2021-04-16 22:07:44 --> URI Class Initialized
DEBUG - 2021-04-16 22:07:44 --> No URI present. Default controller set.
INFO - 2021-04-16 22:07:44 --> Router Class Initialized
INFO - 2021-04-16 22:07:44 --> Output Class Initialized
INFO - 2021-04-16 22:07:44 --> Security Class Initialized
DEBUG - 2021-04-16 22:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 22:07:44 --> Input Class Initialized
INFO - 2021-04-16 22:07:44 --> Language Class Initialized
INFO - 2021-04-16 22:07:44 --> Loader Class Initialized
INFO - 2021-04-16 22:07:44 --> Helper loaded: url_helper
INFO - 2021-04-16 22:07:44 --> Helper loaded: form_helper
INFO - 2021-04-16 22:07:44 --> Helper loaded: common_helper
INFO - 2021-04-16 22:07:44 --> Helper loaded: util_helper
INFO - 2021-04-16 22:07:44 --> Helper loaded: user_helper
INFO - 2021-04-16 22:07:44 --> Database Driver Class Initialized
DEBUG - 2021-04-16 22:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 22:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 22:07:44 --> Form Validation Class Initialized
INFO - 2021-04-16 22:07:44 --> Model Class Initialized
INFO - 2021-04-16 22:07:44 --> Controller Class Initialized
INFO - 2021-04-16 22:07:44 --> Model Class Initialized
INFO - 2021-04-16 22:07:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 22:07:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 22:07:44 --> Final output sent to browser
DEBUG - 2021-04-16 22:07:44 --> Total execution time: 0.0294
INFO - 2021-04-16 22:07:47 --> Config Class Initialized
INFO - 2021-04-16 22:07:47 --> Hooks Class Initialized
DEBUG - 2021-04-16 22:07:47 --> UTF-8 Support Enabled
INFO - 2021-04-16 22:07:47 --> Utf8 Class Initialized
INFO - 2021-04-16 22:07:47 --> URI Class Initialized
DEBUG - 2021-04-16 22:07:47 --> No URI present. Default controller set.
INFO - 2021-04-16 22:07:47 --> Router Class Initialized
INFO - 2021-04-16 22:07:47 --> Output Class Initialized
INFO - 2021-04-16 22:07:47 --> Security Class Initialized
DEBUG - 2021-04-16 22:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-16 22:07:47 --> Input Class Initialized
INFO - 2021-04-16 22:07:47 --> Language Class Initialized
INFO - 2021-04-16 22:07:47 --> Loader Class Initialized
INFO - 2021-04-16 22:07:47 --> Helper loaded: url_helper
INFO - 2021-04-16 22:07:47 --> Helper loaded: form_helper
INFO - 2021-04-16 22:07:47 --> Helper loaded: common_helper
INFO - 2021-04-16 22:07:47 --> Helper loaded: util_helper
INFO - 2021-04-16 22:07:47 --> Helper loaded: user_helper
INFO - 2021-04-16 22:07:47 --> Database Driver Class Initialized
DEBUG - 2021-04-16 22:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-16 22:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-16 22:07:47 --> Form Validation Class Initialized
INFO - 2021-04-16 22:07:47 --> Model Class Initialized
INFO - 2021-04-16 22:07:47 --> Controller Class Initialized
INFO - 2021-04-16 22:07:47 --> Model Class Initialized
INFO - 2021-04-16 22:07:47 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-16 22:07:47 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-16 22:07:47 --> Final output sent to browser
DEBUG - 2021-04-16 22:07:47 --> Total execution time: 0.0307

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-04-28 14:54:26 --> Config Class Initialized
INFO - 2021-04-28 14:54:26 --> Hooks Class Initialized
DEBUG - 2021-04-28 14:54:26 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:54:26 --> Utf8 Class Initialized
INFO - 2021-04-28 14:54:26 --> URI Class Initialized
DEBUG - 2021-04-28 14:54:26 --> No URI present. Default controller set.
INFO - 2021-04-28 14:54:26 --> Router Class Initialized
INFO - 2021-04-28 14:54:26 --> Output Class Initialized
INFO - 2021-04-28 14:54:26 --> Security Class Initialized
DEBUG - 2021-04-28 14:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:54:26 --> Input Class Initialized
INFO - 2021-04-28 14:54:26 --> Language Class Initialized
INFO - 2021-04-28 14:54:26 --> Loader Class Initialized
INFO - 2021-04-28 14:54:26 --> Helper loaded: url_helper
INFO - 2021-04-28 14:54:26 --> Helper loaded: form_helper
INFO - 2021-04-28 14:54:26 --> Helper loaded: common_helper
INFO - 2021-04-28 14:54:26 --> Helper loaded: util_helper
INFO - 2021-04-28 14:54:26 --> Helper loaded: user_helper
INFO - 2021-04-28 14:54:26 --> Database Driver Class Initialized
DEBUG - 2021-04-28 14:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 14:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 14:54:26 --> Form Validation Class Initialized
INFO - 2021-04-28 14:54:26 --> Controller Class Initialized
INFO - 2021-04-28 14:54:26 --> Model Class Initialized
INFO - 2021-04-28 14:54:26 --> Model Class Initialized
INFO - 2021-04-28 14:54:26 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-28 14:54:26 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-28 14:54:26 --> Final output sent to browser
DEBUG - 2021-04-28 14:54:26 --> Total execution time: 0.0659
INFO - 2021-04-28 14:54:26 --> Config Class Initialized
INFO - 2021-04-28 14:54:26 --> Hooks Class Initialized
DEBUG - 2021-04-28 14:54:26 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:54:26 --> Utf8 Class Initialized
INFO - 2021-04-28 14:54:26 --> URI Class Initialized
INFO - 2021-04-28 14:54:26 --> Router Class Initialized
INFO - 2021-04-28 14:54:26 --> Output Class Initialized
INFO - 2021-04-28 14:54:26 --> Security Class Initialized
DEBUG - 2021-04-28 14:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:54:26 --> Input Class Initialized
INFO - 2021-04-28 14:54:26 --> Language Class Initialized
ERROR - 2021-04-28 14:54:26 --> 404 Page Not Found: Assets/img
INFO - 2021-04-28 14:54:26 --> Config Class Initialized
INFO - 2021-04-28 14:54:26 --> Hooks Class Initialized
DEBUG - 2021-04-28 14:54:26 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:54:26 --> Utf8 Class Initialized
INFO - 2021-04-28 14:54:26 --> URI Class Initialized
INFO - 2021-04-28 14:54:26 --> Router Class Initialized
INFO - 2021-04-28 14:54:26 --> Output Class Initialized
INFO - 2021-04-28 14:54:26 --> Security Class Initialized
DEBUG - 2021-04-28 14:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:54:26 --> Input Class Initialized
INFO - 2021-04-28 14:54:26 --> Language Class Initialized
ERROR - 2021-04-28 14:54:26 --> 404 Page Not Found: Fassets/img
INFO - 2021-04-28 14:54:41 --> Config Class Initialized
INFO - 2021-04-28 14:54:41 --> Hooks Class Initialized
DEBUG - 2021-04-28 14:54:41 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:54:41 --> Utf8 Class Initialized
INFO - 2021-04-28 14:54:41 --> URI Class Initialized
INFO - 2021-04-28 14:54:41 --> Router Class Initialized
INFO - 2021-04-28 14:54:41 --> Output Class Initialized
INFO - 2021-04-28 14:54:41 --> Security Class Initialized
DEBUG - 2021-04-28 14:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:54:41 --> Input Class Initialized
INFO - 2021-04-28 14:54:41 --> Language Class Initialized
ERROR - 2021-04-28 14:54:41 --> 404 Page Not Found: UserController/index
INFO - 2021-04-28 14:55:10 --> Config Class Initialized
INFO - 2021-04-28 14:55:10 --> Hooks Class Initialized
DEBUG - 2021-04-28 14:55:10 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:55:10 --> Utf8 Class Initialized
INFO - 2021-04-28 14:55:10 --> URI Class Initialized
INFO - 2021-04-28 14:55:10 --> Router Class Initialized
INFO - 2021-04-28 14:55:10 --> Output Class Initialized
INFO - 2021-04-28 14:55:10 --> Security Class Initialized
DEBUG - 2021-04-28 14:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:55:10 --> Input Class Initialized
INFO - 2021-04-28 14:55:10 --> Language Class Initialized
INFO - 2021-04-28 14:55:10 --> Loader Class Initialized
INFO - 2021-04-28 14:55:10 --> Helper loaded: url_helper
INFO - 2021-04-28 14:55:10 --> Helper loaded: form_helper
INFO - 2021-04-28 14:55:10 --> Helper loaded: common_helper
INFO - 2021-04-28 14:55:10 --> Helper loaded: util_helper
INFO - 2021-04-28 14:55:10 --> Helper loaded: user_helper
INFO - 2021-04-28 14:55:10 --> Database Driver Class Initialized
DEBUG - 2021-04-28 14:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 14:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 14:55:10 --> Form Validation Class Initialized
INFO - 2021-04-28 14:55:10 --> Controller Class Initialized
INFO - 2021-04-28 14:55:10 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewCms.php
INFO - 2021-04-28 14:55:10 --> Final output sent to browser
DEBUG - 2021-04-28 14:55:10 --> Total execution time: 0.1874
INFO - 2021-04-28 14:55:10 --> Config Class Initialized
INFO - 2021-04-28 14:55:10 --> Hooks Class Initialized
INFO - 2021-04-28 14:55:10 --> Config Class Initialized
INFO - 2021-04-28 14:55:10 --> Hooks Class Initialized
DEBUG - 2021-04-28 14:55:10 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:55:10 --> Utf8 Class Initialized
DEBUG - 2021-04-28 14:55:10 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:55:10 --> Utf8 Class Initialized
INFO - 2021-04-28 14:55:10 --> URI Class Initialized
INFO - 2021-04-28 14:55:10 --> URI Class Initialized
INFO - 2021-04-28 14:55:10 --> Router Class Initialized
INFO - 2021-04-28 14:55:10 --> Router Class Initialized
INFO - 2021-04-28 14:55:10 --> Output Class Initialized
INFO - 2021-04-28 14:55:10 --> Security Class Initialized
INFO - 2021-04-28 14:55:10 --> Output Class Initialized
DEBUG - 2021-04-28 14:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:55:10 --> Security Class Initialized
INFO - 2021-04-28 14:55:10 --> Input Class Initialized
INFO - 2021-04-28 14:55:10 --> Language Class Initialized
DEBUG - 2021-04-28 14:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:55:10 --> Input Class Initialized
INFO - 2021-04-28 14:55:10 --> Language Class Initialized
ERROR - 2021-04-28 14:55:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-04-28 14:55:10 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-28 14:55:11 --> Config Class Initialized
INFO - 2021-04-28 14:55:11 --> Hooks Class Initialized
DEBUG - 2021-04-28 14:55:11 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:55:11 --> Utf8 Class Initialized
INFO - 2021-04-28 14:55:11 --> URI Class Initialized
INFO - 2021-04-28 14:55:11 --> Router Class Initialized
INFO - 2021-04-28 14:55:11 --> Output Class Initialized
INFO - 2021-04-28 14:55:11 --> Security Class Initialized
DEBUG - 2021-04-28 14:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:55:11 --> Input Class Initialized
INFO - 2021-04-28 14:55:11 --> Language Class Initialized
ERROR - 2021-04-28 14:55:11 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-28 14:55:11 --> Config Class Initialized
INFO - 2021-04-28 14:55:11 --> Hooks Class Initialized
DEBUG - 2021-04-28 14:55:11 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:55:11 --> Utf8 Class Initialized
INFO - 2021-04-28 14:55:11 --> URI Class Initialized
INFO - 2021-04-28 14:55:11 --> Router Class Initialized
INFO - 2021-04-28 14:55:11 --> Output Class Initialized
INFO - 2021-04-28 14:55:11 --> Security Class Initialized
DEBUG - 2021-04-28 14:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:55:11 --> Input Class Initialized
INFO - 2021-04-28 14:55:11 --> Language Class Initialized
ERROR - 2021-04-28 14:55:11 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-28 14:55:27 --> Config Class Initialized
INFO - 2021-04-28 14:55:27 --> Hooks Class Initialized
DEBUG - 2021-04-28 14:55:27 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:55:27 --> Utf8 Class Initialized
INFO - 2021-04-28 14:55:27 --> URI Class Initialized
INFO - 2021-04-28 14:55:27 --> Router Class Initialized
INFO - 2021-04-28 14:55:27 --> Output Class Initialized
INFO - 2021-04-28 14:55:27 --> Security Class Initialized
DEBUG - 2021-04-28 14:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:55:27 --> Input Class Initialized
INFO - 2021-04-28 14:55:27 --> Language Class Initialized
ERROR - 2021-04-28 14:55:27 --> 404 Page Not Found: Administratir/UserController
INFO - 2021-04-28 14:55:42 --> Config Class Initialized
INFO - 2021-04-28 14:55:42 --> Hooks Class Initialized
DEBUG - 2021-04-28 14:55:42 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:55:42 --> Utf8 Class Initialized
INFO - 2021-04-28 14:55:42 --> URI Class Initialized
DEBUG - 2021-04-28 14:55:42 --> No URI present. Default controller set.
INFO - 2021-04-28 14:55:42 --> Router Class Initialized
INFO - 2021-04-28 14:55:42 --> Output Class Initialized
INFO - 2021-04-28 14:55:42 --> Security Class Initialized
DEBUG - 2021-04-28 14:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:55:42 --> Input Class Initialized
INFO - 2021-04-28 14:55:42 --> Language Class Initialized
INFO - 2021-04-28 14:55:42 --> Loader Class Initialized
INFO - 2021-04-28 14:55:42 --> Helper loaded: url_helper
INFO - 2021-04-28 14:55:42 --> Helper loaded: form_helper
INFO - 2021-04-28 14:55:42 --> Helper loaded: common_helper
INFO - 2021-04-28 14:55:42 --> Helper loaded: util_helper
INFO - 2021-04-28 14:55:42 --> Helper loaded: user_helper
INFO - 2021-04-28 14:55:42 --> Database Driver Class Initialized
DEBUG - 2021-04-28 14:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 14:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 14:55:42 --> Form Validation Class Initialized
INFO - 2021-04-28 14:55:42 --> Controller Class Initialized
INFO - 2021-04-28 14:55:42 --> Model Class Initialized
INFO - 2021-04-28 14:55:42 --> Model Class Initialized
INFO - 2021-04-28 14:55:42 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-28 14:55:42 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-28 14:55:42 --> Final output sent to browser
DEBUG - 2021-04-28 14:55:42 --> Total execution time: 0.0288
INFO - 2021-04-28 14:55:45 --> Config Class Initialized
INFO - 2021-04-28 14:55:45 --> Hooks Class Initialized
DEBUG - 2021-04-28 14:55:45 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:55:45 --> Utf8 Class Initialized
INFO - 2021-04-28 14:55:45 --> URI Class Initialized
INFO - 2021-04-28 14:55:45 --> Router Class Initialized
INFO - 2021-04-28 14:55:45 --> Output Class Initialized
INFO - 2021-04-28 14:55:45 --> Security Class Initialized
DEBUG - 2021-04-28 14:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:55:45 --> Input Class Initialized
INFO - 2021-04-28 14:55:45 --> Language Class Initialized
INFO - 2021-04-28 14:55:45 --> Loader Class Initialized
INFO - 2021-04-28 14:55:45 --> Helper loaded: url_helper
INFO - 2021-04-28 14:55:45 --> Helper loaded: form_helper
INFO - 2021-04-28 14:55:45 --> Helper loaded: common_helper
INFO - 2021-04-28 14:55:45 --> Helper loaded: util_helper
INFO - 2021-04-28 14:55:45 --> Helper loaded: user_helper
INFO - 2021-04-28 14:55:45 --> Database Driver Class Initialized
DEBUG - 2021-04-28 14:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 14:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 14:55:45 --> Form Validation Class Initialized
INFO - 2021-04-28 14:55:45 --> Controller Class Initialized
INFO - 2021-04-28 14:55:45 --> Model Class Initialized
INFO - 2021-04-28 14:55:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 14:55:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 14:55:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 14:55:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 14:55:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 14:55:45 --> Final output sent to browser
DEBUG - 2021-04-28 14:55:45 --> Total execution time: 0.1136
INFO - 2021-04-28 14:55:46 --> Config Class Initialized
INFO - 2021-04-28 14:55:46 --> Hooks Class Initialized
INFO - 2021-04-28 14:55:46 --> Config Class Initialized
INFO - 2021-04-28 14:55:46 --> Config Class Initialized
INFO - 2021-04-28 14:55:46 --> Hooks Class Initialized
INFO - 2021-04-28 14:55:46 --> Hooks Class Initialized
DEBUG - 2021-04-28 14:55:46 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:55:46 --> Utf8 Class Initialized
INFO - 2021-04-28 14:55:46 --> URI Class Initialized
DEBUG - 2021-04-28 14:55:46 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:55:46 --> Utf8 Class Initialized
INFO - 2021-04-28 14:55:46 --> Router Class Initialized
INFO - 2021-04-28 14:55:46 --> URI Class Initialized
DEBUG - 2021-04-28 14:55:46 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:55:46 --> Utf8 Class Initialized
INFO - 2021-04-28 14:55:46 --> Output Class Initialized
INFO - 2021-04-28 14:55:46 --> Router Class Initialized
INFO - 2021-04-28 14:55:46 --> URI Class Initialized
INFO - 2021-04-28 14:55:46 --> Security Class Initialized
INFO - 2021-04-28 14:55:46 --> Output Class Initialized
INFO - 2021-04-28 14:55:46 --> Router Class Initialized
DEBUG - 2021-04-28 14:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:55:46 --> Input Class Initialized
INFO - 2021-04-28 14:55:46 --> Security Class Initialized
INFO - 2021-04-28 14:55:46 --> Language Class Initialized
INFO - 2021-04-28 14:55:46 --> Output Class Initialized
DEBUG - 2021-04-28 14:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:55:46 --> Input Class Initialized
ERROR - 2021-04-28 14:55:46 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 14:55:46 --> Language Class Initialized
INFO - 2021-04-28 14:55:46 --> Security Class Initialized
ERROR - 2021-04-28 14:55:46 --> 404 Page Not Found: administrator/UserController/dist
DEBUG - 2021-04-28 14:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:55:46 --> Config Class Initialized
INFO - 2021-04-28 14:55:46 --> Input Class Initialized
INFO - 2021-04-28 14:55:46 --> Hooks Class Initialized
INFO - 2021-04-28 14:55:46 --> Language Class Initialized
DEBUG - 2021-04-28 14:55:46 --> UTF-8 Support Enabled
ERROR - 2021-04-28 14:55:46 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 14:55:46 --> Utf8 Class Initialized
INFO - 2021-04-28 14:55:46 --> URI Class Initialized
INFO - 2021-04-28 14:55:46 --> Router Class Initialized
INFO - 2021-04-28 14:55:46 --> Output Class Initialized
INFO - 2021-04-28 14:55:46 --> Security Class Initialized
DEBUG - 2021-04-28 14:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:55:46 --> Input Class Initialized
INFO - 2021-04-28 14:55:46 --> Language Class Initialized
ERROR - 2021-04-28 14:55:46 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 14:55:50 --> Config Class Initialized
INFO - 2021-04-28 14:55:50 --> Hooks Class Initialized
DEBUG - 2021-04-28 14:55:50 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:55:50 --> Utf8 Class Initialized
INFO - 2021-04-28 14:55:50 --> URI Class Initialized
INFO - 2021-04-28 14:55:50 --> Router Class Initialized
INFO - 2021-04-28 14:55:50 --> Output Class Initialized
INFO - 2021-04-28 14:55:50 --> Security Class Initialized
DEBUG - 2021-04-28 14:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:55:50 --> Input Class Initialized
INFO - 2021-04-28 14:55:50 --> Language Class Initialized
INFO - 2021-04-28 14:55:50 --> Loader Class Initialized
INFO - 2021-04-28 14:55:50 --> Helper loaded: url_helper
INFO - 2021-04-28 14:55:50 --> Helper loaded: form_helper
INFO - 2021-04-28 14:55:50 --> Helper loaded: common_helper
INFO - 2021-04-28 14:55:50 --> Helper loaded: util_helper
INFO - 2021-04-28 14:55:50 --> Helper loaded: user_helper
INFO - 2021-04-28 14:55:50 --> Database Driver Class Initialized
DEBUG - 2021-04-28 14:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 14:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 14:55:50 --> Form Validation Class Initialized
INFO - 2021-04-28 14:55:50 --> Controller Class Initialized
INFO - 2021-04-28 14:55:50 --> Model Class Initialized
INFO - 2021-04-28 14:55:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 14:55:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 14:55:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/addUser.php
INFO - 2021-04-28 14:55:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 14:55:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 14:55:50 --> Final output sent to browser
DEBUG - 2021-04-28 14:55:50 --> Total execution time: 0.0306
INFO - 2021-04-28 14:55:50 --> Config Class Initialized
INFO - 2021-04-28 14:55:50 --> Hooks Class Initialized
DEBUG - 2021-04-28 14:55:50 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:55:50 --> Utf8 Class Initialized
INFO - 2021-04-28 14:55:50 --> URI Class Initialized
INFO - 2021-04-28 14:55:50 --> Router Class Initialized
INFO - 2021-04-28 14:55:50 --> Output Class Initialized
INFO - 2021-04-28 14:55:50 --> Security Class Initialized
DEBUG - 2021-04-28 14:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:55:50 --> Input Class Initialized
INFO - 2021-04-28 14:55:50 --> Language Class Initialized
ERROR - 2021-04-28 14:55:50 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 14:55:50 --> Config Class Initialized
INFO - 2021-04-28 14:55:50 --> Hooks Class Initialized
DEBUG - 2021-04-28 14:55:50 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:55:50 --> Utf8 Class Initialized
INFO - 2021-04-28 14:55:50 --> URI Class Initialized
INFO - 2021-04-28 14:55:50 --> Router Class Initialized
INFO - 2021-04-28 14:55:50 --> Output Class Initialized
INFO - 2021-04-28 14:55:50 --> Security Class Initialized
INFO - 2021-04-28 14:55:50 --> Config Class Initialized
DEBUG - 2021-04-28 14:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:55:50 --> Hooks Class Initialized
INFO - 2021-04-28 14:55:50 --> Input Class Initialized
INFO - 2021-04-28 14:55:50 --> Language Class Initialized
DEBUG - 2021-04-28 14:55:50 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:55:50 --> Utf8 Class Initialized
ERROR - 2021-04-28 14:55:50 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 14:55:50 --> URI Class Initialized
INFO - 2021-04-28 14:55:50 --> Router Class Initialized
INFO - 2021-04-28 14:55:50 --> Config Class Initialized
INFO - 2021-04-28 14:55:50 --> Hooks Class Initialized
INFO - 2021-04-28 14:55:50 --> Output Class Initialized
INFO - 2021-04-28 14:55:50 --> Security Class Initialized
DEBUG - 2021-04-28 14:55:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-28 14:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:55:50 --> Input Class Initialized
INFO - 2021-04-28 14:55:50 --> Utf8 Class Initialized
INFO - 2021-04-28 14:55:50 --> Language Class Initialized
INFO - 2021-04-28 14:55:50 --> URI Class Initialized
ERROR - 2021-04-28 14:55:50 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 14:55:50 --> Router Class Initialized
INFO - 2021-04-28 14:55:50 --> Output Class Initialized
INFO - 2021-04-28 14:55:50 --> Security Class Initialized
DEBUG - 2021-04-28 14:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:55:50 --> Input Class Initialized
INFO - 2021-04-28 14:55:50 --> Language Class Initialized
ERROR - 2021-04-28 14:55:50 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 14:55:56 --> Config Class Initialized
INFO - 2021-04-28 14:55:56 --> Hooks Class Initialized
DEBUG - 2021-04-28 14:55:56 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:55:56 --> Utf8 Class Initialized
INFO - 2021-04-28 14:55:56 --> URI Class Initialized
INFO - 2021-04-28 14:55:56 --> Router Class Initialized
INFO - 2021-04-28 14:55:56 --> Output Class Initialized
INFO - 2021-04-28 14:55:56 --> Security Class Initialized
DEBUG - 2021-04-28 14:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:55:56 --> Input Class Initialized
INFO - 2021-04-28 14:55:56 --> Language Class Initialized
INFO - 2021-04-28 14:55:56 --> Loader Class Initialized
INFO - 2021-04-28 14:55:56 --> Helper loaded: url_helper
INFO - 2021-04-28 14:55:56 --> Helper loaded: form_helper
INFO - 2021-04-28 14:55:56 --> Helper loaded: common_helper
INFO - 2021-04-28 14:55:56 --> Helper loaded: util_helper
INFO - 2021-04-28 14:55:56 --> Helper loaded: user_helper
INFO - 2021-04-28 14:55:56 --> Database Driver Class Initialized
DEBUG - 2021-04-28 14:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 14:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 14:55:56 --> Form Validation Class Initialized
INFO - 2021-04-28 14:55:56 --> Controller Class Initialized
INFO - 2021-04-28 14:55:56 --> Model Class Initialized
INFO - 2021-04-28 14:55:56 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 14:55:56 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 14:55:56 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 14:55:56 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 14:55:56 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 14:55:56 --> Final output sent to browser
DEBUG - 2021-04-28 14:55:56 --> Total execution time: 0.0309
INFO - 2021-04-28 14:56:02 --> Config Class Initialized
INFO - 2021-04-28 14:56:02 --> Hooks Class Initialized
DEBUG - 2021-04-28 14:56:02 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:56:02 --> Utf8 Class Initialized
INFO - 2021-04-28 14:56:02 --> URI Class Initialized
INFO - 2021-04-28 14:56:02 --> Router Class Initialized
INFO - 2021-04-28 14:56:02 --> Output Class Initialized
INFO - 2021-04-28 14:56:02 --> Security Class Initialized
DEBUG - 2021-04-28 14:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:56:02 --> Input Class Initialized
INFO - 2021-04-28 14:56:02 --> Language Class Initialized
INFO - 2021-04-28 14:56:02 --> Loader Class Initialized
INFO - 2021-04-28 14:56:02 --> Helper loaded: url_helper
INFO - 2021-04-28 14:56:02 --> Helper loaded: form_helper
INFO - 2021-04-28 14:56:02 --> Helper loaded: common_helper
INFO - 2021-04-28 14:56:02 --> Helper loaded: util_helper
INFO - 2021-04-28 14:56:02 --> Helper loaded: user_helper
INFO - 2021-04-28 14:56:02 --> Database Driver Class Initialized
DEBUG - 2021-04-28 14:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 14:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 14:56:02 --> Form Validation Class Initialized
INFO - 2021-04-28 14:56:02 --> Controller Class Initialized
INFO - 2021-04-28 14:56:02 --> Model Class Initialized
INFO - 2021-04-28 14:56:02 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 14:56:02 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 14:56:02 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/editUser.php
INFO - 2021-04-28 14:56:02 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 14:56:02 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 14:56:02 --> Final output sent to browser
DEBUG - 2021-04-28 14:56:02 --> Total execution time: 0.0310
INFO - 2021-04-28 14:56:02 --> Config Class Initialized
INFO - 2021-04-28 14:56:02 --> Hooks Class Initialized
INFO - 2021-04-28 14:56:02 --> Config Class Initialized
INFO - 2021-04-28 14:56:02 --> Hooks Class Initialized
DEBUG - 2021-04-28 14:56:02 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:56:02 --> Utf8 Class Initialized
DEBUG - 2021-04-28 14:56:02 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:56:02 --> Utf8 Class Initialized
INFO - 2021-04-28 14:56:02 --> URI Class Initialized
INFO - 2021-04-28 14:56:02 --> URI Class Initialized
INFO - 2021-04-28 14:56:02 --> Router Class Initialized
INFO - 2021-04-28 14:56:02 --> Router Class Initialized
INFO - 2021-04-28 14:56:02 --> Output Class Initialized
INFO - 2021-04-28 14:56:02 --> Output Class Initialized
INFO - 2021-04-28 14:56:02 --> Security Class Initialized
INFO - 2021-04-28 14:56:02 --> Security Class Initialized
DEBUG - 2021-04-28 14:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-28 14:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:56:02 --> Input Class Initialized
INFO - 2021-04-28 14:56:02 --> Input Class Initialized
INFO - 2021-04-28 14:56:02 --> Language Class Initialized
INFO - 2021-04-28 14:56:02 --> Language Class Initialized
ERROR - 2021-04-28 14:56:02 --> 404 Page Not Found: UserController/update
ERROR - 2021-04-28 14:56:02 --> 404 Page Not Found: UserController/update
INFO - 2021-04-28 14:56:02 --> Config Class Initialized
INFO - 2021-04-28 14:56:02 --> Config Class Initialized
INFO - 2021-04-28 14:56:02 --> Hooks Class Initialized
INFO - 2021-04-28 14:56:02 --> Hooks Class Initialized
DEBUG - 2021-04-28 14:56:02 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:56:02 --> Utf8 Class Initialized
DEBUG - 2021-04-28 14:56:02 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:56:02 --> Utf8 Class Initialized
INFO - 2021-04-28 14:56:02 --> URI Class Initialized
INFO - 2021-04-28 14:56:02 --> URI Class Initialized
INFO - 2021-04-28 14:56:02 --> Router Class Initialized
INFO - 2021-04-28 14:56:02 --> Router Class Initialized
INFO - 2021-04-28 14:56:02 --> Output Class Initialized
INFO - 2021-04-28 14:56:02 --> Output Class Initialized
INFO - 2021-04-28 14:56:02 --> Security Class Initialized
INFO - 2021-04-28 14:56:02 --> Security Class Initialized
DEBUG - 2021-04-28 14:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-28 14:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:56:02 --> Input Class Initialized
INFO - 2021-04-28 14:56:02 --> Input Class Initialized
INFO - 2021-04-28 14:56:02 --> Language Class Initialized
INFO - 2021-04-28 14:56:02 --> Language Class Initialized
ERROR - 2021-04-28 14:56:02 --> 404 Page Not Found: UserController/update
ERROR - 2021-04-28 14:56:02 --> 404 Page Not Found: UserController/update
INFO - 2021-04-28 14:56:09 --> Config Class Initialized
INFO - 2021-04-28 14:56:09 --> Hooks Class Initialized
DEBUG - 2021-04-28 14:56:09 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:56:09 --> Utf8 Class Initialized
INFO - 2021-04-28 14:56:09 --> URI Class Initialized
INFO - 2021-04-28 14:56:09 --> Router Class Initialized
INFO - 2021-04-28 14:56:09 --> Output Class Initialized
INFO - 2021-04-28 14:56:09 --> Security Class Initialized
DEBUG - 2021-04-28 14:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:56:09 --> Input Class Initialized
INFO - 2021-04-28 14:56:09 --> Language Class Initialized
INFO - 2021-04-28 14:56:09 --> Loader Class Initialized
INFO - 2021-04-28 14:56:09 --> Helper loaded: url_helper
INFO - 2021-04-28 14:56:09 --> Helper loaded: form_helper
INFO - 2021-04-28 14:56:09 --> Helper loaded: common_helper
INFO - 2021-04-28 14:56:09 --> Helper loaded: util_helper
INFO - 2021-04-28 14:56:09 --> Helper loaded: user_helper
INFO - 2021-04-28 14:56:09 --> Database Driver Class Initialized
DEBUG - 2021-04-28 14:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 14:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 14:56:09 --> Form Validation Class Initialized
INFO - 2021-04-28 14:56:09 --> Controller Class Initialized
INFO - 2021-04-28 14:56:09 --> Model Class Initialized
INFO - 2021-04-28 14:56:09 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 14:56:09 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 14:56:09 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 14:56:09 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 14:56:09 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 14:56:09 --> Final output sent to browser
DEBUG - 2021-04-28 14:56:09 --> Total execution time: 0.0322
INFO - 2021-04-28 14:56:45 --> Config Class Initialized
INFO - 2021-04-28 14:56:45 --> Hooks Class Initialized
DEBUG - 2021-04-28 14:56:45 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:56:45 --> Utf8 Class Initialized
INFO - 2021-04-28 14:56:45 --> URI Class Initialized
INFO - 2021-04-28 14:56:45 --> Router Class Initialized
INFO - 2021-04-28 14:56:45 --> Output Class Initialized
INFO - 2021-04-28 14:56:45 --> Security Class Initialized
DEBUG - 2021-04-28 14:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:56:45 --> Input Class Initialized
INFO - 2021-04-28 14:56:45 --> Language Class Initialized
INFO - 2021-04-28 14:56:45 --> Loader Class Initialized
INFO - 2021-04-28 14:56:45 --> Helper loaded: url_helper
INFO - 2021-04-28 14:56:45 --> Helper loaded: form_helper
INFO - 2021-04-28 14:56:45 --> Helper loaded: common_helper
INFO - 2021-04-28 14:56:45 --> Helper loaded: util_helper
INFO - 2021-04-28 14:56:45 --> Helper loaded: user_helper
INFO - 2021-04-28 14:56:45 --> Database Driver Class Initialized
DEBUG - 2021-04-28 14:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 14:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 14:56:45 --> Form Validation Class Initialized
INFO - 2021-04-28 14:56:45 --> Controller Class Initialized
INFO - 2021-04-28 14:56:45 --> Model Class Initialized
INFO - 2021-04-28 14:56:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 14:56:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 14:56:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 14:56:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 14:56:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 14:56:45 --> Final output sent to browser
DEBUG - 2021-04-28 14:56:45 --> Total execution time: 0.0334
INFO - 2021-04-28 14:56:45 --> Config Class Initialized
INFO - 2021-04-28 14:56:45 --> Config Class Initialized
INFO - 2021-04-28 14:56:45 --> Hooks Class Initialized
INFO - 2021-04-28 14:56:45 --> Hooks Class Initialized
DEBUG - 2021-04-28 14:56:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-28 14:56:45 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:56:45 --> Utf8 Class Initialized
INFO - 2021-04-28 14:56:45 --> Utf8 Class Initialized
INFO - 2021-04-28 14:56:45 --> URI Class Initialized
INFO - 2021-04-28 14:56:45 --> URI Class Initialized
INFO - 2021-04-28 14:56:45 --> Router Class Initialized
INFO - 2021-04-28 14:56:45 --> Output Class Initialized
INFO - 2021-04-28 14:56:45 --> Router Class Initialized
INFO - 2021-04-28 14:56:45 --> Security Class Initialized
INFO - 2021-04-28 14:56:45 --> Output Class Initialized
DEBUG - 2021-04-28 14:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:56:45 --> Input Class Initialized
INFO - 2021-04-28 14:56:45 --> Security Class Initialized
INFO - 2021-04-28 14:56:45 --> Language Class Initialized
DEBUG - 2021-04-28 14:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:56:45 --> Config Class Initialized
INFO - 2021-04-28 14:56:45 --> Input Class Initialized
INFO - 2021-04-28 14:56:45 --> Hooks Class Initialized
INFO - 2021-04-28 14:56:45 --> Language Class Initialized
ERROR - 2021-04-28 14:56:45 --> 404 Page Not Found: administrator/UserController/dist
DEBUG - 2021-04-28 14:56:45 --> UTF-8 Support Enabled
ERROR - 2021-04-28 14:56:45 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 14:56:45 --> Utf8 Class Initialized
INFO - 2021-04-28 14:56:45 --> URI Class Initialized
INFO - 2021-04-28 14:56:45 --> Router Class Initialized
INFO - 2021-04-28 14:56:45 --> Output Class Initialized
INFO - 2021-04-28 14:56:45 --> Security Class Initialized
DEBUG - 2021-04-28 14:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:56:45 --> Input Class Initialized
INFO - 2021-04-28 14:56:45 --> Language Class Initialized
ERROR - 2021-04-28 14:56:45 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 14:56:45 --> Config Class Initialized
INFO - 2021-04-28 14:56:45 --> Hooks Class Initialized
DEBUG - 2021-04-28 14:56:45 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:56:45 --> Utf8 Class Initialized
INFO - 2021-04-28 14:56:45 --> URI Class Initialized
INFO - 2021-04-28 14:56:45 --> Router Class Initialized
INFO - 2021-04-28 14:56:45 --> Output Class Initialized
INFO - 2021-04-28 14:56:45 --> Security Class Initialized
DEBUG - 2021-04-28 14:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:56:45 --> Input Class Initialized
INFO - 2021-04-28 14:56:45 --> Language Class Initialized
ERROR - 2021-04-28 14:56:45 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 14:56:47 --> Config Class Initialized
INFO - 2021-04-28 14:56:47 --> Hooks Class Initialized
DEBUG - 2021-04-28 14:56:47 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:56:47 --> Utf8 Class Initialized
INFO - 2021-04-28 14:56:47 --> URI Class Initialized
INFO - 2021-04-28 14:56:47 --> Router Class Initialized
INFO - 2021-04-28 14:56:47 --> Output Class Initialized
INFO - 2021-04-28 14:56:47 --> Security Class Initialized
DEBUG - 2021-04-28 14:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:56:47 --> Input Class Initialized
INFO - 2021-04-28 14:56:47 --> Language Class Initialized
INFO - 2021-04-28 14:56:47 --> Loader Class Initialized
INFO - 2021-04-28 14:56:47 --> Helper loaded: url_helper
INFO - 2021-04-28 14:56:47 --> Helper loaded: form_helper
INFO - 2021-04-28 14:56:47 --> Helper loaded: common_helper
INFO - 2021-04-28 14:56:47 --> Helper loaded: util_helper
INFO - 2021-04-28 14:56:47 --> Helper loaded: user_helper
INFO - 2021-04-28 14:56:47 --> Database Driver Class Initialized
DEBUG - 2021-04-28 14:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 14:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 14:56:47 --> Form Validation Class Initialized
INFO - 2021-04-28 14:56:47 --> Controller Class Initialized
INFO - 2021-04-28 14:56:47 --> Model Class Initialized
INFO - 2021-04-28 14:56:47 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 14:56:47 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 14:56:47 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/editUser.php
INFO - 2021-04-28 14:56:47 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 14:56:47 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 14:56:47 --> Final output sent to browser
DEBUG - 2021-04-28 14:56:47 --> Total execution time: 0.0319
INFO - 2021-04-28 14:56:47 --> Config Class Initialized
INFO - 2021-04-28 14:56:47 --> Hooks Class Initialized
INFO - 2021-04-28 14:56:47 --> Config Class Initialized
INFO - 2021-04-28 14:56:47 --> Hooks Class Initialized
DEBUG - 2021-04-28 14:56:47 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:56:47 --> Utf8 Class Initialized
INFO - 2021-04-28 14:56:47 --> URI Class Initialized
INFO - 2021-04-28 14:56:47 --> Router Class Initialized
INFO - 2021-04-28 14:56:47 --> Output Class Initialized
INFO - 2021-04-28 14:56:47 --> Security Class Initialized
DEBUG - 2021-04-28 14:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:56:47 --> Input Class Initialized
INFO - 2021-04-28 14:56:47 --> Language Class Initialized
ERROR - 2021-04-28 14:56:47 --> 404 Page Not Found: UserController/update
INFO - 2021-04-28 14:56:47 --> Config Class Initialized
INFO - 2021-04-28 14:56:47 --> Config Class Initialized
INFO - 2021-04-28 14:56:47 --> Hooks Class Initialized
INFO - 2021-04-28 14:56:47 --> Hooks Class Initialized
DEBUG - 2021-04-28 14:56:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-28 14:56:47 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:56:47 --> Utf8 Class Initialized
INFO - 2021-04-28 14:56:47 --> Utf8 Class Initialized
INFO - 2021-04-28 14:56:47 --> URI Class Initialized
INFO - 2021-04-28 14:56:47 --> URI Class Initialized
INFO - 2021-04-28 14:56:47 --> Router Class Initialized
INFO - 2021-04-28 14:56:47 --> Router Class Initialized
INFO - 2021-04-28 14:56:47 --> Output Class Initialized
INFO - 2021-04-28 14:56:47 --> Output Class Initialized
INFO - 2021-04-28 14:56:47 --> Security Class Initialized
INFO - 2021-04-28 14:56:47 --> Security Class Initialized
DEBUG - 2021-04-28 14:56:47 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:56:47 --> Utf8 Class Initialized
DEBUG - 2021-04-28 14:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-28 14:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:56:47 --> Input Class Initialized
INFO - 2021-04-28 14:56:47 --> Input Class Initialized
INFO - 2021-04-28 14:56:47 --> URI Class Initialized
INFO - 2021-04-28 14:56:47 --> Language Class Initialized
INFO - 2021-04-28 14:56:47 --> Language Class Initialized
INFO - 2021-04-28 14:56:47 --> Router Class Initialized
ERROR - 2021-04-28 14:56:47 --> 404 Page Not Found: UserController/update
ERROR - 2021-04-28 14:56:47 --> 404 Page Not Found: UserController/update
INFO - 2021-04-28 14:56:47 --> Output Class Initialized
INFO - 2021-04-28 14:56:47 --> Security Class Initialized
DEBUG - 2021-04-28 14:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:56:47 --> Input Class Initialized
INFO - 2021-04-28 14:56:47 --> Language Class Initialized
ERROR - 2021-04-28 14:56:47 --> 404 Page Not Found: UserController/update
INFO - 2021-04-28 14:56:49 --> Config Class Initialized
INFO - 2021-04-28 14:56:49 --> Hooks Class Initialized
DEBUG - 2021-04-28 14:56:49 --> UTF-8 Support Enabled
INFO - 2021-04-28 14:56:49 --> Utf8 Class Initialized
INFO - 2021-04-28 14:56:49 --> URI Class Initialized
INFO - 2021-04-28 14:56:49 --> Router Class Initialized
INFO - 2021-04-28 14:56:49 --> Output Class Initialized
INFO - 2021-04-28 14:56:49 --> Security Class Initialized
DEBUG - 2021-04-28 14:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 14:56:49 --> Input Class Initialized
INFO - 2021-04-28 14:56:49 --> Language Class Initialized
INFO - 2021-04-28 14:56:49 --> Loader Class Initialized
INFO - 2021-04-28 14:56:49 --> Helper loaded: url_helper
INFO - 2021-04-28 14:56:49 --> Helper loaded: form_helper
INFO - 2021-04-28 14:56:49 --> Helper loaded: common_helper
INFO - 2021-04-28 14:56:49 --> Helper loaded: util_helper
INFO - 2021-04-28 14:56:49 --> Helper loaded: user_helper
INFO - 2021-04-28 14:56:49 --> Database Driver Class Initialized
DEBUG - 2021-04-28 14:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 14:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 14:56:49 --> Form Validation Class Initialized
INFO - 2021-04-28 14:56:49 --> Controller Class Initialized
INFO - 2021-04-28 14:56:49 --> Model Class Initialized
INFO - 2021-04-28 14:56:49 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 14:56:49 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 14:56:49 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 14:56:49 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 14:56:49 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 14:56:49 --> Final output sent to browser
DEBUG - 2021-04-28 14:56:49 --> Total execution time: 0.0748
INFO - 2021-04-28 15:01:20 --> Config Class Initialized
INFO - 2021-04-28 15:01:20 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:01:20 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:20 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:20 --> URI Class Initialized
INFO - 2021-04-28 15:01:20 --> Router Class Initialized
INFO - 2021-04-28 15:01:20 --> Output Class Initialized
INFO - 2021-04-28 15:01:20 --> Security Class Initialized
DEBUG - 2021-04-28 15:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:20 --> Input Class Initialized
INFO - 2021-04-28 15:01:20 --> Language Class Initialized
INFO - 2021-04-28 15:01:20 --> Loader Class Initialized
INFO - 2021-04-28 15:01:20 --> Helper loaded: url_helper
INFO - 2021-04-28 15:01:20 --> Helper loaded: form_helper
INFO - 2021-04-28 15:01:20 --> Helper loaded: common_helper
INFO - 2021-04-28 15:01:20 --> Helper loaded: util_helper
INFO - 2021-04-28 15:01:20 --> Helper loaded: user_helper
INFO - 2021-04-28 15:01:20 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:01:20 --> Form Validation Class Initialized
INFO - 2021-04-28 15:01:20 --> Controller Class Initialized
INFO - 2021-04-28 15:01:20 --> Model Class Initialized
INFO - 2021-04-28 15:01:20 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:01:20 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:01:20 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 15:01:20 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:01:20 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:01:20 --> Final output sent to browser
DEBUG - 2021-04-28 15:01:20 --> Total execution time: 0.0389
INFO - 2021-04-28 15:01:20 --> Config Class Initialized
INFO - 2021-04-28 15:01:20 --> Hooks Class Initialized
INFO - 2021-04-28 15:01:20 --> Config Class Initialized
INFO - 2021-04-28 15:01:20 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:01:20 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:20 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:20 --> URI Class Initialized
DEBUG - 2021-04-28 15:01:20 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:20 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:20 --> Router Class Initialized
INFO - 2021-04-28 15:01:20 --> URI Class Initialized
INFO - 2021-04-28 15:01:20 --> Output Class Initialized
INFO - 2021-04-28 15:01:20 --> Router Class Initialized
INFO - 2021-04-28 15:01:20 --> Security Class Initialized
INFO - 2021-04-28 15:01:20 --> Output Class Initialized
DEBUG - 2021-04-28 15:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:20 --> Input Class Initialized
INFO - 2021-04-28 15:01:20 --> Language Class Initialized
INFO - 2021-04-28 15:01:20 --> Security Class Initialized
DEBUG - 2021-04-28 15:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:20 --> Input Class Initialized
INFO - 2021-04-28 15:01:20 --> Language Class Initialized
ERROR - 2021-04-28 15:01:20 --> 404 Page Not Found: administrator/UserController/dist
ERROR - 2021-04-28 15:01:20 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:01:20 --> Config Class Initialized
INFO - 2021-04-28 15:01:20 --> Config Class Initialized
INFO - 2021-04-28 15:01:20 --> Hooks Class Initialized
INFO - 2021-04-28 15:01:20 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:01:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-28 15:01:20 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:20 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:20 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:20 --> URI Class Initialized
INFO - 2021-04-28 15:01:20 --> URI Class Initialized
INFO - 2021-04-28 15:01:20 --> Router Class Initialized
INFO - 2021-04-28 15:01:20 --> Router Class Initialized
INFO - 2021-04-28 15:01:20 --> Output Class Initialized
INFO - 2021-04-28 15:01:20 --> Output Class Initialized
INFO - 2021-04-28 15:01:20 --> Security Class Initialized
INFO - 2021-04-28 15:01:20 --> Security Class Initialized
DEBUG - 2021-04-28 15:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-28 15:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:20 --> Input Class Initialized
INFO - 2021-04-28 15:01:20 --> Input Class Initialized
INFO - 2021-04-28 15:01:20 --> Language Class Initialized
INFO - 2021-04-28 15:01:20 --> Language Class Initialized
ERROR - 2021-04-28 15:01:20 --> 404 Page Not Found: administrator/UserController/dist
ERROR - 2021-04-28 15:01:20 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:01:41 --> Config Class Initialized
INFO - 2021-04-28 15:01:41 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:01:41 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:41 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:41 --> URI Class Initialized
INFO - 2021-04-28 15:01:41 --> Router Class Initialized
INFO - 2021-04-28 15:01:41 --> Output Class Initialized
INFO - 2021-04-28 15:01:41 --> Security Class Initialized
DEBUG - 2021-04-28 15:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:41 --> Input Class Initialized
INFO - 2021-04-28 15:01:41 --> Language Class Initialized
INFO - 2021-04-28 15:01:41 --> Loader Class Initialized
INFO - 2021-04-28 15:01:41 --> Helper loaded: url_helper
INFO - 2021-04-28 15:01:41 --> Helper loaded: form_helper
INFO - 2021-04-28 15:01:41 --> Helper loaded: common_helper
INFO - 2021-04-28 15:01:41 --> Helper loaded: util_helper
INFO - 2021-04-28 15:01:41 --> Helper loaded: user_helper
INFO - 2021-04-28 15:01:41 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:01:41 --> Form Validation Class Initialized
INFO - 2021-04-28 15:01:41 --> Controller Class Initialized
INFO - 2021-04-28 15:01:41 --> Model Class Initialized
INFO - 2021-04-28 15:01:41 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:01:41 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:01:41 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 15:01:41 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:01:41 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:01:41 --> Final output sent to browser
DEBUG - 2021-04-28 15:01:41 --> Total execution time: 0.0356
INFO - 2021-04-28 15:01:41 --> Config Class Initialized
INFO - 2021-04-28 15:01:41 --> Hooks Class Initialized
INFO - 2021-04-28 15:01:41 --> Config Class Initialized
DEBUG - 2021-04-28 15:01:41 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:41 --> Hooks Class Initialized
INFO - 2021-04-28 15:01:41 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:41 --> URI Class Initialized
DEBUG - 2021-04-28 15:01:41 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:41 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:41 --> Router Class Initialized
INFO - 2021-04-28 15:01:41 --> URI Class Initialized
INFO - 2021-04-28 15:01:41 --> Output Class Initialized
INFO - 2021-04-28 15:01:41 --> Router Class Initialized
INFO - 2021-04-28 15:01:41 --> Security Class Initialized
INFO - 2021-04-28 15:01:41 --> Output Class Initialized
DEBUG - 2021-04-28 15:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:41 --> Input Class Initialized
INFO - 2021-04-28 15:01:41 --> Language Class Initialized
INFO - 2021-04-28 15:01:41 --> Security Class Initialized
DEBUG - 2021-04-28 15:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:41 --> Input Class Initialized
ERROR - 2021-04-28 15:01:41 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:01:41 --> Language Class Initialized
ERROR - 2021-04-28 15:01:41 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:01:41 --> Config Class Initialized
INFO - 2021-04-28 15:01:41 --> Config Class Initialized
INFO - 2021-04-28 15:01:41 --> Hooks Class Initialized
INFO - 2021-04-28 15:01:41 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:01:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-28 15:01:41 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:41 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:41 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:41 --> URI Class Initialized
INFO - 2021-04-28 15:01:41 --> URI Class Initialized
INFO - 2021-04-28 15:01:41 --> Router Class Initialized
INFO - 2021-04-28 15:01:41 --> Router Class Initialized
INFO - 2021-04-28 15:01:41 --> Output Class Initialized
INFO - 2021-04-28 15:01:41 --> Output Class Initialized
INFO - 2021-04-28 15:01:41 --> Security Class Initialized
INFO - 2021-04-28 15:01:41 --> Security Class Initialized
DEBUG - 2021-04-28 15:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-28 15:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:41 --> Input Class Initialized
INFO - 2021-04-28 15:01:41 --> Input Class Initialized
INFO - 2021-04-28 15:01:41 --> Language Class Initialized
INFO - 2021-04-28 15:01:41 --> Language Class Initialized
ERROR - 2021-04-28 15:01:41 --> 404 Page Not Found: administrator/UserController/dist
ERROR - 2021-04-28 15:01:41 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:01:42 --> Config Class Initialized
INFO - 2021-04-28 15:01:42 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:01:42 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:42 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:42 --> URI Class Initialized
INFO - 2021-04-28 15:01:42 --> Router Class Initialized
INFO - 2021-04-28 15:01:42 --> Output Class Initialized
INFO - 2021-04-28 15:01:42 --> Security Class Initialized
DEBUG - 2021-04-28 15:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:42 --> Input Class Initialized
INFO - 2021-04-28 15:01:42 --> Language Class Initialized
INFO - 2021-04-28 15:01:42 --> Loader Class Initialized
INFO - 2021-04-28 15:01:42 --> Helper loaded: url_helper
INFO - 2021-04-28 15:01:42 --> Helper loaded: form_helper
INFO - 2021-04-28 15:01:42 --> Helper loaded: common_helper
INFO - 2021-04-28 15:01:42 --> Helper loaded: util_helper
INFO - 2021-04-28 15:01:42 --> Helper loaded: user_helper
INFO - 2021-04-28 15:01:42 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:01:42 --> Form Validation Class Initialized
INFO - 2021-04-28 15:01:42 --> Controller Class Initialized
INFO - 2021-04-28 15:01:42 --> Model Class Initialized
INFO - 2021-04-28 15:01:42 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:01:42 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:01:42 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 15:01:42 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:01:42 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:01:42 --> Final output sent to browser
DEBUG - 2021-04-28 15:01:42 --> Total execution time: 0.0384
INFO - 2021-04-28 15:01:42 --> Config Class Initialized
INFO - 2021-04-28 15:01:42 --> Config Class Initialized
INFO - 2021-04-28 15:01:42 --> Hooks Class Initialized
INFO - 2021-04-28 15:01:42 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:01:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-28 15:01:42 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:42 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:42 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:42 --> URI Class Initialized
INFO - 2021-04-28 15:01:42 --> URI Class Initialized
INFO - 2021-04-28 15:01:42 --> Router Class Initialized
INFO - 2021-04-28 15:01:42 --> Router Class Initialized
INFO - 2021-04-28 15:01:42 --> Output Class Initialized
INFO - 2021-04-28 15:01:42 --> Output Class Initialized
INFO - 2021-04-28 15:01:42 --> Security Class Initialized
INFO - 2021-04-28 15:01:42 --> Security Class Initialized
DEBUG - 2021-04-28 15:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-28 15:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:42 --> Input Class Initialized
INFO - 2021-04-28 15:01:42 --> Input Class Initialized
INFO - 2021-04-28 15:01:42 --> Language Class Initialized
INFO - 2021-04-28 15:01:42 --> Language Class Initialized
ERROR - 2021-04-28 15:01:42 --> 404 Page Not Found: administrator/UserController/dist
ERROR - 2021-04-28 15:01:42 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:01:42 --> Config Class Initialized
INFO - 2021-04-28 15:01:42 --> Hooks Class Initialized
INFO - 2021-04-28 15:01:42 --> Config Class Initialized
INFO - 2021-04-28 15:01:42 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:01:42 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:42 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:42 --> URI Class Initialized
DEBUG - 2021-04-28 15:01:42 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:42 --> Router Class Initialized
INFO - 2021-04-28 15:01:42 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:42 --> Output Class Initialized
INFO - 2021-04-28 15:01:42 --> URI Class Initialized
INFO - 2021-04-28 15:01:42 --> Security Class Initialized
DEBUG - 2021-04-28 15:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:42 --> Input Class Initialized
INFO - 2021-04-28 15:01:42 --> Language Class Initialized
INFO - 2021-04-28 15:01:42 --> Router Class Initialized
ERROR - 2021-04-28 15:01:42 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:01:42 --> Output Class Initialized
INFO - 2021-04-28 15:01:42 --> Security Class Initialized
DEBUG - 2021-04-28 15:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:42 --> Input Class Initialized
INFO - 2021-04-28 15:01:42 --> Language Class Initialized
ERROR - 2021-04-28 15:01:42 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:01:43 --> Config Class Initialized
INFO - 2021-04-28 15:01:43 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:01:43 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:43 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:43 --> URI Class Initialized
INFO - 2021-04-28 15:01:43 --> Router Class Initialized
INFO - 2021-04-28 15:01:43 --> Output Class Initialized
INFO - 2021-04-28 15:01:43 --> Security Class Initialized
DEBUG - 2021-04-28 15:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:43 --> Input Class Initialized
INFO - 2021-04-28 15:01:43 --> Language Class Initialized
INFO - 2021-04-28 15:01:43 --> Loader Class Initialized
INFO - 2021-04-28 15:01:43 --> Helper loaded: url_helper
INFO - 2021-04-28 15:01:43 --> Helper loaded: form_helper
INFO - 2021-04-28 15:01:43 --> Helper loaded: common_helper
INFO - 2021-04-28 15:01:43 --> Helper loaded: util_helper
INFO - 2021-04-28 15:01:43 --> Helper loaded: user_helper
INFO - 2021-04-28 15:01:43 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:01:43 --> Form Validation Class Initialized
INFO - 2021-04-28 15:01:43 --> Controller Class Initialized
INFO - 2021-04-28 15:01:43 --> Model Class Initialized
INFO - 2021-04-28 15:01:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:01:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:01:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 15:01:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:01:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:01:43 --> Final output sent to browser
DEBUG - 2021-04-28 15:01:43 --> Total execution time: 0.0361
INFO - 2021-04-28 15:01:43 --> Config Class Initialized
INFO - 2021-04-28 15:01:43 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:01:43 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:43 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:43 --> Config Class Initialized
INFO - 2021-04-28 15:01:43 --> Hooks Class Initialized
INFO - 2021-04-28 15:01:43 --> URI Class Initialized
INFO - 2021-04-28 15:01:43 --> Router Class Initialized
DEBUG - 2021-04-28 15:01:43 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:43 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:43 --> Output Class Initialized
INFO - 2021-04-28 15:01:43 --> URI Class Initialized
INFO - 2021-04-28 15:01:43 --> Security Class Initialized
INFO - 2021-04-28 15:01:43 --> Router Class Initialized
DEBUG - 2021-04-28 15:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:43 --> Input Class Initialized
INFO - 2021-04-28 15:01:43 --> Language Class Initialized
INFO - 2021-04-28 15:01:43 --> Output Class Initialized
INFO - 2021-04-28 15:01:43 --> Security Class Initialized
ERROR - 2021-04-28 15:01:43 --> 404 Page Not Found: administrator/UserController/dist
DEBUG - 2021-04-28 15:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:43 --> Input Class Initialized
INFO - 2021-04-28 15:01:43 --> Language Class Initialized
ERROR - 2021-04-28 15:01:43 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:01:43 --> Config Class Initialized
INFO - 2021-04-28 15:01:43 --> Hooks Class Initialized
INFO - 2021-04-28 15:01:43 --> Config Class Initialized
INFO - 2021-04-28 15:01:43 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:01:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-28 15:01:43 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:43 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:43 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:43 --> URI Class Initialized
INFO - 2021-04-28 15:01:43 --> URI Class Initialized
INFO - 2021-04-28 15:01:43 --> Router Class Initialized
INFO - 2021-04-28 15:01:43 --> Router Class Initialized
INFO - 2021-04-28 15:01:43 --> Output Class Initialized
INFO - 2021-04-28 15:01:43 --> Output Class Initialized
INFO - 2021-04-28 15:01:43 --> Security Class Initialized
INFO - 2021-04-28 15:01:43 --> Security Class Initialized
DEBUG - 2021-04-28 15:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:43 --> Input Class Initialized
INFO - 2021-04-28 15:01:43 --> Language Class Initialized
DEBUG - 2021-04-28 15:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:43 --> Input Class Initialized
INFO - 2021-04-28 15:01:43 --> Language Class Initialized
ERROR - 2021-04-28 15:01:43 --> 404 Page Not Found: administrator/UserController/dist
ERROR - 2021-04-28 15:01:43 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:01:44 --> Config Class Initialized
INFO - 2021-04-28 15:01:44 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:01:44 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:44 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:44 --> URI Class Initialized
INFO - 2021-04-28 15:01:44 --> Router Class Initialized
INFO - 2021-04-28 15:01:44 --> Output Class Initialized
INFO - 2021-04-28 15:01:44 --> Security Class Initialized
DEBUG - 2021-04-28 15:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:44 --> Input Class Initialized
INFO - 2021-04-28 15:01:44 --> Language Class Initialized
INFO - 2021-04-28 15:01:44 --> Loader Class Initialized
INFO - 2021-04-28 15:01:44 --> Helper loaded: url_helper
INFO - 2021-04-28 15:01:44 --> Helper loaded: form_helper
INFO - 2021-04-28 15:01:44 --> Helper loaded: common_helper
INFO - 2021-04-28 15:01:44 --> Helper loaded: util_helper
INFO - 2021-04-28 15:01:44 --> Helper loaded: user_helper
INFO - 2021-04-28 15:01:44 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:01:44 --> Form Validation Class Initialized
INFO - 2021-04-28 15:01:44 --> Controller Class Initialized
INFO - 2021-04-28 15:01:44 --> Model Class Initialized
INFO - 2021-04-28 15:01:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:01:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:01:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 15:01:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:01:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:01:44 --> Final output sent to browser
DEBUG - 2021-04-28 15:01:44 --> Total execution time: 0.0376
INFO - 2021-04-28 15:01:44 --> Config Class Initialized
INFO - 2021-04-28 15:01:44 --> Config Class Initialized
INFO - 2021-04-28 15:01:44 --> Hooks Class Initialized
INFO - 2021-04-28 15:01:44 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:01:44 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:44 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:44 --> URI Class Initialized
INFO - 2021-04-28 15:01:44 --> Router Class Initialized
INFO - 2021-04-28 15:01:44 --> Output Class Initialized
INFO - 2021-04-28 15:01:44 --> Security Class Initialized
DEBUG - 2021-04-28 15:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-28 15:01:44 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:44 --> Config Class Initialized
INFO - 2021-04-28 15:01:44 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:44 --> Hooks Class Initialized
INFO - 2021-04-28 15:01:44 --> Config Class Initialized
INFO - 2021-04-28 15:01:44 --> URI Class Initialized
INFO - 2021-04-28 15:01:44 --> Input Class Initialized
INFO - 2021-04-28 15:01:44 --> Router Class Initialized
DEBUG - 2021-04-28 15:01:44 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:44 --> Language Class Initialized
INFO - 2021-04-28 15:01:44 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:44 --> Output Class Initialized
INFO - 2021-04-28 15:01:44 --> URI Class Initialized
ERROR - 2021-04-28 15:01:44 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:01:44 --> Security Class Initialized
INFO - 2021-04-28 15:01:44 --> Router Class Initialized
INFO - 2021-04-28 15:01:44 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:44 --> Input Class Initialized
INFO - 2021-04-28 15:01:44 --> Output Class Initialized
INFO - 2021-04-28 15:01:44 --> Language Class Initialized
DEBUG - 2021-04-28 15:01:44 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:44 --> Security Class Initialized
INFO - 2021-04-28 15:01:44 --> Utf8 Class Initialized
ERROR - 2021-04-28 15:01:44 --> 404 Page Not Found: administrator/UserController/dist
DEBUG - 2021-04-28 15:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:44 --> Input Class Initialized
INFO - 2021-04-28 15:01:44 --> URI Class Initialized
INFO - 2021-04-28 15:01:44 --> Language Class Initialized
INFO - 2021-04-28 15:01:44 --> Router Class Initialized
ERROR - 2021-04-28 15:01:44 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:01:44 --> Output Class Initialized
INFO - 2021-04-28 15:01:44 --> Security Class Initialized
DEBUG - 2021-04-28 15:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:44 --> Input Class Initialized
INFO - 2021-04-28 15:01:44 --> Language Class Initialized
ERROR - 2021-04-28 15:01:44 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:01:44 --> Config Class Initialized
INFO - 2021-04-28 15:01:44 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:01:44 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:44 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:44 --> URI Class Initialized
INFO - 2021-04-28 15:01:44 --> Router Class Initialized
INFO - 2021-04-28 15:01:44 --> Output Class Initialized
INFO - 2021-04-28 15:01:44 --> Security Class Initialized
DEBUG - 2021-04-28 15:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:44 --> Input Class Initialized
INFO - 2021-04-28 15:01:44 --> Language Class Initialized
INFO - 2021-04-28 15:01:44 --> Loader Class Initialized
INFO - 2021-04-28 15:01:44 --> Helper loaded: url_helper
INFO - 2021-04-28 15:01:44 --> Helper loaded: form_helper
INFO - 2021-04-28 15:01:44 --> Helper loaded: common_helper
INFO - 2021-04-28 15:01:44 --> Helper loaded: util_helper
INFO - 2021-04-28 15:01:44 --> Helper loaded: user_helper
INFO - 2021-04-28 15:01:44 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:01:44 --> Form Validation Class Initialized
INFO - 2021-04-28 15:01:44 --> Controller Class Initialized
INFO - 2021-04-28 15:01:44 --> Model Class Initialized
INFO - 2021-04-28 15:01:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:01:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:01:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 15:01:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:01:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:01:44 --> Final output sent to browser
DEBUG - 2021-04-28 15:01:44 --> Total execution time: 0.0367
INFO - 2021-04-28 15:01:44 --> Config Class Initialized
INFO - 2021-04-28 15:01:44 --> Hooks Class Initialized
INFO - 2021-04-28 15:01:44 --> Config Class Initialized
INFO - 2021-04-28 15:01:44 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:01:44 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:44 --> Utf8 Class Initialized
DEBUG - 2021-04-28 15:01:44 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:44 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:44 --> Config Class Initialized
INFO - 2021-04-28 15:01:44 --> URI Class Initialized
INFO - 2021-04-28 15:01:44 --> Hooks Class Initialized
INFO - 2021-04-28 15:01:44 --> Config Class Initialized
INFO - 2021-04-28 15:01:44 --> Hooks Class Initialized
INFO - 2021-04-28 15:01:44 --> URI Class Initialized
INFO - 2021-04-28 15:01:44 --> Router Class Initialized
INFO - 2021-04-28 15:01:44 --> Router Class Initialized
DEBUG - 2021-04-28 15:01:44 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:44 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:44 --> Output Class Initialized
DEBUG - 2021-04-28 15:01:44 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:44 --> URI Class Initialized
INFO - 2021-04-28 15:01:44 --> Output Class Initialized
INFO - 2021-04-28 15:01:44 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:44 --> Security Class Initialized
INFO - 2021-04-28 15:01:44 --> Security Class Initialized
INFO - 2021-04-28 15:01:44 --> URI Class Initialized
INFO - 2021-04-28 15:01:44 --> Router Class Initialized
DEBUG - 2021-04-28 15:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:44 --> Input Class Initialized
DEBUG - 2021-04-28 15:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:44 --> Router Class Initialized
INFO - 2021-04-28 15:01:44 --> Input Class Initialized
INFO - 2021-04-28 15:01:44 --> Language Class Initialized
INFO - 2021-04-28 15:01:44 --> Output Class Initialized
INFO - 2021-04-28 15:01:44 --> Language Class Initialized
INFO - 2021-04-28 15:01:44 --> Output Class Initialized
INFO - 2021-04-28 15:01:44 --> Security Class Initialized
ERROR - 2021-04-28 15:01:44 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:01:44 --> Security Class Initialized
ERROR - 2021-04-28 15:01:44 --> 404 Page Not Found: administrator/UserController/dist
DEBUG - 2021-04-28 15:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:44 --> Input Class Initialized
DEBUG - 2021-04-28 15:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:44 --> Input Class Initialized
INFO - 2021-04-28 15:01:44 --> Language Class Initialized
INFO - 2021-04-28 15:01:44 --> Language Class Initialized
ERROR - 2021-04-28 15:01:44 --> 404 Page Not Found: administrator/UserController/dist
ERROR - 2021-04-28 15:01:44 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:01:45 --> Config Class Initialized
INFO - 2021-04-28 15:01:45 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:01:45 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:45 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:45 --> URI Class Initialized
INFO - 2021-04-28 15:01:45 --> Router Class Initialized
INFO - 2021-04-28 15:01:45 --> Output Class Initialized
INFO - 2021-04-28 15:01:45 --> Security Class Initialized
DEBUG - 2021-04-28 15:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:45 --> Input Class Initialized
INFO - 2021-04-28 15:01:45 --> Language Class Initialized
INFO - 2021-04-28 15:01:45 --> Loader Class Initialized
INFO - 2021-04-28 15:01:45 --> Helper loaded: url_helper
INFO - 2021-04-28 15:01:45 --> Helper loaded: form_helper
INFO - 2021-04-28 15:01:45 --> Helper loaded: common_helper
INFO - 2021-04-28 15:01:45 --> Helper loaded: util_helper
INFO - 2021-04-28 15:01:45 --> Helper loaded: user_helper
INFO - 2021-04-28 15:01:45 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:01:45 --> Form Validation Class Initialized
INFO - 2021-04-28 15:01:45 --> Controller Class Initialized
INFO - 2021-04-28 15:01:45 --> Model Class Initialized
INFO - 2021-04-28 15:01:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:01:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:01:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 15:01:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:01:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:01:45 --> Final output sent to browser
DEBUG - 2021-04-28 15:01:45 --> Total execution time: 0.0393
INFO - 2021-04-28 15:01:45 --> Config Class Initialized
INFO - 2021-04-28 15:01:45 --> Hooks Class Initialized
INFO - 2021-04-28 15:01:45 --> Config Class Initialized
INFO - 2021-04-28 15:01:45 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:01:45 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:45 --> Utf8 Class Initialized
DEBUG - 2021-04-28 15:01:45 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:45 --> URI Class Initialized
INFO - 2021-04-28 15:01:45 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:45 --> URI Class Initialized
INFO - 2021-04-28 15:01:45 --> Router Class Initialized
INFO - 2021-04-28 15:01:45 --> Router Class Initialized
INFO - 2021-04-28 15:01:45 --> Output Class Initialized
INFO - 2021-04-28 15:01:45 --> Output Class Initialized
INFO - 2021-04-28 15:01:45 --> Security Class Initialized
DEBUG - 2021-04-28 15:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:45 --> Security Class Initialized
INFO - 2021-04-28 15:01:45 --> Input Class Initialized
INFO - 2021-04-28 15:01:45 --> Language Class Initialized
DEBUG - 2021-04-28 15:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:45 --> Config Class Initialized
INFO - 2021-04-28 15:01:45 --> Input Class Initialized
INFO - 2021-04-28 15:01:45 --> Hooks Class Initialized
INFO - 2021-04-28 15:01:45 --> Language Class Initialized
ERROR - 2021-04-28 15:01:45 --> 404 Page Not Found: administrator/UserController/dist
DEBUG - 2021-04-28 15:01:45 --> UTF-8 Support Enabled
ERROR - 2021-04-28 15:01:45 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:01:45 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:45 --> URI Class Initialized
INFO - 2021-04-28 15:01:45 --> Router Class Initialized
INFO - 2021-04-28 15:01:45 --> Output Class Initialized
INFO - 2021-04-28 15:01:45 --> Security Class Initialized
DEBUG - 2021-04-28 15:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:45 --> Input Class Initialized
INFO - 2021-04-28 15:01:45 --> Language Class Initialized
ERROR - 2021-04-28 15:01:45 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:01:45 --> Config Class Initialized
INFO - 2021-04-28 15:01:45 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:01:45 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:01:45 --> Utf8 Class Initialized
INFO - 2021-04-28 15:01:45 --> URI Class Initialized
INFO - 2021-04-28 15:01:45 --> Router Class Initialized
INFO - 2021-04-28 15:01:45 --> Output Class Initialized
INFO - 2021-04-28 15:01:45 --> Security Class Initialized
DEBUG - 2021-04-28 15:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:01:45 --> Input Class Initialized
INFO - 2021-04-28 15:01:45 --> Language Class Initialized
ERROR - 2021-04-28 15:01:45 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:06:32 --> Config Class Initialized
INFO - 2021-04-28 15:06:32 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:06:32 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:06:32 --> Utf8 Class Initialized
INFO - 2021-04-28 15:06:32 --> URI Class Initialized
INFO - 2021-04-28 15:06:32 --> Router Class Initialized
INFO - 2021-04-28 15:06:32 --> Output Class Initialized
INFO - 2021-04-28 15:06:32 --> Security Class Initialized
DEBUG - 2021-04-28 15:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:06:32 --> Input Class Initialized
INFO - 2021-04-28 15:06:32 --> Language Class Initialized
INFO - 2021-04-28 15:06:32 --> Loader Class Initialized
INFO - 2021-04-28 15:06:32 --> Helper loaded: url_helper
INFO - 2021-04-28 15:06:32 --> Helper loaded: form_helper
INFO - 2021-04-28 15:06:32 --> Helper loaded: common_helper
INFO - 2021-04-28 15:06:32 --> Helper loaded: util_helper
INFO - 2021-04-28 15:06:32 --> Helper loaded: user_helper
INFO - 2021-04-28 15:06:32 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:06:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:06:32 --> Form Validation Class Initialized
INFO - 2021-04-28 15:06:32 --> Controller Class Initialized
INFO - 2021-04-28 15:06:32 --> Model Class Initialized
INFO - 2021-04-28 15:06:32 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:06:32 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:06:32 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 15:06:32 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:06:32 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:06:32 --> Final output sent to browser
DEBUG - 2021-04-28 15:06:32 --> Total execution time: 0.0412
INFO - 2021-04-28 15:06:32 --> Config Class Initialized
INFO - 2021-04-28 15:06:32 --> Hooks Class Initialized
INFO - 2021-04-28 15:06:32 --> Config Class Initialized
INFO - 2021-04-28 15:06:32 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:06:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-28 15:06:32 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:06:32 --> Utf8 Class Initialized
INFO - 2021-04-28 15:06:32 --> Utf8 Class Initialized
INFO - 2021-04-28 15:06:32 --> URI Class Initialized
INFO - 2021-04-28 15:06:32 --> URI Class Initialized
INFO - 2021-04-28 15:06:32 --> Router Class Initialized
INFO - 2021-04-28 15:06:32 --> Router Class Initialized
INFO - 2021-04-28 15:06:32 --> Output Class Initialized
INFO - 2021-04-28 15:06:32 --> Output Class Initialized
INFO - 2021-04-28 15:06:32 --> Security Class Initialized
INFO - 2021-04-28 15:06:32 --> Security Class Initialized
DEBUG - 2021-04-28 15:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-28 15:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:06:32 --> Input Class Initialized
INFO - 2021-04-28 15:06:32 --> Input Class Initialized
INFO - 2021-04-28 15:06:32 --> Language Class Initialized
INFO - 2021-04-28 15:06:32 --> Language Class Initialized
ERROR - 2021-04-28 15:06:32 --> 404 Page Not Found: administrator/UserController/dist
ERROR - 2021-04-28 15:06:32 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:06:32 --> Config Class Initialized
INFO - 2021-04-28 15:06:32 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:06:32 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:06:32 --> Utf8 Class Initialized
INFO - 2021-04-28 15:06:32 --> Config Class Initialized
INFO - 2021-04-28 15:06:32 --> Hooks Class Initialized
INFO - 2021-04-28 15:06:32 --> URI Class Initialized
DEBUG - 2021-04-28 15:06:32 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:06:32 --> Utf8 Class Initialized
INFO - 2021-04-28 15:06:32 --> URI Class Initialized
INFO - 2021-04-28 15:06:32 --> Router Class Initialized
INFO - 2021-04-28 15:06:32 --> Router Class Initialized
INFO - 2021-04-28 15:06:32 --> Output Class Initialized
INFO - 2021-04-28 15:06:32 --> Output Class Initialized
INFO - 2021-04-28 15:06:32 --> Security Class Initialized
INFO - 2021-04-28 15:06:32 --> Security Class Initialized
DEBUG - 2021-04-28 15:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:06:32 --> Input Class Initialized
INFO - 2021-04-28 15:06:32 --> Language Class Initialized
DEBUG - 2021-04-28 15:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:06:32 --> Input Class Initialized
INFO - 2021-04-28 15:06:32 --> Language Class Initialized
ERROR - 2021-04-28 15:06:32 --> 404 Page Not Found: administrator/UserController/dist
ERROR - 2021-04-28 15:06:32 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:07:15 --> Config Class Initialized
INFO - 2021-04-28 15:07:15 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:07:15 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:07:15 --> Utf8 Class Initialized
INFO - 2021-04-28 15:07:15 --> URI Class Initialized
INFO - 2021-04-28 15:07:15 --> Router Class Initialized
INFO - 2021-04-28 15:07:15 --> Output Class Initialized
INFO - 2021-04-28 15:07:15 --> Security Class Initialized
DEBUG - 2021-04-28 15:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:07:15 --> Input Class Initialized
INFO - 2021-04-28 15:07:15 --> Language Class Initialized
INFO - 2021-04-28 15:07:15 --> Loader Class Initialized
INFO - 2021-04-28 15:07:15 --> Helper loaded: url_helper
INFO - 2021-04-28 15:07:15 --> Helper loaded: form_helper
INFO - 2021-04-28 15:07:15 --> Helper loaded: common_helper
INFO - 2021-04-28 15:07:15 --> Helper loaded: util_helper
INFO - 2021-04-28 15:07:15 --> Helper loaded: user_helper
INFO - 2021-04-28 15:07:15 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:07:15 --> Form Validation Class Initialized
INFO - 2021-04-28 15:07:15 --> Controller Class Initialized
INFO - 2021-04-28 15:07:15 --> Model Class Initialized
ERROR - 2021-04-28 15:07:15 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: SELECT *
FROM `user`
WHERE `id` = 2
ERROR - 2021-04-28 15:07:15 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\xampp1\htdocs\FoodTruck\php\application\models\Common_model.php 29
INFO - 2021-04-28 15:07:53 --> Config Class Initialized
INFO - 2021-04-28 15:07:53 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:07:53 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:07:53 --> Utf8 Class Initialized
INFO - 2021-04-28 15:07:53 --> URI Class Initialized
INFO - 2021-04-28 15:07:53 --> Router Class Initialized
INFO - 2021-04-28 15:07:53 --> Output Class Initialized
INFO - 2021-04-28 15:07:53 --> Security Class Initialized
DEBUG - 2021-04-28 15:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:07:53 --> Input Class Initialized
INFO - 2021-04-28 15:07:53 --> Language Class Initialized
INFO - 2021-04-28 15:07:54 --> Loader Class Initialized
INFO - 2021-04-28 15:07:54 --> Helper loaded: url_helper
INFO - 2021-04-28 15:07:54 --> Helper loaded: form_helper
INFO - 2021-04-28 15:07:54 --> Helper loaded: common_helper
INFO - 2021-04-28 15:07:54 --> Helper loaded: util_helper
INFO - 2021-04-28 15:07:54 --> Helper loaded: user_helper
INFO - 2021-04-28 15:07:54 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:07:54 --> Form Validation Class Initialized
INFO - 2021-04-28 15:07:54 --> Controller Class Initialized
INFO - 2021-04-28 15:07:54 --> Model Class Initialized
ERROR - 2021-04-28 15:07:54 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: SELECT *
FROM `user`
WHERE `id` = 2
ERROR - 2021-04-28 15:07:54 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\xampp1\htdocs\FoodTruck\php\application\models\Common_model.php 29
INFO - 2021-04-28 15:07:54 --> Config Class Initialized
INFO - 2021-04-28 15:07:54 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:07:54 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:07:54 --> Utf8 Class Initialized
INFO - 2021-04-28 15:07:54 --> URI Class Initialized
INFO - 2021-04-28 15:07:54 --> Router Class Initialized
INFO - 2021-04-28 15:07:54 --> Output Class Initialized
INFO - 2021-04-28 15:07:54 --> Security Class Initialized
DEBUG - 2021-04-28 15:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:07:54 --> Input Class Initialized
INFO - 2021-04-28 15:07:54 --> Language Class Initialized
INFO - 2021-04-28 15:07:54 --> Loader Class Initialized
INFO - 2021-04-28 15:07:54 --> Helper loaded: url_helper
INFO - 2021-04-28 15:07:54 --> Helper loaded: form_helper
INFO - 2021-04-28 15:07:54 --> Helper loaded: common_helper
INFO - 2021-04-28 15:07:54 --> Helper loaded: util_helper
INFO - 2021-04-28 15:07:54 --> Helper loaded: user_helper
INFO - 2021-04-28 15:07:54 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:07:54 --> Form Validation Class Initialized
INFO - 2021-04-28 15:07:54 --> Controller Class Initialized
INFO - 2021-04-28 15:07:54 --> Model Class Initialized
ERROR - 2021-04-28 15:07:54 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: SELECT *
FROM `user`
WHERE `id` = 2
ERROR - 2021-04-28 15:07:54 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\xampp1\htdocs\FoodTruck\php\application\models\Common_model.php 29
INFO - 2021-04-28 15:07:54 --> Config Class Initialized
INFO - 2021-04-28 15:07:54 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:07:54 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:07:54 --> Utf8 Class Initialized
INFO - 2021-04-28 15:07:54 --> URI Class Initialized
INFO - 2021-04-28 15:07:54 --> Router Class Initialized
INFO - 2021-04-28 15:07:54 --> Output Class Initialized
INFO - 2021-04-28 15:07:54 --> Security Class Initialized
DEBUG - 2021-04-28 15:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:07:54 --> Input Class Initialized
INFO - 2021-04-28 15:07:54 --> Language Class Initialized
INFO - 2021-04-28 15:07:54 --> Loader Class Initialized
INFO - 2021-04-28 15:07:54 --> Helper loaded: url_helper
INFO - 2021-04-28 15:07:54 --> Helper loaded: form_helper
INFO - 2021-04-28 15:07:54 --> Helper loaded: common_helper
INFO - 2021-04-28 15:07:54 --> Helper loaded: util_helper
INFO - 2021-04-28 15:07:54 --> Helper loaded: user_helper
INFO - 2021-04-28 15:07:54 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:07:54 --> Form Validation Class Initialized
INFO - 2021-04-28 15:07:54 --> Controller Class Initialized
INFO - 2021-04-28 15:07:54 --> Model Class Initialized
ERROR - 2021-04-28 15:07:54 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: SELECT *
FROM `user`
WHERE `id` = 2
ERROR - 2021-04-28 15:07:54 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\xampp1\htdocs\FoodTruck\php\application\models\Common_model.php 29
INFO - 2021-04-28 15:07:54 --> Config Class Initialized
INFO - 2021-04-28 15:07:54 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:07:54 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:07:54 --> Utf8 Class Initialized
INFO - 2021-04-28 15:07:54 --> URI Class Initialized
INFO - 2021-04-28 15:07:54 --> Router Class Initialized
INFO - 2021-04-28 15:07:54 --> Output Class Initialized
INFO - 2021-04-28 15:07:54 --> Security Class Initialized
DEBUG - 2021-04-28 15:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:07:54 --> Input Class Initialized
INFO - 2021-04-28 15:07:54 --> Language Class Initialized
INFO - 2021-04-28 15:07:54 --> Loader Class Initialized
INFO - 2021-04-28 15:07:54 --> Helper loaded: url_helper
INFO - 2021-04-28 15:07:54 --> Helper loaded: form_helper
INFO - 2021-04-28 15:07:54 --> Helper loaded: common_helper
INFO - 2021-04-28 15:07:54 --> Helper loaded: util_helper
INFO - 2021-04-28 15:07:54 --> Helper loaded: user_helper
INFO - 2021-04-28 15:07:54 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:07:54 --> Form Validation Class Initialized
INFO - 2021-04-28 15:07:54 --> Controller Class Initialized
INFO - 2021-04-28 15:07:54 --> Model Class Initialized
ERROR - 2021-04-28 15:07:54 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: SELECT *
FROM `user`
WHERE `id` = 2
ERROR - 2021-04-28 15:07:54 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\xampp1\htdocs\FoodTruck\php\application\models\Common_model.php 29
INFO - 2021-04-28 15:07:55 --> Config Class Initialized
INFO - 2021-04-28 15:07:55 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:07:55 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:07:55 --> Utf8 Class Initialized
INFO - 2021-04-28 15:07:55 --> URI Class Initialized
INFO - 2021-04-28 15:07:55 --> Router Class Initialized
INFO - 2021-04-28 15:07:55 --> Output Class Initialized
INFO - 2021-04-28 15:07:55 --> Security Class Initialized
DEBUG - 2021-04-28 15:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:07:55 --> Input Class Initialized
INFO - 2021-04-28 15:07:55 --> Language Class Initialized
INFO - 2021-04-28 15:07:55 --> Loader Class Initialized
INFO - 2021-04-28 15:07:55 --> Helper loaded: url_helper
INFO - 2021-04-28 15:07:55 --> Helper loaded: form_helper
INFO - 2021-04-28 15:07:55 --> Helper loaded: common_helper
INFO - 2021-04-28 15:07:55 --> Helper loaded: util_helper
INFO - 2021-04-28 15:07:55 --> Helper loaded: user_helper
INFO - 2021-04-28 15:07:55 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:07:55 --> Form Validation Class Initialized
INFO - 2021-04-28 15:07:55 --> Controller Class Initialized
INFO - 2021-04-28 15:07:55 --> Model Class Initialized
ERROR - 2021-04-28 15:07:55 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: SELECT *
FROM `user`
WHERE `id` = 2
ERROR - 2021-04-28 15:07:55 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\xampp1\htdocs\FoodTruck\php\application\models\Common_model.php 29
INFO - 2021-04-28 15:07:56 --> Config Class Initialized
INFO - 2021-04-28 15:07:56 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:07:56 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:07:56 --> Utf8 Class Initialized
INFO - 2021-04-28 15:07:56 --> URI Class Initialized
INFO - 2021-04-28 15:07:56 --> Router Class Initialized
INFO - 2021-04-28 15:07:56 --> Output Class Initialized
INFO - 2021-04-28 15:07:56 --> Security Class Initialized
DEBUG - 2021-04-28 15:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:07:56 --> Input Class Initialized
INFO - 2021-04-28 15:07:56 --> Language Class Initialized
INFO - 2021-04-28 15:07:56 --> Loader Class Initialized
INFO - 2021-04-28 15:07:56 --> Helper loaded: url_helper
INFO - 2021-04-28 15:07:56 --> Helper loaded: form_helper
INFO - 2021-04-28 15:07:56 --> Helper loaded: common_helper
INFO - 2021-04-28 15:07:56 --> Helper loaded: util_helper
INFO - 2021-04-28 15:07:56 --> Helper loaded: user_helper
INFO - 2021-04-28 15:07:56 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:07:56 --> Form Validation Class Initialized
INFO - 2021-04-28 15:07:56 --> Controller Class Initialized
INFO - 2021-04-28 15:07:56 --> Model Class Initialized
ERROR - 2021-04-28 15:07:56 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: SELECT *
FROM `user`
WHERE `id` = 2
ERROR - 2021-04-28 15:07:56 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\xampp1\htdocs\FoodTruck\php\application\models\Common_model.php 29
INFO - 2021-04-28 15:08:37 --> Config Class Initialized
INFO - 2021-04-28 15:08:37 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:08:37 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:08:37 --> Utf8 Class Initialized
INFO - 2021-04-28 15:08:37 --> URI Class Initialized
INFO - 2021-04-28 15:08:37 --> Router Class Initialized
INFO - 2021-04-28 15:08:37 --> Output Class Initialized
INFO - 2021-04-28 15:08:37 --> Security Class Initialized
DEBUG - 2021-04-28 15:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:08:37 --> Input Class Initialized
INFO - 2021-04-28 15:08:37 --> Language Class Initialized
INFO - 2021-04-28 15:08:37 --> Loader Class Initialized
INFO - 2021-04-28 15:08:37 --> Helper loaded: url_helper
INFO - 2021-04-28 15:08:37 --> Helper loaded: form_helper
INFO - 2021-04-28 15:08:37 --> Helper loaded: common_helper
INFO - 2021-04-28 15:08:37 --> Helper loaded: util_helper
INFO - 2021-04-28 15:08:37 --> Helper loaded: user_helper
INFO - 2021-04-28 15:08:37 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:08:37 --> Form Validation Class Initialized
INFO - 2021-04-28 15:08:37 --> Controller Class Initialized
INFO - 2021-04-28 15:08:37 --> Model Class Initialized
INFO - 2021-04-28 15:08:37 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:08:37 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:08:37 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 15:08:37 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:08:37 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:08:37 --> Final output sent to browser
DEBUG - 2021-04-28 15:08:37 --> Total execution time: 0.0477
INFO - 2021-04-28 15:08:37 --> Config Class Initialized
INFO - 2021-04-28 15:08:37 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:08:37 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:08:37 --> Utf8 Class Initialized
INFO - 2021-04-28 15:08:37 --> URI Class Initialized
INFO - 2021-04-28 15:08:37 --> Router Class Initialized
INFO - 2021-04-28 15:08:37 --> Config Class Initialized
INFO - 2021-04-28 15:08:37 --> Hooks Class Initialized
INFO - 2021-04-28 15:08:37 --> Config Class Initialized
INFO - 2021-04-28 15:08:37 --> Hooks Class Initialized
INFO - 2021-04-28 15:08:37 --> Output Class Initialized
INFO - 2021-04-28 15:08:37 --> Config Class Initialized
INFO - 2021-04-28 15:08:37 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:08:37 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:08:37 --> Security Class Initialized
INFO - 2021-04-28 15:08:37 --> Utf8 Class Initialized
DEBUG - 2021-04-28 15:08:37 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:08:37 --> Utf8 Class Initialized
DEBUG - 2021-04-28 15:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:08:37 --> URI Class Initialized
INFO - 2021-04-28 15:08:37 --> Input Class Initialized
DEBUG - 2021-04-28 15:08:37 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:08:37 --> Language Class Initialized
INFO - 2021-04-28 15:08:37 --> URI Class Initialized
INFO - 2021-04-28 15:08:37 --> Utf8 Class Initialized
INFO - 2021-04-28 15:08:37 --> Router Class Initialized
INFO - 2021-04-28 15:08:37 --> URI Class Initialized
INFO - 2021-04-28 15:08:37 --> Router Class Initialized
ERROR - 2021-04-28 15:08:37 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:08:37 --> Output Class Initialized
INFO - 2021-04-28 15:08:37 --> Router Class Initialized
INFO - 2021-04-28 15:08:37 --> Output Class Initialized
INFO - 2021-04-28 15:08:37 --> Security Class Initialized
INFO - 2021-04-28 15:08:37 --> Output Class Initialized
INFO - 2021-04-28 15:08:37 --> Security Class Initialized
DEBUG - 2021-04-28 15:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:08:37 --> Input Class Initialized
INFO - 2021-04-28 15:08:37 --> Security Class Initialized
DEBUG - 2021-04-28 15:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:08:37 --> Input Class Initialized
INFO - 2021-04-28 15:08:37 --> Language Class Initialized
INFO - 2021-04-28 15:08:37 --> Language Class Initialized
DEBUG - 2021-04-28 15:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:08:37 --> Input Class Initialized
INFO - 2021-04-28 15:08:37 --> Language Class Initialized
ERROR - 2021-04-28 15:08:37 --> 404 Page Not Found: administrator/UserController/dist
ERROR - 2021-04-28 15:08:37 --> 404 Page Not Found: administrator/UserController/dist
ERROR - 2021-04-28 15:08:37 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:38:59 --> Config Class Initialized
INFO - 2021-04-28 15:38:59 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:38:59 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:38:59 --> Utf8 Class Initialized
INFO - 2021-04-28 15:38:59 --> URI Class Initialized
INFO - 2021-04-28 15:38:59 --> Router Class Initialized
INFO - 2021-04-28 15:38:59 --> Output Class Initialized
INFO - 2021-04-28 15:38:59 --> Security Class Initialized
DEBUG - 2021-04-28 15:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:38:59 --> Input Class Initialized
INFO - 2021-04-28 15:38:59 --> Language Class Initialized
INFO - 2021-04-28 15:38:59 --> Loader Class Initialized
INFO - 2021-04-28 15:38:59 --> Helper loaded: url_helper
INFO - 2021-04-28 15:38:59 --> Helper loaded: form_helper
INFO - 2021-04-28 15:38:59 --> Helper loaded: common_helper
INFO - 2021-04-28 15:38:59 --> Helper loaded: util_helper
INFO - 2021-04-28 15:38:59 --> Helper loaded: user_helper
INFO - 2021-04-28 15:38:59 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:38:59 --> Form Validation Class Initialized
INFO - 2021-04-28 15:38:59 --> Controller Class Initialized
INFO - 2021-04-28 15:38:59 --> Model Class Initialized
INFO - 2021-04-28 15:38:59 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:39:00 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:39:00 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 15:39:00 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:39:00 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:39:00 --> Final output sent to browser
DEBUG - 2021-04-28 15:39:00 --> Total execution time: 0.0326
INFO - 2021-04-28 15:39:00 --> Config Class Initialized
INFO - 2021-04-28 15:39:00 --> Hooks Class Initialized
INFO - 2021-04-28 15:39:00 --> Config Class Initialized
INFO - 2021-04-28 15:39:00 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:00 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:00 --> Utf8 Class Initialized
DEBUG - 2021-04-28 15:39:00 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:00 --> URI Class Initialized
INFO - 2021-04-28 15:39:00 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:00 --> URI Class Initialized
INFO - 2021-04-28 15:39:00 --> Router Class Initialized
INFO - 2021-04-28 15:39:00 --> Router Class Initialized
INFO - 2021-04-28 15:39:00 --> Output Class Initialized
INFO - 2021-04-28 15:39:00 --> Output Class Initialized
INFO - 2021-04-28 15:39:00 --> Security Class Initialized
INFO - 2021-04-28 15:39:00 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:00 --> Input Class Initialized
INFO - 2021-04-28 15:39:00 --> Language Class Initialized
DEBUG - 2021-04-28 15:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:00 --> Input Class Initialized
INFO - 2021-04-28 15:39:00 --> Language Class Initialized
ERROR - 2021-04-28 15:39:00 --> 404 Page Not Found: administrator/UserController/dist
ERROR - 2021-04-28 15:39:00 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:39:00 --> Config Class Initialized
INFO - 2021-04-28 15:39:00 --> Hooks Class Initialized
INFO - 2021-04-28 15:39:00 --> Config Class Initialized
INFO - 2021-04-28 15:39:00 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:00 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:00 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:00 --> URI Class Initialized
DEBUG - 2021-04-28 15:39:00 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:00 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:00 --> Router Class Initialized
INFO - 2021-04-28 15:39:00 --> URI Class Initialized
INFO - 2021-04-28 15:39:00 --> Output Class Initialized
INFO - 2021-04-28 15:39:00 --> Router Class Initialized
INFO - 2021-04-28 15:39:00 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:00 --> Output Class Initialized
INFO - 2021-04-28 15:39:00 --> Input Class Initialized
INFO - 2021-04-28 15:39:00 --> Language Class Initialized
INFO - 2021-04-28 15:39:00 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:00 --> Input Class Initialized
ERROR - 2021-04-28 15:39:00 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:39:00 --> Language Class Initialized
ERROR - 2021-04-28 15:39:00 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:39:00 --> Config Class Initialized
INFO - 2021-04-28 15:39:00 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:00 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:00 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:00 --> URI Class Initialized
INFO - 2021-04-28 15:39:00 --> Router Class Initialized
INFO - 2021-04-28 15:39:00 --> Output Class Initialized
INFO - 2021-04-28 15:39:00 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:00 --> Input Class Initialized
INFO - 2021-04-28 15:39:00 --> Language Class Initialized
INFO - 2021-04-28 15:39:00 --> Loader Class Initialized
INFO - 2021-04-28 15:39:00 --> Helper loaded: url_helper
INFO - 2021-04-28 15:39:00 --> Helper loaded: form_helper
INFO - 2021-04-28 15:39:00 --> Helper loaded: common_helper
INFO - 2021-04-28 15:39:00 --> Helper loaded: util_helper
INFO - 2021-04-28 15:39:00 --> Helper loaded: user_helper
INFO - 2021-04-28 15:39:00 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:39:00 --> Form Validation Class Initialized
INFO - 2021-04-28 15:39:00 --> Controller Class Initialized
INFO - 2021-04-28 15:39:00 --> Model Class Initialized
INFO - 2021-04-28 15:39:00 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:39:00 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:39:00 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 15:39:00 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:39:00 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:39:00 --> Final output sent to browser
DEBUG - 2021-04-28 15:39:00 --> Total execution time: 0.0397
INFO - 2021-04-28 15:39:00 --> Config Class Initialized
INFO - 2021-04-28 15:39:00 --> Hooks Class Initialized
INFO - 2021-04-28 15:39:00 --> Config Class Initialized
INFO - 2021-04-28 15:39:00 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:00 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:00 --> Utf8 Class Initialized
DEBUG - 2021-04-28 15:39:00 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:00 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:00 --> URI Class Initialized
INFO - 2021-04-28 15:39:00 --> URI Class Initialized
INFO - 2021-04-28 15:39:00 --> Router Class Initialized
INFO - 2021-04-28 15:39:00 --> Router Class Initialized
INFO - 2021-04-28 15:39:00 --> Output Class Initialized
INFO - 2021-04-28 15:39:00 --> Output Class Initialized
INFO - 2021-04-28 15:39:00 --> Security Class Initialized
INFO - 2021-04-28 15:39:00 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:00 --> Input Class Initialized
DEBUG - 2021-04-28 15:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:00 --> Input Class Initialized
INFO - 2021-04-28 15:39:00 --> Language Class Initialized
INFO - 2021-04-28 15:39:00 --> Language Class Initialized
ERROR - 2021-04-28 15:39:00 --> 404 Page Not Found: administrator/UserController/dist
ERROR - 2021-04-28 15:39:00 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:39:00 --> Config Class Initialized
INFO - 2021-04-28 15:39:00 --> Hooks Class Initialized
INFO - 2021-04-28 15:39:00 --> Config Class Initialized
INFO - 2021-04-28 15:39:00 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:00 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:00 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:00 --> URI Class Initialized
DEBUG - 2021-04-28 15:39:00 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:00 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:00 --> Router Class Initialized
INFO - 2021-04-28 15:39:00 --> URI Class Initialized
INFO - 2021-04-28 15:39:00 --> Router Class Initialized
INFO - 2021-04-28 15:39:00 --> Output Class Initialized
INFO - 2021-04-28 15:39:00 --> Output Class Initialized
INFO - 2021-04-28 15:39:00 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:00 --> Security Class Initialized
INFO - 2021-04-28 15:39:00 --> Input Class Initialized
INFO - 2021-04-28 15:39:00 --> Language Class Initialized
DEBUG - 2021-04-28 15:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:00 --> Input Class Initialized
INFO - 2021-04-28 15:39:00 --> Language Class Initialized
ERROR - 2021-04-28 15:39:00 --> 404 Page Not Found: administrator/UserController/dist
ERROR - 2021-04-28 15:39:00 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:39:01 --> Config Class Initialized
INFO - 2021-04-28 15:39:01 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:01 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:01 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:01 --> URI Class Initialized
INFO - 2021-04-28 15:39:01 --> Router Class Initialized
INFO - 2021-04-28 15:39:01 --> Output Class Initialized
INFO - 2021-04-28 15:39:01 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:01 --> Input Class Initialized
INFO - 2021-04-28 15:39:01 --> Language Class Initialized
INFO - 2021-04-28 15:39:01 --> Loader Class Initialized
INFO - 2021-04-28 15:39:01 --> Helper loaded: url_helper
INFO - 2021-04-28 15:39:01 --> Helper loaded: form_helper
INFO - 2021-04-28 15:39:01 --> Helper loaded: common_helper
INFO - 2021-04-28 15:39:01 --> Helper loaded: util_helper
INFO - 2021-04-28 15:39:01 --> Helper loaded: user_helper
INFO - 2021-04-28 15:39:01 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:39:01 --> Form Validation Class Initialized
INFO - 2021-04-28 15:39:01 --> Controller Class Initialized
INFO - 2021-04-28 15:39:01 --> Model Class Initialized
INFO - 2021-04-28 15:39:01 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:39:01 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:39:01 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 15:39:01 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:39:01 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:39:01 --> Final output sent to browser
DEBUG - 2021-04-28 15:39:01 --> Total execution time: 0.0302
INFO - 2021-04-28 15:39:01 --> Config Class Initialized
INFO - 2021-04-28 15:39:01 --> Hooks Class Initialized
INFO - 2021-04-28 15:39:01 --> Config Class Initialized
INFO - 2021-04-28 15:39:01 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:01 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:01 --> Utf8 Class Initialized
DEBUG - 2021-04-28 15:39:01 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:01 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:01 --> URI Class Initialized
INFO - 2021-04-28 15:39:01 --> URI Class Initialized
INFO - 2021-04-28 15:39:01 --> Router Class Initialized
INFO - 2021-04-28 15:39:01 --> Router Class Initialized
INFO - 2021-04-28 15:39:01 --> Output Class Initialized
INFO - 2021-04-28 15:39:01 --> Output Class Initialized
INFO - 2021-04-28 15:39:01 --> Security Class Initialized
INFO - 2021-04-28 15:39:01 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:01 --> Input Class Initialized
INFO - 2021-04-28 15:39:01 --> Language Class Initialized
DEBUG - 2021-04-28 15:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:01 --> Input Class Initialized
INFO - 2021-04-28 15:39:01 --> Language Class Initialized
ERROR - 2021-04-28 15:39:01 --> 404 Page Not Found: administrator/UserController/dist
ERROR - 2021-04-28 15:39:01 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:39:01 --> Config Class Initialized
INFO - 2021-04-28 15:39:01 --> Hooks Class Initialized
INFO - 2021-04-28 15:39:01 --> Config Class Initialized
INFO - 2021-04-28 15:39:01 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:01 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:01 --> Utf8 Class Initialized
DEBUG - 2021-04-28 15:39:01 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:01 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:01 --> URI Class Initialized
INFO - 2021-04-28 15:39:01 --> URI Class Initialized
INFO - 2021-04-28 15:39:01 --> Router Class Initialized
INFO - 2021-04-28 15:39:01 --> Router Class Initialized
INFO - 2021-04-28 15:39:01 --> Output Class Initialized
INFO - 2021-04-28 15:39:01 --> Security Class Initialized
INFO - 2021-04-28 15:39:01 --> Output Class Initialized
DEBUG - 2021-04-28 15:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:01 --> Input Class Initialized
INFO - 2021-04-28 15:39:01 --> Security Class Initialized
INFO - 2021-04-28 15:39:01 --> Language Class Initialized
DEBUG - 2021-04-28 15:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:01 --> Input Class Initialized
INFO - 2021-04-28 15:39:01 --> Language Class Initialized
ERROR - 2021-04-28 15:39:01 --> 404 Page Not Found: administrator/UserController/dist
ERROR - 2021-04-28 15:39:01 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:39:03 --> Config Class Initialized
INFO - 2021-04-28 15:39:03 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:03 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:03 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:03 --> URI Class Initialized
INFO - 2021-04-28 15:39:03 --> Router Class Initialized
INFO - 2021-04-28 15:39:03 --> Output Class Initialized
INFO - 2021-04-28 15:39:03 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:03 --> Input Class Initialized
INFO - 2021-04-28 15:39:03 --> Language Class Initialized
INFO - 2021-04-28 15:39:03 --> Loader Class Initialized
INFO - 2021-04-28 15:39:03 --> Helper loaded: url_helper
INFO - 2021-04-28 15:39:03 --> Helper loaded: form_helper
INFO - 2021-04-28 15:39:03 --> Helper loaded: common_helper
INFO - 2021-04-28 15:39:03 --> Helper loaded: util_helper
INFO - 2021-04-28 15:39:03 --> Helper loaded: user_helper
INFO - 2021-04-28 15:39:03 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:39:03 --> Form Validation Class Initialized
INFO - 2021-04-28 15:39:03 --> Controller Class Initialized
INFO - 2021-04-28 15:39:03 --> Model Class Initialized
INFO - 2021-04-28 15:39:03 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:39:03 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:39:03 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/editUser.php
INFO - 2021-04-28 15:39:03 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:39:03 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:39:03 --> Final output sent to browser
DEBUG - 2021-04-28 15:39:03 --> Total execution time: 0.0356
INFO - 2021-04-28 15:39:03 --> Config Class Initialized
INFO - 2021-04-28 15:39:03 --> Hooks Class Initialized
INFO - 2021-04-28 15:39:03 --> Config Class Initialized
INFO - 2021-04-28 15:39:03 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:03 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:03 --> Utf8 Class Initialized
DEBUG - 2021-04-28 15:39:03 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:03 --> URI Class Initialized
INFO - 2021-04-28 15:39:03 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:03 --> URI Class Initialized
INFO - 2021-04-28 15:39:03 --> Router Class Initialized
INFO - 2021-04-28 15:39:03 --> Router Class Initialized
INFO - 2021-04-28 15:39:03 --> Output Class Initialized
INFO - 2021-04-28 15:39:03 --> Output Class Initialized
INFO - 2021-04-28 15:39:03 --> Security Class Initialized
INFO - 2021-04-28 15:39:03 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:03 --> Input Class Initialized
INFO - 2021-04-28 15:39:03 --> Language Class Initialized
DEBUG - 2021-04-28 15:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:03 --> Input Class Initialized
INFO - 2021-04-28 15:39:03 --> Language Class Initialized
ERROR - 2021-04-28 15:39:03 --> 404 Page Not Found: UserController/update
ERROR - 2021-04-28 15:39:03 --> 404 Page Not Found: UserController/update
INFO - 2021-04-28 15:39:03 --> Config Class Initialized
INFO - 2021-04-28 15:39:03 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:03 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:03 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:03 --> URI Class Initialized
INFO - 2021-04-28 15:39:03 --> Router Class Initialized
INFO - 2021-04-28 15:39:03 --> Output Class Initialized
INFO - 2021-04-28 15:39:03 --> Security Class Initialized
INFO - 2021-04-28 15:39:03 --> Config Class Initialized
INFO - 2021-04-28 15:39:03 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:03 --> Input Class Initialized
INFO - 2021-04-28 15:39:03 --> Language Class Initialized
DEBUG - 2021-04-28 15:39:03 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:03 --> Utf8 Class Initialized
ERROR - 2021-04-28 15:39:03 --> 404 Page Not Found: UserController/update
INFO - 2021-04-28 15:39:03 --> URI Class Initialized
INFO - 2021-04-28 15:39:03 --> Router Class Initialized
INFO - 2021-04-28 15:39:03 --> Output Class Initialized
INFO - 2021-04-28 15:39:03 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:03 --> Input Class Initialized
INFO - 2021-04-28 15:39:03 --> Language Class Initialized
ERROR - 2021-04-28 15:39:03 --> 404 Page Not Found: UserController/update
INFO - 2021-04-28 15:39:05 --> Config Class Initialized
INFO - 2021-04-28 15:39:05 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:05 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:05 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:05 --> URI Class Initialized
INFO - 2021-04-28 15:39:05 --> Router Class Initialized
INFO - 2021-04-28 15:39:05 --> Output Class Initialized
INFO - 2021-04-28 15:39:05 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:05 --> Input Class Initialized
INFO - 2021-04-28 15:39:05 --> Language Class Initialized
INFO - 2021-04-28 15:39:05 --> Loader Class Initialized
INFO - 2021-04-28 15:39:05 --> Helper loaded: url_helper
INFO - 2021-04-28 15:39:06 --> Helper loaded: form_helper
INFO - 2021-04-28 15:39:06 --> Helper loaded: common_helper
INFO - 2021-04-28 15:39:06 --> Helper loaded: util_helper
INFO - 2021-04-28 15:39:06 --> Helper loaded: user_helper
INFO - 2021-04-28 15:39:06 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:39:06 --> Form Validation Class Initialized
INFO - 2021-04-28 15:39:06 --> Controller Class Initialized
INFO - 2021-04-28 15:39:06 --> Model Class Initialized
INFO - 2021-04-28 15:39:06 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:39:06 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:39:06 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 15:39:06 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:39:06 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:39:06 --> Final output sent to browser
DEBUG - 2021-04-28 15:39:06 --> Total execution time: 0.0302
INFO - 2021-04-28 15:39:09 --> Config Class Initialized
INFO - 2021-04-28 15:39:09 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:09 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:09 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:09 --> URI Class Initialized
INFO - 2021-04-28 15:39:09 --> Router Class Initialized
INFO - 2021-04-28 15:39:09 --> Output Class Initialized
INFO - 2021-04-28 15:39:09 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:09 --> Input Class Initialized
INFO - 2021-04-28 15:39:09 --> Language Class Initialized
INFO - 2021-04-28 15:39:09 --> Loader Class Initialized
INFO - 2021-04-28 15:39:09 --> Helper loaded: url_helper
INFO - 2021-04-28 15:39:09 --> Helper loaded: form_helper
INFO - 2021-04-28 15:39:09 --> Helper loaded: common_helper
INFO - 2021-04-28 15:39:09 --> Helper loaded: util_helper
INFO - 2021-04-28 15:39:09 --> Helper loaded: user_helper
INFO - 2021-04-28 15:39:09 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:39:09 --> Form Validation Class Initialized
INFO - 2021-04-28 15:39:09 --> Controller Class Initialized
INFO - 2021-04-28 15:39:09 --> Model Class Initialized
INFO - 2021-04-28 15:39:09 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:39:09 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:39:09 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/addUser.php
INFO - 2021-04-28 15:39:09 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:39:09 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:39:09 --> Final output sent to browser
DEBUG - 2021-04-28 15:39:09 --> Total execution time: 0.0297
INFO - 2021-04-28 15:39:09 --> Config Class Initialized
INFO - 2021-04-28 15:39:09 --> Hooks Class Initialized
INFO - 2021-04-28 15:39:09 --> Config Class Initialized
INFO - 2021-04-28 15:39:09 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:09 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:09 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:09 --> URI Class Initialized
DEBUG - 2021-04-28 15:39:09 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:09 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:09 --> URI Class Initialized
INFO - 2021-04-28 15:39:09 --> Router Class Initialized
INFO - 2021-04-28 15:39:09 --> Router Class Initialized
INFO - 2021-04-28 15:39:09 --> Output Class Initialized
INFO - 2021-04-28 15:39:09 --> Output Class Initialized
INFO - 2021-04-28 15:39:09 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:09 --> Security Class Initialized
INFO - 2021-04-28 15:39:09 --> Input Class Initialized
INFO - 2021-04-28 15:39:09 --> Language Class Initialized
DEBUG - 2021-04-28 15:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:09 --> Input Class Initialized
INFO - 2021-04-28 15:39:09 --> Language Class Initialized
ERROR - 2021-04-28 15:39:09 --> 404 Page Not Found: administrator/UserController/dist
ERROR - 2021-04-28 15:39:09 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:39:09 --> Config Class Initialized
INFO - 2021-04-28 15:39:09 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:09 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:09 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:09 --> URI Class Initialized
INFO - 2021-04-28 15:39:09 --> Router Class Initialized
INFO - 2021-04-28 15:39:09 --> Output Class Initialized
INFO - 2021-04-28 15:39:09 --> Security Class Initialized
INFO - 2021-04-28 15:39:09 --> Config Class Initialized
INFO - 2021-04-28 15:39:09 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:09 --> Input Class Initialized
INFO - 2021-04-28 15:39:09 --> Language Class Initialized
DEBUG - 2021-04-28 15:39:09 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:09 --> Utf8 Class Initialized
ERROR - 2021-04-28 15:39:09 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:39:09 --> URI Class Initialized
INFO - 2021-04-28 15:39:09 --> Router Class Initialized
INFO - 2021-04-28 15:39:09 --> Output Class Initialized
INFO - 2021-04-28 15:39:09 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:09 --> Input Class Initialized
INFO - 2021-04-28 15:39:09 --> Language Class Initialized
ERROR - 2021-04-28 15:39:09 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:39:12 --> Config Class Initialized
INFO - 2021-04-28 15:39:12 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:12 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:12 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:12 --> URI Class Initialized
INFO - 2021-04-28 15:39:12 --> Router Class Initialized
INFO - 2021-04-28 15:39:12 --> Output Class Initialized
INFO - 2021-04-28 15:39:12 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:12 --> Input Class Initialized
INFO - 2021-04-28 15:39:12 --> Language Class Initialized
INFO - 2021-04-28 15:39:12 --> Loader Class Initialized
INFO - 2021-04-28 15:39:12 --> Helper loaded: url_helper
INFO - 2021-04-28 15:39:12 --> Helper loaded: form_helper
INFO - 2021-04-28 15:39:12 --> Helper loaded: common_helper
INFO - 2021-04-28 15:39:12 --> Helper loaded: util_helper
INFO - 2021-04-28 15:39:12 --> Helper loaded: user_helper
INFO - 2021-04-28 15:39:12 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:39:12 --> Form Validation Class Initialized
INFO - 2021-04-28 15:39:12 --> Controller Class Initialized
INFO - 2021-04-28 15:39:12 --> Model Class Initialized
INFO - 2021-04-28 15:39:12 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:39:12 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:39:12 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 15:39:12 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:39:12 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:39:12 --> Final output sent to browser
DEBUG - 2021-04-28 15:39:12 --> Total execution time: 0.0310
INFO - 2021-04-28 15:39:31 --> Config Class Initialized
INFO - 2021-04-28 15:39:31 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:31 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:31 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:31 --> URI Class Initialized
INFO - 2021-04-28 15:39:31 --> Router Class Initialized
INFO - 2021-04-28 15:39:31 --> Output Class Initialized
INFO - 2021-04-28 15:39:31 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:31 --> Input Class Initialized
INFO - 2021-04-28 15:39:31 --> Language Class Initialized
INFO - 2021-04-28 15:39:31 --> Loader Class Initialized
INFO - 2021-04-28 15:39:31 --> Helper loaded: url_helper
INFO - 2021-04-28 15:39:31 --> Helper loaded: form_helper
INFO - 2021-04-28 15:39:31 --> Helper loaded: common_helper
INFO - 2021-04-28 15:39:31 --> Helper loaded: util_helper
INFO - 2021-04-28 15:39:31 --> Helper loaded: user_helper
INFO - 2021-04-28 15:39:31 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:39:31 --> Form Validation Class Initialized
INFO - 2021-04-28 15:39:31 --> Controller Class Initialized
INFO - 2021-04-28 15:39:31 --> Model Class Initialized
INFO - 2021-04-28 15:39:31 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:39:31 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:39:31 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/editUser.php
INFO - 2021-04-28 15:39:31 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:39:31 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:39:31 --> Final output sent to browser
DEBUG - 2021-04-28 15:39:31 --> Total execution time: 0.0305
INFO - 2021-04-28 15:39:31 --> Config Class Initialized
INFO - 2021-04-28 15:39:31 --> Hooks Class Initialized
INFO - 2021-04-28 15:39:31 --> Config Class Initialized
INFO - 2021-04-28 15:39:31 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:31 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:31 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:31 --> URI Class Initialized
INFO - 2021-04-28 15:39:31 --> Router Class Initialized
INFO - 2021-04-28 15:39:31 --> Output Class Initialized
DEBUG - 2021-04-28 15:39:31 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:31 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:31 --> Security Class Initialized
INFO - 2021-04-28 15:39:31 --> URI Class Initialized
DEBUG - 2021-04-28 15:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:31 --> Input Class Initialized
INFO - 2021-04-28 15:39:31 --> Router Class Initialized
INFO - 2021-04-28 15:39:31 --> Language Class Initialized
INFO - 2021-04-28 15:39:31 --> Output Class Initialized
ERROR - 2021-04-28 15:39:31 --> 404 Page Not Found: UserController/update
INFO - 2021-04-28 15:39:31 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:31 --> Input Class Initialized
INFO - 2021-04-28 15:39:31 --> Language Class Initialized
ERROR - 2021-04-28 15:39:31 --> 404 Page Not Found: UserController/update
INFO - 2021-04-28 15:39:31 --> Config Class Initialized
INFO - 2021-04-28 15:39:31 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:31 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:31 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:31 --> URI Class Initialized
INFO - 2021-04-28 15:39:31 --> Router Class Initialized
INFO - 2021-04-28 15:39:31 --> Config Class Initialized
INFO - 2021-04-28 15:39:31 --> Hooks Class Initialized
INFO - 2021-04-28 15:39:31 --> Output Class Initialized
INFO - 2021-04-28 15:39:31 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:31 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:31 --> Utf8 Class Initialized
DEBUG - 2021-04-28 15:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:31 --> Input Class Initialized
INFO - 2021-04-28 15:39:31 --> URI Class Initialized
INFO - 2021-04-28 15:39:31 --> Language Class Initialized
INFO - 2021-04-28 15:39:31 --> Router Class Initialized
ERROR - 2021-04-28 15:39:31 --> 404 Page Not Found: UserController/update
INFO - 2021-04-28 15:39:31 --> Output Class Initialized
INFO - 2021-04-28 15:39:31 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:31 --> Input Class Initialized
INFO - 2021-04-28 15:39:31 --> Language Class Initialized
ERROR - 2021-04-28 15:39:31 --> 404 Page Not Found: UserController/update
INFO - 2021-04-28 15:39:34 --> Config Class Initialized
INFO - 2021-04-28 15:39:34 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:34 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:34 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:34 --> URI Class Initialized
INFO - 2021-04-28 15:39:34 --> Router Class Initialized
INFO - 2021-04-28 15:39:34 --> Output Class Initialized
INFO - 2021-04-28 15:39:34 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:34 --> Input Class Initialized
INFO - 2021-04-28 15:39:34 --> Language Class Initialized
INFO - 2021-04-28 15:39:34 --> Loader Class Initialized
INFO - 2021-04-28 15:39:34 --> Helper loaded: url_helper
INFO - 2021-04-28 15:39:34 --> Helper loaded: form_helper
INFO - 2021-04-28 15:39:34 --> Helper loaded: common_helper
INFO - 2021-04-28 15:39:34 --> Helper loaded: util_helper
INFO - 2021-04-28 15:39:34 --> Helper loaded: user_helper
INFO - 2021-04-28 15:39:34 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:39:34 --> Form Validation Class Initialized
INFO - 2021-04-28 15:39:34 --> Controller Class Initialized
INFO - 2021-04-28 15:39:34 --> Model Class Initialized
INFO - 2021-04-28 15:39:34 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:39:34 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:39:34 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 15:39:34 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:39:34 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:39:34 --> Final output sent to browser
DEBUG - 2021-04-28 15:39:34 --> Total execution time: 0.0305
INFO - 2021-04-28 15:39:38 --> Config Class Initialized
INFO - 2021-04-28 15:39:38 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:38 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:38 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:38 --> URI Class Initialized
INFO - 2021-04-28 15:39:38 --> Router Class Initialized
INFO - 2021-04-28 15:39:38 --> Output Class Initialized
INFO - 2021-04-28 15:39:38 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:38 --> Input Class Initialized
INFO - 2021-04-28 15:39:38 --> Language Class Initialized
INFO - 2021-04-28 15:39:38 --> Loader Class Initialized
INFO - 2021-04-28 15:39:38 --> Helper loaded: url_helper
INFO - 2021-04-28 15:39:38 --> Helper loaded: form_helper
INFO - 2021-04-28 15:39:38 --> Helper loaded: common_helper
INFO - 2021-04-28 15:39:38 --> Helper loaded: util_helper
INFO - 2021-04-28 15:39:38 --> Helper loaded: user_helper
INFO - 2021-04-28 15:39:38 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:39:38 --> Form Validation Class Initialized
INFO - 2021-04-28 15:39:38 --> Controller Class Initialized
INFO - 2021-04-28 15:39:38 --> Model Class Initialized
INFO - 2021-04-28 15:39:38 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:39:38 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:39:38 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/addUser.php
INFO - 2021-04-28 15:39:38 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:39:38 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:39:38 --> Final output sent to browser
DEBUG - 2021-04-28 15:39:38 --> Total execution time: 0.0294
INFO - 2021-04-28 15:39:38 --> Config Class Initialized
INFO - 2021-04-28 15:39:38 --> Hooks Class Initialized
INFO - 2021-04-28 15:39:38 --> Config Class Initialized
INFO - 2021-04-28 15:39:38 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:38 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:38 --> Utf8 Class Initialized
DEBUG - 2021-04-28 15:39:38 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:38 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:38 --> URI Class Initialized
INFO - 2021-04-28 15:39:38 --> URI Class Initialized
INFO - 2021-04-28 15:39:38 --> Router Class Initialized
INFO - 2021-04-28 15:39:38 --> Router Class Initialized
INFO - 2021-04-28 15:39:38 --> Output Class Initialized
INFO - 2021-04-28 15:39:38 --> Output Class Initialized
INFO - 2021-04-28 15:39:38 --> Security Class Initialized
INFO - 2021-04-28 15:39:38 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:38 --> Input Class Initialized
DEBUG - 2021-04-28 15:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:38 --> Input Class Initialized
INFO - 2021-04-28 15:39:38 --> Language Class Initialized
INFO - 2021-04-28 15:39:38 --> Language Class Initialized
ERROR - 2021-04-28 15:39:38 --> 404 Page Not Found: administrator/UserController/dist
ERROR - 2021-04-28 15:39:38 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:39:38 --> Config Class Initialized
INFO - 2021-04-28 15:39:38 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:38 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:38 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:38 --> URI Class Initialized
INFO - 2021-04-28 15:39:38 --> Config Class Initialized
INFO - 2021-04-28 15:39:38 --> Hooks Class Initialized
INFO - 2021-04-28 15:39:38 --> Router Class Initialized
INFO - 2021-04-28 15:39:38 --> Output Class Initialized
DEBUG - 2021-04-28 15:39:38 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:38 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:38 --> Security Class Initialized
INFO - 2021-04-28 15:39:38 --> URI Class Initialized
DEBUG - 2021-04-28 15:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:38 --> Input Class Initialized
INFO - 2021-04-28 15:39:38 --> Router Class Initialized
INFO - 2021-04-28 15:39:38 --> Language Class Initialized
INFO - 2021-04-28 15:39:38 --> Output Class Initialized
ERROR - 2021-04-28 15:39:38 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:39:38 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:38 --> Input Class Initialized
INFO - 2021-04-28 15:39:38 --> Language Class Initialized
ERROR - 2021-04-28 15:39:38 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:39:40 --> Config Class Initialized
INFO - 2021-04-28 15:39:40 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:40 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:40 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:40 --> URI Class Initialized
INFO - 2021-04-28 15:39:40 --> Router Class Initialized
INFO - 2021-04-28 15:39:40 --> Output Class Initialized
INFO - 2021-04-28 15:39:40 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:40 --> Input Class Initialized
INFO - 2021-04-28 15:39:40 --> Language Class Initialized
INFO - 2021-04-28 15:39:40 --> Loader Class Initialized
INFO - 2021-04-28 15:39:40 --> Helper loaded: url_helper
INFO - 2021-04-28 15:39:40 --> Helper loaded: form_helper
INFO - 2021-04-28 15:39:40 --> Helper loaded: common_helper
INFO - 2021-04-28 15:39:40 --> Helper loaded: util_helper
INFO - 2021-04-28 15:39:40 --> Helper loaded: user_helper
INFO - 2021-04-28 15:39:40 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:39:40 --> Form Validation Class Initialized
INFO - 2021-04-28 15:39:40 --> Controller Class Initialized
INFO - 2021-04-28 15:39:40 --> Model Class Initialized
INFO - 2021-04-28 15:39:40 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:39:40 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:39:40 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 15:39:40 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:39:40 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:39:40 --> Final output sent to browser
DEBUG - 2021-04-28 15:39:40 --> Total execution time: 0.0315
INFO - 2021-04-28 15:39:43 --> Config Class Initialized
INFO - 2021-04-28 15:39:43 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:43 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:43 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:43 --> URI Class Initialized
INFO - 2021-04-28 15:39:43 --> Router Class Initialized
INFO - 2021-04-28 15:39:43 --> Output Class Initialized
INFO - 2021-04-28 15:39:43 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:43 --> Input Class Initialized
INFO - 2021-04-28 15:39:43 --> Language Class Initialized
INFO - 2021-04-28 15:39:43 --> Loader Class Initialized
INFO - 2021-04-28 15:39:43 --> Helper loaded: url_helper
INFO - 2021-04-28 15:39:43 --> Helper loaded: form_helper
INFO - 2021-04-28 15:39:43 --> Helper loaded: common_helper
INFO - 2021-04-28 15:39:43 --> Helper loaded: util_helper
INFO - 2021-04-28 15:39:43 --> Helper loaded: user_helper
INFO - 2021-04-28 15:39:43 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:39:43 --> Form Validation Class Initialized
INFO - 2021-04-28 15:39:43 --> Controller Class Initialized
INFO - 2021-04-28 15:39:43 --> Model Class Initialized
INFO - 2021-04-28 15:39:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:39:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:39:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/addUser.php
INFO - 2021-04-28 15:39:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:39:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:39:43 --> Final output sent to browser
DEBUG - 2021-04-28 15:39:43 --> Total execution time: 0.0297
INFO - 2021-04-28 15:39:43 --> Config Class Initialized
INFO - 2021-04-28 15:39:43 --> Hooks Class Initialized
INFO - 2021-04-28 15:39:43 --> Config Class Initialized
INFO - 2021-04-28 15:39:43 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:43 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:43 --> Utf8 Class Initialized
DEBUG - 2021-04-28 15:39:43 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:43 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:43 --> URI Class Initialized
INFO - 2021-04-28 15:39:43 --> URI Class Initialized
INFO - 2021-04-28 15:39:43 --> Router Class Initialized
INFO - 2021-04-28 15:39:43 --> Output Class Initialized
INFO - 2021-04-28 15:39:43 --> Router Class Initialized
INFO - 2021-04-28 15:39:43 --> Security Class Initialized
INFO - 2021-04-28 15:39:43 --> Output Class Initialized
DEBUG - 2021-04-28 15:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:43 --> Input Class Initialized
INFO - 2021-04-28 15:39:43 --> Language Class Initialized
INFO - 2021-04-28 15:39:43 --> Security Class Initialized
INFO - 2021-04-28 15:39:43 --> Config Class Initialized
INFO - 2021-04-28 15:39:43 --> Hooks Class Initialized
ERROR - 2021-04-28 15:39:43 --> 404 Page Not Found: administrator/UserController/dist
DEBUG - 2021-04-28 15:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:43 --> Input Class Initialized
INFO - 2021-04-28 15:39:43 --> Language Class Initialized
DEBUG - 2021-04-28 15:39:43 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:43 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:43 --> URI Class Initialized
ERROR - 2021-04-28 15:39:43 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:39:43 --> Router Class Initialized
INFO - 2021-04-28 15:39:43 --> Output Class Initialized
INFO - 2021-04-28 15:39:43 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:43 --> Input Class Initialized
INFO - 2021-04-28 15:39:43 --> Language Class Initialized
INFO - 2021-04-28 15:39:43 --> Config Class Initialized
INFO - 2021-04-28 15:39:43 --> Hooks Class Initialized
ERROR - 2021-04-28 15:39:43 --> 404 Page Not Found: administrator/UserController/dist
DEBUG - 2021-04-28 15:39:43 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:43 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:43 --> URI Class Initialized
INFO - 2021-04-28 15:39:43 --> Router Class Initialized
INFO - 2021-04-28 15:39:43 --> Output Class Initialized
INFO - 2021-04-28 15:39:43 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:43 --> Input Class Initialized
INFO - 2021-04-28 15:39:43 --> Language Class Initialized
ERROR - 2021-04-28 15:39:43 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:39:45 --> Config Class Initialized
INFO - 2021-04-28 15:39:45 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:45 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:45 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:45 --> URI Class Initialized
INFO - 2021-04-28 15:39:45 --> Router Class Initialized
INFO - 2021-04-28 15:39:45 --> Output Class Initialized
INFO - 2021-04-28 15:39:45 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:45 --> Input Class Initialized
INFO - 2021-04-28 15:39:45 --> Language Class Initialized
INFO - 2021-04-28 15:39:45 --> Loader Class Initialized
INFO - 2021-04-28 15:39:45 --> Helper loaded: url_helper
INFO - 2021-04-28 15:39:45 --> Helper loaded: form_helper
INFO - 2021-04-28 15:39:45 --> Helper loaded: common_helper
INFO - 2021-04-28 15:39:45 --> Helper loaded: util_helper
INFO - 2021-04-28 15:39:45 --> Helper loaded: user_helper
INFO - 2021-04-28 15:39:45 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:39:45 --> Form Validation Class Initialized
INFO - 2021-04-28 15:39:45 --> Controller Class Initialized
INFO - 2021-04-28 15:39:45 --> Model Class Initialized
INFO - 2021-04-28 15:39:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:39:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:39:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/list.php
INFO - 2021-04-28 15:39:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:39:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:39:45 --> Final output sent to browser
DEBUG - 2021-04-28 15:39:45 --> Total execution time: 0.0819
INFO - 2021-04-28 15:39:46 --> Config Class Initialized
INFO - 2021-04-28 15:39:46 --> Hooks Class Initialized
INFO - 2021-04-28 15:39:46 --> Config Class Initialized
INFO - 2021-04-28 15:39:46 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:46 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:46 --> Utf8 Class Initialized
DEBUG - 2021-04-28 15:39:46 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:46 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:46 --> URI Class Initialized
INFO - 2021-04-28 15:39:46 --> URI Class Initialized
INFO - 2021-04-28 15:39:46 --> Router Class Initialized
INFO - 2021-04-28 15:39:46 --> Router Class Initialized
INFO - 2021-04-28 15:39:46 --> Output Class Initialized
INFO - 2021-04-28 15:39:46 --> Output Class Initialized
INFO - 2021-04-28 15:39:46 --> Security Class Initialized
INFO - 2021-04-28 15:39:46 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:46 --> Input Class Initialized
DEBUG - 2021-04-28 15:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:46 --> Input Class Initialized
INFO - 2021-04-28 15:39:46 --> Language Class Initialized
INFO - 2021-04-28 15:39:46 --> Config Class Initialized
INFO - 2021-04-28 15:39:46 --> Hooks Class Initialized
INFO - 2021-04-28 15:39:46 --> Language Class Initialized
ERROR - 2021-04-28 15:39:46 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-04-28 15:39:46 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-04-28 15:39:46 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:46 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:46 --> URI Class Initialized
INFO - 2021-04-28 15:39:46 --> Router Class Initialized
INFO - 2021-04-28 15:39:46 --> Output Class Initialized
INFO - 2021-04-28 15:39:46 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:46 --> Input Class Initialized
INFO - 2021-04-28 15:39:46 --> Language Class Initialized
ERROR - 2021-04-28 15:39:46 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-28 15:39:46 --> Config Class Initialized
INFO - 2021-04-28 15:39:46 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:46 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:46 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:46 --> URI Class Initialized
INFO - 2021-04-28 15:39:46 --> Router Class Initialized
INFO - 2021-04-28 15:39:46 --> Output Class Initialized
INFO - 2021-04-28 15:39:46 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:46 --> Input Class Initialized
INFO - 2021-04-28 15:39:46 --> Language Class Initialized
ERROR - 2021-04-28 15:39:46 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-28 15:39:50 --> Config Class Initialized
INFO - 2021-04-28 15:39:50 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:50 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:50 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:50 --> URI Class Initialized
INFO - 2021-04-28 15:39:50 --> Router Class Initialized
INFO - 2021-04-28 15:39:50 --> Output Class Initialized
INFO - 2021-04-28 15:39:50 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:50 --> Input Class Initialized
INFO - 2021-04-28 15:39:50 --> Language Class Initialized
INFO - 2021-04-28 15:39:50 --> Loader Class Initialized
INFO - 2021-04-28 15:39:50 --> Helper loaded: url_helper
INFO - 2021-04-28 15:39:50 --> Helper loaded: form_helper
INFO - 2021-04-28 15:39:50 --> Helper loaded: common_helper
INFO - 2021-04-28 15:39:50 --> Helper loaded: util_helper
INFO - 2021-04-28 15:39:50 --> Helper loaded: user_helper
INFO - 2021-04-28 15:39:50 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:39:50 --> Form Validation Class Initialized
INFO - 2021-04-28 15:39:50 --> Controller Class Initialized
INFO - 2021-04-28 15:39:50 --> Model Class Initialized
INFO - 2021-04-28 15:39:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:39:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:39:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/addUser.php
INFO - 2021-04-28 15:39:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:39:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:39:50 --> Final output sent to browser
DEBUG - 2021-04-28 15:39:50 --> Total execution time: 0.0299
INFO - 2021-04-28 15:39:54 --> Config Class Initialized
INFO - 2021-04-28 15:39:54 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:54 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:54 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:54 --> URI Class Initialized
INFO - 2021-04-28 15:39:54 --> Router Class Initialized
INFO - 2021-04-28 15:39:54 --> Output Class Initialized
INFO - 2021-04-28 15:39:54 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:54 --> Input Class Initialized
INFO - 2021-04-28 15:39:54 --> Language Class Initialized
INFO - 2021-04-28 15:39:54 --> Loader Class Initialized
INFO - 2021-04-28 15:39:54 --> Helper loaded: url_helper
INFO - 2021-04-28 15:39:54 --> Helper loaded: form_helper
INFO - 2021-04-28 15:39:54 --> Helper loaded: common_helper
INFO - 2021-04-28 15:39:54 --> Helper loaded: util_helper
INFO - 2021-04-28 15:39:54 --> Helper loaded: user_helper
INFO - 2021-04-28 15:39:54 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:39:54 --> Form Validation Class Initialized
INFO - 2021-04-28 15:39:54 --> Controller Class Initialized
INFO - 2021-04-28 15:39:54 --> Model Class Initialized
INFO - 2021-04-28 15:39:54 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:39:54 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:39:54 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/list.php
INFO - 2021-04-28 15:39:54 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:39:54 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:39:54 --> Final output sent to browser
DEBUG - 2021-04-28 15:39:54 --> Total execution time: 0.0313
INFO - 2021-04-28 15:39:54 --> Config Class Initialized
INFO - 2021-04-28 15:39:54 --> Config Class Initialized
INFO - 2021-04-28 15:39:54 --> Hooks Class Initialized
INFO - 2021-04-28 15:39:54 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-28 15:39:54 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:54 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:54 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:54 --> URI Class Initialized
INFO - 2021-04-28 15:39:54 --> URI Class Initialized
INFO - 2021-04-28 15:39:54 --> Router Class Initialized
INFO - 2021-04-28 15:39:54 --> Router Class Initialized
INFO - 2021-04-28 15:39:54 --> Output Class Initialized
INFO - 2021-04-28 15:39:54 --> Output Class Initialized
INFO - 2021-04-28 15:39:54 --> Security Class Initialized
INFO - 2021-04-28 15:39:54 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-28 15:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:54 --> Input Class Initialized
INFO - 2021-04-28 15:39:54 --> Input Class Initialized
INFO - 2021-04-28 15:39:54 --> Language Class Initialized
INFO - 2021-04-28 15:39:54 --> Language Class Initialized
ERROR - 2021-04-28 15:39:54 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-04-28 15:39:54 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-28 15:39:54 --> Config Class Initialized
INFO - 2021-04-28 15:39:54 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:54 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:54 --> Config Class Initialized
INFO - 2021-04-28 15:39:54 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:54 --> Hooks Class Initialized
INFO - 2021-04-28 15:39:54 --> URI Class Initialized
INFO - 2021-04-28 15:39:54 --> Router Class Initialized
DEBUG - 2021-04-28 15:39:54 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:54 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:54 --> URI Class Initialized
INFO - 2021-04-28 15:39:54 --> Output Class Initialized
INFO - 2021-04-28 15:39:54 --> Router Class Initialized
INFO - 2021-04-28 15:39:54 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:54 --> Input Class Initialized
INFO - 2021-04-28 15:39:54 --> Output Class Initialized
INFO - 2021-04-28 15:39:54 --> Language Class Initialized
INFO - 2021-04-28 15:39:54 --> Security Class Initialized
ERROR - 2021-04-28 15:39:54 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-04-28 15:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:54 --> Input Class Initialized
INFO - 2021-04-28 15:39:54 --> Language Class Initialized
ERROR - 2021-04-28 15:39:54 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-28 15:39:56 --> Config Class Initialized
INFO - 2021-04-28 15:39:56 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:56 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:56 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:56 --> URI Class Initialized
INFO - 2021-04-28 15:39:56 --> Router Class Initialized
INFO - 2021-04-28 15:39:56 --> Output Class Initialized
INFO - 2021-04-28 15:39:56 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:56 --> Input Class Initialized
INFO - 2021-04-28 15:39:56 --> Language Class Initialized
INFO - 2021-04-28 15:39:56 --> Loader Class Initialized
INFO - 2021-04-28 15:39:56 --> Helper loaded: url_helper
INFO - 2021-04-28 15:39:56 --> Helper loaded: form_helper
INFO - 2021-04-28 15:39:56 --> Helper loaded: common_helper
INFO - 2021-04-28 15:39:56 --> Helper loaded: util_helper
INFO - 2021-04-28 15:39:56 --> Helper loaded: user_helper
INFO - 2021-04-28 15:39:56 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:39:56 --> Form Validation Class Initialized
INFO - 2021-04-28 15:39:56 --> Controller Class Initialized
INFO - 2021-04-28 15:39:56 --> Model Class Initialized
INFO - 2021-04-28 15:39:56 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:39:56 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:39:56 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/addUser.php
INFO - 2021-04-28 15:39:56 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:39:56 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:39:56 --> Final output sent to browser
DEBUG - 2021-04-28 15:39:56 --> Total execution time: 0.0306
INFO - 2021-04-28 15:39:57 --> Config Class Initialized
INFO - 2021-04-28 15:39:57 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:39:57 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:39:57 --> Utf8 Class Initialized
INFO - 2021-04-28 15:39:57 --> URI Class Initialized
INFO - 2021-04-28 15:39:57 --> Router Class Initialized
INFO - 2021-04-28 15:39:57 --> Output Class Initialized
INFO - 2021-04-28 15:39:57 --> Security Class Initialized
DEBUG - 2021-04-28 15:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:39:57 --> Input Class Initialized
INFO - 2021-04-28 15:39:57 --> Language Class Initialized
INFO - 2021-04-28 15:39:57 --> Loader Class Initialized
INFO - 2021-04-28 15:39:57 --> Helper loaded: url_helper
INFO - 2021-04-28 15:39:57 --> Helper loaded: form_helper
INFO - 2021-04-28 15:39:57 --> Helper loaded: common_helper
INFO - 2021-04-28 15:39:57 --> Helper loaded: util_helper
INFO - 2021-04-28 15:39:57 --> Helper loaded: user_helper
INFO - 2021-04-28 15:39:57 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:39:57 --> Form Validation Class Initialized
INFO - 2021-04-28 15:39:57 --> Controller Class Initialized
INFO - 2021-04-28 15:39:57 --> Model Class Initialized
INFO - 2021-04-28 15:39:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:39:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:39:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 15:39:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:39:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:39:57 --> Final output sent to browser
DEBUG - 2021-04-28 15:39:57 --> Total execution time: 0.0402
INFO - 2021-04-28 15:40:01 --> Config Class Initialized
INFO - 2021-04-28 15:40:01 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:40:01 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:40:01 --> Utf8 Class Initialized
INFO - 2021-04-28 15:40:01 --> URI Class Initialized
INFO - 2021-04-28 15:40:01 --> Router Class Initialized
INFO - 2021-04-28 15:40:01 --> Output Class Initialized
INFO - 2021-04-28 15:40:01 --> Security Class Initialized
DEBUG - 2021-04-28 15:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:40:01 --> Input Class Initialized
INFO - 2021-04-28 15:40:01 --> Language Class Initialized
INFO - 2021-04-28 15:40:01 --> Loader Class Initialized
INFO - 2021-04-28 15:40:01 --> Helper loaded: url_helper
INFO - 2021-04-28 15:40:01 --> Helper loaded: form_helper
INFO - 2021-04-28 15:40:01 --> Helper loaded: common_helper
INFO - 2021-04-28 15:40:01 --> Helper loaded: util_helper
INFO - 2021-04-28 15:40:01 --> Helper loaded: user_helper
INFO - 2021-04-28 15:40:01 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:40:01 --> Form Validation Class Initialized
INFO - 2021-04-28 15:40:01 --> Controller Class Initialized
INFO - 2021-04-28 15:40:01 --> Model Class Initialized
INFO - 2021-04-28 15:40:01 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:40:01 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:40:01 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/addUser.php
INFO - 2021-04-28 15:40:01 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:40:01 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:40:01 --> Final output sent to browser
DEBUG - 2021-04-28 15:40:01 --> Total execution time: 0.0299
INFO - 2021-04-28 15:40:01 --> Config Class Initialized
INFO - 2021-04-28 15:40:01 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:40:01 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:40:01 --> Utf8 Class Initialized
INFO - 2021-04-28 15:40:01 --> URI Class Initialized
INFO - 2021-04-28 15:40:01 --> Config Class Initialized
INFO - 2021-04-28 15:40:01 --> Router Class Initialized
INFO - 2021-04-28 15:40:01 --> Output Class Initialized
INFO - 2021-04-28 15:40:01 --> Security Class Initialized
DEBUG - 2021-04-28 15:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:40:01 --> Input Class Initialized
INFO - 2021-04-28 15:40:01 --> Language Class Initialized
ERROR - 2021-04-28 15:40:01 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:40:01 --> Hooks Class Initialized
INFO - 2021-04-28 15:40:01 --> Config Class Initialized
INFO - 2021-04-28 15:40:01 --> Hooks Class Initialized
INFO - 2021-04-28 15:40:01 --> Config Class Initialized
INFO - 2021-04-28 15:40:01 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:40:01 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:40:01 --> Utf8 Class Initialized
DEBUG - 2021-04-28 15:40:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-28 15:40:01 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:40:01 --> Utf8 Class Initialized
INFO - 2021-04-28 15:40:01 --> Utf8 Class Initialized
INFO - 2021-04-28 15:40:01 --> URI Class Initialized
INFO - 2021-04-28 15:40:01 --> URI Class Initialized
INFO - 2021-04-28 15:40:01 --> URI Class Initialized
INFO - 2021-04-28 15:40:01 --> Router Class Initialized
INFO - 2021-04-28 15:40:01 --> Router Class Initialized
INFO - 2021-04-28 15:40:01 --> Router Class Initialized
INFO - 2021-04-28 15:40:01 --> Output Class Initialized
INFO - 2021-04-28 15:40:01 --> Output Class Initialized
INFO - 2021-04-28 15:40:01 --> Output Class Initialized
INFO - 2021-04-28 15:40:01 --> Security Class Initialized
INFO - 2021-04-28 15:40:01 --> Security Class Initialized
INFO - 2021-04-28 15:40:01 --> Security Class Initialized
DEBUG - 2021-04-28 15:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:40:01 --> Input Class Initialized
INFO - 2021-04-28 15:40:01 --> Language Class Initialized
DEBUG - 2021-04-28 15:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-28 15:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:40:01 --> Input Class Initialized
INFO - 2021-04-28 15:40:01 --> Input Class Initialized
INFO - 2021-04-28 15:40:01 --> Language Class Initialized
INFO - 2021-04-28 15:40:01 --> Language Class Initialized
ERROR - 2021-04-28 15:40:01 --> 404 Page Not Found: administrator/UserController/dist
ERROR - 2021-04-28 15:40:01 --> 404 Page Not Found: administrator/UserController/dist
ERROR - 2021-04-28 15:40:01 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:40:03 --> Config Class Initialized
INFO - 2021-04-28 15:40:03 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:40:03 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:40:03 --> Utf8 Class Initialized
INFO - 2021-04-28 15:40:03 --> URI Class Initialized
INFO - 2021-04-28 15:40:03 --> Router Class Initialized
INFO - 2021-04-28 15:40:03 --> Output Class Initialized
INFO - 2021-04-28 15:40:03 --> Security Class Initialized
DEBUG - 2021-04-28 15:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:40:03 --> Input Class Initialized
INFO - 2021-04-28 15:40:03 --> Language Class Initialized
INFO - 2021-04-28 15:40:03 --> Loader Class Initialized
INFO - 2021-04-28 15:40:03 --> Helper loaded: url_helper
INFO - 2021-04-28 15:40:03 --> Helper loaded: form_helper
INFO - 2021-04-28 15:40:03 --> Helper loaded: common_helper
INFO - 2021-04-28 15:40:03 --> Helper loaded: util_helper
INFO - 2021-04-28 15:40:03 --> Helper loaded: user_helper
INFO - 2021-04-28 15:40:03 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:40:03 --> Form Validation Class Initialized
INFO - 2021-04-28 15:40:03 --> Controller Class Initialized
INFO - 2021-04-28 15:40:03 --> Model Class Initialized
INFO - 2021-04-28 15:40:03 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:40:03 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:40:03 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/list.php
INFO - 2021-04-28 15:40:03 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:40:03 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:40:03 --> Final output sent to browser
DEBUG - 2021-04-28 15:40:03 --> Total execution time: 0.0312
INFO - 2021-04-28 15:40:03 --> Config Class Initialized
INFO - 2021-04-28 15:40:03 --> Hooks Class Initialized
INFO - 2021-04-28 15:40:03 --> Config Class Initialized
DEBUG - 2021-04-28 15:40:03 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:40:03 --> Utf8 Class Initialized
INFO - 2021-04-28 15:40:03 --> URI Class Initialized
INFO - 2021-04-28 15:40:03 --> Router Class Initialized
INFO - 2021-04-28 15:40:03 --> Output Class Initialized
INFO - 2021-04-28 15:40:03 --> Security Class Initialized
DEBUG - 2021-04-28 15:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:40:03 --> Input Class Initialized
INFO - 2021-04-28 15:40:03 --> Language Class Initialized
INFO - 2021-04-28 15:40:03 --> Config Class Initialized
INFO - 2021-04-28 15:40:03 --> Hooks Class Initialized
ERROR - 2021-04-28 15:40:03 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-28 15:40:03 --> Config Class Initialized
INFO - 2021-04-28 15:40:03 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:40:03 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:40:03 --> Utf8 Class Initialized
INFO - 2021-04-28 15:40:03 --> URI Class Initialized
DEBUG - 2021-04-28 15:40:03 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:40:03 --> Utf8 Class Initialized
INFO - 2021-04-28 15:40:03 --> Hooks Class Initialized
INFO - 2021-04-28 15:40:03 --> Router Class Initialized
INFO - 2021-04-28 15:40:03 --> URI Class Initialized
INFO - 2021-04-28 15:40:03 --> Router Class Initialized
INFO - 2021-04-28 15:40:03 --> Output Class Initialized
INFO - 2021-04-28 15:40:03 --> Security Class Initialized
INFO - 2021-04-28 15:40:03 --> Output Class Initialized
DEBUG - 2021-04-28 15:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:40:03 --> Input Class Initialized
INFO - 2021-04-28 15:40:03 --> Security Class Initialized
DEBUG - 2021-04-28 15:40:03 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:40:03 --> Language Class Initialized
INFO - 2021-04-28 15:40:03 --> Utf8 Class Initialized
DEBUG - 2021-04-28 15:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:40:03 --> Input Class Initialized
INFO - 2021-04-28 15:40:03 --> URI Class Initialized
INFO - 2021-04-28 15:40:03 --> Language Class Initialized
ERROR - 2021-04-28 15:40:03 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-28 15:40:03 --> Router Class Initialized
ERROR - 2021-04-28 15:40:03 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-28 15:40:03 --> Output Class Initialized
INFO - 2021-04-28 15:40:03 --> Security Class Initialized
DEBUG - 2021-04-28 15:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:40:03 --> Input Class Initialized
INFO - 2021-04-28 15:40:03 --> Language Class Initialized
ERROR - 2021-04-28 15:40:03 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-28 15:40:07 --> Config Class Initialized
INFO - 2021-04-28 15:40:07 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:40:07 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:40:07 --> Utf8 Class Initialized
INFO - 2021-04-28 15:40:07 --> URI Class Initialized
INFO - 2021-04-28 15:40:07 --> Router Class Initialized
INFO - 2021-04-28 15:40:07 --> Output Class Initialized
INFO - 2021-04-28 15:40:07 --> Security Class Initialized
DEBUG - 2021-04-28 15:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:40:07 --> Input Class Initialized
INFO - 2021-04-28 15:40:07 --> Language Class Initialized
INFO - 2021-04-28 15:40:07 --> Loader Class Initialized
INFO - 2021-04-28 15:40:07 --> Helper loaded: url_helper
INFO - 2021-04-28 15:40:07 --> Helper loaded: form_helper
INFO - 2021-04-28 15:40:07 --> Helper loaded: common_helper
INFO - 2021-04-28 15:40:07 --> Helper loaded: util_helper
INFO - 2021-04-28 15:40:07 --> Helper loaded: user_helper
INFO - 2021-04-28 15:40:07 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:40:07 --> Form Validation Class Initialized
INFO - 2021-04-28 15:40:07 --> Controller Class Initialized
INFO - 2021-04-28 15:40:07 --> Model Class Initialized
INFO - 2021-04-28 15:40:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:40:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:40:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/addUser.php
INFO - 2021-04-28 15:40:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:40:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:40:07 --> Final output sent to browser
DEBUG - 2021-04-28 15:40:07 --> Total execution time: 0.0303
INFO - 2021-04-28 15:40:52 --> Config Class Initialized
INFO - 2021-04-28 15:40:52 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:40:52 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:40:52 --> Utf8 Class Initialized
INFO - 2021-04-28 15:40:52 --> URI Class Initialized
INFO - 2021-04-28 15:40:52 --> Router Class Initialized
INFO - 2021-04-28 15:40:52 --> Output Class Initialized
INFO - 2021-04-28 15:40:52 --> Security Class Initialized
DEBUG - 2021-04-28 15:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:40:52 --> Input Class Initialized
INFO - 2021-04-28 15:40:52 --> Language Class Initialized
INFO - 2021-04-28 15:40:52 --> Loader Class Initialized
INFO - 2021-04-28 15:40:52 --> Helper loaded: url_helper
INFO - 2021-04-28 15:40:52 --> Helper loaded: form_helper
INFO - 2021-04-28 15:40:52 --> Helper loaded: common_helper
INFO - 2021-04-28 15:40:52 --> Helper loaded: util_helper
INFO - 2021-04-28 15:40:52 --> Helper loaded: user_helper
INFO - 2021-04-28 15:40:52 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:40:52 --> Form Validation Class Initialized
INFO - 2021-04-28 15:40:52 --> Controller Class Initialized
INFO - 2021-04-28 15:40:52 --> Model Class Initialized
INFO - 2021-04-28 15:40:52 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:40:52 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:40:52 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/addUser.php
INFO - 2021-04-28 15:40:52 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:40:52 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:40:52 --> Final output sent to browser
DEBUG - 2021-04-28 15:40:52 --> Total execution time: 0.0308
INFO - 2021-04-28 15:40:52 --> Config Class Initialized
INFO - 2021-04-28 15:40:52 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:40:52 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:40:52 --> Utf8 Class Initialized
INFO - 2021-04-28 15:40:52 --> Config Class Initialized
INFO - 2021-04-28 15:40:52 --> Hooks Class Initialized
INFO - 2021-04-28 15:40:52 --> URI Class Initialized
INFO - 2021-04-28 15:40:52 --> Router Class Initialized
DEBUG - 2021-04-28 15:40:52 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:40:52 --> Utf8 Class Initialized
INFO - 2021-04-28 15:40:52 --> Output Class Initialized
INFO - 2021-04-28 15:40:52 --> URI Class Initialized
INFO - 2021-04-28 15:40:52 --> Security Class Initialized
INFO - 2021-04-28 15:40:52 --> Router Class Initialized
DEBUG - 2021-04-28 15:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:40:52 --> Input Class Initialized
INFO - 2021-04-28 15:40:52 --> Output Class Initialized
INFO - 2021-04-28 15:40:52 --> Language Class Initialized
ERROR - 2021-04-28 15:40:52 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:40:52 --> Security Class Initialized
DEBUG - 2021-04-28 15:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:40:52 --> Input Class Initialized
INFO - 2021-04-28 15:40:52 --> Language Class Initialized
INFO - 2021-04-28 15:40:52 --> Config Class Initialized
INFO - 2021-04-28 15:40:52 --> Hooks Class Initialized
ERROR - 2021-04-28 15:40:52 --> 404 Page Not Found: administrator/UserController/dist
DEBUG - 2021-04-28 15:40:52 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:40:52 --> Utf8 Class Initialized
INFO - 2021-04-28 15:40:52 --> URI Class Initialized
INFO - 2021-04-28 15:40:52 --> Router Class Initialized
INFO - 2021-04-28 15:40:52 --> Output Class Initialized
INFO - 2021-04-28 15:40:52 --> Config Class Initialized
INFO - 2021-04-28 15:40:52 --> Security Class Initialized
INFO - 2021-04-28 15:40:52 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:40:52 --> Input Class Initialized
INFO - 2021-04-28 15:40:52 --> Language Class Initialized
DEBUG - 2021-04-28 15:40:52 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:40:52 --> Utf8 Class Initialized
INFO - 2021-04-28 15:40:52 --> URI Class Initialized
ERROR - 2021-04-28 15:40:52 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:40:52 --> Router Class Initialized
INFO - 2021-04-28 15:40:52 --> Output Class Initialized
INFO - 2021-04-28 15:40:52 --> Security Class Initialized
DEBUG - 2021-04-28 15:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:40:52 --> Input Class Initialized
INFO - 2021-04-28 15:40:52 --> Language Class Initialized
ERROR - 2021-04-28 15:40:52 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:40:54 --> Config Class Initialized
INFO - 2021-04-28 15:40:54 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:40:54 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:40:54 --> Utf8 Class Initialized
INFO - 2021-04-28 15:40:54 --> URI Class Initialized
INFO - 2021-04-28 15:40:54 --> Router Class Initialized
INFO - 2021-04-28 15:40:54 --> Output Class Initialized
INFO - 2021-04-28 15:40:54 --> Security Class Initialized
DEBUG - 2021-04-28 15:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:40:54 --> Input Class Initialized
INFO - 2021-04-28 15:40:54 --> Language Class Initialized
INFO - 2021-04-28 15:40:54 --> Loader Class Initialized
INFO - 2021-04-28 15:40:54 --> Helper loaded: url_helper
INFO - 2021-04-28 15:40:54 --> Helper loaded: form_helper
INFO - 2021-04-28 15:40:54 --> Helper loaded: common_helper
INFO - 2021-04-28 15:40:54 --> Helper loaded: util_helper
INFO - 2021-04-28 15:40:54 --> Helper loaded: user_helper
INFO - 2021-04-28 15:40:54 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:40:54 --> Form Validation Class Initialized
INFO - 2021-04-28 15:40:54 --> Controller Class Initialized
INFO - 2021-04-28 15:40:54 --> Model Class Initialized
INFO - 2021-04-28 15:40:54 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:40:54 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:40:54 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 15:40:54 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:40:54 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:40:54 --> Final output sent to browser
DEBUG - 2021-04-28 15:40:54 --> Total execution time: 0.0333
INFO - 2021-04-28 15:40:54 --> Config Class Initialized
INFO - 2021-04-28 15:40:54 --> Hooks Class Initialized
INFO - 2021-04-28 15:40:54 --> Config Class Initialized
INFO - 2021-04-28 15:40:54 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:40:54 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:40:54 --> Utf8 Class Initialized
DEBUG - 2021-04-28 15:40:54 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:40:54 --> URI Class Initialized
INFO - 2021-04-28 15:40:54 --> Utf8 Class Initialized
INFO - 2021-04-28 15:40:54 --> URI Class Initialized
INFO - 2021-04-28 15:40:54 --> Router Class Initialized
INFO - 2021-04-28 15:40:54 --> Router Class Initialized
INFO - 2021-04-28 15:40:54 --> Output Class Initialized
INFO - 2021-04-28 15:40:54 --> Output Class Initialized
INFO - 2021-04-28 15:40:54 --> Security Class Initialized
INFO - 2021-04-28 15:40:54 --> Security Class Initialized
DEBUG - 2021-04-28 15:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:40:54 --> Input Class Initialized
INFO - 2021-04-28 15:40:54 --> Language Class Initialized
DEBUG - 2021-04-28 15:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:40:54 --> Input Class Initialized
INFO - 2021-04-28 15:40:54 --> Language Class Initialized
ERROR - 2021-04-28 15:40:54 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-04-28 15:40:54 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-28 15:40:54 --> Config Class Initialized
INFO - 2021-04-28 15:40:54 --> Hooks Class Initialized
INFO - 2021-04-28 15:40:54 --> Config Class Initialized
DEBUG - 2021-04-28 15:40:54 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:40:54 --> Hooks Class Initialized
INFO - 2021-04-28 15:40:54 --> Utf8 Class Initialized
INFO - 2021-04-28 15:40:54 --> URI Class Initialized
DEBUG - 2021-04-28 15:40:54 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:40:54 --> Utf8 Class Initialized
INFO - 2021-04-28 15:40:54 --> Router Class Initialized
INFO - 2021-04-28 15:40:54 --> URI Class Initialized
INFO - 2021-04-28 15:40:54 --> Output Class Initialized
INFO - 2021-04-28 15:40:54 --> Router Class Initialized
INFO - 2021-04-28 15:40:54 --> Security Class Initialized
DEBUG - 2021-04-28 15:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:40:54 --> Output Class Initialized
INFO - 2021-04-28 15:40:54 --> Input Class Initialized
INFO - 2021-04-28 15:40:54 --> Language Class Initialized
INFO - 2021-04-28 15:40:54 --> Security Class Initialized
ERROR - 2021-04-28 15:40:54 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-04-28 15:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:40:54 --> Input Class Initialized
INFO - 2021-04-28 15:40:54 --> Language Class Initialized
ERROR - 2021-04-28 15:40:54 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-28 15:40:57 --> Config Class Initialized
INFO - 2021-04-28 15:40:57 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:40:57 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:40:57 --> Utf8 Class Initialized
INFO - 2021-04-28 15:40:57 --> URI Class Initialized
INFO - 2021-04-28 15:40:57 --> Router Class Initialized
INFO - 2021-04-28 15:40:57 --> Output Class Initialized
INFO - 2021-04-28 15:40:57 --> Security Class Initialized
DEBUG - 2021-04-28 15:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:40:57 --> Input Class Initialized
INFO - 2021-04-28 15:40:57 --> Language Class Initialized
INFO - 2021-04-28 15:40:57 --> Loader Class Initialized
INFO - 2021-04-28 15:40:57 --> Helper loaded: url_helper
INFO - 2021-04-28 15:40:57 --> Helper loaded: form_helper
INFO - 2021-04-28 15:40:57 --> Helper loaded: common_helper
INFO - 2021-04-28 15:40:57 --> Helper loaded: util_helper
INFO - 2021-04-28 15:40:57 --> Helper loaded: user_helper
INFO - 2021-04-28 15:40:57 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:40:57 --> Form Validation Class Initialized
INFO - 2021-04-28 15:40:57 --> Controller Class Initialized
INFO - 2021-04-28 15:40:57 --> Model Class Initialized
INFO - 2021-04-28 15:40:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:40:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:40:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/addUser.php
INFO - 2021-04-28 15:40:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:40:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:40:57 --> Final output sent to browser
DEBUG - 2021-04-28 15:40:57 --> Total execution time: 0.0306
INFO - 2021-04-28 15:40:57 --> Config Class Initialized
INFO - 2021-04-28 15:40:57 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:40:57 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:40:57 --> Utf8 Class Initialized
INFO - 2021-04-28 15:40:57 --> URI Class Initialized
INFO - 2021-04-28 15:40:57 --> Router Class Initialized
INFO - 2021-04-28 15:40:57 --> Output Class Initialized
INFO - 2021-04-28 15:40:57 --> Security Class Initialized
DEBUG - 2021-04-28 15:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:40:57 --> Input Class Initialized
INFO - 2021-04-28 15:40:57 --> Language Class Initialized
INFO - 2021-04-28 15:40:57 --> Loader Class Initialized
INFO - 2021-04-28 15:40:57 --> Helper loaded: url_helper
INFO - 2021-04-28 15:40:57 --> Helper loaded: form_helper
INFO - 2021-04-28 15:40:57 --> Helper loaded: common_helper
INFO - 2021-04-28 15:40:57 --> Helper loaded: util_helper
INFO - 2021-04-28 15:40:57 --> Helper loaded: user_helper
INFO - 2021-04-28 15:40:57 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:40:57 --> Form Validation Class Initialized
INFO - 2021-04-28 15:40:57 --> Controller Class Initialized
INFO - 2021-04-28 15:40:57 --> Model Class Initialized
INFO - 2021-04-28 15:40:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:40:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:40:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 15:40:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:40:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:40:57 --> Final output sent to browser
DEBUG - 2021-04-28 15:40:57 --> Total execution time: 0.0308
INFO - 2021-04-28 15:40:59 --> Config Class Initialized
INFO - 2021-04-28 15:40:59 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:40:59 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:40:59 --> Utf8 Class Initialized
INFO - 2021-04-28 15:40:59 --> URI Class Initialized
INFO - 2021-04-28 15:40:59 --> Router Class Initialized
INFO - 2021-04-28 15:40:59 --> Output Class Initialized
INFO - 2021-04-28 15:40:59 --> Security Class Initialized
DEBUG - 2021-04-28 15:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:40:59 --> Input Class Initialized
INFO - 2021-04-28 15:40:59 --> Language Class Initialized
INFO - 2021-04-28 15:40:59 --> Loader Class Initialized
INFO - 2021-04-28 15:40:59 --> Helper loaded: url_helper
INFO - 2021-04-28 15:40:59 --> Helper loaded: form_helper
INFO - 2021-04-28 15:40:59 --> Helper loaded: common_helper
INFO - 2021-04-28 15:40:59 --> Helper loaded: util_helper
INFO - 2021-04-28 15:40:59 --> Helper loaded: user_helper
INFO - 2021-04-28 15:40:59 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:40:59 --> Form Validation Class Initialized
INFO - 2021-04-28 15:40:59 --> Controller Class Initialized
INFO - 2021-04-28 15:40:59 --> Model Class Initialized
INFO - 2021-04-28 15:40:59 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:40:59 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:40:59 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 15:40:59 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:40:59 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:40:59 --> Final output sent to browser
DEBUG - 2021-04-28 15:40:59 --> Total execution time: 0.0455
INFO - 2021-04-28 15:41:41 --> Config Class Initialized
INFO - 2021-04-28 15:41:41 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:41:41 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:41:41 --> Utf8 Class Initialized
INFO - 2021-04-28 15:41:41 --> URI Class Initialized
INFO - 2021-04-28 15:41:41 --> Router Class Initialized
INFO - 2021-04-28 15:41:41 --> Output Class Initialized
INFO - 2021-04-28 15:41:41 --> Security Class Initialized
DEBUG - 2021-04-28 15:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:41:41 --> Input Class Initialized
INFO - 2021-04-28 15:41:41 --> Language Class Initialized
INFO - 2021-04-28 15:41:41 --> Loader Class Initialized
INFO - 2021-04-28 15:41:41 --> Helper loaded: url_helper
INFO - 2021-04-28 15:41:41 --> Helper loaded: form_helper
INFO - 2021-04-28 15:41:41 --> Helper loaded: common_helper
INFO - 2021-04-28 15:41:41 --> Helper loaded: util_helper
INFO - 2021-04-28 15:41:41 --> Helper loaded: user_helper
INFO - 2021-04-28 15:41:41 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:41:41 --> Form Validation Class Initialized
INFO - 2021-04-28 15:41:41 --> Controller Class Initialized
INFO - 2021-04-28 15:41:41 --> Model Class Initialized
INFO - 2021-04-28 15:41:41 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:41:41 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:41:41 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 15:41:41 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:41:41 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:41:41 --> Final output sent to browser
DEBUG - 2021-04-28 15:41:41 --> Total execution time: 0.0359
INFO - 2021-04-28 15:41:43 --> Config Class Initialized
INFO - 2021-04-28 15:41:43 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:41:43 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:41:43 --> Utf8 Class Initialized
INFO - 2021-04-28 15:41:43 --> URI Class Initialized
INFO - 2021-04-28 15:41:43 --> Router Class Initialized
INFO - 2021-04-28 15:41:43 --> Output Class Initialized
INFO - 2021-04-28 15:41:43 --> Security Class Initialized
DEBUG - 2021-04-28 15:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:41:43 --> Input Class Initialized
INFO - 2021-04-28 15:41:43 --> Language Class Initialized
INFO - 2021-04-28 15:41:43 --> Loader Class Initialized
INFO - 2021-04-28 15:41:43 --> Helper loaded: url_helper
INFO - 2021-04-28 15:41:43 --> Helper loaded: form_helper
INFO - 2021-04-28 15:41:43 --> Helper loaded: common_helper
INFO - 2021-04-28 15:41:43 --> Helper loaded: util_helper
INFO - 2021-04-28 15:41:43 --> Helper loaded: user_helper
INFO - 2021-04-28 15:41:43 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:41:43 --> Form Validation Class Initialized
INFO - 2021-04-28 15:41:43 --> Controller Class Initialized
INFO - 2021-04-28 15:41:43 --> Model Class Initialized
INFO - 2021-04-28 15:41:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:41:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:41:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 15:41:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:41:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:41:43 --> Final output sent to browser
DEBUG - 2021-04-28 15:41:43 --> Total execution time: 0.0405
INFO - 2021-04-28 15:41:43 --> Config Class Initialized
INFO - 2021-04-28 15:41:43 --> Config Class Initialized
INFO - 2021-04-28 15:41:43 --> Hooks Class Initialized
INFO - 2021-04-28 15:41:43 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:41:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-28 15:41:43 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:41:43 --> Utf8 Class Initialized
INFO - 2021-04-28 15:41:43 --> Utf8 Class Initialized
INFO - 2021-04-28 15:41:43 --> URI Class Initialized
INFO - 2021-04-28 15:41:43 --> URI Class Initialized
INFO - 2021-04-28 15:41:43 --> Router Class Initialized
INFO - 2021-04-28 15:41:43 --> Router Class Initialized
INFO - 2021-04-28 15:41:43 --> Output Class Initialized
INFO - 2021-04-28 15:41:43 --> Output Class Initialized
INFO - 2021-04-28 15:41:43 --> Security Class Initialized
INFO - 2021-04-28 15:41:43 --> Security Class Initialized
DEBUG - 2021-04-28 15:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:41:43 --> Input Class Initialized
DEBUG - 2021-04-28 15:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:41:43 --> Language Class Initialized
INFO - 2021-04-28 15:41:43 --> Input Class Initialized
INFO - 2021-04-28 15:41:43 --> Language Class Initialized
ERROR - 2021-04-28 15:41:43 --> 404 Page Not Found: administrator/UserController/dist
ERROR - 2021-04-28 15:41:43 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:41:43 --> Config Class Initialized
INFO - 2021-04-28 15:41:43 --> Hooks Class Initialized
INFO - 2021-04-28 15:41:43 --> Config Class Initialized
INFO - 2021-04-28 15:41:43 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:41:43 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:41:43 --> Utf8 Class Initialized
DEBUG - 2021-04-28 15:41:43 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:41:43 --> Utf8 Class Initialized
INFO - 2021-04-28 15:41:43 --> URI Class Initialized
INFO - 2021-04-28 15:41:43 --> URI Class Initialized
INFO - 2021-04-28 15:41:43 --> Router Class Initialized
INFO - 2021-04-28 15:41:43 --> Router Class Initialized
INFO - 2021-04-28 15:41:43 --> Output Class Initialized
INFO - 2021-04-28 15:41:43 --> Output Class Initialized
INFO - 2021-04-28 15:41:43 --> Security Class Initialized
INFO - 2021-04-28 15:41:43 --> Security Class Initialized
DEBUG - 2021-04-28 15:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:41:43 --> Input Class Initialized
DEBUG - 2021-04-28 15:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:41:43 --> Input Class Initialized
INFO - 2021-04-28 15:41:43 --> Language Class Initialized
INFO - 2021-04-28 15:41:43 --> Language Class Initialized
ERROR - 2021-04-28 15:41:43 --> 404 Page Not Found: administrator/UserController/dist
ERROR - 2021-04-28 15:41:43 --> 404 Page Not Found: administrator/UserController/dist
INFO - 2021-04-28 15:41:46 --> Config Class Initialized
INFO - 2021-04-28 15:41:46 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:41:46 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:41:46 --> Utf8 Class Initialized
INFO - 2021-04-28 15:41:46 --> URI Class Initialized
INFO - 2021-04-28 15:41:46 --> Router Class Initialized
INFO - 2021-04-28 15:41:46 --> Output Class Initialized
INFO - 2021-04-28 15:41:46 --> Security Class Initialized
DEBUG - 2021-04-28 15:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:41:46 --> Input Class Initialized
INFO - 2021-04-28 15:41:46 --> Language Class Initialized
INFO - 2021-04-28 15:41:46 --> Loader Class Initialized
INFO - 2021-04-28 15:41:46 --> Helper loaded: url_helper
INFO - 2021-04-28 15:41:46 --> Helper loaded: form_helper
INFO - 2021-04-28 15:41:46 --> Helper loaded: common_helper
INFO - 2021-04-28 15:41:46 --> Helper loaded: util_helper
INFO - 2021-04-28 15:41:46 --> Helper loaded: user_helper
INFO - 2021-04-28 15:41:46 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:41:46 --> Form Validation Class Initialized
INFO - 2021-04-28 15:41:46 --> Controller Class Initialized
INFO - 2021-04-28 15:41:46 --> Model Class Initialized
INFO - 2021-04-28 15:41:46 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:41:46 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:41:46 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/editUser.php
INFO - 2021-04-28 15:41:46 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:41:46 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:41:46 --> Final output sent to browser
DEBUG - 2021-04-28 15:41:46 --> Total execution time: 0.0300
INFO - 2021-04-28 15:41:46 --> Config Class Initialized
INFO - 2021-04-28 15:41:46 --> Hooks Class Initialized
INFO - 2021-04-28 15:41:46 --> Config Class Initialized
INFO - 2021-04-28 15:41:46 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:41:46 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:41:46 --> Utf8 Class Initialized
DEBUG - 2021-04-28 15:41:46 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:41:46 --> Utf8 Class Initialized
INFO - 2021-04-28 15:41:46 --> URI Class Initialized
INFO - 2021-04-28 15:41:46 --> URI Class Initialized
INFO - 2021-04-28 15:41:46 --> Router Class Initialized
INFO - 2021-04-28 15:41:46 --> Router Class Initialized
INFO - 2021-04-28 15:41:46 --> Output Class Initialized
INFO - 2021-04-28 15:41:46 --> Output Class Initialized
INFO - 2021-04-28 15:41:46 --> Security Class Initialized
INFO - 2021-04-28 15:41:46 --> Security Class Initialized
DEBUG - 2021-04-28 15:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:41:46 --> Input Class Initialized
DEBUG - 2021-04-28 15:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:41:46 --> Language Class Initialized
INFO - 2021-04-28 15:41:46 --> Input Class Initialized
INFO - 2021-04-28 15:41:46 --> Language Class Initialized
ERROR - 2021-04-28 15:41:46 --> 404 Page Not Found: UserController/update
ERROR - 2021-04-28 15:41:46 --> 404 Page Not Found: UserController/update
INFO - 2021-04-28 15:41:46 --> Config Class Initialized
INFO - 2021-04-28 15:41:46 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:41:46 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:41:46 --> Utf8 Class Initialized
INFO - 2021-04-28 15:41:46 --> URI Class Initialized
INFO - 2021-04-28 15:41:46 --> Router Class Initialized
INFO - 2021-04-28 15:41:46 --> Output Class Initialized
INFO - 2021-04-28 15:41:46 --> Config Class Initialized
INFO - 2021-04-28 15:41:46 --> Hooks Class Initialized
INFO - 2021-04-28 15:41:46 --> Security Class Initialized
DEBUG - 2021-04-28 15:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:41:46 --> Input Class Initialized
DEBUG - 2021-04-28 15:41:46 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:41:46 --> Language Class Initialized
INFO - 2021-04-28 15:41:46 --> Utf8 Class Initialized
INFO - 2021-04-28 15:41:46 --> URI Class Initialized
ERROR - 2021-04-28 15:41:46 --> 404 Page Not Found: UserController/update
INFO - 2021-04-28 15:41:46 --> Router Class Initialized
INFO - 2021-04-28 15:41:46 --> Output Class Initialized
INFO - 2021-04-28 15:41:46 --> Security Class Initialized
DEBUG - 2021-04-28 15:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:41:46 --> Input Class Initialized
INFO - 2021-04-28 15:41:46 --> Language Class Initialized
ERROR - 2021-04-28 15:41:46 --> 404 Page Not Found: UserController/update
INFO - 2021-04-28 15:41:50 --> Config Class Initialized
INFO - 2021-04-28 15:41:50 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:41:50 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:41:50 --> Utf8 Class Initialized
INFO - 2021-04-28 15:41:50 --> URI Class Initialized
INFO - 2021-04-28 15:41:50 --> Router Class Initialized
INFO - 2021-04-28 15:41:50 --> Output Class Initialized
INFO - 2021-04-28 15:41:50 --> Security Class Initialized
DEBUG - 2021-04-28 15:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:41:50 --> Input Class Initialized
INFO - 2021-04-28 15:41:50 --> Language Class Initialized
INFO - 2021-04-28 15:41:50 --> Loader Class Initialized
INFO - 2021-04-28 15:41:50 --> Helper loaded: url_helper
INFO - 2021-04-28 15:41:50 --> Helper loaded: form_helper
INFO - 2021-04-28 15:41:50 --> Helper loaded: common_helper
INFO - 2021-04-28 15:41:50 --> Helper loaded: util_helper
INFO - 2021-04-28 15:41:50 --> Helper loaded: user_helper
INFO - 2021-04-28 15:41:50 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:41:50 --> Form Validation Class Initialized
INFO - 2021-04-28 15:41:50 --> Controller Class Initialized
INFO - 2021-04-28 15:41:50 --> Model Class Initialized
INFO - 2021-04-28 15:41:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:41:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:41:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 15:41:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:41:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:41:50 --> Final output sent to browser
DEBUG - 2021-04-28 15:41:50 --> Total execution time: 0.0316
INFO - 2021-04-28 15:41:53 --> Config Class Initialized
INFO - 2021-04-28 15:41:53 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:41:53 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:41:53 --> Utf8 Class Initialized
INFO - 2021-04-28 15:41:53 --> URI Class Initialized
INFO - 2021-04-28 15:41:53 --> Router Class Initialized
INFO - 2021-04-28 15:41:53 --> Output Class Initialized
INFO - 2021-04-28 15:41:53 --> Security Class Initialized
DEBUG - 2021-04-28 15:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:41:53 --> Input Class Initialized
INFO - 2021-04-28 15:41:53 --> Language Class Initialized
INFO - 2021-04-28 15:41:53 --> Loader Class Initialized
INFO - 2021-04-28 15:41:53 --> Helper loaded: url_helper
INFO - 2021-04-28 15:41:53 --> Helper loaded: form_helper
INFO - 2021-04-28 15:41:53 --> Helper loaded: common_helper
INFO - 2021-04-28 15:41:53 --> Helper loaded: util_helper
INFO - 2021-04-28 15:41:53 --> Helper loaded: user_helper
INFO - 2021-04-28 15:41:53 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:41:53 --> Form Validation Class Initialized
INFO - 2021-04-28 15:41:53 --> Controller Class Initialized
INFO - 2021-04-28 15:41:53 --> Model Class Initialized
INFO - 2021-04-28 15:41:53 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:41:53 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:41:53 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/editUser.php
INFO - 2021-04-28 15:41:53 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:41:53 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:41:53 --> Final output sent to browser
DEBUG - 2021-04-28 15:41:53 --> Total execution time: 0.0300
INFO - 2021-04-28 15:41:53 --> Config Class Initialized
INFO - 2021-04-28 15:41:53 --> Hooks Class Initialized
INFO - 2021-04-28 15:41:53 --> Config Class Initialized
INFO - 2021-04-28 15:41:53 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:41:53 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:41:53 --> Utf8 Class Initialized
DEBUG - 2021-04-28 15:41:53 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:41:53 --> URI Class Initialized
INFO - 2021-04-28 15:41:53 --> Utf8 Class Initialized
INFO - 2021-04-28 15:41:53 --> Router Class Initialized
INFO - 2021-04-28 15:41:53 --> Output Class Initialized
INFO - 2021-04-28 15:41:53 --> Security Class Initialized
DEBUG - 2021-04-28 15:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:41:53 --> Input Class Initialized
INFO - 2021-04-28 15:41:53 --> Language Class Initialized
ERROR - 2021-04-28 15:41:53 --> 404 Page Not Found: UserController/update
INFO - 2021-04-28 15:41:53 --> Config Class Initialized
INFO - 2021-04-28 15:41:53 --> Hooks Class Initialized
INFO - 2021-04-28 15:41:53 --> Config Class Initialized
INFO - 2021-04-28 15:41:53 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:41:53 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:41:53 --> Utf8 Class Initialized
DEBUG - 2021-04-28 15:41:53 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:41:53 --> Utf8 Class Initialized
INFO - 2021-04-28 15:41:53 --> URI Class Initialized
INFO - 2021-04-28 15:41:53 --> URI Class Initialized
INFO - 2021-04-28 15:41:53 --> URI Class Initialized
INFO - 2021-04-28 15:41:53 --> Router Class Initialized
INFO - 2021-04-28 15:41:53 --> Router Class Initialized
INFO - 2021-04-28 15:41:53 --> Router Class Initialized
INFO - 2021-04-28 15:41:53 --> Output Class Initialized
INFO - 2021-04-28 15:41:53 --> Output Class Initialized
INFO - 2021-04-28 15:41:53 --> Output Class Initialized
INFO - 2021-04-28 15:41:53 --> Security Class Initialized
INFO - 2021-04-28 15:41:53 --> Security Class Initialized
INFO - 2021-04-28 15:41:53 --> Security Class Initialized
DEBUG - 2021-04-28 15:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-28 15:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-28 15:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:41:53 --> Input Class Initialized
INFO - 2021-04-28 15:41:53 --> Input Class Initialized
INFO - 2021-04-28 15:41:53 --> Input Class Initialized
INFO - 2021-04-28 15:41:53 --> Language Class Initialized
INFO - 2021-04-28 15:41:53 --> Language Class Initialized
INFO - 2021-04-28 15:41:53 --> Language Class Initialized
ERROR - 2021-04-28 15:41:53 --> 404 Page Not Found: UserController/update
ERROR - 2021-04-28 15:41:53 --> 404 Page Not Found: UserController/update
ERROR - 2021-04-28 15:41:53 --> 404 Page Not Found: UserController/update
INFO - 2021-04-28 15:41:56 --> Config Class Initialized
INFO - 2021-04-28 15:41:56 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:41:56 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:41:56 --> Utf8 Class Initialized
INFO - 2021-04-28 15:41:56 --> URI Class Initialized
DEBUG - 2021-04-28 15:41:56 --> No URI present. Default controller set.
INFO - 2021-04-28 15:41:56 --> Router Class Initialized
INFO - 2021-04-28 15:41:56 --> Output Class Initialized
INFO - 2021-04-28 15:41:56 --> Security Class Initialized
DEBUG - 2021-04-28 15:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:41:56 --> Input Class Initialized
INFO - 2021-04-28 15:41:56 --> Language Class Initialized
INFO - 2021-04-28 15:41:56 --> Loader Class Initialized
INFO - 2021-04-28 15:41:56 --> Helper loaded: url_helper
INFO - 2021-04-28 15:41:56 --> Helper loaded: form_helper
INFO - 2021-04-28 15:41:56 --> Helper loaded: common_helper
INFO - 2021-04-28 15:41:56 --> Helper loaded: util_helper
INFO - 2021-04-28 15:41:56 --> Helper loaded: user_helper
INFO - 2021-04-28 15:41:56 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:41:56 --> Form Validation Class Initialized
INFO - 2021-04-28 15:41:56 --> Controller Class Initialized
INFO - 2021-04-28 15:41:56 --> Model Class Initialized
INFO - 2021-04-28 15:41:56 --> Model Class Initialized
INFO - 2021-04-28 15:41:56 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-28 15:41:56 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-28 15:41:56 --> Final output sent to browser
DEBUG - 2021-04-28 15:41:56 --> Total execution time: 0.0312
INFO - 2021-04-28 15:41:56 --> Config Class Initialized
INFO - 2021-04-28 15:41:56 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:41:56 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:41:56 --> Utf8 Class Initialized
INFO - 2021-04-28 15:41:56 --> URI Class Initialized
INFO - 2021-04-28 15:41:56 --> Router Class Initialized
INFO - 2021-04-28 15:41:56 --> Output Class Initialized
INFO - 2021-04-28 15:41:56 --> Security Class Initialized
DEBUG - 2021-04-28 15:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:41:56 --> Input Class Initialized
INFO - 2021-04-28 15:41:56 --> Language Class Initialized
ERROR - 2021-04-28 15:41:56 --> 404 Page Not Found: Assets/img
INFO - 2021-04-28 15:41:59 --> Config Class Initialized
INFO - 2021-04-28 15:41:59 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:41:59 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:41:59 --> Utf8 Class Initialized
INFO - 2021-04-28 15:41:59 --> URI Class Initialized
INFO - 2021-04-28 15:41:59 --> Router Class Initialized
INFO - 2021-04-28 15:41:59 --> Output Class Initialized
INFO - 2021-04-28 15:41:59 --> Security Class Initialized
DEBUG - 2021-04-28 15:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:41:59 --> Input Class Initialized
INFO - 2021-04-28 15:41:59 --> Language Class Initialized
INFO - 2021-04-28 15:41:59 --> Loader Class Initialized
INFO - 2021-04-28 15:41:59 --> Helper loaded: url_helper
INFO - 2021-04-28 15:41:59 --> Helper loaded: form_helper
INFO - 2021-04-28 15:41:59 --> Helper loaded: common_helper
INFO - 2021-04-28 15:41:59 --> Helper loaded: util_helper
INFO - 2021-04-28 15:41:59 --> Helper loaded: user_helper
INFO - 2021-04-28 15:41:59 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:41:59 --> Form Validation Class Initialized
INFO - 2021-04-28 15:41:59 --> Controller Class Initialized
INFO - 2021-04-28 15:41:59 --> Model Class Initialized
INFO - 2021-04-28 15:41:59 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:41:59 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:41:59 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/editUser.php
INFO - 2021-04-28 15:41:59 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:41:59 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:41:59 --> Final output sent to browser
DEBUG - 2021-04-28 15:41:59 --> Total execution time: 0.0315
INFO - 2021-04-28 15:42:44 --> Config Class Initialized
INFO - 2021-04-28 15:42:44 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:42:44 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:42:44 --> Utf8 Class Initialized
INFO - 2021-04-28 15:42:44 --> URI Class Initialized
INFO - 2021-04-28 15:42:44 --> Router Class Initialized
INFO - 2021-04-28 15:42:44 --> Output Class Initialized
INFO - 2021-04-28 15:42:44 --> Security Class Initialized
DEBUG - 2021-04-28 15:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:42:44 --> Input Class Initialized
INFO - 2021-04-28 15:42:44 --> Language Class Initialized
INFO - 2021-04-28 15:42:44 --> Loader Class Initialized
INFO - 2021-04-28 15:42:44 --> Helper loaded: url_helper
INFO - 2021-04-28 15:42:44 --> Helper loaded: form_helper
INFO - 2021-04-28 15:42:44 --> Helper loaded: common_helper
INFO - 2021-04-28 15:42:44 --> Helper loaded: util_helper
INFO - 2021-04-28 15:42:44 --> Helper loaded: user_helper
INFO - 2021-04-28 15:42:44 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:42:44 --> Form Validation Class Initialized
INFO - 2021-04-28 15:42:44 --> Controller Class Initialized
INFO - 2021-04-28 15:42:44 --> Model Class Initialized
INFO - 2021-04-28 15:42:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:42:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:42:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 15:42:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:42:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:42:44 --> Final output sent to browser
DEBUG - 2021-04-28 15:42:44 --> Total execution time: 0.0328
INFO - 2021-04-28 15:42:47 --> Config Class Initialized
INFO - 2021-04-28 15:42:47 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:42:47 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:42:47 --> Utf8 Class Initialized
INFO - 2021-04-28 15:42:47 --> URI Class Initialized
INFO - 2021-04-28 15:42:47 --> Router Class Initialized
INFO - 2021-04-28 15:42:47 --> Output Class Initialized
INFO - 2021-04-28 15:42:47 --> Security Class Initialized
DEBUG - 2021-04-28 15:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:42:47 --> Input Class Initialized
INFO - 2021-04-28 15:42:47 --> Language Class Initialized
INFO - 2021-04-28 15:42:47 --> Loader Class Initialized
INFO - 2021-04-28 15:42:47 --> Helper loaded: url_helper
INFO - 2021-04-28 15:42:47 --> Helper loaded: form_helper
INFO - 2021-04-28 15:42:47 --> Helper loaded: common_helper
INFO - 2021-04-28 15:42:47 --> Helper loaded: util_helper
INFO - 2021-04-28 15:42:47 --> Helper loaded: user_helper
INFO - 2021-04-28 15:42:47 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:42:47 --> Form Validation Class Initialized
INFO - 2021-04-28 15:42:47 --> Controller Class Initialized
INFO - 2021-04-28 15:42:47 --> Model Class Initialized
INFO - 2021-04-28 15:42:47 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:42:47 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:42:47 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/editUser.php
INFO - 2021-04-28 15:42:47 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:42:47 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:42:47 --> Final output sent to browser
DEBUG - 2021-04-28 15:42:47 --> Total execution time: 0.0385
INFO - 2021-04-28 15:42:47 --> Config Class Initialized
INFO - 2021-04-28 15:42:47 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:42:47 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:42:47 --> Utf8 Class Initialized
INFO - 2021-04-28 15:42:47 --> Config Class Initialized
INFO - 2021-04-28 15:42:47 --> URI Class Initialized
INFO - 2021-04-28 15:42:47 --> Hooks Class Initialized
INFO - 2021-04-28 15:42:47 --> Router Class Initialized
DEBUG - 2021-04-28 15:42:47 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:42:47 --> Output Class Initialized
INFO - 2021-04-28 15:42:47 --> Utf8 Class Initialized
INFO - 2021-04-28 15:42:47 --> URI Class Initialized
INFO - 2021-04-28 15:42:47 --> Security Class Initialized
INFO - 2021-04-28 15:42:47 --> Router Class Initialized
DEBUG - 2021-04-28 15:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:42:47 --> Input Class Initialized
INFO - 2021-04-28 15:42:47 --> Language Class Initialized
INFO - 2021-04-28 15:42:47 --> Output Class Initialized
INFO - 2021-04-28 15:42:47 --> Security Class Initialized
ERROR - 2021-04-28 15:42:47 --> 404 Page Not Found: UserController/update
DEBUG - 2021-04-28 15:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:42:47 --> Input Class Initialized
INFO - 2021-04-28 15:42:47 --> Language Class Initialized
ERROR - 2021-04-28 15:42:47 --> 404 Page Not Found: UserController/update
INFO - 2021-04-28 15:42:47 --> Config Class Initialized
INFO - 2021-04-28 15:42:47 --> Hooks Class Initialized
INFO - 2021-04-28 15:42:47 --> Config Class Initialized
INFO - 2021-04-28 15:42:47 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:42:47 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:42:47 --> Utf8 Class Initialized
INFO - 2021-04-28 15:42:47 --> URI Class Initialized
DEBUG - 2021-04-28 15:42:47 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:42:47 --> Utf8 Class Initialized
INFO - 2021-04-28 15:42:47 --> URI Class Initialized
INFO - 2021-04-28 15:42:47 --> Router Class Initialized
INFO - 2021-04-28 15:42:47 --> Router Class Initialized
INFO - 2021-04-28 15:42:47 --> Output Class Initialized
INFO - 2021-04-28 15:42:47 --> Output Class Initialized
INFO - 2021-04-28 15:42:47 --> Security Class Initialized
INFO - 2021-04-28 15:42:47 --> Security Class Initialized
DEBUG - 2021-04-28 15:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:42:47 --> Input Class Initialized
INFO - 2021-04-28 15:42:47 --> Language Class Initialized
DEBUG - 2021-04-28 15:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:42:47 --> Input Class Initialized
INFO - 2021-04-28 15:42:47 --> Language Class Initialized
ERROR - 2021-04-28 15:42:47 --> 404 Page Not Found: UserController/update
ERROR - 2021-04-28 15:42:47 --> 404 Page Not Found: UserController/update
INFO - 2021-04-28 15:42:50 --> Config Class Initialized
INFO - 2021-04-28 15:42:50 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:42:50 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:42:50 --> Utf8 Class Initialized
INFO - 2021-04-28 15:42:50 --> URI Class Initialized
INFO - 2021-04-28 15:42:50 --> Router Class Initialized
INFO - 2021-04-28 15:42:50 --> Output Class Initialized
INFO - 2021-04-28 15:42:50 --> Security Class Initialized
DEBUG - 2021-04-28 15:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:42:50 --> Input Class Initialized
INFO - 2021-04-28 15:42:50 --> Language Class Initialized
INFO - 2021-04-28 15:42:50 --> Loader Class Initialized
INFO - 2021-04-28 15:42:50 --> Helper loaded: url_helper
INFO - 2021-04-28 15:42:50 --> Helper loaded: form_helper
INFO - 2021-04-28 15:42:50 --> Helper loaded: common_helper
INFO - 2021-04-28 15:42:50 --> Helper loaded: util_helper
INFO - 2021-04-28 15:42:50 --> Helper loaded: user_helper
INFO - 2021-04-28 15:42:50 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:42:50 --> Form Validation Class Initialized
INFO - 2021-04-28 15:42:50 --> Controller Class Initialized
INFO - 2021-04-28 15:42:50 --> Model Class Initialized
INFO - 2021-04-28 15:42:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:42:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:42:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/userlist.php
INFO - 2021-04-28 15:42:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:42:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:42:50 --> Final output sent to browser
DEBUG - 2021-04-28 15:42:50 --> Total execution time: 0.0303
INFO - 2021-04-28 15:42:50 --> Config Class Initialized
INFO - 2021-04-28 15:42:50 --> Hooks Class Initialized
INFO - 2021-04-28 15:42:50 --> Config Class Initialized
INFO - 2021-04-28 15:42:50 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:42:50 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:42:50 --> Utf8 Class Initialized
DEBUG - 2021-04-28 15:42:50 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:42:50 --> Utf8 Class Initialized
INFO - 2021-04-28 15:42:50 --> URI Class Initialized
INFO - 2021-04-28 15:42:50 --> URI Class Initialized
INFO - 2021-04-28 15:42:50 --> Router Class Initialized
INFO - 2021-04-28 15:42:50 --> Router Class Initialized
INFO - 2021-04-28 15:42:50 --> Output Class Initialized
INFO - 2021-04-28 15:42:50 --> Output Class Initialized
INFO - 2021-04-28 15:42:50 --> Security Class Initialized
INFO - 2021-04-28 15:42:50 --> Security Class Initialized
DEBUG - 2021-04-28 15:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:42:50 --> Input Class Initialized
DEBUG - 2021-04-28 15:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:42:50 --> Input Class Initialized
INFO - 2021-04-28 15:42:50 --> Language Class Initialized
INFO - 2021-04-28 15:42:50 --> Language Class Initialized
ERROR - 2021-04-28 15:42:50 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-04-28 15:42:50 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-28 15:42:50 --> Config Class Initialized
INFO - 2021-04-28 15:42:50 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:42:50 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:42:50 --> Utf8 Class Initialized
INFO - 2021-04-28 15:42:50 --> URI Class Initialized
INFO - 2021-04-28 15:42:50 --> Router Class Initialized
INFO - 2021-04-28 15:42:50 --> Output Class Initialized
INFO - 2021-04-28 15:42:50 --> Security Class Initialized
INFO - 2021-04-28 15:42:50 --> Config Class Initialized
INFO - 2021-04-28 15:42:50 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:42:50 --> Input Class Initialized
INFO - 2021-04-28 15:42:50 --> Language Class Initialized
DEBUG - 2021-04-28 15:42:50 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:42:50 --> Utf8 Class Initialized
ERROR - 2021-04-28 15:42:50 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-28 15:42:50 --> URI Class Initialized
INFO - 2021-04-28 15:42:50 --> Router Class Initialized
INFO - 2021-04-28 15:42:50 --> Output Class Initialized
INFO - 2021-04-28 15:42:50 --> Security Class Initialized
DEBUG - 2021-04-28 15:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:42:50 --> Input Class Initialized
INFO - 2021-04-28 15:42:50 --> Language Class Initialized
ERROR - 2021-04-28 15:42:50 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-04-28 15:42:52 --> Config Class Initialized
INFO - 2021-04-28 15:42:52 --> Hooks Class Initialized
DEBUG - 2021-04-28 15:42:52 --> UTF-8 Support Enabled
INFO - 2021-04-28 15:42:52 --> Utf8 Class Initialized
INFO - 2021-04-28 15:42:52 --> URI Class Initialized
INFO - 2021-04-28 15:42:52 --> Router Class Initialized
INFO - 2021-04-28 15:42:52 --> Output Class Initialized
INFO - 2021-04-28 15:42:52 --> Security Class Initialized
DEBUG - 2021-04-28 15:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-28 15:42:52 --> Input Class Initialized
INFO - 2021-04-28 15:42:52 --> Language Class Initialized
INFO - 2021-04-28 15:42:52 --> Loader Class Initialized
INFO - 2021-04-28 15:42:52 --> Helper loaded: url_helper
INFO - 2021-04-28 15:42:52 --> Helper loaded: form_helper
INFO - 2021-04-28 15:42:52 --> Helper loaded: common_helper
INFO - 2021-04-28 15:42:52 --> Helper loaded: util_helper
INFO - 2021-04-28 15:42:52 --> Helper loaded: user_helper
INFO - 2021-04-28 15:42:52 --> Database Driver Class Initialized
DEBUG - 2021-04-28 15:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-28 15:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-28 15:42:52 --> Form Validation Class Initialized
INFO - 2021-04-28 15:42:52 --> Controller Class Initialized
INFO - 2021-04-28 15:42:52 --> Model Class Initialized
INFO - 2021-04-28 15:42:52 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/header.php
INFO - 2021-04-28 15:42:52 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/sidebar.php
INFO - 2021-04-28 15:42:52 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/cms/editUser.php
INFO - 2021-04-28 15:42:52 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/footer.php
INFO - 2021-04-28 15:42:52 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\admin/layouts/index.php
INFO - 2021-04-28 15:42:52 --> Final output sent to browser
DEBUG - 2021-04-28 15:42:52 --> Total execution time: 0.0307

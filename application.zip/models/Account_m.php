<?php
class Account_m extends CI_Model
{
	
	function __construct() { 
        // Set table name 
        $this->table = 'user'; 
    }

	public function get_row ()
	{
		$id = $_SESSION['user_id'];
		$this -> db -> where('user_id', $id);
		return $this -> db -> get('user') -> row_array();
		
	}

    public function getUserdata()
    {
        $this->load->database();
        $q=$this->db->where("user_id",3)
                    ->get("user");
        return $q->result_array();
    }

	function update($data){
            $this->db->where('user_id',$data['user_id']);
            $this->db->update('user', $data);
    }

    public function get_data($id=0)
    {
        if($id==0)
        {
            $query = $this->db->get('user')->result();
            return $query;
        }
        else
        {
            $this->db->where('user_id',$id);
            $query = $this->db->get('user')->result();
            return $query;
        }
        
    }

    public function upddata($data,$id)       
    {
        extract($data); 
        $this->db->where('user_id', $id);
        // $this->db->update($table_name, array('full_name' => $full_name, 'email' =>$email, 'mobile' =>$mobile, 'status' =>$status, 'user_role' =>$user_role, 'profile_pic'=>$profile_pic));
        $this->db->update('user', $data);
        return true;
    }

    public function delete_data($id)
    {
        $this -> db -> where('user_id', $id);
        $this -> db -> delete('user');
    }

    public function insert($data = array()) { 
        if(!empty($data)){ 
            $insert = $this->db->insert($this->table, $data); 
             
            // Return the status 
            return $insert?$this->db->insert_id():false; 
        } 
        return false; 
    } 
}
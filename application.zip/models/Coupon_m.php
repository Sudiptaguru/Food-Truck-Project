<?php
class Coupon_m extends CI_Model
{
	public $_table = 'coupon';
	function __construct ()
	{
		parent::__construct();
	}

	
	
	public function save($data)
	{	
		if ($data['id']){
			$this -> db -> update($this -> _table, $data, array('id' => $data['id']));
			return $data['id'];
			
		}
		else {
		
			$this -> db -> insert($this -> _table, $data);
			return $this -> db -> insert_id();
			
		}
				
	}
	
	public function getResult($id = ''){
		if ($id){
			return $this -> db -> get_where($this -> _table, array('id' => $id)) -> row_array();
		}
		else {
			$this -> db -> order_by('id','desc');
			$this -> db -> where('user_id', $this -> session -> userdata('user_id'));
			return $this -> db -> get($this -> _table) -> result_array();
		}
	}
	
	 function getNew($table = false){
       
        $f = $this -> db -> list_fields($this -> _table);
        $temp = array();
        $temp['id'] = false;
        foreach($f as $fields){
            $temp[$fields] = '';
        }
        return $temp;
    }
	
	 
}
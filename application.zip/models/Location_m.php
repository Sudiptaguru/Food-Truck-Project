<?php
class Location_m extends CI_Model
{
	
	
	function __construct ()
	{
		parent::__construct();
	}

	public function getRow ($uid)
	{
		return $this -> db -> get_where('location', array('user_id' => $uid)) -> row_array();
		
	}
}
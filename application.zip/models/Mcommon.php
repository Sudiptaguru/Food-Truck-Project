<?php
 class Mcommon extends CI_Model {
    function __construct(){
        parent::__construct();
    }
    public function insert($table,$data){
        $this->db->insert($table,$data);     
        return $this->db->insert_id();
    }
    public function batch_insert($table,$data){
        $this->db->insert_batch($table,$data); 
        return 1; 
    }
    public function getDetails($table,$condition){
        $this->db->where($condition);
        $query=$this->db->get($table);
        //return $this->db->last_query();
        return $query->result_array(); 
    }
    public function getFullDetails($table){
        $query=$this->db->get($table);
        return $query->result_array();
    }
    public function getRow($table,$condition){
        $this->db->where($condition);        
        $query=$this->db->get($table);          
        $res = array();
        if($query->num_rows()>0){ 
            $res = $query->row_array();    
        }
        return $res;            
    }  

    public function getRowV2($table,$condition,$order_by=''){
        $this->db->where($condition);        
        $query=$this->db->get($table); 
        if (isset($order_by)) {
          $this->db->order_by($order_by);          
        }

        $this->db->limit(1);          
                 
        $res = array();
        if($query->num_rows()>0){ 
            $res = $query->row_array();    
        }
        return $res;            
    }  

    public function getRows($table, $condition, $order_by='', $group_by=''){

        $this->db->where($condition);        
        /*if($table=='tbl_package'){
            $this->db->order_by('category_id','asc');          
        }else{
            $this->db->order_by('date_of_creation', 'desc');
        }*/
        if (isset($order_by)) {
          $this->db->order_by($order_by);          
        }

        if (isset($group_by)) {
          $this->db->group_by($group_by);          
        }
        
        $query=$this->db->get($table);          
        $res = array();
        if($query->num_rows()>0){ 
            $res = $query->result_array();    
        }
        return $res;            
    }  

    public function checkUser($table,$condition){
        $this->db->where($condition);
        $query=$this->db->get('admins');
        return $query->row_array(); 
    } 
    public function update($table,$condition,$data){
        $this->db->where($condition);
        $this->db->update($table,$data);
        //echo $this->db->last_query();
        return 1;
    }
    public function delete($table,$condition){ 
        $this->db->where($condition);
        $this->db->delete($table);
        return 1;
    }


    
    public function getTestimonial($condition){
        $this->db->select('*');
        $this->db->from('testimonial');
        $this->db->join('tbl_user', 'tbl_user.user_id = testimonial.user_id','left');
        $this->db->where($condition);
        $query=$this->db->get();
        return $query->result_array();
    }

    public function get_user_template($table,$condition){
        $this->db->where($condition);
        $this->db->order_by('updated_at','desc');
        $query=$this->db->get($table);
        return $query->result_array(); 
    }

    public function category()
    {
        $this->db->from('categories');
        $this->db->where('category_status',1);
        $this->db->where('parent_id', '0');
        $this->db->order_by('category_name');
        $result = $this->db->get();

        $temp_arr = $temp_arr1 = array();

        foreach($result->result_array() as $key=>$value){

           $temp_arr['category_id']       = $value['category_id']; 
           $temp_arr['category_name']     = $value['category_name']; 
           $temp_arr['category_slug']     = $value['category_slug']; 
           $temp_arr['sub_category_list'] = $this->getSubCategory($value['category_id']);

           $temp_arr1[] = $temp_arr; 
        }

        //echo "<pre>";print_r($temp_arr1);
        return $temp_arr1;
    }
   

    // Get Sub Category
    public function getSubCategory($parent_id)
    {
        $this->db->select('category_id,category_name,category_slug');
        $this->db->from('categories');
        $this->db->where('category_status',1);
        $this->db->where('parent_id', $parent_id);
        $this->db->order_by('category_name');
        $result = $this->db->get();

        $temp_arr = $temp_arr1 = array();

        foreach($result->result_array() as $key=>$value){

           $temp_arr['category_id']       = $value['category_id']; 
           $temp_arr['category_name']     = $value['category_name']; 
           $temp_arr['category_slug']     = $value['category_slug']; 
           $temp_arr['sub_category_list'] = $this->getSubCategory($value['category_id']);

           $temp_arr1[] = $temp_arr; 
        }

        //echo "<pre>";print_r($temp_arr1);
        return $temp_arr1;
    }

    public function get_image_category()
    {
        $this->db->from('image_categories');
        $this->db->where('status',1);
        $this->db->where('parent_id', '0');
        $this->db->order_by('category_name');
        $result = $this->db->get();

        $temp_arr = $temp_arr1 = array();

        foreach($result->result_array() as $key=>$value){

           $temp_arr['id']       = $value['id']; 
           $temp_arr['category_name']     = $value['category_name']; 
           $temp_arr['category_slug']     = $value['category_slug']; 
           $temp_arr['sub_category_list'] = $this->getSubImageCategory($value['id']);

           $temp_arr1[] = $temp_arr; 
        }

        //echo "<pre>";print_r($temp_arr1);

        return $temp_arr1;
    }
   

    // Get Sub Category
    public function getSubImageCategory($parent_id)
    {
        $this->db->select('id,category_name,category_slug');
        $this->db->from('image_categories');
        $this->db->where('status',1);
        $this->db->where('parent_id', $parent_id);
        $this->db->order_by('category_name');
        $result = $this->db->get();

        $temp_arr = $temp_arr1 = array();

        foreach($result->result_array() as $key=>$value){

           $temp_arr['id']       = $value['id']; 
           $temp_arr['category_name']     = $value['category_name']; 
           $temp_arr['category_slug']     = $value['category_slug']; 
           $temp_arr['sub_category_list'] = $this->getSubImageCategory($value['id']);

           $temp_arr1[] = $temp_arr; 
        }

        //echo "<pre>";print_r($temp_arr1);

        return $temp_arr1;
    }

    public function get_page_details($condition)
    {
        $this->db->select('*');
        $this->db->from('cms');
        $this->db->where($condition);
        $query=$this->db->get();
        return $query->row_array();
    }

    public function saveCanvas($data){
        $query = $this->db->insert('user_templates',$data);
        return $this->db->insert_id();
        /*if($query){
            return true;
        }else{
            return false;
        }*/
    }

    public function getTemplateByID($id){
        $this->db->where('id',$id);
        $query = $this->db->get('templates');
        if($query->num_rows() == 1){
          return $query->row();
        }else{
          return false;
        }
    }

    public function getTemplateByIDUser($id){
        $this->db->where('id',$id);
        $query = $this->db->get('user_templates');
        if($query->num_rows() == 1){
          return $query->row();
        }else{
          return false;
        }
    }

    public function updateCanvas($data){
        $this->db->where('id',$data['id']);
        $query = $this->db->update('user_templates',$data);
        if($query){
            return true;
        }else{
            return false;
        }
    }

    public function get_templates()
    {
        $this->db->select('templates.*,categories.category_name');
        $this->db->from('templates');
        $this->db->join('categories', 'categories.category_id = templates.category');
        $query=$this->db->get();
        return $query->result_array();
    }

    public function get_templates_by_cat($cat_slug,$flag="", $limit='', $start='')
    {
        $this->db->select('templates.*,categories.category_name');
        $this->db->from('templates');
        $this->db->join('categories', 'categories.category_id = templates.category');
        $this->db->where('categories.category_slug',$cat_slug);
        if($flag!='count'){
            $this->db->limit($limit, $start); 
        }
        $query=$this->db->get();
        if($flag=='count'){
            return $query->num_rows();
            exit();
        }
        return $query->result_array();
    }

    public function get_templates_bytitle($template)
    {
        $this->db->select('templates.*,categories.category_name');
        $this->db->from('templates');
        $this->db->join('categories', 'categories.category_id = templates.category');
        $this->db->like('templates.template_title',$template);
        $query=$this->db->get();
        //echo "<pre>"; print_r($query->result_array()); 
        return $query->result_array();
    }

    public function isexist_search_text($under,$search_text)
    {
        $this->db->select('*');
        $this->db->from('search_text');
        $this->db->where('text',$search_text);
        $this->db->where('under',$under);
        $query=$this->db->get();
        //echo "<pre>"; print_r($query->result_array()); 
        return $query->row_array();
    }

    public function get_popular_search_text($under)
    {
        $this->db->select('*');
        $this->db->from('search_text');
        $this->db->where('under',$under);
        $this->db->order_by("id", "desc");
        $this->db->limit(5); 
        $query=$this->db->get();
        //echo "<pre>"; print_r($query->result_array()); 
        return $query->result_array();
    }

    public function get_user_image_by_search_text($table,$condition,$like)
    {
        $this->db->like($like, 'both'); 
        $this->db->where($condition);
        $query=$this->db->get($table);
        //return $this->db->last_query();
        return $query->result_array();
    }

    public function download_limit($user_id)
    {
        $curr_date = date('Y-m-d');
        $this->db->select('*');
        $this->db->from('share_download_limit sdl');
        $this->db->join('tbl_user', 'tbl_user.user_id = sdl.user_id');
        $this->db->where('sdl.user_id',$user_id);
        $this->db->where('DATE(`date`)',$curr_date);
        $this->db->where('tbl_user.package_id',2);
        $query=$this->db->get();
        //echo $this->db->last_query(); exit();
        return $query->result_array();
    }
    public function get($table, $what = null, $condition = null, $limit_start = null, $limit_end = null, $group = null, $condition1 = null, $order_in = null, $order_by = 'DESC', $join = null, $join_type = null,$response = null)
    {
        if (isset($what)) {
            foreach ($what as $key => $value) {
                $this->db->select($value);
            }
        } else {
            $this->db->select('*');
        }

        $this->db->from($table);
        if (isset($condition)) {
            foreach ($condition as $key => $value) {
                $this->db->where($key, $value);
            }
        }
        if (!empty($condition1)) {
            $this->db->where($condition1);
        }
        
        if (isset($join)) {
            foreach ($join as $key => $value) {
               
                $this->db->join($key, $value, $join_type);
                // $this->db->join($key, $value, $join_type[$key]);
            }
        }

        if ($limit_start != null) {
            $this->db->limit($limit_start, $limit_end);
        }
        if ($group != null) {
            $this->db->group_by($group);
        }

        if ($order_in != null) {
            $this->db->order_by($order_in, $order_by);
        }
        $query = $this->db->get();
        // echo $this->db->last_query();die;
        if ($response == 'result') {

            return   $query->result();
        } 
        elseif($response == 'row') {
            return $query->row();
        }
        elseif($response == 'row_array') {
            return $query->row_array();
        }
        else{
            return $query->result_array();
        }
        
    }

    /** added by ishani **/
     public function getNumRows($table,$condition){
        $this->db->where($condition);
        $query=$this->db->get($table);
      //echo $this->db->last_query(); exit();
        $res = array();
        
        return $query->num_rows();            
    }
    public function PolicyList($table,$condition,$join,$joinType)
    {

        // $this->db->select('make_master.make_name AS make_names,policy_master.policy_id,policy_master.model,policy_master.year,policy_master.driver_type,policy_master.no_of_accident,policy_master.policy_amount');
        //$this->db->select('make_master.make_name AS make_names,policy_master.*,model_master.model_name AS model_names,year_master.year_name AS year_names');
        $this->db->select('make_master.make_name AS make_names,policy_master.*,model_master.model_name AS model_names');
        $this->db->from($table);
        if (isset($join)) {
            foreach ($join as $key => $value) {
                $this->db->join($key, $value,$joinType);
            }
        }
        if (!empty($condition)) {
            $this->db->where($condition);
        }
        $this->db->order_by('policy_id', 'desc');
        $query=$this->db->get();
        //echo $this->db->last_query();exit;
        return $query->result_array();

    }

    public function ModelList($table,$condition,$join,$joinType)
    {

        // $this->db->select('make_master.make_name AS make_names,policy_master.policy_id,policy_master.model,policy_master.year,policy_master.driver_type,policy_master.no_of_accident,policy_master.policy_amount');
        $this->db->select('make_master.make_name AS make_names,model_master.*');
        $this->db->from($table);
        if (isset($join)) {
            foreach ($join as $key => $value) {
                $this->db->join($key, $value,$joinType);
            }
        }
        if (!empty($condition)) {
            $this->db->where($condition);
        }
        $query=$this->db->get();
        return $query->result_array();

    }


    public function DriverList($table,$condition,$join,$joinType)
    {

        // $this->db->select('make_master.make_name AS make_names,policy_master.policy_id,policy_master.model,policy_master.year,policy_master.driver_type,policy_master.no_of_accident,policy_master.policy_amount');
        $this->db->select('states.name AS state_name,user_master.*');
        $this->db->from($table);
        if (isset($join)) {
            foreach ($join as $key => $value) {
                $this->db->join($key, $value,$joinType);
            }
        }
        if (!empty($condition)) {
            $this->db->where($condition);
        }
        $query=$this->db->get();
        return $query->result_array();

    }


    public function Policy_payment($table,$condition,$join,$joinType)
    {     
        $this->db->select('policy_payment_schedule.price AS prices,policy_payment_schedule.id AS ids,policy_schedule_master.*');
        $this->db->from($table);
        if (isset($join)) {
            foreach ($join as $key => $value) {
                $this->db->join($key, $value,'LEFT JOIN');
            }
        }
        if (!empty($condition)) {
            $this->db->where($condition);
        }
        $query=$this->db->get();
        return $query->result_array();

    }
    public function PolicyMasterAPI($condition)
    {
        $year = $condition['year'];
        $condition['policy_master.status'] = 1;
        unset($condition['year']);
        $this->db->select("policy_master.liability_id,policy_payment_schedule.*,policy_schedule_master.*,policy_master.policy_id");
        $this->db->where($condition);  
        $this->db->like("policy_master.year", $year);        
        $this->db->join('policy_payment_schedule','policy_master.policy_id = policy_payment_schedule.policy_master_id ','INNER');        
        $this->db->join('policy_schedule_master' ,'policy_payment_schedule.policy_schedule_id = policy_schedule_master.policy_schedule_id ','INNER');
        //$this->db->join('year_master' ,'policy_master.year = year_master.year_id ','INNER');
        $query=$this->db->get('policy_master');
        //echo $this->db->last_query();exit;
        $res = array();
        if($query->num_rows()>0){ 
            $res = $query->result_array();    
        }

        return $res;   
    }

    public function AddActivity($title ,$description ,$created_by)
    {
        $data = array(
                        'activity_title' => $title,
                        'description' => $description,
                        'created_by' => $created_by,
                        'datetime' => date('Y-m-d H:i:m')
                    );
        $this->db->insert('activity_log',$data);     
        return $this->db->insert_id();
    }

    public function selectAll($from, $where = array(), $select = '', $order_by = '', $mode = '', $join = array(), $limit = '', $offset = 0, $group_by = '', $order_by2 = '')
    {
        if ($select) {
           $this->db->select($select);
        } else {
           $this->db->select('*');
        }
        $this->db->from($from);
        if (!empty($join)) {
               foreach ($join as $qry) {
                $this->db->join($qry['table'], $qry['on'], $qry['type']);
            }
        }
        if (!empty($where)) {
           $this->db->where($where);
        }
        if (!empty($group_by)) {
           $this->db->group_by($group_by);
        }
        if ($order_by && $mode) {
           $this->db->order_by($order_by, $mode);
        } else {
           $this->db->order_by($order_by);
        }
          // only for dispatched incident listing
        if($order_by2){
           $this->db->order_by($order_by2, $mode);
        }
        if ($limit) {
           $this->db->limit($limit, $offset);
        }
        return $this->db->get()->result_array();
     }

}

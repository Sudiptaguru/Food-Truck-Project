<?php
class Schedule_m extends CI_Model
{
	public $_table = 'foodtruck_schedule';
	function __construct ()
	{
		parent::__construct();
	}

	public function get_detail($id)
	{
				
		$this -> db -> where('truck_owner_id', $id);
		return $this -> db -> get($this -> _table) -> result_array();
	   	
	}
	
	 
}
<?php
class mod_home extends CI_Model
{
	public function get_count()
	{
		$sql = "SELECT sum(id) as id FROM users";
		$result = $this->db->query($sql);
		return $result->row()->id;
	}
	public function get_sum()
	{
		$sql = "SELECT sum(phone) as id FROM users";
		$result = $this->db->query($sql);
		return $result->row()->id;
	}
}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Role_m extends CI_Model
{
	private $_table = 'role';

	public function __construct()
	{
		parent::__construct();
		
	}

	function get($id = ''){
		
		if ($id){

			return $this -> db -> get_where($this -> _table,['group_id' => $id]) -> row_array()	;
		}

		else {
			$this -> db -> order_by('name');
			return $this -> db -> get($this -> _table) -> result_array();
		}	
	}

}

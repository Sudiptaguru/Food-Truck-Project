<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_m extends CI_Model
{
	private $_table = 'user';

	public function __construct()
	{
		parent::__construct();
		
	}

	function get($id = ''){
		if ($id){

			return $this -> db -> get_where($this -> _table,['user_id' => $id]) -> row_array();
		}

		else {
			$sql = "select u.*, g.name
					from cms_master u, role g
					where u.group_id = g.group_id
					and u.is_deleted = '0'
					and u.group_id <> '1'
					order  by u.first_name";

   
			return $this -> db -> query($sql) -> result_array();
		}	
	}

}

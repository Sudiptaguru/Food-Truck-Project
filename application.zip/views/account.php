<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="icon" href="assets/img/fav-icon.png">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://use.fontawesome.com/releases/v5.0.4/css/all.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700&display=swap" rel="stylesheet">
<!-- Bootstrap core CSS -->
<link rel="stylesheet" type="text/css" href="assets/css/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="assets/css/bootstrap-theme.min.css">
<link rel="stylesheet" type="text/css" href="assets/css/theme.css">
<link rel="stylesheet" type="text/css" href="assets/css/responsive.css">
<title>Food Track</title>
</head>
<body>

	<div class="container-fluid">
		<div class="row align-items-center">
			<div class="col-md-6">
				<div class="logo">
					<a href="#"><i class="fas fa-home"></i></a>
				</div>
			</div>
			<div class="col-md-6">
				<ul class="top-list">
					<li><a href="#">Sign In</a></li>
					<li><a href="#">Register</a></li>
				</ul>
			</div>
		</div>
		
		<div class="template-format">
			<h1 class="page-title">WHERE is that FOOD TRUCK?</h1>
			<div class="row">
				<div class="col-md-2">
					<div class="ad-sec">
						<h4>PAID AD</h4>
					</div>
				</div>
				<div class="col-md-8">
					<div class="middle-sec">
						<div class="account-sec">
							<div class="cover-pic">
								<img src="assets/img/cover-pic.jpg" width="100%">
								<h3>MY ACCOUNT</h3>
							</div>
							<div class="edit-profile">
								<div class="edit-profile-top">
									<div class="info-profile-img">
									<img src="assets/img/profile-pic.jpg" class="profile-pic">
									<div class="p-image">
										<label><i class="fas fa-pencil-alt"></i></label>
										<input type="file" class="file-upload">
									</div>
								</div>
								<h5>steve@smith</h5>
								</div>
							
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<input type="text" value="Steve Smith" class="form-control">
									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<input type="email" value="Steve@gmail.com" class="form-control">
									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<input type="text" value="001234567890" class="form-control">
									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<select class="form-control">
											<option>Select State</option>
										</select>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<input type="password" value="******" class="form-control">
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<a href="#" style="color: #ff6f2a;font-size: 12px">Change Password</a>
									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group  text-center">
										<button type="submit">UPDATE</button>
									</div>
								</div>
							</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-2">
					<div class="ad-sec">
						<h4>PAID AD</h4>
					</div>
				</div>
			</div>
		</div>
		<ul class="footer-menu">
			<li><a href="#">Advertising Programs</a></li>
			<li><a href="#">Privacy & Terms</a></li>
			<li><a href="#">About WITFT</a></li>
		</ul>
	</div>


 


<!-- Bootstrap core JavaScript --> 
<!--<script src="https://code.jquery.com/jquery-3.4.1.js"></script>--> 
<script src="assets/js/jquery.1.11.3.min.js"></script>
<script src="assets/js/owl.carousel.js"></script>  
<script src="assets/js/bootstrap.min.js"></script> 	
<script src="assets/js/theme.js"></script> 
</body>
</html>

<div class="content-wrapper">
<div class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
         </div>
         <!-- /.col -->
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li><a href="<?=base_url('administrator/CMS')?>">List CMs</a></li>
            </ol>
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </div>
   <!-- /.container-fluid -->
</div>
         <div class="col-md-12">
            <!-- general form elements -->
            <?php echo validation_errors(); ?>
            <?php
               if($this -> session -> flashdata('success')) {?>
            <div class="alert alert-info" role="alert">
               <?=$this -> session -> flashdata('success')?>
            </div>
            <?php } ?>
            <?php
               if($this -> session -> flashdata('error')) {?>
            <div class="alert alert-danger" role="alert">
               <?=$this -> session -> flashdata('error')?>
            </div>
            <?php } ?>
         </div>
<!-- Main content -->
<section class="content">
   <div class="container-fluid">
   <div class="row">
   <!-- left column -->
   <div class="col-md-12">

   <!-- general form elements -->
   <div class="card card-primary">
      <div class="card-header">
         <h3 class="card-title">Add CMS</h3>
      </div>
      <!-- /.card-header -->


       <div class="card-body">   
         <form action="<?= base_url('cms/save') ?>" method="post">
            <div class="form-group">
               <label for="exampleInputEmail1"> Page Title</label>
               <input type="text" class="form-control" id="title" name="title" value="<?=set_value('title')?>" placeholder="Enter Title">
            </div>
            <div class="form-group">
               <label for="exampleInputEmail1"> Page Slug</label>
               <input type="text" class="form-control" id="page_slug" name="page_slug" value="<?=set_value('page_slug')?>" placeholder="Enter Page Slug">
            </div>
            <div class="form-group">
               <label for="exampleInputEmail1">Description</label>
              
                <textarea name="slug"  placeholder="Enter Slug">
                  <?=set_value('content')?>
                </textarea>
            </div>
           
            <!-- /.card-body -->
      </div>
    
      <div class="card-footer">
      <button type="submit" class="btn btn-primary">Submit</button>
      </div>
      </form>
     </div>
     </div>
      
     </div>
      </div>
</section>
</div>
<script src="https://cdn.ckeditor.com/4.16.0/standard/ckeditor.js"></script>
<script>
   CKEDITOR.replace( 'slug' );
</script>
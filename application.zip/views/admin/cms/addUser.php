<div class="content-wrapper">
<div class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
         </div>
         <!-- /.col -->
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li><a href="<?=base_url('administrator/UserController')?>">List CMs</a></li>
            </ol>
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </div>
   <!-- /.container-fluid -->
</div>
         <div class="col-md-12">
            <!-- general form elements -->
            <?php echo validation_errors(); ?>
            <?php
               if($this -> session -> flashdata('success')) {?>
            <div class="alert alert-info" role="alert">
               <?=$this -> session -> flashdata('success')?>
            </div>
            <?php } ?>
            <?php
               if($this -> session -> flashdata('error')) {?>
            <div class="alert alert-danger" role="alert">
               <?=$this -> session -> flashdata('error')?>
            </div>
            <?php } ?>
<!-- 
            <?php if ($this->session->flashdata()) { ?>
        <div class="alert alert-danger">
            <?=$this->session->flashdata('errors'); ?>
        </div>
    <?php } ?> -->
         </div>
<!-- Main content -->
<section class="content">
   <div class="container-fluid">
   <div class="row">
   <!-- left column -->
   <div class="col-md-12">

   <!-- general form elements -->
   <div class="card card-primary">
      <div class="card-header">
         <h3 class="card-title">Add CMS</h3>
      </div>
      <!-- /.card-header -->


       <div class="card-body">   
         <form action="<?= base_url('UserController/save') ?>" method="post">
            <div class="form-group">
               <label for="exampleInputEmail1"> First Name</label>
               <input type="text" class="form-control" id="first_name" name="first_name" value="<?=set_value('first_name')?>" placeholder="Enter First Name">
            </div>
            <div class="form-group">
               <label for="exampleInputEmail1"> Last Name</label>
               <input type="text" class="form-control" id="last_name" name="last_name" value="<?=set_value('last_name')?>" placeholder="Enter Page Last Name">
            </div>
            <div class="form-group">
               <label for="exampleInputEmail1"> Mobile</label>
               <input type="number" class="form-control mobile" id="mobile" name="mobile" value="<?=set_value('mobile')?>" placeholder="Enter Mobile">
               <!-- <input type="number" value="<?=set_value('mobile')?>" name="mobile" placeholder="Phone..." maxlength="10" class="mobile"> -->
            </div>
            <div class="form-group">
               <label for="exampleInputEmail1"> Email</label>
               <input type="email" class="form-control" id="textEmail" name="email" value="<?=set_value('email')?>" onblur="validateEmail(this);" placeholder="Enter Page Email">
               <p id="demo" style="color: red;"></p>
            </div>
            <div class="form-group">
               <label for="exampleInputEmail1"> Password</label>
               <input type="password" class="form-control" id="password" name="password" value="<?=set_value('password')?>" placeholder="Enter Password">
            </div>
            <!-- <div class="form-group">
               <label for="exampleInputEmail1"> Image</label>
               <input type="file" class="form-control" id="profile_pic" name="profile_pic" value="<?=set_value('profile_pic')?>" placeholder="Enter Image">
            </div> -->
            <!-- <div class="form-group">
               <label for="exampleInputEmail1">Description</label>
              
                <textarea name="slug"  placeholder="Enter Slug">
                  <?=set_value('content')?>
                </textarea>
            </div> -->
           
            <!-- /.card-body -->
      </div>
    
      <div class="card-footer">
      <button type="submit" class="btn btn-primary" onclick="myFunction()">Submit</button>
      </div>
      </form>
     </div>
     </div>
      
     </div>
      </div>
</section>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script type="text/javascript">
  $('.mobile').keypress(function(e) {
      var arr = [];
      var kk = e.which;
   
      for (i = 48; i < 58; i++)
          arr.push(i);
   
      if (!(arr.indexOf(kk)>=0))
          e.preventDefault();
  });
</script>
<script type="text/javascript">
   function validateEmail(emailField){
        var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

        if (reg.test(emailField.value) == false) 
        {
            alert('Invalid Email Address');
            return false;
        }

        return true;

}
</script>

<script>
    function myFunction() {
        var email;

        email = document.getElementById("textEmail").value;

            var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

            if (reg.test(textEmail.value) == false) 
            {
            document.getElementById("demo").style.color = "red";
                document.getElementById("demo").innerHTML ="Invalid EMail ->"+ email;
                alert('Invalid Email Address ->'+email);
                return false;
            } else{
            document.getElementById("demo").style.color = "DarkGreen";      
            document.getElementById("demo").innerHTML ="Valid Email ->"+email;
            }

       return true;
    }
    </script>
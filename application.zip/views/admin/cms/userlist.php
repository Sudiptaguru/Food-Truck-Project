<div class="content-wrapper">
<div class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
         </div>
         <!-- /.col -->
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li><a href="<?=base_url('administrator/UserController/add')?>"><i class="fa fa-plus"></i> Add User</a></li>
            </ol>
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </div>
   <!-- /.container-fluid -->
</div>
        <div class="col-md-12">
            <!-- general form elements -->
            <?php echo validation_errors(); ?>
            <?php
               if($this -> session -> flashdata('success')) {?>
            <div class="alert alert-info" role="alert">
               <?=$this -> session -> flashdata('success')?>
            </div>
            <?php } ?>
            <?php
               if($this -> session -> flashdata('error')) {?>
            <div class="alert alert-danger" role="alert">
               <?=$this -> session -> flashdata('error')?>
            </div>
            <?php } ?>
         </div>
    <!-- Main content -->
  <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- <div class="col-md-12">
             <?php if($this -> session -> flashdata('success')) {?>
                <div class="alert alert-info" role="alert">
                  <?=$this -> session -> flashdata('success')?>
                </div>

            <?php } ?>

          </div> -->
        </div>
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
          <div class="card">
              <div class="card-header">
                <h3 class="card-title">User List</h3>

                <div class="card-tools">
                  <div class="input-group input-group-sm" style="width: 150px;">
                    <input type="text" name="table_search" class="form-control float-right" placeholder="Search">

                    <div class="input-group-append">
                      <button type="submit" class="btn btn-default">
                        <i class="fas fa-search"></i>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0">
                <table class="table table-hover text-nowrap">
                  <thead>
                    <tr>
                     
                       <th>Sno.</th>
                       <!-- <th>GroupId.</th> -->
                      <th>First Name</th>
                      <th>Last Name</th>
                      <th>Mobile</th>
                      <th>Email</th>
                      <!-- <th>Profile Pic</th> -->
                      <th>Created</th>
                      <!-- <th>Updated</th>            -->
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php
                  if (count($cms)){

                    foreach ($cms as  $k => $u) {

                      ?>
                    <tr>
                       <td><?=$k+1?></td>
                     
                      <td><?=$u['first_name']?></td>
                      <td><?=$u['last_name']?></td>
                      <td><?=$u['mobile']?></td>
                      <td><?=$u['email']?></td>
                      <!-- <td><?=$u['profile_pic']?></td> -->
                      <td><?=$u['created_on']?></td>
                      <!-- <td><?=$u['updated_on']?></td> -->
                      <td>
                      <a  href="<?=base_url('UserController/update/'.$u['user_id'])?>"><i class="fa fa-edit"></i></a> | 
                      <a onclick ="return confirm('Do you want to delete?');" href="<?=base_url('administrator/UserController/delete_row/'.$u['user_id'])?>"><i class="fa fa-trash"></i></a> 

                      <!-- <a  href="<?php echo base_url('administrator/Cms/delete_row/'.$cms_id);?>" onclick="return confirm('Are you sure you want to delete this item ?');"><i class="fa fa-trash"></i></a> -->
                    </td>
                    </tr>
                   <?php 
                 }
                 }
                   ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>

          </div>


       
 
          
              </div>
           
      </div>
    </section>
  </div>
  <!-- <script>
 
   function changeStatus(id, val) {


    if (!confirm("Do you want to change status?")){
      return false;
    }
         
      if (val ==  ""){
        alert("Please select...");
        return false;

      }

       var status = val;
       var uid = id.split('_')[1];

      $.ajax({
          url:"<?=base_url('administrator/User/changeUserStatusAjax')?>",
          type:"post",
          data:{uid:uid, status:status}
      }).done(function(response){
        if (response == "1"){
          let txtStatus = status == "1"  ? "Activated..." : "Deactivated...";
          alert("User "+txtStatus);
        }
        else {
          alert("Problem changing the status. Try again.")
        }

      }).catch(function(error){
          console.log(error);
      });
}
 
  </script> -->
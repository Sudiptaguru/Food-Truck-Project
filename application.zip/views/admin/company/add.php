<div class="content-wrapper">
<div class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
         </div>
         <!-- /.col -->
         <!--<div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li><a href=""><i class="fa fa-plus"></i> List User</a></li>
            </ol>
         </div>-->
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </div>
   <!-- /.container-fluid -->
</div>
<!-- Main content -->
<section class="content">
   <div class="container-fluid">
   <div class="row">
   <!-- left column -->
   <div class="col-md-6">
   <!-- general form elements -->
   <div class="card card-primary">
      <div class="card-header">
         <h3 class="card-title">Add Company</h3>
      </div>
      <!-- /.card-header -->
      <!-- form start -->
      <div class="card-body">
         <form action="" method="post" autocomplete="off">
            <div class="form-group">
               <label for="exampleInputEmail1"><span class="mandatory">*</span> Company Name</label>
               <input type="text" class="form-control" id="company_name" name="company_name" value="<?=set_value('company_name')?>" placeholder="Company name...">
            </div>
            <div class="form-group">
               <label for="exampleInputEmail1"><span class="mandatory">*</span> Company Email</label>
               <input type="text" class="form-control" id="company_email" name="company_email"  value="<?=set_value('company_email')?>" placeholder="Companyemail...">
            </div>
            <div class="form-group">
               <label for="exampleInputEmail1"><span class="mandatory">*</span> Company Phone</label>
               <input type="number" class="form-control" id="company_phone" name="company_phone"   value="<?=set_value('company_phone')?>" placeholder="Company phone...">
            </div>
            <div class="form-group">
               <label for="exampleInputEmail1">Alternate phone</label>
               <input type="number" class="form-control" id="alternate_phone" name="alternate_phone"  value="<?=set_value('alternate_phone')?>" placeholder="Alternate phone...">
            </div>

             <div class="form-group">
               <label for="exampleInputEmail1">Company Address</label>
               <textarea class="form-control" id="company_address" name="company_address" place holder="Company address..."></textarea>
            </div>
            <div class="form-group">
               <label for="exampleInputEmail1"><span class="mandatory">*</span> Company password</label>
               <input type="password" class="form-control" id="company_password" name="company_password"  placeholder="Company password...">
            </div>

             <div class="form-group">
               <label for="exampleInputEmail1">Contact name</label>
               <input type="text" class="form-control" id="contact_name" name="contact_name"   value="<?=set_value('contact_name')?>" placeholder="Contact name...">
            </div>
            <div class="form-group">
               <label for="exampleInputEmail1">Contact phone</label>
               <input type="number" class="form-control" id="contact_phone" name="contact_phone"  value="<?=set_value('contact_phone')?>" placeholder="Contact phone...">
            </div>


 <div class="form-group">
               <label for="exampleInputEmail1">Contact Email</label>
               <input type="text" class="form-control" id="contact_email" name="contact_email"   value="<?=set_value('contact_email')?>" placeholder="Contact email...">
            </div>
            

          
            <div class="form-check-inline">
               <input class="form-check-input" type="radio" value="1" name="status" checked>
               <label class="form-check-label">Active</label>
            </div>
            <div class="form-check-inline">
               <input class="form-check-input" type="radio" value="0" name="status">
               <label class="form-check-label">Inactive</label>
            </div>
            <!-- /.card-body -->
     
    
      <div class="card-footer">
      <button type="submit" class="btn btn-primary">Submit</button>
      </div>
      </form>
     </div>
     </div>
     </div>
      <div class="col-md-6">
     <?php echo validation_errors(); ?>
         <?php
            if($this -> session -> flashdata('success')) {?>
         <div class="alert alert-info" role="alert">
            <?=$this -> session -> flashdata('success')?>
         </div>
         <?php } ?>
         <?php
            if($this -> session -> flashdata('error')) {?>
         <div class="alert alert-danger" role="alert">
            <?=$this -> session -> flashdata('error')?>
         </div>
         <?php } ?>
      </div>
    
     
     </div>
     </div>
    
</section>
</div>
<div class="content-wrapper">
<div class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
         </div>
         <!-- /.col -->
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <!-- <li><a href=""><i class="fa fa-tasks"></i> Manage Food truck</a></li>-->
            </ol>
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </div>
   <!-- /.container-fluid -->
</div>
    <!-- Main content -->
  <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
		  <?php 
		  if($this -> session -> flashdata('uploaderror')) {
				echo $this -> session -> flashdata('uploaderror');
		       }
		  ?>
             <?php if($this -> session -> flashdata('success')) {?>
                <div class="alert alert-info" role="alert">
                  <?=$this -> session -> flashdata('success')?>
                </div>

            <?php } ?>
			
			 <?php if($this -> session -> flashdata('error')) {?>
                <div class="alert alert-danger" role="alert">
                  <?=$this -> session -> flashdata('error')?>
                </div>

            <?php } ?>

          </div>
        </div>
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
          <div class="card">
              <div class="card-header">
                <h3 class="card-title">Add Chef </h3>

                <div class="card-tools">
                  <div class="input-group input-group-sm" style="width: 150px;">
                   
                  </div>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body  p-0">	
				<div class="row">
					<div class="col-sm-12">
					<form action="" method="post" autocomplete="off" enctype="multipart/form-data">
         <div class="row">
        
            <div class="col-sm-6">
            <div class="form-group">
               <label for="exampleInputEmail1">Chef Name</label>
               <input type="text" class="form-control" id="chef_name" name="chef_name" value="<?=set_value('chef_name')?>" placeholder="Enter chef name">
            </div>
            </div>
			
			 <div class="col-sm-6">
             <div class="form-group">
               <label for="exampleInputEmail1">Upload Chef Image</label>
               <input type="file" class="form-control" id="file" name="files[]"   />
            </div>
            </div>
            </div>
           
            <div class="row">
          
            <div class="col-sm-6">
            <div class="form-group">
               <label for="exampleInputEmail1">Detail</label>
               <textarea  class="form-control" id="chef_detail"  placeholder="Detail..." name="chef_detail"> <?=set_value('detail')?>  </textarea>
            </div>
              </div>
              </div>

      
            <!-- /.card-body -->
      </div>
    
      <div class="card-footer">
      <button type="submit" class="btn btn-primary">Submit</button>
      </div>
      </form>
					</div>
			   </div>
			   
             
			</div>
   


              </div>
              <!-- /.card-body -->
            </div>

          </div>      
              </div>
           
     
    </section>
  </div>
  <script>
  $(function(){
	  $("#save-btn").click(function(){
		   var inp = document.getElementById('upload');
		  if (inp.files.length == 0){
			  alert("Select menu image...");
			  return false;
		  }
		  $("#form").submit();
	  });
  });
  </script>
  
 
<div class="content-wrapper">
<div class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
         </div>
         <!-- /.col -->
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li><a href="<?=base_url('administrator/Foodtruck')?>"><i class="fa fa-list"></i> Manage Food Truck</a></li>
            </ol>
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </div>
   <!-- /.container-fluid -->
</div>
    <!-- Main content -->
  <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
             <?php if($this -> session -> flashdata('success')) {?>
                <div class="alert alert-info" role="alert">
                  <?=$this -> session -> flashdata('success')?>
                </div>

            <?php } ?>

          </div>
        </div>
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
          <div class="card">
              <div class="card-header">
                <h3 class="card-title">Owner Detail View</h3>

              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0">
                <table class="table">
                
                  <tbody>
					 <tr>
                      <th>Truck Name</th>
					  <td><?=$u['truck_name']?></td>
					 </tr>
					 
                    <tr>
                      <th>Owner name</th>
					  <td><?=$u['first_name'].' '.$u['last_name']?></td>
					</tr>
					
					
					 
					 <tr>
                      
					  <td colspan="2"><a  href="<?=base_url('administrator/Foodtruck/schedule?truck_owner='.$u['uid'])?>"><i class="fa fa-plus"></i> Schedule</a></td>
					 </tr>
					 
					  <tr>
                      
					  <td colspan="2"><a href="<?=base_url('administrator/Foodtruck/menu?truck_owner='.$u['uid'])?>"><i class="fa fa-plus"></i> Menu</a></td>
					 </tr>
					 
					  <tr>
                      
					  <td colspan="2"><a href="<?=base_url('administrator/Foodtruck/chef?truck_owner='.$u['uid'])?>"><i class="fa fa-plus"></i> Chef</a></td>
					 </tr>
					 
					 
									
				
					            
                  </tbody>
                </table>
			
				
              </div>
              <!-- /.card-body -->
            </div>

          </div>


       
 
          
              </div>
           
      </div>
    </section>
  </div>
 
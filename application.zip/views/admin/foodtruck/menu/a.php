 <div class="content-wrapper">
<div class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
         </div>
         <!-- /.col -->
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li><a href="<?=base_url('administrator/Foodtruck/manage/'.$u['uid'])?>"><i class="fa fa-tasks"></i> Manage Food truck</a></li>
            </ol>
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </div>
   <!-- /.container-fluid -->
</div>
    <!-- Main content -->
  <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
             <?php if($this -> session -> flashdata('success')) {?>
                <div class="alert alert-info" role="alert">
                  <?=$this -> session -> flashdata('success')?>
                </div>

            <?php } ?>

          </div>
        </div>
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
          <div class="card">
              <div class="card-header">
                <h3 class="card-title">Add Food Menu</h3>

                <div class="card-tools">
                  <div class="input-group input-group-sm" style="width: 150px;">
                    <button class="btn btn-primary" id="save-btn">Publish</button>
                  </div>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body  p-0">	
				<div class="row">
					<div class="col-sm-12">
					 <form method="post" enctype="multipart/form-data">
						  <div class="from-group">
						    <input type="file" name="files[]" mutiple />
						  </div>
					  </form>
					</div>
			   </div>
			   
               <div class="row">
				<div class="col-sm-3">
				  
				</div>
			   </div>
			</div>
   
</td>
		 <td>  
			<input type="text" name="location" id="<?php echo 'loc_'.$k?>" class="form-control location" placeholder="location" />
		</td>

                                                               
                                                              

                                                            </tr>
												
                                                  
                                                        </tbody>
                                                    </table>
              </div>
              <!-- /.card-body -->
            </div>

          </div>


       
 
          
              </div>
           
      </div>
    </section>
  </div>
 
<div class="content-wrapper">
<div class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
         </div>
         <!-- /.col -->
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li><a href="<?=base_url('administrator/Foodtruck/manage/'.$u['uid'])?>"><i class="fa fa-tasks"></i> Manage Food truck</a></li>
            </ol>
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </div>
   <!-- /.container-fluid -->
</div>
    <!-- Main content -->
  <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
		  <?php 
		  if($this -> session -> flashdata('uploaderror')) {
				echo $this -> session -> flashdata('uploaderror');
		       }
		  ?>
             <?php if($this -> session -> flashdata('success')) {?>
                <div class="alert alert-info" role="alert">
                  <?=$this -> session -> flashdata('success')?>
                </div>

            <?php } ?>
			
			 <?php if($this -> session -> flashdata('error')) {?>
                <div class="alert alert-danger" role="alert">
                  <?=$this -> session -> flashdata('error')?>
                </div>

            <?php } ?>

          </div>
        </div>
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
          <div class="card">
              <div class="card-header">
                <h3 class="card-title">Add Food Menu</h3>

                <div class="card-tools">
                  <div class="input-group input-group-sm" style="width: 150px;">
                    <button class="btn btn-primary" id="save-btn">Publish</button>
                  </div>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body  p-0">	
				<div class="row">
					<div class="col-sm-12">
					 <form id="form" method="post" enctype="multipart/form-data">
						  <div class="from-group">
						    <input type="file" name="files[]" id="upload" multiple />
						  </div>
					  </form>
					</div>
			   </div>
			   
               <div class="row">
				<div class="col-sm-12">
				<br /> <br />
				  <?php
				    if (count($menu_images)){
						foreach ($menu_images as $row) { ?>
							<img src="<?=base_url('uploads/menu_images/'.$row['images'])?>" alt="" style="width:120px;height:120px;" />
							
					<?php
						}
					}
					else {
						echo '<p class="text-center" style="color:red;">No menu found!</p>';
					}
					?>
				</div>
			   </div>
			</div>
   


              </div>
              <!-- /.card-body -->
            </div>

          </div>      
              </div>
           
     
    </section>
  </div>
  <script>
  $(function(){
	  $("#save-btn").click(function(){
		   var inp = document.getElementById('upload');
		  if (inp.files.length == 0){
			  alert("Select menu image...");
			  return false;
		  }
		  $("#form").submit();
	  });
  });
  </script>
  
 
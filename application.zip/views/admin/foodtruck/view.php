<div class="content-wrapper">
<div class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
         </div>
         <!-- /.col -->
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li><a href="<?=base_url('administrator/Foodtruck')?>"><i class="fa fa-list"></i> List Truck</a></li>
            </ol>
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </div>
   <!-- /.container-fluid -->
</div>
    <!-- Main content -->
  <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
             <?php if($this -> session -> flashdata('success')) {?>
                <div class="alert alert-info" role="alert">
                  <?=$this -> session -> flashdata('success')?>
                </div>

            <?php } ?>

          </div>
        </div>
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
          <div class="card">
              <div class="card-header">
                <h3 class="card-title">Food Truck Detail View</h3>

              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0">
                <table class="table">
                
                  <tbody>
                
                    <tr>
                      <th>Owner name</th>
					  <td><?=$u['first_name'].' '.$u['last_name']?></td>
					</tr>
					
					 <tr>
                      <th>Truck Name</th>
					  <td><?=$u['truck_name']?></td>
					 </tr>
					 
					 <tr>
                      <th>Email ID</th>
					  <td><?=$u['email']?></td>
					 </tr>
					 
					  <tr>
                      <th>Contact</th>
					  <td><?=$u['mobile']?></td>
					 </tr>
					 
					  <tr>
                      <th>Facebook</th>
					  <td><?=$u['facebook']?></td>
					 </tr>
					 
					  <tr>
                      <th>Twitter</th>
					  <td><?=$u['twitter']?></td>
					 </tr>
					 
					  <tr>
                      <th>LinkedIn</th>
					  <td><?=$u['linkedin']?></td>
					 </tr>
					 
					  <tr>
                      <th>Website</th>
					  <td><?=$u['website']?></td>
					 </tr>
					
					
					
					
					 <tr>
                      <th>Created</th>
					  <td><?=date('j-M-y',strtotime($u['created_at']))?></td>
					 </tr>
					 
					  <tr>
                      <th>Updated</th>
					  <td><?=date('j-M-y',strtotime($u['updated_at']))?></td>
					 </tr>
					 
					 <tr>
                      <th>Truck Images</th>
					  <td>
					  <div id="image-block"></div>
					  </td>
					 </tr>
					
					            
                  </tbody>
                </table>
			
				
              </div>
              <!-- /.card-body -->
            </div>

          </div>


       
 
          
              </div>
           
      </div>
    </section>
  </div>
  <script>
  $(function(){
    var uid = '<?=$u['uid']?>';
    get_all_truck_image(uid);
  });
 
   function get_all_truck_image(uid) {


      $.ajax({
          url:"<?=base_url('administrator/Foodtruck/get_all_truck_image_ajax')?>",
          type:"post",
          data:{uid:uid}
      }).done(function(response){
		var data = JSON.parse(response);
		var imagePath = '<?=base_url("uploads/truck_images/")?>';
		html = "";
		if (data.length){
			for (var i=0; i <  data.length; i++){
				html += '<div style="padding:10px;display:inline;"><img  src="'+imagePath+data[i].image+'" alt="" width="100" height="100" /></div>';
			
		}
		}
		
		$("#image-block").html(html);

      }).catch(function(error){
          console.log(error);
      });
}
 
  </script>
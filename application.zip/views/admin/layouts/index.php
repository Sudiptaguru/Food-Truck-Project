<?php

$this->load->view('admin/layouts/header');
$this->load->view('admin/layouts/sidebar');
$this->load->view($content);
$this->load->view('admin/layouts/footer');

?>